"""Training-fitted preparation for explicitly frozen pool partitions.

The historical normalise.clean/split path is unchanged. This version accepts
features only and never selects rows or learns a vocabulary from evaluation data.
"""

from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.preprocessing import OneHotEncoder, StandardScaler

PARTITIONS = ("train", "validation", "test")
CATEGORY_CAP = 20
MAX_MISSING_SHARE = 0.5


from mutmut.mutation.trampoline import wrap_in_trampoline as _mutmut_mutated, MutantDict
mutants_x_validate_partitions__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_validate_partitions__mutmut)
def validate_partitions(partitions: dict, rows: int) -> None:
    """Require a complete ordered assignment; never invent or repair positions."""
    if set(partitions) != set(PARTITIONS):
        raise ValueError("partitions must contain train, validation and test")
    positions = []
    for name in PARTITIONS:
        values = partitions[name]
        if not isinstance(values, list) or not values:
            raise ValueError("each partition must be a nonempty position list")
        if any(type(value) is not int or not 0 <= value < rows for value in values):
            raise ValueError("partition positions must be in-range integers")
        positions.extend(values)
    if len(positions) != rows or len(set(positions)) != rows:
        raise ValueError("partitions must cover every row exactly once without overlap")


def x_validate_partitions__mutmut_orig(partitions: dict, rows: int) -> None:
    """Require a complete ordered assignment; never invent or repair positions."""
    if set(partitions) != set(PARTITIONS):
        raise ValueError("partitions must contain train, validation and test")
    positions = []
    for name in PARTITIONS:
        values = partitions[name]
        if not isinstance(values, list) or not values:
            raise ValueError("each partition must be a nonempty position list")
        if any(type(value) is not int or not 0 <= value < rows for value in values):
            raise ValueError("partition positions must be in-range integers")
        positions.extend(values)
    if len(positions) != rows or len(set(positions)) != rows:
        raise ValueError("partitions must cover every row exactly once without overlap")


def x_validate_partitions__mutmut_1(partitions: dict, rows: int) -> None:
    """Require a complete ordered assignment; never invent or repair positions."""
    if set(None) != set(PARTITIONS):
        raise ValueError("partitions must contain train, validation and test")
    positions = []
    for name in PARTITIONS:
        values = partitions[name]
        if not isinstance(values, list) or not values:
            raise ValueError("each partition must be a nonempty position list")
        if any(type(value) is not int or not 0 <= value < rows for value in values):
            raise ValueError("partition positions must be in-range integers")
        positions.extend(values)
    if len(positions) != rows or len(set(positions)) != rows:
        raise ValueError("partitions must cover every row exactly once without overlap")


def x_validate_partitions__mutmut_2(partitions: dict, rows: int) -> None:
    """Require a complete ordered assignment; never invent or repair positions."""
    if set(partitions) == set(PARTITIONS):
        raise ValueError("partitions must contain train, validation and test")
    positions = []
    for name in PARTITIONS:
        values = partitions[name]
        if not isinstance(values, list) or not values:
            raise ValueError("each partition must be a nonempty position list")
        if any(type(value) is not int or not 0 <= value < rows for value in values):
            raise ValueError("partition positions must be in-range integers")
        positions.extend(values)
    if len(positions) != rows or len(set(positions)) != rows:
        raise ValueError("partitions must cover every row exactly once without overlap")


def x_validate_partitions__mutmut_3(partitions: dict, rows: int) -> None:
    """Require a complete ordered assignment; never invent or repair positions."""
    if set(partitions) != set(None):
        raise ValueError("partitions must contain train, validation and test")
    positions = []
    for name in PARTITIONS:
        values = partitions[name]
        if not isinstance(values, list) or not values:
            raise ValueError("each partition must be a nonempty position list")
        if any(type(value) is not int or not 0 <= value < rows for value in values):
            raise ValueError("partition positions must be in-range integers")
        positions.extend(values)
    if len(positions) != rows or len(set(positions)) != rows:
        raise ValueError("partitions must cover every row exactly once without overlap")


def x_validate_partitions__mutmut_4(partitions: dict, rows: int) -> None:
    """Require a complete ordered assignment; never invent or repair positions."""
    if set(partitions) != set(PARTITIONS):
        raise ValueError(None)
    positions = []
    for name in PARTITIONS:
        values = partitions[name]
        if not isinstance(values, list) or not values:
            raise ValueError("each partition must be a nonempty position list")
        if any(type(value) is not int or not 0 <= value < rows for value in values):
            raise ValueError("partition positions must be in-range integers")
        positions.extend(values)
    if len(positions) != rows or len(set(positions)) != rows:
        raise ValueError("partitions must cover every row exactly once without overlap")


def x_validate_partitions__mutmut_5(partitions: dict, rows: int) -> None:
    """Require a complete ordered assignment; never invent or repair positions."""
    if set(partitions) != set(PARTITIONS):
        raise ValueError("XXpartitions must contain train, validation and testXX")
    positions = []
    for name in PARTITIONS:
        values = partitions[name]
        if not isinstance(values, list) or not values:
            raise ValueError("each partition must be a nonempty position list")
        if any(type(value) is not int or not 0 <= value < rows for value in values):
            raise ValueError("partition positions must be in-range integers")
        positions.extend(values)
    if len(positions) != rows or len(set(positions)) != rows:
        raise ValueError("partitions must cover every row exactly once without overlap")


def x_validate_partitions__mutmut_6(partitions: dict, rows: int) -> None:
    """Require a complete ordered assignment; never invent or repair positions."""
    if set(partitions) != set(PARTITIONS):
        raise ValueError("PARTITIONS MUST CONTAIN TRAIN, VALIDATION AND TEST")
    positions = []
    for name in PARTITIONS:
        values = partitions[name]
        if not isinstance(values, list) or not values:
            raise ValueError("each partition must be a nonempty position list")
        if any(type(value) is not int or not 0 <= value < rows for value in values):
            raise ValueError("partition positions must be in-range integers")
        positions.extend(values)
    if len(positions) != rows or len(set(positions)) != rows:
        raise ValueError("partitions must cover every row exactly once without overlap")


def x_validate_partitions__mutmut_7(partitions: dict, rows: int) -> None:
    """Require a complete ordered assignment; never invent or repair positions."""
    if set(partitions) != set(PARTITIONS):
        raise ValueError("partitions must contain train, validation and test")
    positions = None
    for name in PARTITIONS:
        values = partitions[name]
        if not isinstance(values, list) or not values:
            raise ValueError("each partition must be a nonempty position list")
        if any(type(value) is not int or not 0 <= value < rows for value in values):
            raise ValueError("partition positions must be in-range integers")
        positions.extend(values)
    if len(positions) != rows or len(set(positions)) != rows:
        raise ValueError("partitions must cover every row exactly once without overlap")


def x_validate_partitions__mutmut_8(partitions: dict, rows: int) -> None:
    """Require a complete ordered assignment; never invent or repair positions."""
    if set(partitions) != set(PARTITIONS):
        raise ValueError("partitions must contain train, validation and test")
    positions = []
    for name in PARTITIONS:
        values = None
        if not isinstance(values, list) or not values:
            raise ValueError("each partition must be a nonempty position list")
        if any(type(value) is not int or not 0 <= value < rows for value in values):
            raise ValueError("partition positions must be in-range integers")
        positions.extend(values)
    if len(positions) != rows or len(set(positions)) != rows:
        raise ValueError("partitions must cover every row exactly once without overlap")


def x_validate_partitions__mutmut_9(partitions: dict, rows: int) -> None:
    """Require a complete ordered assignment; never invent or repair positions."""
    if set(partitions) != set(PARTITIONS):
        raise ValueError("partitions must contain train, validation and test")
    positions = []
    for name in PARTITIONS:
        values = partitions[name]
        if not isinstance(values, list) and not values:
            raise ValueError("each partition must be a nonempty position list")
        if any(type(value) is not int or not 0 <= value < rows for value in values):
            raise ValueError("partition positions must be in-range integers")
        positions.extend(values)
    if len(positions) != rows or len(set(positions)) != rows:
        raise ValueError("partitions must cover every row exactly once without overlap")


def x_validate_partitions__mutmut_10(partitions: dict, rows: int) -> None:
    """Require a complete ordered assignment; never invent or repair positions."""
    if set(partitions) != set(PARTITIONS):
        raise ValueError("partitions must contain train, validation and test")
    positions = []
    for name in PARTITIONS:
        values = partitions[name]
        if isinstance(values, list) or not values:
            raise ValueError("each partition must be a nonempty position list")
        if any(type(value) is not int or not 0 <= value < rows for value in values):
            raise ValueError("partition positions must be in-range integers")
        positions.extend(values)
    if len(positions) != rows or len(set(positions)) != rows:
        raise ValueError("partitions must cover every row exactly once without overlap")


def x_validate_partitions__mutmut_11(partitions: dict, rows: int) -> None:
    """Require a complete ordered assignment; never invent or repair positions."""
    if set(partitions) != set(PARTITIONS):
        raise ValueError("partitions must contain train, validation and test")
    positions = []
    for name in PARTITIONS:
        values = partitions[name]
        if not isinstance(values, list) or values:
            raise ValueError("each partition must be a nonempty position list")
        if any(type(value) is not int or not 0 <= value < rows for value in values):
            raise ValueError("partition positions must be in-range integers")
        positions.extend(values)
    if len(positions) != rows or len(set(positions)) != rows:
        raise ValueError("partitions must cover every row exactly once without overlap")


def x_validate_partitions__mutmut_12(partitions: dict, rows: int) -> None:
    """Require a complete ordered assignment; never invent or repair positions."""
    if set(partitions) != set(PARTITIONS):
        raise ValueError("partitions must contain train, validation and test")
    positions = []
    for name in PARTITIONS:
        values = partitions[name]
        if not isinstance(values, list) or not values:
            raise ValueError(None)
        if any(type(value) is not int or not 0 <= value < rows for value in values):
            raise ValueError("partition positions must be in-range integers")
        positions.extend(values)
    if len(positions) != rows or len(set(positions)) != rows:
        raise ValueError("partitions must cover every row exactly once without overlap")


def x_validate_partitions__mutmut_13(partitions: dict, rows: int) -> None:
    """Require a complete ordered assignment; never invent or repair positions."""
    if set(partitions) != set(PARTITIONS):
        raise ValueError("partitions must contain train, validation and test")
    positions = []
    for name in PARTITIONS:
        values = partitions[name]
        if not isinstance(values, list) or not values:
            raise ValueError("XXeach partition must be a nonempty position listXX")
        if any(type(value) is not int or not 0 <= value < rows for value in values):
            raise ValueError("partition positions must be in-range integers")
        positions.extend(values)
    if len(positions) != rows or len(set(positions)) != rows:
        raise ValueError("partitions must cover every row exactly once without overlap")


def x_validate_partitions__mutmut_14(partitions: dict, rows: int) -> None:
    """Require a complete ordered assignment; never invent or repair positions."""
    if set(partitions) != set(PARTITIONS):
        raise ValueError("partitions must contain train, validation and test")
    positions = []
    for name in PARTITIONS:
        values = partitions[name]
        if not isinstance(values, list) or not values:
            raise ValueError("EACH PARTITION MUST BE A NONEMPTY POSITION LIST")
        if any(type(value) is not int or not 0 <= value < rows for value in values):
            raise ValueError("partition positions must be in-range integers")
        positions.extend(values)
    if len(positions) != rows or len(set(positions)) != rows:
        raise ValueError("partitions must cover every row exactly once without overlap")


def x_validate_partitions__mutmut_15(partitions: dict, rows: int) -> None:
    """Require a complete ordered assignment; never invent or repair positions."""
    if set(partitions) != set(PARTITIONS):
        raise ValueError("partitions must contain train, validation and test")
    positions = []
    for name in PARTITIONS:
        values = partitions[name]
        if not isinstance(values, list) or not values:
            raise ValueError("each partition must be a nonempty position list")
        if any(None):
            raise ValueError("partition positions must be in-range integers")
        positions.extend(values)
    if len(positions) != rows or len(set(positions)) != rows:
        raise ValueError("partitions must cover every row exactly once without overlap")


def x_validate_partitions__mutmut_16(partitions: dict, rows: int) -> None:
    """Require a complete ordered assignment; never invent or repair positions."""
    if set(partitions) != set(PARTITIONS):
        raise ValueError("partitions must contain train, validation and test")
    positions = []
    for name in PARTITIONS:
        values = partitions[name]
        if not isinstance(values, list) or not values:
            raise ValueError("each partition must be a nonempty position list")
        if any(type(value) is not int and not 0 <= value < rows for value in values):
            raise ValueError("partition positions must be in-range integers")
        positions.extend(values)
    if len(positions) != rows or len(set(positions)) != rows:
        raise ValueError("partitions must cover every row exactly once without overlap")


def x_validate_partitions__mutmut_17(partitions: dict, rows: int) -> None:
    """Require a complete ordered assignment; never invent or repair positions."""
    if set(partitions) != set(PARTITIONS):
        raise ValueError("partitions must contain train, validation and test")
    positions = []
    for name in PARTITIONS:
        values = partitions[name]
        if not isinstance(values, list) or not values:
            raise ValueError("each partition must be a nonempty position list")
        if any(type(None) is not int or not 0 <= value < rows for value in values):
            raise ValueError("partition positions must be in-range integers")
        positions.extend(values)
    if len(positions) != rows or len(set(positions)) != rows:
        raise ValueError("partitions must cover every row exactly once without overlap")


def x_validate_partitions__mutmut_18(partitions: dict, rows: int) -> None:
    """Require a complete ordered assignment; never invent or repair positions."""
    if set(partitions) != set(PARTITIONS):
        raise ValueError("partitions must contain train, validation and test")
    positions = []
    for name in PARTITIONS:
        values = partitions[name]
        if not isinstance(values, list) or not values:
            raise ValueError("each partition must be a nonempty position list")
        if any(type(value) is int or not 0 <= value < rows for value in values):
            raise ValueError("partition positions must be in-range integers")
        positions.extend(values)
    if len(positions) != rows or len(set(positions)) != rows:
        raise ValueError("partitions must cover every row exactly once without overlap")


def x_validate_partitions__mutmut_19(partitions: dict, rows: int) -> None:
    """Require a complete ordered assignment; never invent or repair positions."""
    if set(partitions) != set(PARTITIONS):
        raise ValueError("partitions must contain train, validation and test")
    positions = []
    for name in PARTITIONS:
        values = partitions[name]
        if not isinstance(values, list) or not values:
            raise ValueError("each partition must be a nonempty position list")
        if any(type(value) is not int or 0 <= value < rows for value in values):
            raise ValueError("partition positions must be in-range integers")
        positions.extend(values)
    if len(positions) != rows or len(set(positions)) != rows:
        raise ValueError("partitions must cover every row exactly once without overlap")


def x_validate_partitions__mutmut_20(partitions: dict, rows: int) -> None:
    """Require a complete ordered assignment; never invent or repair positions."""
    if set(partitions) != set(PARTITIONS):
        raise ValueError("partitions must contain train, validation and test")
    positions = []
    for name in PARTITIONS:
        values = partitions[name]
        if not isinstance(values, list) or not values:
            raise ValueError("each partition must be a nonempty position list")
        if any(type(value) is not int or not 1 <= value < rows for value in values):
            raise ValueError("partition positions must be in-range integers")
        positions.extend(values)
    if len(positions) != rows or len(set(positions)) != rows:
        raise ValueError("partitions must cover every row exactly once without overlap")


def x_validate_partitions__mutmut_21(partitions: dict, rows: int) -> None:
    """Require a complete ordered assignment; never invent or repair positions."""
    if set(partitions) != set(PARTITIONS):
        raise ValueError("partitions must contain train, validation and test")
    positions = []
    for name in PARTITIONS:
        values = partitions[name]
        if not isinstance(values, list) or not values:
            raise ValueError("each partition must be a nonempty position list")
        if any(type(value) is not int or not 0 < value < rows for value in values):
            raise ValueError("partition positions must be in-range integers")
        positions.extend(values)
    if len(positions) != rows or len(set(positions)) != rows:
        raise ValueError("partitions must cover every row exactly once without overlap")


def x_validate_partitions__mutmut_22(partitions: dict, rows: int) -> None:
    """Require a complete ordered assignment; never invent or repair positions."""
    if set(partitions) != set(PARTITIONS):
        raise ValueError("partitions must contain train, validation and test")
    positions = []
    for name in PARTITIONS:
        values = partitions[name]
        if not isinstance(values, list) or not values:
            raise ValueError("each partition must be a nonempty position list")
        if any(type(value) is not int or not 0 <= value <= rows for value in values):
            raise ValueError("partition positions must be in-range integers")
        positions.extend(values)
    if len(positions) != rows or len(set(positions)) != rows:
        raise ValueError("partitions must cover every row exactly once without overlap")


def x_validate_partitions__mutmut_23(partitions: dict, rows: int) -> None:
    """Require a complete ordered assignment; never invent or repair positions."""
    if set(partitions) != set(PARTITIONS):
        raise ValueError("partitions must contain train, validation and test")
    positions = []
    for name in PARTITIONS:
        values = partitions[name]
        if not isinstance(values, list) or not values:
            raise ValueError("each partition must be a nonempty position list")
        if any(type(value) is not int or not 0 <= value < rows for value in values):
            raise ValueError(None)
        positions.extend(values)
    if len(positions) != rows or len(set(positions)) != rows:
        raise ValueError("partitions must cover every row exactly once without overlap")


def x_validate_partitions__mutmut_24(partitions: dict, rows: int) -> None:
    """Require a complete ordered assignment; never invent or repair positions."""
    if set(partitions) != set(PARTITIONS):
        raise ValueError("partitions must contain train, validation and test")
    positions = []
    for name in PARTITIONS:
        values = partitions[name]
        if not isinstance(values, list) or not values:
            raise ValueError("each partition must be a nonempty position list")
        if any(type(value) is not int or not 0 <= value < rows for value in values):
            raise ValueError("XXpartition positions must be in-range integersXX")
        positions.extend(values)
    if len(positions) != rows or len(set(positions)) != rows:
        raise ValueError("partitions must cover every row exactly once without overlap")


def x_validate_partitions__mutmut_25(partitions: dict, rows: int) -> None:
    """Require a complete ordered assignment; never invent or repair positions."""
    if set(partitions) != set(PARTITIONS):
        raise ValueError("partitions must contain train, validation and test")
    positions = []
    for name in PARTITIONS:
        values = partitions[name]
        if not isinstance(values, list) or not values:
            raise ValueError("each partition must be a nonempty position list")
        if any(type(value) is not int or not 0 <= value < rows for value in values):
            raise ValueError("PARTITION POSITIONS MUST BE IN-RANGE INTEGERS")
        positions.extend(values)
    if len(positions) != rows or len(set(positions)) != rows:
        raise ValueError("partitions must cover every row exactly once without overlap")


def x_validate_partitions__mutmut_26(partitions: dict, rows: int) -> None:
    """Require a complete ordered assignment; never invent or repair positions."""
    if set(partitions) != set(PARTITIONS):
        raise ValueError("partitions must contain train, validation and test")
    positions = []
    for name in PARTITIONS:
        values = partitions[name]
        if not isinstance(values, list) or not values:
            raise ValueError("each partition must be a nonempty position list")
        if any(type(value) is not int or not 0 <= value < rows for value in values):
            raise ValueError("partition positions must be in-range integers")
        positions.extend(None)
    if len(positions) != rows or len(set(positions)) != rows:
        raise ValueError("partitions must cover every row exactly once without overlap")


def x_validate_partitions__mutmut_27(partitions: dict, rows: int) -> None:
    """Require a complete ordered assignment; never invent or repair positions."""
    if set(partitions) != set(PARTITIONS):
        raise ValueError("partitions must contain train, validation and test")
    positions = []
    for name in PARTITIONS:
        values = partitions[name]
        if not isinstance(values, list) or not values:
            raise ValueError("each partition must be a nonempty position list")
        if any(type(value) is not int or not 0 <= value < rows for value in values):
            raise ValueError("partition positions must be in-range integers")
        positions.extend(values)
    if len(positions) != rows and len(set(positions)) != rows:
        raise ValueError("partitions must cover every row exactly once without overlap")


def x_validate_partitions__mutmut_28(partitions: dict, rows: int) -> None:
    """Require a complete ordered assignment; never invent or repair positions."""
    if set(partitions) != set(PARTITIONS):
        raise ValueError("partitions must contain train, validation and test")
    positions = []
    for name in PARTITIONS:
        values = partitions[name]
        if not isinstance(values, list) or not values:
            raise ValueError("each partition must be a nonempty position list")
        if any(type(value) is not int or not 0 <= value < rows for value in values):
            raise ValueError("partition positions must be in-range integers")
        positions.extend(values)
    if len(positions) == rows or len(set(positions)) != rows:
        raise ValueError("partitions must cover every row exactly once without overlap")


def x_validate_partitions__mutmut_29(partitions: dict, rows: int) -> None:
    """Require a complete ordered assignment; never invent or repair positions."""
    if set(partitions) != set(PARTITIONS):
        raise ValueError("partitions must contain train, validation and test")
    positions = []
    for name in PARTITIONS:
        values = partitions[name]
        if not isinstance(values, list) or not values:
            raise ValueError("each partition must be a nonempty position list")
        if any(type(value) is not int or not 0 <= value < rows for value in values):
            raise ValueError("partition positions must be in-range integers")
        positions.extend(values)
    if len(positions) != rows or len(set(positions)) == rows:
        raise ValueError("partitions must cover every row exactly once without overlap")


def x_validate_partitions__mutmut_30(partitions: dict, rows: int) -> None:
    """Require a complete ordered assignment; never invent or repair positions."""
    if set(partitions) != set(PARTITIONS):
        raise ValueError("partitions must contain train, validation and test")
    positions = []
    for name in PARTITIONS:
        values = partitions[name]
        if not isinstance(values, list) or not values:
            raise ValueError("each partition must be a nonempty position list")
        if any(type(value) is not int or not 0 <= value < rows for value in values):
            raise ValueError("partition positions must be in-range integers")
        positions.extend(values)
    if len(positions) != rows or len(set(positions)) != rows:
        raise ValueError(None)


def x_validate_partitions__mutmut_31(partitions: dict, rows: int) -> None:
    """Require a complete ordered assignment; never invent or repair positions."""
    if set(partitions) != set(PARTITIONS):
        raise ValueError("partitions must contain train, validation and test")
    positions = []
    for name in PARTITIONS:
        values = partitions[name]
        if not isinstance(values, list) or not values:
            raise ValueError("each partition must be a nonempty position list")
        if any(type(value) is not int or not 0 <= value < rows for value in values):
            raise ValueError("partition positions must be in-range integers")
        positions.extend(values)
    if len(positions) != rows or len(set(positions)) != rows:
        raise ValueError("XXpartitions must cover every row exactly once without overlapXX")


def x_validate_partitions__mutmut_32(partitions: dict, rows: int) -> None:
    """Require a complete ordered assignment; never invent or repair positions."""
    if set(partitions) != set(PARTITIONS):
        raise ValueError("partitions must contain train, validation and test")
    positions = []
    for name in PARTITIONS:
        values = partitions[name]
        if not isinstance(values, list) or not values:
            raise ValueError("each partition must be a nonempty position list")
        if any(type(value) is not int or not 0 <= value < rows for value in values):
            raise ValueError("partition positions must be in-range integers")
        positions.extend(values)
    if len(positions) != rows or len(set(positions)) != rows:
        raise ValueError("PARTITIONS MUST COVER EVERY ROW EXACTLY ONCE WITHOUT OVERLAP")

mutants_x_validate_partitions__mutmut['_mutmut_orig'] = x_validate_partitions__mutmut_orig # type: ignore # mutmut generated
mutants_x_validate_partitions__mutmut['x_validate_partitions__mutmut_1'] = x_validate_partitions__mutmut_1 # type: ignore # mutmut generated
mutants_x_validate_partitions__mutmut['x_validate_partitions__mutmut_2'] = x_validate_partitions__mutmut_2 # type: ignore # mutmut generated
mutants_x_validate_partitions__mutmut['x_validate_partitions__mutmut_3'] = x_validate_partitions__mutmut_3 # type: ignore # mutmut generated
mutants_x_validate_partitions__mutmut['x_validate_partitions__mutmut_4'] = x_validate_partitions__mutmut_4 # type: ignore # mutmut generated
mutants_x_validate_partitions__mutmut['x_validate_partitions__mutmut_5'] = x_validate_partitions__mutmut_5 # type: ignore # mutmut generated
mutants_x_validate_partitions__mutmut['x_validate_partitions__mutmut_6'] = x_validate_partitions__mutmut_6 # type: ignore # mutmut generated
mutants_x_validate_partitions__mutmut['x_validate_partitions__mutmut_7'] = x_validate_partitions__mutmut_7 # type: ignore # mutmut generated
mutants_x_validate_partitions__mutmut['x_validate_partitions__mutmut_8'] = x_validate_partitions__mutmut_8 # type: ignore # mutmut generated
mutants_x_validate_partitions__mutmut['x_validate_partitions__mutmut_9'] = x_validate_partitions__mutmut_9 # type: ignore # mutmut generated
mutants_x_validate_partitions__mutmut['x_validate_partitions__mutmut_10'] = x_validate_partitions__mutmut_10 # type: ignore # mutmut generated
mutants_x_validate_partitions__mutmut['x_validate_partitions__mutmut_11'] = x_validate_partitions__mutmut_11 # type: ignore # mutmut generated
mutants_x_validate_partitions__mutmut['x_validate_partitions__mutmut_12'] = x_validate_partitions__mutmut_12 # type: ignore # mutmut generated
mutants_x_validate_partitions__mutmut['x_validate_partitions__mutmut_13'] = x_validate_partitions__mutmut_13 # type: ignore # mutmut generated
mutants_x_validate_partitions__mutmut['x_validate_partitions__mutmut_14'] = x_validate_partitions__mutmut_14 # type: ignore # mutmut generated
mutants_x_validate_partitions__mutmut['x_validate_partitions__mutmut_15'] = x_validate_partitions__mutmut_15 # type: ignore # mutmut generated
mutants_x_validate_partitions__mutmut['x_validate_partitions__mutmut_16'] = x_validate_partitions__mutmut_16 # type: ignore # mutmut generated
mutants_x_validate_partitions__mutmut['x_validate_partitions__mutmut_17'] = x_validate_partitions__mutmut_17 # type: ignore # mutmut generated
mutants_x_validate_partitions__mutmut['x_validate_partitions__mutmut_18'] = x_validate_partitions__mutmut_18 # type: ignore # mutmut generated
mutants_x_validate_partitions__mutmut['x_validate_partitions__mutmut_19'] = x_validate_partitions__mutmut_19 # type: ignore # mutmut generated
mutants_x_validate_partitions__mutmut['x_validate_partitions__mutmut_20'] = x_validate_partitions__mutmut_20 # type: ignore # mutmut generated
mutants_x_validate_partitions__mutmut['x_validate_partitions__mutmut_21'] = x_validate_partitions__mutmut_21 # type: ignore # mutmut generated
mutants_x_validate_partitions__mutmut['x_validate_partitions__mutmut_22'] = x_validate_partitions__mutmut_22 # type: ignore # mutmut generated
mutants_x_validate_partitions__mutmut['x_validate_partitions__mutmut_23'] = x_validate_partitions__mutmut_23 # type: ignore # mutmut generated
mutants_x_validate_partitions__mutmut['x_validate_partitions__mutmut_24'] = x_validate_partitions__mutmut_24 # type: ignore # mutmut generated
mutants_x_validate_partitions__mutmut['x_validate_partitions__mutmut_25'] = x_validate_partitions__mutmut_25 # type: ignore # mutmut generated
mutants_x_validate_partitions__mutmut['x_validate_partitions__mutmut_26'] = x_validate_partitions__mutmut_26 # type: ignore # mutmut generated
mutants_x_validate_partitions__mutmut['x_validate_partitions__mutmut_27'] = x_validate_partitions__mutmut_27 # type: ignore # mutmut generated
mutants_x_validate_partitions__mutmut['x_validate_partitions__mutmut_28'] = x_validate_partitions__mutmut_28 # type: ignore # mutmut generated
mutants_x_validate_partitions__mutmut['x_validate_partitions__mutmut_29'] = x_validate_partitions__mutmut_29 # type: ignore # mutmut generated
mutants_x_validate_partitions__mutmut['x_validate_partitions__mutmut_30'] = x_validate_partitions__mutmut_30 # type: ignore # mutmut generated
mutants_x_validate_partitions__mutmut['x_validate_partitions__mutmut_31'] = x_validate_partitions__mutmut_31 # type: ignore # mutmut generated
mutants_x_validate_partitions__mutmut['x_validate_partitions__mutmut_32'] = x_validate_partitions__mutmut_32 # type: ignore # mutmut generated
mutants_x__categorical__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x__categorical__mutmut)
def _categorical(frame: pd.DataFrame, columns: list[str]) -> np.ndarray:
    return np.column_stack(
        [frame[name].astype("string").to_numpy(dtype=object, na_value=np.nan) for name in columns]
    )


def x__categorical__mutmut_orig(frame: pd.DataFrame, columns: list[str]) -> np.ndarray:
    return np.column_stack(
        [frame[name].astype("string").to_numpy(dtype=object, na_value=np.nan) for name in columns]
    )


def x__categorical__mutmut_1(frame: pd.DataFrame, columns: list[str]) -> np.ndarray:
    return np.column_stack(
        None
    )


def x__categorical__mutmut_2(frame: pd.DataFrame, columns: list[str]) -> np.ndarray:
    return np.column_stack(
        [frame[name].astype("string").to_numpy(dtype=None, na_value=np.nan) for name in columns]
    )


def x__categorical__mutmut_3(frame: pd.DataFrame, columns: list[str]) -> np.ndarray:
    return np.column_stack(
        [frame[name].astype("string").to_numpy(dtype=object, na_value=None) for name in columns]
    )


def x__categorical__mutmut_4(frame: pd.DataFrame, columns: list[str]) -> np.ndarray:
    return np.column_stack(
        [frame[name].astype("string").to_numpy(na_value=np.nan) for name in columns]
    )


def x__categorical__mutmut_5(frame: pd.DataFrame, columns: list[str]) -> np.ndarray:
    return np.column_stack(
        [frame[name].astype("string").to_numpy(dtype=object, ) for name in columns]
    )


def x__categorical__mutmut_6(frame: pd.DataFrame, columns: list[str]) -> np.ndarray:
    return np.column_stack(
        [frame[name].astype(None).to_numpy(dtype=object, na_value=np.nan) for name in columns]
    )


def x__categorical__mutmut_7(frame: pd.DataFrame, columns: list[str]) -> np.ndarray:
    return np.column_stack(
        [frame[name].astype("XXstringXX").to_numpy(dtype=object, na_value=np.nan) for name in columns]
    )


def x__categorical__mutmut_8(frame: pd.DataFrame, columns: list[str]) -> np.ndarray:
    return np.column_stack(
        [frame[name].astype("STRING").to_numpy(dtype=object, na_value=np.nan) for name in columns]
    )

mutants_x__categorical__mutmut['_mutmut_orig'] = x__categorical__mutmut_orig # type: ignore # mutmut generated
mutants_x__categorical__mutmut['x__categorical__mutmut_1'] = x__categorical__mutmut_1 # type: ignore # mutmut generated
mutants_x__categorical__mutmut['x__categorical__mutmut_2'] = x__categorical__mutmut_2 # type: ignore # mutmut generated
mutants_x__categorical__mutmut['x__categorical__mutmut_3'] = x__categorical__mutmut_3 # type: ignore # mutmut generated
mutants_x__categorical__mutmut['x__categorical__mutmut_4'] = x__categorical__mutmut_4 # type: ignore # mutmut generated
mutants_x__categorical__mutmut['x__categorical__mutmut_5'] = x__categorical__mutmut_5 # type: ignore # mutmut generated
mutants_x__categorical__mutmut['x__categorical__mutmut_6'] = x__categorical__mutmut_6 # type: ignore # mutmut generated
mutants_x__categorical__mutmut['x__categorical__mutmut_7'] = x__categorical__mutmut_7 # type: ignore # mutmut generated
mutants_x__categorical__mutmut['x__categorical__mutmut_8'] = x__categorical__mutmut_8 # type: ignore # mutmut generated
mutants_x__numeric__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x__numeric__mutmut)
def _numeric(frame: pd.DataFrame, columns: list[str]) -> np.ndarray:
    if not columns:
        return np.empty((len(frame), 0))
    values = frame[columns].apply(pd.to_numeric, errors="raise").to_numpy(dtype=float)
    if np.isinf(values).any():
        raise ValueError("numeric feature values must be finite or missing")
    return values


def x__numeric__mutmut_orig(frame: pd.DataFrame, columns: list[str]) -> np.ndarray:
    if not columns:
        return np.empty((len(frame), 0))
    values = frame[columns].apply(pd.to_numeric, errors="raise").to_numpy(dtype=float)
    if np.isinf(values).any():
        raise ValueError("numeric feature values must be finite or missing")
    return values


def x__numeric__mutmut_1(frame: pd.DataFrame, columns: list[str]) -> np.ndarray:
    if columns:
        return np.empty((len(frame), 0))
    values = frame[columns].apply(pd.to_numeric, errors="raise").to_numpy(dtype=float)
    if np.isinf(values).any():
        raise ValueError("numeric feature values must be finite or missing")
    return values


def x__numeric__mutmut_2(frame: pd.DataFrame, columns: list[str]) -> np.ndarray:
    if not columns:
        return np.empty(None)
    values = frame[columns].apply(pd.to_numeric, errors="raise").to_numpy(dtype=float)
    if np.isinf(values).any():
        raise ValueError("numeric feature values must be finite or missing")
    return values


def x__numeric__mutmut_3(frame: pd.DataFrame, columns: list[str]) -> np.ndarray:
    if not columns:
        return np.empty((len(frame), 1))
    values = frame[columns].apply(pd.to_numeric, errors="raise").to_numpy(dtype=float)
    if np.isinf(values).any():
        raise ValueError("numeric feature values must be finite or missing")
    return values


def x__numeric__mutmut_4(frame: pd.DataFrame, columns: list[str]) -> np.ndarray:
    if not columns:
        return np.empty((len(frame), 0))
    values = None
    if np.isinf(values).any():
        raise ValueError("numeric feature values must be finite or missing")
    return values


def x__numeric__mutmut_5(frame: pd.DataFrame, columns: list[str]) -> np.ndarray:
    if not columns:
        return np.empty((len(frame), 0))
    values = frame[columns].apply(pd.to_numeric, errors="raise").to_numpy(dtype=None)
    if np.isinf(values).any():
        raise ValueError("numeric feature values must be finite or missing")
    return values


def x__numeric__mutmut_6(frame: pd.DataFrame, columns: list[str]) -> np.ndarray:
    if not columns:
        return np.empty((len(frame), 0))
    values = frame[columns].apply(None, errors="raise").to_numpy(dtype=float)
    if np.isinf(values).any():
        raise ValueError("numeric feature values must be finite or missing")
    return values


def x__numeric__mutmut_7(frame: pd.DataFrame, columns: list[str]) -> np.ndarray:
    if not columns:
        return np.empty((len(frame), 0))
    values = frame[columns].apply(pd.to_numeric, errors=None).to_numpy(dtype=float)
    if np.isinf(values).any():
        raise ValueError("numeric feature values must be finite or missing")
    return values


def x__numeric__mutmut_8(frame: pd.DataFrame, columns: list[str]) -> np.ndarray:
    if not columns:
        return np.empty((len(frame), 0))
    values = frame[columns].apply(errors="raise").to_numpy(dtype=float)
    if np.isinf(values).any():
        raise ValueError("numeric feature values must be finite or missing")
    return values


def x__numeric__mutmut_9(frame: pd.DataFrame, columns: list[str]) -> np.ndarray:
    if not columns:
        return np.empty((len(frame), 0))
    values = frame[columns].apply(pd.to_numeric, ).to_numpy(dtype=float)
    if np.isinf(values).any():
        raise ValueError("numeric feature values must be finite or missing")
    return values


def x__numeric__mutmut_10(frame: pd.DataFrame, columns: list[str]) -> np.ndarray:
    if not columns:
        return np.empty((len(frame), 0))
    values = frame[columns].apply(pd.to_numeric, errors="XXraiseXX").to_numpy(dtype=float)
    if np.isinf(values).any():
        raise ValueError("numeric feature values must be finite or missing")
    return values


def x__numeric__mutmut_11(frame: pd.DataFrame, columns: list[str]) -> np.ndarray:
    if not columns:
        return np.empty((len(frame), 0))
    values = frame[columns].apply(pd.to_numeric, errors="RAISE").to_numpy(dtype=float)
    if np.isinf(values).any():
        raise ValueError("numeric feature values must be finite or missing")
    return values


def x__numeric__mutmut_12(frame: pd.DataFrame, columns: list[str]) -> np.ndarray:
    if not columns:
        return np.empty((len(frame), 0))
    values = frame[columns].apply(pd.to_numeric, errors="raise").to_numpy(dtype=float)
    if np.isinf(None).any():
        raise ValueError("numeric feature values must be finite or missing")
    return values


def x__numeric__mutmut_13(frame: pd.DataFrame, columns: list[str]) -> np.ndarray:
    if not columns:
        return np.empty((len(frame), 0))
    values = frame[columns].apply(pd.to_numeric, errors="raise").to_numpy(dtype=float)
    if np.isinf(values).any():
        raise ValueError(None)
    return values


def x__numeric__mutmut_14(frame: pd.DataFrame, columns: list[str]) -> np.ndarray:
    if not columns:
        return np.empty((len(frame), 0))
    values = frame[columns].apply(pd.to_numeric, errors="raise").to_numpy(dtype=float)
    if np.isinf(values).any():
        raise ValueError("XXnumeric feature values must be finite or missingXX")
    return values


def x__numeric__mutmut_15(frame: pd.DataFrame, columns: list[str]) -> np.ndarray:
    if not columns:
        return np.empty((len(frame), 0))
    values = frame[columns].apply(pd.to_numeric, errors="raise").to_numpy(dtype=float)
    if np.isinf(values).any():
        raise ValueError("NUMERIC FEATURE VALUES MUST BE FINITE OR MISSING")
    return values

mutants_x__numeric__mutmut['_mutmut_orig'] = x__numeric__mutmut_orig # type: ignore # mutmut generated
mutants_x__numeric__mutmut['x__numeric__mutmut_1'] = x__numeric__mutmut_1 # type: ignore # mutmut generated
mutants_x__numeric__mutmut['x__numeric__mutmut_2'] = x__numeric__mutmut_2 # type: ignore # mutmut generated
mutants_x__numeric__mutmut['x__numeric__mutmut_3'] = x__numeric__mutmut_3 # type: ignore # mutmut generated
mutants_x__numeric__mutmut['x__numeric__mutmut_4'] = x__numeric__mutmut_4 # type: ignore # mutmut generated
mutants_x__numeric__mutmut['x__numeric__mutmut_5'] = x__numeric__mutmut_5 # type: ignore # mutmut generated
mutants_x__numeric__mutmut['x__numeric__mutmut_6'] = x__numeric__mutmut_6 # type: ignore # mutmut generated
mutants_x__numeric__mutmut['x__numeric__mutmut_7'] = x__numeric__mutmut_7 # type: ignore # mutmut generated
mutants_x__numeric__mutmut['x__numeric__mutmut_8'] = x__numeric__mutmut_8 # type: ignore # mutmut generated
mutants_x__numeric__mutmut['x__numeric__mutmut_9'] = x__numeric__mutmut_9 # type: ignore # mutmut generated
mutants_x__numeric__mutmut['x__numeric__mutmut_10'] = x__numeric__mutmut_10 # type: ignore # mutmut generated
mutants_x__numeric__mutmut['x__numeric__mutmut_11'] = x__numeric__mutmut_11 # type: ignore # mutmut generated
mutants_x__numeric__mutmut['x__numeric__mutmut_12'] = x__numeric__mutmut_12 # type: ignore # mutmut generated
mutants_x__numeric__mutmut['x__numeric__mutmut_13'] = x__numeric__mutmut_13 # type: ignore # mutmut generated
mutants_x__numeric__mutmut['x__numeric__mutmut_14'] = x__numeric__mutmut_14 # type: ignore # mutmut generated
mutants_x__numeric__mutmut['x__numeric__mutmut_15'] = x__numeric__mutmut_15 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_prepare_frozen__mutmut)
def prepare_frozen(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_orig(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_1(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique and any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_2(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns) and not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_3(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_4(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_5(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(None)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_6(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_7(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError(None)
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_8(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("XXfeature columns must be nonempty, unique stringsXX")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_9(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("FEATURE COLUMNS MUST BE NONEMPTY, UNIQUE STRINGS")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_10(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(None, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_11(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, None)
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_12(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_13(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, )
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_14(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = None
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_15(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(None, dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_16(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=None)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_17(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_18(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), )
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_19(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(None):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_20(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = None
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_21(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = None
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_22(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(None, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_23(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=None).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_24(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_25(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, ).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_26(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=True).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_27(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = None
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_28(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby(None)["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_29(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame(None).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_30(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"XXkeyXX": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_31(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"KEY": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_32(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "XXfoldXX": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_33(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "FOLD": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_34(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("XXkeyXX")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_35(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("KEY")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_36(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["XXfoldXX"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_37(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["FOLD"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_38(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups >= 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_39(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 2).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_40(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError(None)

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_41(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("XXduplicate feature rows cross partitionsXX")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_42(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("DUPLICATE FEATURE ROWS CROSS PARTITIONS")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_43(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = None
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_44(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["XXtrainXX"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_45(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["TRAIN"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_46(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = None
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_47(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = None
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_48(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"XXmissingXX": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_49(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"MISSING": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_50(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "XXconstantXX": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_51(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "CONSTANT": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_52(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "XXcardinalityXX": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_53(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "CARDINALITY": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_54(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = None
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_55(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() >= MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_56(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(None)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_57(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["XXmissingXX"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_58(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["MISSING"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_59(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() < 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_60(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 2:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_61(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(None)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_62(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["XXconstantXX"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_63(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["CONSTANT"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_64(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = None
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_65(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(None, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_66(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors=None)
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_67(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_68(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, )
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_69(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="XXcoerceXX")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_70(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="COERCE")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_71(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted) or converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_72(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_73(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(None)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_74(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(None)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_75(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() >= CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_76(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(None)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_77(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["XXcardinalityXX"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_78(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["CARDINALITY"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_79(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(None)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_80(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric or not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_81(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_82(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_83(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError(None)

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_84(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("XXno usable training feature remainsXX")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_85(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("NO USABLE TRAINING FEATURE REMAINS")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_86(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = None
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_87(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(None, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_88(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, None)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_89(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_90(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, )
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_91(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = None
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_92(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if (numeric) and False else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_93(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if (numeric) or True else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_94(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(None, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_95(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=None) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_96(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_97(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, ) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_98(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=1) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_99(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(None)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_100(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(1)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_101(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = ""
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_102(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = None
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_103(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown=None, sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_104(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=None)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_105(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_106(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", )
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_107(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="XXignoreXX", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_108(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="IGNORE", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_109(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=True)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_110(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(None)

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_111(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(None, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_112(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, None))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_113(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_114(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, ))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_115(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = None
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_116(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(None, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_117(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, None)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_118(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_119(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, )
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_120(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = None
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_121(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(None, medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_122(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), None, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_123(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, None)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_124(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_125(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_126(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, )
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_127(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(None), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_128(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_129(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = None
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_130(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack(None)
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_131(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(None)])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_132(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(None, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_133(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, None))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_134(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_135(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, ))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_136(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = None
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_137(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(None)
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_138(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(None))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_139(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = None
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_140(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(None)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_141(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = None
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_142(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "XXinput_columnsXX": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_143(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "INPUT_COLUMNS": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_144(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "XXnumeric_columnsXX": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_145(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "NUMERIC_COLUMNS": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_146(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "XXcategorical_columnsXX": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_147(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "CATEGORICAL_COLUMNS": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_148(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "XXdroppedXX": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_149(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "DROPPED": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_150(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "XXmediansXX": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_151(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "MEDIANS": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_152(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "XXcategoriesXX": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_153(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "CATEGORIES": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_154(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if (encoder is not None) and False
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_155(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if (encoder is not None) or True
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_156(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if (pd.isna(value)) and False else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_157(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if (pd.isna(value)) or True else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_158(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(None) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_159(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(None) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_160(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_161(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "XXmeanXX": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_162(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "MEAN": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_163(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "XXscaleXX": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_164(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "SCALE": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_165(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "XXoutput_columnsXX": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_166(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "OUTPUT_COLUMNS": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_167(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "XXcategory_capXX": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_168(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "CATEGORY_CAP": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_169(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "XXmax_missing_shareXX": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_170(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "MAX_MISSING_SHARE": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_171(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "XXunknown_categoriesXX": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_172(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "UNKNOWN_CATEGORIES": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_173(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "XXzero one-hot block before scalingXX",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_174(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "ZERO ONE-HOT BLOCK BEFORE SCALING",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_175(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = None
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_176(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"XXfitXX": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_177(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"FIT": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_178(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = None
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_179(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = None
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_180(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(None)
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_181(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(None))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_182(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_183(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(None).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_184(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError(None)
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_185(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("XXtransformed features must be finiteXX")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_186(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("TRANSFORMED FEATURES MUST BE FINITE")
        result[name] = pd.DataFrame(transformed, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_187(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = None
    return result


def x_prepare_frozen__mutmut_188(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(None, index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_189(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=None, columns=columns)
    return result


def x_prepare_frozen__mutmut_190(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, columns=None)
    return result


def x_prepare_frozen__mutmut_191(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(index=positions, columns=columns)
    return result


def x_prepare_frozen__mutmut_192(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, columns=columns)
    return result


def x_prepare_frozen__mutmut_193(frame: pd.DataFrame, partitions: dict) -> dict:
    """Fit on supplied training positions; transform every fold without labels.

    Unknown categories have an all-zero one-hot block before training-fitted
    scaling. No row is dropped, including duplicates within a partition.
    """
    if (
        not len(frame.columns)
        or not frame.columns.is_unique
        or any(not isinstance(name, str) for name in frame.columns)
    ):
        raise ValueError("feature columns must be nonempty, unique strings")
    validate_partitions(partitions, len(frame))
    membership = np.empty(len(frame), dtype=int)
    for fold, name in enumerate(PARTITIONS):
        membership[partitions[name]] = fold
    keys = pd.util.hash_pandas_object(frame, index=False).to_numpy()
    groups = pd.DataFrame({"key": keys, "fold": membership}).groupby("key")["fold"].nunique()
    if (groups > 1).any():
        raise ValueError("duplicate feature rows cross partitions")

    train = frame.iloc[partitions["train"]]
    numeric, categorical = [], []
    dropped = {"missing": [], "constant": [], "cardinality": []}
    for name in train:
        column = train[name]
        if column.isna().mean() > MAX_MISSING_SHARE:
            dropped["missing"].append(name)
        elif column.nunique() <= 1:
            dropped["constant"].append(name)
        else:
            converted = pd.to_numeric(column, errors="coerce")
            if (
                not pd.api.types.is_bool_dtype(converted)
                and converted[column.notna()].notna().all()
            ):
                numeric.append(name)
            elif column.nunique() > CATEGORY_CAP:
                dropped["cardinality"].append(name)
            else:
                categorical.append(name)
    if not numeric and not categorical:
        raise ValueError("no usable training feature remains")

    values = _numeric(train, numeric)
    medians = np.nanmedian(values, axis=0) if numeric else np.empty(0)
    encoder = None
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        encoder.fit(_categorical(train, categorical))

    def matrix(part: pd.DataFrame) -> np.ndarray:
        values = _numeric(part, numeric)
        filled = np.where(np.isnan(values), medians, values)
        if encoder is not None:
            filled = np.column_stack([filled, encoder.transform(_categorical(part, categorical))])
        return filled

    scaler = StandardScaler().fit(matrix(train))
    columns = [f"f{i}" for i in range(scaler.n_features_in_)]
    report = {
        "input_columns": frame.columns.tolist(),
        "numeric_columns": numeric,
        "categorical_columns": categorical,
        "dropped": dropped,
        "medians": medians.tolist(),
        "categories": (
            [
                [None if pd.isna(value) else str(value) for value in group]
                for group in encoder.categories_
            ]
            if encoder is not None
            else []
        ),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "output_columns": columns,
        "category_cap": CATEGORY_CAP,
        "max_missing_share": MAX_MISSING_SHARE,
        "unknown_categories": "zero one-hot block before scaling",
    }
    result = {"fit": report}
    for name in PARTITIONS:
        positions = partitions[name]
        transformed = scaler.transform(matrix(frame.iloc[positions]))
        if not np.isfinite(transformed).all():
            raise ValueError("transformed features must be finite")
        result[name] = pd.DataFrame(transformed, index=positions, )
    return result

mutants_x_prepare_frozen__mutmut['_mutmut_orig'] = x_prepare_frozen__mutmut_orig # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_1'] = x_prepare_frozen__mutmut_1 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_2'] = x_prepare_frozen__mutmut_2 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_3'] = x_prepare_frozen__mutmut_3 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_4'] = x_prepare_frozen__mutmut_4 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_5'] = x_prepare_frozen__mutmut_5 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_6'] = x_prepare_frozen__mutmut_6 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_7'] = x_prepare_frozen__mutmut_7 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_8'] = x_prepare_frozen__mutmut_8 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_9'] = x_prepare_frozen__mutmut_9 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_10'] = x_prepare_frozen__mutmut_10 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_11'] = x_prepare_frozen__mutmut_11 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_12'] = x_prepare_frozen__mutmut_12 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_13'] = x_prepare_frozen__mutmut_13 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_14'] = x_prepare_frozen__mutmut_14 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_15'] = x_prepare_frozen__mutmut_15 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_16'] = x_prepare_frozen__mutmut_16 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_17'] = x_prepare_frozen__mutmut_17 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_18'] = x_prepare_frozen__mutmut_18 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_19'] = x_prepare_frozen__mutmut_19 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_20'] = x_prepare_frozen__mutmut_20 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_21'] = x_prepare_frozen__mutmut_21 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_22'] = x_prepare_frozen__mutmut_22 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_23'] = x_prepare_frozen__mutmut_23 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_24'] = x_prepare_frozen__mutmut_24 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_25'] = x_prepare_frozen__mutmut_25 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_26'] = x_prepare_frozen__mutmut_26 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_27'] = x_prepare_frozen__mutmut_27 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_28'] = x_prepare_frozen__mutmut_28 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_29'] = x_prepare_frozen__mutmut_29 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_30'] = x_prepare_frozen__mutmut_30 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_31'] = x_prepare_frozen__mutmut_31 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_32'] = x_prepare_frozen__mutmut_32 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_33'] = x_prepare_frozen__mutmut_33 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_34'] = x_prepare_frozen__mutmut_34 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_35'] = x_prepare_frozen__mutmut_35 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_36'] = x_prepare_frozen__mutmut_36 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_37'] = x_prepare_frozen__mutmut_37 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_38'] = x_prepare_frozen__mutmut_38 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_39'] = x_prepare_frozen__mutmut_39 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_40'] = x_prepare_frozen__mutmut_40 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_41'] = x_prepare_frozen__mutmut_41 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_42'] = x_prepare_frozen__mutmut_42 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_43'] = x_prepare_frozen__mutmut_43 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_44'] = x_prepare_frozen__mutmut_44 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_45'] = x_prepare_frozen__mutmut_45 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_46'] = x_prepare_frozen__mutmut_46 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_47'] = x_prepare_frozen__mutmut_47 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_48'] = x_prepare_frozen__mutmut_48 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_49'] = x_prepare_frozen__mutmut_49 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_50'] = x_prepare_frozen__mutmut_50 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_51'] = x_prepare_frozen__mutmut_51 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_52'] = x_prepare_frozen__mutmut_52 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_53'] = x_prepare_frozen__mutmut_53 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_54'] = x_prepare_frozen__mutmut_54 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_55'] = x_prepare_frozen__mutmut_55 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_56'] = x_prepare_frozen__mutmut_56 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_57'] = x_prepare_frozen__mutmut_57 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_58'] = x_prepare_frozen__mutmut_58 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_59'] = x_prepare_frozen__mutmut_59 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_60'] = x_prepare_frozen__mutmut_60 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_61'] = x_prepare_frozen__mutmut_61 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_62'] = x_prepare_frozen__mutmut_62 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_63'] = x_prepare_frozen__mutmut_63 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_64'] = x_prepare_frozen__mutmut_64 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_65'] = x_prepare_frozen__mutmut_65 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_66'] = x_prepare_frozen__mutmut_66 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_67'] = x_prepare_frozen__mutmut_67 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_68'] = x_prepare_frozen__mutmut_68 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_69'] = x_prepare_frozen__mutmut_69 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_70'] = x_prepare_frozen__mutmut_70 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_71'] = x_prepare_frozen__mutmut_71 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_72'] = x_prepare_frozen__mutmut_72 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_73'] = x_prepare_frozen__mutmut_73 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_74'] = x_prepare_frozen__mutmut_74 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_75'] = x_prepare_frozen__mutmut_75 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_76'] = x_prepare_frozen__mutmut_76 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_77'] = x_prepare_frozen__mutmut_77 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_78'] = x_prepare_frozen__mutmut_78 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_79'] = x_prepare_frozen__mutmut_79 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_80'] = x_prepare_frozen__mutmut_80 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_81'] = x_prepare_frozen__mutmut_81 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_82'] = x_prepare_frozen__mutmut_82 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_83'] = x_prepare_frozen__mutmut_83 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_84'] = x_prepare_frozen__mutmut_84 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_85'] = x_prepare_frozen__mutmut_85 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_86'] = x_prepare_frozen__mutmut_86 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_87'] = x_prepare_frozen__mutmut_87 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_88'] = x_prepare_frozen__mutmut_88 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_89'] = x_prepare_frozen__mutmut_89 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_90'] = x_prepare_frozen__mutmut_90 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_91'] = x_prepare_frozen__mutmut_91 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_92'] = x_prepare_frozen__mutmut_92 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_93'] = x_prepare_frozen__mutmut_93 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_94'] = x_prepare_frozen__mutmut_94 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_95'] = x_prepare_frozen__mutmut_95 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_96'] = x_prepare_frozen__mutmut_96 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_97'] = x_prepare_frozen__mutmut_97 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_98'] = x_prepare_frozen__mutmut_98 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_99'] = x_prepare_frozen__mutmut_99 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_100'] = x_prepare_frozen__mutmut_100 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_101'] = x_prepare_frozen__mutmut_101 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_102'] = x_prepare_frozen__mutmut_102 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_103'] = x_prepare_frozen__mutmut_103 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_104'] = x_prepare_frozen__mutmut_104 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_105'] = x_prepare_frozen__mutmut_105 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_106'] = x_prepare_frozen__mutmut_106 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_107'] = x_prepare_frozen__mutmut_107 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_108'] = x_prepare_frozen__mutmut_108 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_109'] = x_prepare_frozen__mutmut_109 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_110'] = x_prepare_frozen__mutmut_110 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_111'] = x_prepare_frozen__mutmut_111 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_112'] = x_prepare_frozen__mutmut_112 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_113'] = x_prepare_frozen__mutmut_113 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_114'] = x_prepare_frozen__mutmut_114 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_115'] = x_prepare_frozen__mutmut_115 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_116'] = x_prepare_frozen__mutmut_116 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_117'] = x_prepare_frozen__mutmut_117 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_118'] = x_prepare_frozen__mutmut_118 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_119'] = x_prepare_frozen__mutmut_119 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_120'] = x_prepare_frozen__mutmut_120 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_121'] = x_prepare_frozen__mutmut_121 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_122'] = x_prepare_frozen__mutmut_122 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_123'] = x_prepare_frozen__mutmut_123 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_124'] = x_prepare_frozen__mutmut_124 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_125'] = x_prepare_frozen__mutmut_125 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_126'] = x_prepare_frozen__mutmut_126 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_127'] = x_prepare_frozen__mutmut_127 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_128'] = x_prepare_frozen__mutmut_128 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_129'] = x_prepare_frozen__mutmut_129 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_130'] = x_prepare_frozen__mutmut_130 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_131'] = x_prepare_frozen__mutmut_131 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_132'] = x_prepare_frozen__mutmut_132 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_133'] = x_prepare_frozen__mutmut_133 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_134'] = x_prepare_frozen__mutmut_134 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_135'] = x_prepare_frozen__mutmut_135 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_136'] = x_prepare_frozen__mutmut_136 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_137'] = x_prepare_frozen__mutmut_137 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_138'] = x_prepare_frozen__mutmut_138 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_139'] = x_prepare_frozen__mutmut_139 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_140'] = x_prepare_frozen__mutmut_140 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_141'] = x_prepare_frozen__mutmut_141 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_142'] = x_prepare_frozen__mutmut_142 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_143'] = x_prepare_frozen__mutmut_143 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_144'] = x_prepare_frozen__mutmut_144 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_145'] = x_prepare_frozen__mutmut_145 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_146'] = x_prepare_frozen__mutmut_146 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_147'] = x_prepare_frozen__mutmut_147 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_148'] = x_prepare_frozen__mutmut_148 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_149'] = x_prepare_frozen__mutmut_149 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_150'] = x_prepare_frozen__mutmut_150 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_151'] = x_prepare_frozen__mutmut_151 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_152'] = x_prepare_frozen__mutmut_152 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_153'] = x_prepare_frozen__mutmut_153 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_154'] = x_prepare_frozen__mutmut_154 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_155'] = x_prepare_frozen__mutmut_155 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_156'] = x_prepare_frozen__mutmut_156 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_157'] = x_prepare_frozen__mutmut_157 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_158'] = x_prepare_frozen__mutmut_158 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_159'] = x_prepare_frozen__mutmut_159 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_160'] = x_prepare_frozen__mutmut_160 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_161'] = x_prepare_frozen__mutmut_161 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_162'] = x_prepare_frozen__mutmut_162 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_163'] = x_prepare_frozen__mutmut_163 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_164'] = x_prepare_frozen__mutmut_164 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_165'] = x_prepare_frozen__mutmut_165 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_166'] = x_prepare_frozen__mutmut_166 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_167'] = x_prepare_frozen__mutmut_167 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_168'] = x_prepare_frozen__mutmut_168 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_169'] = x_prepare_frozen__mutmut_169 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_170'] = x_prepare_frozen__mutmut_170 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_171'] = x_prepare_frozen__mutmut_171 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_172'] = x_prepare_frozen__mutmut_172 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_173'] = x_prepare_frozen__mutmut_173 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_174'] = x_prepare_frozen__mutmut_174 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_175'] = x_prepare_frozen__mutmut_175 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_176'] = x_prepare_frozen__mutmut_176 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_177'] = x_prepare_frozen__mutmut_177 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_178'] = x_prepare_frozen__mutmut_178 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_179'] = x_prepare_frozen__mutmut_179 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_180'] = x_prepare_frozen__mutmut_180 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_181'] = x_prepare_frozen__mutmut_181 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_182'] = x_prepare_frozen__mutmut_182 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_183'] = x_prepare_frozen__mutmut_183 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_184'] = x_prepare_frozen__mutmut_184 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_185'] = x_prepare_frozen__mutmut_185 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_186'] = x_prepare_frozen__mutmut_186 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_187'] = x_prepare_frozen__mutmut_187 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_188'] = x_prepare_frozen__mutmut_188 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_189'] = x_prepare_frozen__mutmut_189 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_190'] = x_prepare_frozen__mutmut_190 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_191'] = x_prepare_frozen__mutmut_191 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_192'] = x_prepare_frozen__mutmut_192 # type: ignore # mutmut generated
mutants_x_prepare_frozen__mutmut['x_prepare_frozen__mutmut_193'] = x_prepare_frozen__mutmut_193 # type: ignore # mutmut generated
