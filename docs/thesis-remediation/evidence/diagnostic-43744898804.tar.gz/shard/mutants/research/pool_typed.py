"""Typed injection and severity sweep on every eligible table of the pool (pool_extension.md).

The carriers are the 116 UCI tables and the 36 ADBench datasets (the normal class only for a
labelled set). The eligibility rule of ``injection.py`` is unchanged; each table that fails it is
recorded with the reason. The reference run repeats ``typed_run.py`` on the ADBench carriers
(the UCI ones are already archived); the severity sweep covers every eligible table.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import warnings
from concurrent.futures import ProcessPoolExecutor
from functools import partial as bind
from pathlib import Path
from typing import Any

os.environ.setdefault("TQDM_DISABLE", "1")

import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path[:0] = [str(HERE), str(ROOT / "src")]

import dataset_registry as dr  # noqa: E402
import injection as inj  # noqa: E402
import typed_run as tr  # noqa: E402

from etl_benchmark.registry import DEEP_NAMES  # noqa: E402

SEEDS = tr.SEEDS
SWEEP_SEEDS = (42, 1, 2)
SEVERITIES = (0.5, 1.0, 2.0, 4.0)
MAGNITUDE_TYPES = ("univariate_outlier", "multivariate_outlier", "temporal_drift")


from mutmut.mutation.trampoline import wrap_in_trampoline as _mutmut_mutated, MutantDict
mutants_x_jobs__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_jobs__mutmut)
def jobs(registry: Path, data: Path, adbench: Path) -> list[dict[str, Any]]:
    """Every dataset of the pool as a carrier job."""
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    out = []
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        out.append(
            {
                "id": f"uci:{row['uci_id']}",
                "source": "uci",
                "name": meta[row["uci_id"]]["name"],
                "meta": meta[row["uci_id"]],
                "path": str(data / f"{row['uci_id']}.csv"),
            }
        )
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    report = json.loads((registry / "adbench_normalisation_report.json").read_text())
    for name in sorted(report):
        out.append(
            {
                "id": f"adbench:{name}",
                "source": "adbench",
                "name": name,
                "path": str(adbench / files[name]),
            }
        )
    return out


def x_jobs__mutmut_orig(registry: Path, data: Path, adbench: Path) -> list[dict[str, Any]]:
    """Every dataset of the pool as a carrier job."""
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    out = []
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        out.append(
            {
                "id": f"uci:{row['uci_id']}",
                "source": "uci",
                "name": meta[row["uci_id"]]["name"],
                "meta": meta[row["uci_id"]],
                "path": str(data / f"{row['uci_id']}.csv"),
            }
        )
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    report = json.loads((registry / "adbench_normalisation_report.json").read_text())
    for name in sorted(report):
        out.append(
            {
                "id": f"adbench:{name}",
                "source": "adbench",
                "name": name,
                "path": str(adbench / files[name]),
            }
        )
    return out


def x_jobs__mutmut_1(registry: Path, data: Path, adbench: Path) -> list[dict[str, Any]]:
    """Every dataset of the pool as a carrier job."""
    meta = None
    out = []
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        out.append(
            {
                "id": f"uci:{row['uci_id']}",
                "source": "uci",
                "name": meta[row["uci_id"]]["name"],
                "meta": meta[row["uci_id"]],
                "path": str(data / f"{row['uci_id']}.csv"),
            }
        )
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    report = json.loads((registry / "adbench_normalisation_report.json").read_text())
    for name in sorted(report):
        out.append(
            {
                "id": f"adbench:{name}",
                "source": "adbench",
                "name": name,
                "path": str(adbench / files[name]),
            }
        )
    return out


def x_jobs__mutmut_2(registry: Path, data: Path, adbench: Path) -> list[dict[str, Any]]:
    """Every dataset of the pool as a carrier job."""
    meta = {m["XXuci_idXX"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    out = []
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        out.append(
            {
                "id": f"uci:{row['uci_id']}",
                "source": "uci",
                "name": meta[row["uci_id"]]["name"],
                "meta": meta[row["uci_id"]],
                "path": str(data / f"{row['uci_id']}.csv"),
            }
        )
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    report = json.loads((registry / "adbench_normalisation_report.json").read_text())
    for name in sorted(report):
        out.append(
            {
                "id": f"adbench:{name}",
                "source": "adbench",
                "name": name,
                "path": str(adbench / files[name]),
            }
        )
    return out


def x_jobs__mutmut_3(registry: Path, data: Path, adbench: Path) -> list[dict[str, Any]]:
    """Every dataset of the pool as a carrier job."""
    meta = {m["UCI_ID"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    out = []
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        out.append(
            {
                "id": f"uci:{row['uci_id']}",
                "source": "uci",
                "name": meta[row["uci_id"]]["name"],
                "meta": meta[row["uci_id"]],
                "path": str(data / f"{row['uci_id']}.csv"),
            }
        )
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    report = json.loads((registry / "adbench_normalisation_report.json").read_text())
    for name in sorted(report):
        out.append(
            {
                "id": f"adbench:{name}",
                "source": "adbench",
                "name": name,
                "path": str(adbench / files[name]),
            }
        )
    return out


def x_jobs__mutmut_4(registry: Path, data: Path, adbench: Path) -> list[dict[str, Any]]:
    """Every dataset of the pool as a carrier job."""
    meta = {m["uci_id"]: m for m in json.loads(None)["kept"]}
    out = []
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        out.append(
            {
                "id": f"uci:{row['uci_id']}",
                "source": "uci",
                "name": meta[row["uci_id"]]["name"],
                "meta": meta[row["uci_id"]],
                "path": str(data / f"{row['uci_id']}.csv"),
            }
        )
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    report = json.loads((registry / "adbench_normalisation_report.json").read_text())
    for name in sorted(report):
        out.append(
            {
                "id": f"adbench:{name}",
                "source": "adbench",
                "name": name,
                "path": str(adbench / files[name]),
            }
        )
    return out


def x_jobs__mutmut_5(registry: Path, data: Path, adbench: Path) -> list[dict[str, Any]]:
    """Every dataset of the pool as a carrier job."""
    meta = {m["uci_id"]: m for m in json.loads((registry * "uci_curated.json").read_text())["kept"]}
    out = []
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        out.append(
            {
                "id": f"uci:{row['uci_id']}",
                "source": "uci",
                "name": meta[row["uci_id"]]["name"],
                "meta": meta[row["uci_id"]],
                "path": str(data / f"{row['uci_id']}.csv"),
            }
        )
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    report = json.loads((registry / "adbench_normalisation_report.json").read_text())
    for name in sorted(report):
        out.append(
            {
                "id": f"adbench:{name}",
                "source": "adbench",
                "name": name,
                "path": str(adbench / files[name]),
            }
        )
    return out


def x_jobs__mutmut_6(registry: Path, data: Path, adbench: Path) -> list[dict[str, Any]]:
    """Every dataset of the pool as a carrier job."""
    meta = {m["uci_id"]: m for m in json.loads((registry / "XXuci_curated.jsonXX").read_text())["kept"]}
    out = []
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        out.append(
            {
                "id": f"uci:{row['uci_id']}",
                "source": "uci",
                "name": meta[row["uci_id"]]["name"],
                "meta": meta[row["uci_id"]],
                "path": str(data / f"{row['uci_id']}.csv"),
            }
        )
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    report = json.loads((registry / "adbench_normalisation_report.json").read_text())
    for name in sorted(report):
        out.append(
            {
                "id": f"adbench:{name}",
                "source": "adbench",
                "name": name,
                "path": str(adbench / files[name]),
            }
        )
    return out


def x_jobs__mutmut_7(registry: Path, data: Path, adbench: Path) -> list[dict[str, Any]]:
    """Every dataset of the pool as a carrier job."""
    meta = {m["uci_id"]: m for m in json.loads((registry / "UCI_CURATED.JSON").read_text())["kept"]}
    out = []
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        out.append(
            {
                "id": f"uci:{row['uci_id']}",
                "source": "uci",
                "name": meta[row["uci_id"]]["name"],
                "meta": meta[row["uci_id"]],
                "path": str(data / f"{row['uci_id']}.csv"),
            }
        )
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    report = json.loads((registry / "adbench_normalisation_report.json").read_text())
    for name in sorted(report):
        out.append(
            {
                "id": f"adbench:{name}",
                "source": "adbench",
                "name": name,
                "path": str(adbench / files[name]),
            }
        )
    return out


def x_jobs__mutmut_8(registry: Path, data: Path, adbench: Path) -> list[dict[str, Any]]:
    """Every dataset of the pool as a carrier job."""
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["XXkeptXX"]}
    out = []
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        out.append(
            {
                "id": f"uci:{row['uci_id']}",
                "source": "uci",
                "name": meta[row["uci_id"]]["name"],
                "meta": meta[row["uci_id"]],
                "path": str(data / f"{row['uci_id']}.csv"),
            }
        )
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    report = json.loads((registry / "adbench_normalisation_report.json").read_text())
    for name in sorted(report):
        out.append(
            {
                "id": f"adbench:{name}",
                "source": "adbench",
                "name": name,
                "path": str(adbench / files[name]),
            }
        )
    return out


def x_jobs__mutmut_9(registry: Path, data: Path, adbench: Path) -> list[dict[str, Any]]:
    """Every dataset of the pool as a carrier job."""
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["KEPT"]}
    out = []
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        out.append(
            {
                "id": f"uci:{row['uci_id']}",
                "source": "uci",
                "name": meta[row["uci_id"]]["name"],
                "meta": meta[row["uci_id"]],
                "path": str(data / f"{row['uci_id']}.csv"),
            }
        )
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    report = json.loads((registry / "adbench_normalisation_report.json").read_text())
    for name in sorted(report):
        out.append(
            {
                "id": f"adbench:{name}",
                "source": "adbench",
                "name": name,
                "path": str(adbench / files[name]),
            }
        )
    return out


def x_jobs__mutmut_10(registry: Path, data: Path, adbench: Path) -> list[dict[str, Any]]:
    """Every dataset of the pool as a carrier job."""
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    out = None
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        out.append(
            {
                "id": f"uci:{row['uci_id']}",
                "source": "uci",
                "name": meta[row["uci_id"]]["name"],
                "meta": meta[row["uci_id"]],
                "path": str(data / f"{row['uci_id']}.csv"),
            }
        )
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    report = json.loads((registry / "adbench_normalisation_report.json").read_text())
    for name in sorted(report):
        out.append(
            {
                "id": f"adbench:{name}",
                "source": "adbench",
                "name": name,
                "path": str(adbench / files[name]),
            }
        )
    return out


def x_jobs__mutmut_11(registry: Path, data: Path, adbench: Path) -> list[dict[str, Any]]:
    """Every dataset of the pool as a carrier job."""
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    out = []
    for row in json.loads(None)["rows"]:
        out.append(
            {
                "id": f"uci:{row['uci_id']}",
                "source": "uci",
                "name": meta[row["uci_id"]]["name"],
                "meta": meta[row["uci_id"]],
                "path": str(data / f"{row['uci_id']}.csv"),
            }
        )
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    report = json.loads((registry / "adbench_normalisation_report.json").read_text())
    for name in sorted(report):
        out.append(
            {
                "id": f"adbench:{name}",
                "source": "adbench",
                "name": name,
                "path": str(adbench / files[name]),
            }
        )
    return out


def x_jobs__mutmut_12(registry: Path, data: Path, adbench: Path) -> list[dict[str, Any]]:
    """Every dataset of the pool as a carrier job."""
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    out = []
    for row in json.loads((registry * "uci_pool.json").read_text())["rows"]:
        out.append(
            {
                "id": f"uci:{row['uci_id']}",
                "source": "uci",
                "name": meta[row["uci_id"]]["name"],
                "meta": meta[row["uci_id"]],
                "path": str(data / f"{row['uci_id']}.csv"),
            }
        )
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    report = json.loads((registry / "adbench_normalisation_report.json").read_text())
    for name in sorted(report):
        out.append(
            {
                "id": f"adbench:{name}",
                "source": "adbench",
                "name": name,
                "path": str(adbench / files[name]),
            }
        )
    return out


def x_jobs__mutmut_13(registry: Path, data: Path, adbench: Path) -> list[dict[str, Any]]:
    """Every dataset of the pool as a carrier job."""
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    out = []
    for row in json.loads((registry / "XXuci_pool.jsonXX").read_text())["rows"]:
        out.append(
            {
                "id": f"uci:{row['uci_id']}",
                "source": "uci",
                "name": meta[row["uci_id"]]["name"],
                "meta": meta[row["uci_id"]],
                "path": str(data / f"{row['uci_id']}.csv"),
            }
        )
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    report = json.loads((registry / "adbench_normalisation_report.json").read_text())
    for name in sorted(report):
        out.append(
            {
                "id": f"adbench:{name}",
                "source": "adbench",
                "name": name,
                "path": str(adbench / files[name]),
            }
        )
    return out


def x_jobs__mutmut_14(registry: Path, data: Path, adbench: Path) -> list[dict[str, Any]]:
    """Every dataset of the pool as a carrier job."""
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    out = []
    for row in json.loads((registry / "UCI_POOL.JSON").read_text())["rows"]:
        out.append(
            {
                "id": f"uci:{row['uci_id']}",
                "source": "uci",
                "name": meta[row["uci_id"]]["name"],
                "meta": meta[row["uci_id"]],
                "path": str(data / f"{row['uci_id']}.csv"),
            }
        )
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    report = json.loads((registry / "adbench_normalisation_report.json").read_text())
    for name in sorted(report):
        out.append(
            {
                "id": f"adbench:{name}",
                "source": "adbench",
                "name": name,
                "path": str(adbench / files[name]),
            }
        )
    return out


def x_jobs__mutmut_15(registry: Path, data: Path, adbench: Path) -> list[dict[str, Any]]:
    """Every dataset of the pool as a carrier job."""
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    out = []
    for row in json.loads((registry / "uci_pool.json").read_text())["XXrowsXX"]:
        out.append(
            {
                "id": f"uci:{row['uci_id']}",
                "source": "uci",
                "name": meta[row["uci_id"]]["name"],
                "meta": meta[row["uci_id"]],
                "path": str(data / f"{row['uci_id']}.csv"),
            }
        )
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    report = json.loads((registry / "adbench_normalisation_report.json").read_text())
    for name in sorted(report):
        out.append(
            {
                "id": f"adbench:{name}",
                "source": "adbench",
                "name": name,
                "path": str(adbench / files[name]),
            }
        )
    return out


def x_jobs__mutmut_16(registry: Path, data: Path, adbench: Path) -> list[dict[str, Any]]:
    """Every dataset of the pool as a carrier job."""
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    out = []
    for row in json.loads((registry / "uci_pool.json").read_text())["ROWS"]:
        out.append(
            {
                "id": f"uci:{row['uci_id']}",
                "source": "uci",
                "name": meta[row["uci_id"]]["name"],
                "meta": meta[row["uci_id"]],
                "path": str(data / f"{row['uci_id']}.csv"),
            }
        )
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    report = json.loads((registry / "adbench_normalisation_report.json").read_text())
    for name in sorted(report):
        out.append(
            {
                "id": f"adbench:{name}",
                "source": "adbench",
                "name": name,
                "path": str(adbench / files[name]),
            }
        )
    return out


def x_jobs__mutmut_17(registry: Path, data: Path, adbench: Path) -> list[dict[str, Any]]:
    """Every dataset of the pool as a carrier job."""
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    out = []
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        out.append(
            None
        )
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    report = json.loads((registry / "adbench_normalisation_report.json").read_text())
    for name in sorted(report):
        out.append(
            {
                "id": f"adbench:{name}",
                "source": "adbench",
                "name": name,
                "path": str(adbench / files[name]),
            }
        )
    return out


def x_jobs__mutmut_18(registry: Path, data: Path, adbench: Path) -> list[dict[str, Any]]:
    """Every dataset of the pool as a carrier job."""
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    out = []
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        out.append(
            {
                "XXidXX": f"uci:{row['uci_id']}",
                "source": "uci",
                "name": meta[row["uci_id"]]["name"],
                "meta": meta[row["uci_id"]],
                "path": str(data / f"{row['uci_id']}.csv"),
            }
        )
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    report = json.loads((registry / "adbench_normalisation_report.json").read_text())
    for name in sorted(report):
        out.append(
            {
                "id": f"adbench:{name}",
                "source": "adbench",
                "name": name,
                "path": str(adbench / files[name]),
            }
        )
    return out


def x_jobs__mutmut_19(registry: Path, data: Path, adbench: Path) -> list[dict[str, Any]]:
    """Every dataset of the pool as a carrier job."""
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    out = []
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        out.append(
            {
                "ID": f"uci:{row['uci_id']}",
                "source": "uci",
                "name": meta[row["uci_id"]]["name"],
                "meta": meta[row["uci_id"]],
                "path": str(data / f"{row['uci_id']}.csv"),
            }
        )
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    report = json.loads((registry / "adbench_normalisation_report.json").read_text())
    for name in sorted(report):
        out.append(
            {
                "id": f"adbench:{name}",
                "source": "adbench",
                "name": name,
                "path": str(adbench / files[name]),
            }
        )
    return out


def x_jobs__mutmut_20(registry: Path, data: Path, adbench: Path) -> list[dict[str, Any]]:
    """Every dataset of the pool as a carrier job."""
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    out = []
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        out.append(
            {
                "id": f"uci:{row['XXuci_idXX']}",
                "source": "uci",
                "name": meta[row["uci_id"]]["name"],
                "meta": meta[row["uci_id"]],
                "path": str(data / f"{row['uci_id']}.csv"),
            }
        )
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    report = json.loads((registry / "adbench_normalisation_report.json").read_text())
    for name in sorted(report):
        out.append(
            {
                "id": f"adbench:{name}",
                "source": "adbench",
                "name": name,
                "path": str(adbench / files[name]),
            }
        )
    return out


def x_jobs__mutmut_21(registry: Path, data: Path, adbench: Path) -> list[dict[str, Any]]:
    """Every dataset of the pool as a carrier job."""
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    out = []
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        out.append(
            {
                "id": f"uci:{row['UCI_ID']}",
                "source": "uci",
                "name": meta[row["uci_id"]]["name"],
                "meta": meta[row["uci_id"]],
                "path": str(data / f"{row['uci_id']}.csv"),
            }
        )
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    report = json.loads((registry / "adbench_normalisation_report.json").read_text())
    for name in sorted(report):
        out.append(
            {
                "id": f"adbench:{name}",
                "source": "adbench",
                "name": name,
                "path": str(adbench / files[name]),
            }
        )
    return out


def x_jobs__mutmut_22(registry: Path, data: Path, adbench: Path) -> list[dict[str, Any]]:
    """Every dataset of the pool as a carrier job."""
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    out = []
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        out.append(
            {
                "id": f"uci:{row['uci_id']}",
                "XXsourceXX": "uci",
                "name": meta[row["uci_id"]]["name"],
                "meta": meta[row["uci_id"]],
                "path": str(data / f"{row['uci_id']}.csv"),
            }
        )
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    report = json.loads((registry / "adbench_normalisation_report.json").read_text())
    for name in sorted(report):
        out.append(
            {
                "id": f"adbench:{name}",
                "source": "adbench",
                "name": name,
                "path": str(adbench / files[name]),
            }
        )
    return out


def x_jobs__mutmut_23(registry: Path, data: Path, adbench: Path) -> list[dict[str, Any]]:
    """Every dataset of the pool as a carrier job."""
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    out = []
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        out.append(
            {
                "id": f"uci:{row['uci_id']}",
                "SOURCE": "uci",
                "name": meta[row["uci_id"]]["name"],
                "meta": meta[row["uci_id"]],
                "path": str(data / f"{row['uci_id']}.csv"),
            }
        )
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    report = json.loads((registry / "adbench_normalisation_report.json").read_text())
    for name in sorted(report):
        out.append(
            {
                "id": f"adbench:{name}",
                "source": "adbench",
                "name": name,
                "path": str(adbench / files[name]),
            }
        )
    return out


def x_jobs__mutmut_24(registry: Path, data: Path, adbench: Path) -> list[dict[str, Any]]:
    """Every dataset of the pool as a carrier job."""
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    out = []
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        out.append(
            {
                "id": f"uci:{row['uci_id']}",
                "source": "XXuciXX",
                "name": meta[row["uci_id"]]["name"],
                "meta": meta[row["uci_id"]],
                "path": str(data / f"{row['uci_id']}.csv"),
            }
        )
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    report = json.loads((registry / "adbench_normalisation_report.json").read_text())
    for name in sorted(report):
        out.append(
            {
                "id": f"adbench:{name}",
                "source": "adbench",
                "name": name,
                "path": str(adbench / files[name]),
            }
        )
    return out


def x_jobs__mutmut_25(registry: Path, data: Path, adbench: Path) -> list[dict[str, Any]]:
    """Every dataset of the pool as a carrier job."""
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    out = []
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        out.append(
            {
                "id": f"uci:{row['uci_id']}",
                "source": "UCI",
                "name": meta[row["uci_id"]]["name"],
                "meta": meta[row["uci_id"]],
                "path": str(data / f"{row['uci_id']}.csv"),
            }
        )
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    report = json.loads((registry / "adbench_normalisation_report.json").read_text())
    for name in sorted(report):
        out.append(
            {
                "id": f"adbench:{name}",
                "source": "adbench",
                "name": name,
                "path": str(adbench / files[name]),
            }
        )
    return out


def x_jobs__mutmut_26(registry: Path, data: Path, adbench: Path) -> list[dict[str, Any]]:
    """Every dataset of the pool as a carrier job."""
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    out = []
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        out.append(
            {
                "id": f"uci:{row['uci_id']}",
                "source": "uci",
                "XXnameXX": meta[row["uci_id"]]["name"],
                "meta": meta[row["uci_id"]],
                "path": str(data / f"{row['uci_id']}.csv"),
            }
        )
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    report = json.loads((registry / "adbench_normalisation_report.json").read_text())
    for name in sorted(report):
        out.append(
            {
                "id": f"adbench:{name}",
                "source": "adbench",
                "name": name,
                "path": str(adbench / files[name]),
            }
        )
    return out


def x_jobs__mutmut_27(registry: Path, data: Path, adbench: Path) -> list[dict[str, Any]]:
    """Every dataset of the pool as a carrier job."""
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    out = []
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        out.append(
            {
                "id": f"uci:{row['uci_id']}",
                "source": "uci",
                "NAME": meta[row["uci_id"]]["name"],
                "meta": meta[row["uci_id"]],
                "path": str(data / f"{row['uci_id']}.csv"),
            }
        )
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    report = json.loads((registry / "adbench_normalisation_report.json").read_text())
    for name in sorted(report):
        out.append(
            {
                "id": f"adbench:{name}",
                "source": "adbench",
                "name": name,
                "path": str(adbench / files[name]),
            }
        )
    return out


def x_jobs__mutmut_28(registry: Path, data: Path, adbench: Path) -> list[dict[str, Any]]:
    """Every dataset of the pool as a carrier job."""
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    out = []
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        out.append(
            {
                "id": f"uci:{row['uci_id']}",
                "source": "uci",
                "name": meta[row["XXuci_idXX"]]["name"],
                "meta": meta[row["uci_id"]],
                "path": str(data / f"{row['uci_id']}.csv"),
            }
        )
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    report = json.loads((registry / "adbench_normalisation_report.json").read_text())
    for name in sorted(report):
        out.append(
            {
                "id": f"adbench:{name}",
                "source": "adbench",
                "name": name,
                "path": str(adbench / files[name]),
            }
        )
    return out


def x_jobs__mutmut_29(registry: Path, data: Path, adbench: Path) -> list[dict[str, Any]]:
    """Every dataset of the pool as a carrier job."""
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    out = []
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        out.append(
            {
                "id": f"uci:{row['uci_id']}",
                "source": "uci",
                "name": meta[row["UCI_ID"]]["name"],
                "meta": meta[row["uci_id"]],
                "path": str(data / f"{row['uci_id']}.csv"),
            }
        )
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    report = json.loads((registry / "adbench_normalisation_report.json").read_text())
    for name in sorted(report):
        out.append(
            {
                "id": f"adbench:{name}",
                "source": "adbench",
                "name": name,
                "path": str(adbench / files[name]),
            }
        )
    return out


def x_jobs__mutmut_30(registry: Path, data: Path, adbench: Path) -> list[dict[str, Any]]:
    """Every dataset of the pool as a carrier job."""
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    out = []
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        out.append(
            {
                "id": f"uci:{row['uci_id']}",
                "source": "uci",
                "name": meta[row["uci_id"]]["XXnameXX"],
                "meta": meta[row["uci_id"]],
                "path": str(data / f"{row['uci_id']}.csv"),
            }
        )
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    report = json.loads((registry / "adbench_normalisation_report.json").read_text())
    for name in sorted(report):
        out.append(
            {
                "id": f"adbench:{name}",
                "source": "adbench",
                "name": name,
                "path": str(adbench / files[name]),
            }
        )
    return out


def x_jobs__mutmut_31(registry: Path, data: Path, adbench: Path) -> list[dict[str, Any]]:
    """Every dataset of the pool as a carrier job."""
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    out = []
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        out.append(
            {
                "id": f"uci:{row['uci_id']}",
                "source": "uci",
                "name": meta[row["uci_id"]]["NAME"],
                "meta": meta[row["uci_id"]],
                "path": str(data / f"{row['uci_id']}.csv"),
            }
        )
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    report = json.loads((registry / "adbench_normalisation_report.json").read_text())
    for name in sorted(report):
        out.append(
            {
                "id": f"adbench:{name}",
                "source": "adbench",
                "name": name,
                "path": str(adbench / files[name]),
            }
        )
    return out


def x_jobs__mutmut_32(registry: Path, data: Path, adbench: Path) -> list[dict[str, Any]]:
    """Every dataset of the pool as a carrier job."""
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    out = []
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        out.append(
            {
                "id": f"uci:{row['uci_id']}",
                "source": "uci",
                "name": meta[row["uci_id"]]["name"],
                "XXmetaXX": meta[row["uci_id"]],
                "path": str(data / f"{row['uci_id']}.csv"),
            }
        )
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    report = json.loads((registry / "adbench_normalisation_report.json").read_text())
    for name in sorted(report):
        out.append(
            {
                "id": f"adbench:{name}",
                "source": "adbench",
                "name": name,
                "path": str(adbench / files[name]),
            }
        )
    return out


def x_jobs__mutmut_33(registry: Path, data: Path, adbench: Path) -> list[dict[str, Any]]:
    """Every dataset of the pool as a carrier job."""
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    out = []
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        out.append(
            {
                "id": f"uci:{row['uci_id']}",
                "source": "uci",
                "name": meta[row["uci_id"]]["name"],
                "META": meta[row["uci_id"]],
                "path": str(data / f"{row['uci_id']}.csv"),
            }
        )
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    report = json.loads((registry / "adbench_normalisation_report.json").read_text())
    for name in sorted(report):
        out.append(
            {
                "id": f"adbench:{name}",
                "source": "adbench",
                "name": name,
                "path": str(adbench / files[name]),
            }
        )
    return out


def x_jobs__mutmut_34(registry: Path, data: Path, adbench: Path) -> list[dict[str, Any]]:
    """Every dataset of the pool as a carrier job."""
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    out = []
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        out.append(
            {
                "id": f"uci:{row['uci_id']}",
                "source": "uci",
                "name": meta[row["uci_id"]]["name"],
                "meta": meta[row["XXuci_idXX"]],
                "path": str(data / f"{row['uci_id']}.csv"),
            }
        )
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    report = json.loads((registry / "adbench_normalisation_report.json").read_text())
    for name in sorted(report):
        out.append(
            {
                "id": f"adbench:{name}",
                "source": "adbench",
                "name": name,
                "path": str(adbench / files[name]),
            }
        )
    return out


def x_jobs__mutmut_35(registry: Path, data: Path, adbench: Path) -> list[dict[str, Any]]:
    """Every dataset of the pool as a carrier job."""
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    out = []
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        out.append(
            {
                "id": f"uci:{row['uci_id']}",
                "source": "uci",
                "name": meta[row["uci_id"]]["name"],
                "meta": meta[row["UCI_ID"]],
                "path": str(data / f"{row['uci_id']}.csv"),
            }
        )
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    report = json.loads((registry / "adbench_normalisation_report.json").read_text())
    for name in sorted(report):
        out.append(
            {
                "id": f"adbench:{name}",
                "source": "adbench",
                "name": name,
                "path": str(adbench / files[name]),
            }
        )
    return out


def x_jobs__mutmut_36(registry: Path, data: Path, adbench: Path) -> list[dict[str, Any]]:
    """Every dataset of the pool as a carrier job."""
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    out = []
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        out.append(
            {
                "id": f"uci:{row['uci_id']}",
                "source": "uci",
                "name": meta[row["uci_id"]]["name"],
                "meta": meta[row["uci_id"]],
                "XXpathXX": str(data / f"{row['uci_id']}.csv"),
            }
        )
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    report = json.loads((registry / "adbench_normalisation_report.json").read_text())
    for name in sorted(report):
        out.append(
            {
                "id": f"adbench:{name}",
                "source": "adbench",
                "name": name,
                "path": str(adbench / files[name]),
            }
        )
    return out


def x_jobs__mutmut_37(registry: Path, data: Path, adbench: Path) -> list[dict[str, Any]]:
    """Every dataset of the pool as a carrier job."""
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    out = []
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        out.append(
            {
                "id": f"uci:{row['uci_id']}",
                "source": "uci",
                "name": meta[row["uci_id"]]["name"],
                "meta": meta[row["uci_id"]],
                "PATH": str(data / f"{row['uci_id']}.csv"),
            }
        )
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    report = json.loads((registry / "adbench_normalisation_report.json").read_text())
    for name in sorted(report):
        out.append(
            {
                "id": f"adbench:{name}",
                "source": "adbench",
                "name": name,
                "path": str(adbench / files[name]),
            }
        )
    return out


def x_jobs__mutmut_38(registry: Path, data: Path, adbench: Path) -> list[dict[str, Any]]:
    """Every dataset of the pool as a carrier job."""
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    out = []
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        out.append(
            {
                "id": f"uci:{row['uci_id']}",
                "source": "uci",
                "name": meta[row["uci_id"]]["name"],
                "meta": meta[row["uci_id"]],
                "path": str(None),
            }
        )
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    report = json.loads((registry / "adbench_normalisation_report.json").read_text())
    for name in sorted(report):
        out.append(
            {
                "id": f"adbench:{name}",
                "source": "adbench",
                "name": name,
                "path": str(adbench / files[name]),
            }
        )
    return out


def x_jobs__mutmut_39(registry: Path, data: Path, adbench: Path) -> list[dict[str, Any]]:
    """Every dataset of the pool as a carrier job."""
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    out = []
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        out.append(
            {
                "id": f"uci:{row['uci_id']}",
                "source": "uci",
                "name": meta[row["uci_id"]]["name"],
                "meta": meta[row["uci_id"]],
                "path": str(data * f"{row['uci_id']}.csv"),
            }
        )
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    report = json.loads((registry / "adbench_normalisation_report.json").read_text())
    for name in sorted(report):
        out.append(
            {
                "id": f"adbench:{name}",
                "source": "adbench",
                "name": name,
                "path": str(adbench / files[name]),
            }
        )
    return out


def x_jobs__mutmut_40(registry: Path, data: Path, adbench: Path) -> list[dict[str, Any]]:
    """Every dataset of the pool as a carrier job."""
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    out = []
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        out.append(
            {
                "id": f"uci:{row['uci_id']}",
                "source": "uci",
                "name": meta[row["uci_id"]]["name"],
                "meta": meta[row["uci_id"]],
                "path": str(data / f"{row['XXuci_idXX']}.csv"),
            }
        )
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    report = json.loads((registry / "adbench_normalisation_report.json").read_text())
    for name in sorted(report):
        out.append(
            {
                "id": f"adbench:{name}",
                "source": "adbench",
                "name": name,
                "path": str(adbench / files[name]),
            }
        )
    return out


def x_jobs__mutmut_41(registry: Path, data: Path, adbench: Path) -> list[dict[str, Any]]:
    """Every dataset of the pool as a carrier job."""
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    out = []
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        out.append(
            {
                "id": f"uci:{row['uci_id']}",
                "source": "uci",
                "name": meta[row["uci_id"]]["name"],
                "meta": meta[row["uci_id"]],
                "path": str(data / f"{row['UCI_ID']}.csv"),
            }
        )
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    report = json.loads((registry / "adbench_normalisation_report.json").read_text())
    for name in sorted(report):
        out.append(
            {
                "id": f"adbench:{name}",
                "source": "adbench",
                "name": name,
                "path": str(adbench / files[name]),
            }
        )
    return out


def x_jobs__mutmut_42(registry: Path, data: Path, adbench: Path) -> list[dict[str, Any]]:
    """Every dataset of the pool as a carrier job."""
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    out = []
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        out.append(
            {
                "id": f"uci:{row['uci_id']}",
                "source": "uci",
                "name": meta[row["uci_id"]]["name"],
                "meta": meta[row["uci_id"]],
                "path": str(data / f"{row['uci_id']}.csv"),
            }
        )
    files = None
    report = json.loads((registry / "adbench_normalisation_report.json").read_text())
    for name in sorted(report):
        out.append(
            {
                "id": f"adbench:{name}",
                "source": "adbench",
                "name": name,
                "path": str(adbench / files[name]),
            }
        )
    return out


def x_jobs__mutmut_43(registry: Path, data: Path, adbench: Path) -> list[dict[str, Any]]:
    """Every dataset of the pool as a carrier job."""
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    out = []
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        out.append(
            {
                "id": f"uci:{row['uci_id']}",
                "source": "uci",
                "name": meta[row["uci_id"]]["name"],
                "meta": meta[row["uci_id"]],
                "path": str(data / f"{row['uci_id']}.csv"),
            }
        )
    files = {t["XXnameXX"]: t["file"] for t in dr.ADBENCH_TABULAR}
    report = json.loads((registry / "adbench_normalisation_report.json").read_text())
    for name in sorted(report):
        out.append(
            {
                "id": f"adbench:{name}",
                "source": "adbench",
                "name": name,
                "path": str(adbench / files[name]),
            }
        )
    return out


def x_jobs__mutmut_44(registry: Path, data: Path, adbench: Path) -> list[dict[str, Any]]:
    """Every dataset of the pool as a carrier job."""
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    out = []
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        out.append(
            {
                "id": f"uci:{row['uci_id']}",
                "source": "uci",
                "name": meta[row["uci_id"]]["name"],
                "meta": meta[row["uci_id"]],
                "path": str(data / f"{row['uci_id']}.csv"),
            }
        )
    files = {t["NAME"]: t["file"] for t in dr.ADBENCH_TABULAR}
    report = json.loads((registry / "adbench_normalisation_report.json").read_text())
    for name in sorted(report):
        out.append(
            {
                "id": f"adbench:{name}",
                "source": "adbench",
                "name": name,
                "path": str(adbench / files[name]),
            }
        )
    return out


def x_jobs__mutmut_45(registry: Path, data: Path, adbench: Path) -> list[dict[str, Any]]:
    """Every dataset of the pool as a carrier job."""
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    out = []
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        out.append(
            {
                "id": f"uci:{row['uci_id']}",
                "source": "uci",
                "name": meta[row["uci_id"]]["name"],
                "meta": meta[row["uci_id"]],
                "path": str(data / f"{row['uci_id']}.csv"),
            }
        )
    files = {t["name"]: t["XXfileXX"] for t in dr.ADBENCH_TABULAR}
    report = json.loads((registry / "adbench_normalisation_report.json").read_text())
    for name in sorted(report):
        out.append(
            {
                "id": f"adbench:{name}",
                "source": "adbench",
                "name": name,
                "path": str(adbench / files[name]),
            }
        )
    return out


def x_jobs__mutmut_46(registry: Path, data: Path, adbench: Path) -> list[dict[str, Any]]:
    """Every dataset of the pool as a carrier job."""
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    out = []
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        out.append(
            {
                "id": f"uci:{row['uci_id']}",
                "source": "uci",
                "name": meta[row["uci_id"]]["name"],
                "meta": meta[row["uci_id"]],
                "path": str(data / f"{row['uci_id']}.csv"),
            }
        )
    files = {t["name"]: t["FILE"] for t in dr.ADBENCH_TABULAR}
    report = json.loads((registry / "adbench_normalisation_report.json").read_text())
    for name in sorted(report):
        out.append(
            {
                "id": f"adbench:{name}",
                "source": "adbench",
                "name": name,
                "path": str(adbench / files[name]),
            }
        )
    return out


def x_jobs__mutmut_47(registry: Path, data: Path, adbench: Path) -> list[dict[str, Any]]:
    """Every dataset of the pool as a carrier job."""
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    out = []
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        out.append(
            {
                "id": f"uci:{row['uci_id']}",
                "source": "uci",
                "name": meta[row["uci_id"]]["name"],
                "meta": meta[row["uci_id"]],
                "path": str(data / f"{row['uci_id']}.csv"),
            }
        )
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    report = None
    for name in sorted(report):
        out.append(
            {
                "id": f"adbench:{name}",
                "source": "adbench",
                "name": name,
                "path": str(adbench / files[name]),
            }
        )
    return out


def x_jobs__mutmut_48(registry: Path, data: Path, adbench: Path) -> list[dict[str, Any]]:
    """Every dataset of the pool as a carrier job."""
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    out = []
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        out.append(
            {
                "id": f"uci:{row['uci_id']}",
                "source": "uci",
                "name": meta[row["uci_id"]]["name"],
                "meta": meta[row["uci_id"]],
                "path": str(data / f"{row['uci_id']}.csv"),
            }
        )
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    report = json.loads(None)
    for name in sorted(report):
        out.append(
            {
                "id": f"adbench:{name}",
                "source": "adbench",
                "name": name,
                "path": str(adbench / files[name]),
            }
        )
    return out


def x_jobs__mutmut_49(registry: Path, data: Path, adbench: Path) -> list[dict[str, Any]]:
    """Every dataset of the pool as a carrier job."""
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    out = []
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        out.append(
            {
                "id": f"uci:{row['uci_id']}",
                "source": "uci",
                "name": meta[row["uci_id"]]["name"],
                "meta": meta[row["uci_id"]],
                "path": str(data / f"{row['uci_id']}.csv"),
            }
        )
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    report = json.loads((registry * "adbench_normalisation_report.json").read_text())
    for name in sorted(report):
        out.append(
            {
                "id": f"adbench:{name}",
                "source": "adbench",
                "name": name,
                "path": str(adbench / files[name]),
            }
        )
    return out


def x_jobs__mutmut_50(registry: Path, data: Path, adbench: Path) -> list[dict[str, Any]]:
    """Every dataset of the pool as a carrier job."""
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    out = []
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        out.append(
            {
                "id": f"uci:{row['uci_id']}",
                "source": "uci",
                "name": meta[row["uci_id"]]["name"],
                "meta": meta[row["uci_id"]],
                "path": str(data / f"{row['uci_id']}.csv"),
            }
        )
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    report = json.loads((registry / "XXadbench_normalisation_report.jsonXX").read_text())
    for name in sorted(report):
        out.append(
            {
                "id": f"adbench:{name}",
                "source": "adbench",
                "name": name,
                "path": str(adbench / files[name]),
            }
        )
    return out


def x_jobs__mutmut_51(registry: Path, data: Path, adbench: Path) -> list[dict[str, Any]]:
    """Every dataset of the pool as a carrier job."""
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    out = []
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        out.append(
            {
                "id": f"uci:{row['uci_id']}",
                "source": "uci",
                "name": meta[row["uci_id"]]["name"],
                "meta": meta[row["uci_id"]],
                "path": str(data / f"{row['uci_id']}.csv"),
            }
        )
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    report = json.loads((registry / "ADBENCH_NORMALISATION_REPORT.JSON").read_text())
    for name in sorted(report):
        out.append(
            {
                "id": f"adbench:{name}",
                "source": "adbench",
                "name": name,
                "path": str(adbench / files[name]),
            }
        )
    return out


def x_jobs__mutmut_52(registry: Path, data: Path, adbench: Path) -> list[dict[str, Any]]:
    """Every dataset of the pool as a carrier job."""
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    out = []
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        out.append(
            {
                "id": f"uci:{row['uci_id']}",
                "source": "uci",
                "name": meta[row["uci_id"]]["name"],
                "meta": meta[row["uci_id"]],
                "path": str(data / f"{row['uci_id']}.csv"),
            }
        )
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    report = json.loads((registry / "adbench_normalisation_report.json").read_text())
    for name in sorted(None):
        out.append(
            {
                "id": f"adbench:{name}",
                "source": "adbench",
                "name": name,
                "path": str(adbench / files[name]),
            }
        )
    return out


def x_jobs__mutmut_53(registry: Path, data: Path, adbench: Path) -> list[dict[str, Any]]:
    """Every dataset of the pool as a carrier job."""
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    out = []
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        out.append(
            {
                "id": f"uci:{row['uci_id']}",
                "source": "uci",
                "name": meta[row["uci_id"]]["name"],
                "meta": meta[row["uci_id"]],
                "path": str(data / f"{row['uci_id']}.csv"),
            }
        )
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    report = json.loads((registry / "adbench_normalisation_report.json").read_text())
    for name in sorted(report):
        out.append(
            None
        )
    return out


def x_jobs__mutmut_54(registry: Path, data: Path, adbench: Path) -> list[dict[str, Any]]:
    """Every dataset of the pool as a carrier job."""
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    out = []
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        out.append(
            {
                "id": f"uci:{row['uci_id']}",
                "source": "uci",
                "name": meta[row["uci_id"]]["name"],
                "meta": meta[row["uci_id"]],
                "path": str(data / f"{row['uci_id']}.csv"),
            }
        )
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    report = json.loads((registry / "adbench_normalisation_report.json").read_text())
    for name in sorted(report):
        out.append(
            {
                "XXidXX": f"adbench:{name}",
                "source": "adbench",
                "name": name,
                "path": str(adbench / files[name]),
            }
        )
    return out


def x_jobs__mutmut_55(registry: Path, data: Path, adbench: Path) -> list[dict[str, Any]]:
    """Every dataset of the pool as a carrier job."""
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    out = []
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        out.append(
            {
                "id": f"uci:{row['uci_id']}",
                "source": "uci",
                "name": meta[row["uci_id"]]["name"],
                "meta": meta[row["uci_id"]],
                "path": str(data / f"{row['uci_id']}.csv"),
            }
        )
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    report = json.loads((registry / "adbench_normalisation_report.json").read_text())
    for name in sorted(report):
        out.append(
            {
                "ID": f"adbench:{name}",
                "source": "adbench",
                "name": name,
                "path": str(adbench / files[name]),
            }
        )
    return out


def x_jobs__mutmut_56(registry: Path, data: Path, adbench: Path) -> list[dict[str, Any]]:
    """Every dataset of the pool as a carrier job."""
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    out = []
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        out.append(
            {
                "id": f"uci:{row['uci_id']}",
                "source": "uci",
                "name": meta[row["uci_id"]]["name"],
                "meta": meta[row["uci_id"]],
                "path": str(data / f"{row['uci_id']}.csv"),
            }
        )
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    report = json.loads((registry / "adbench_normalisation_report.json").read_text())
    for name in sorted(report):
        out.append(
            {
                "id": f"adbench:{name}",
                "XXsourceXX": "adbench",
                "name": name,
                "path": str(adbench / files[name]),
            }
        )
    return out


def x_jobs__mutmut_57(registry: Path, data: Path, adbench: Path) -> list[dict[str, Any]]:
    """Every dataset of the pool as a carrier job."""
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    out = []
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        out.append(
            {
                "id": f"uci:{row['uci_id']}",
                "source": "uci",
                "name": meta[row["uci_id"]]["name"],
                "meta": meta[row["uci_id"]],
                "path": str(data / f"{row['uci_id']}.csv"),
            }
        )
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    report = json.loads((registry / "adbench_normalisation_report.json").read_text())
    for name in sorted(report):
        out.append(
            {
                "id": f"adbench:{name}",
                "SOURCE": "adbench",
                "name": name,
                "path": str(adbench / files[name]),
            }
        )
    return out


def x_jobs__mutmut_58(registry: Path, data: Path, adbench: Path) -> list[dict[str, Any]]:
    """Every dataset of the pool as a carrier job."""
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    out = []
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        out.append(
            {
                "id": f"uci:{row['uci_id']}",
                "source": "uci",
                "name": meta[row["uci_id"]]["name"],
                "meta": meta[row["uci_id"]],
                "path": str(data / f"{row['uci_id']}.csv"),
            }
        )
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    report = json.loads((registry / "adbench_normalisation_report.json").read_text())
    for name in sorted(report):
        out.append(
            {
                "id": f"adbench:{name}",
                "source": "XXadbenchXX",
                "name": name,
                "path": str(adbench / files[name]),
            }
        )
    return out


def x_jobs__mutmut_59(registry: Path, data: Path, adbench: Path) -> list[dict[str, Any]]:
    """Every dataset of the pool as a carrier job."""
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    out = []
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        out.append(
            {
                "id": f"uci:{row['uci_id']}",
                "source": "uci",
                "name": meta[row["uci_id"]]["name"],
                "meta": meta[row["uci_id"]],
                "path": str(data / f"{row['uci_id']}.csv"),
            }
        )
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    report = json.loads((registry / "adbench_normalisation_report.json").read_text())
    for name in sorted(report):
        out.append(
            {
                "id": f"adbench:{name}",
                "source": "ADBENCH",
                "name": name,
                "path": str(adbench / files[name]),
            }
        )
    return out


def x_jobs__mutmut_60(registry: Path, data: Path, adbench: Path) -> list[dict[str, Any]]:
    """Every dataset of the pool as a carrier job."""
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    out = []
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        out.append(
            {
                "id": f"uci:{row['uci_id']}",
                "source": "uci",
                "name": meta[row["uci_id"]]["name"],
                "meta": meta[row["uci_id"]],
                "path": str(data / f"{row['uci_id']}.csv"),
            }
        )
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    report = json.loads((registry / "adbench_normalisation_report.json").read_text())
    for name in sorted(report):
        out.append(
            {
                "id": f"adbench:{name}",
                "source": "adbench",
                "XXnameXX": name,
                "path": str(adbench / files[name]),
            }
        )
    return out


def x_jobs__mutmut_61(registry: Path, data: Path, adbench: Path) -> list[dict[str, Any]]:
    """Every dataset of the pool as a carrier job."""
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    out = []
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        out.append(
            {
                "id": f"uci:{row['uci_id']}",
                "source": "uci",
                "name": meta[row["uci_id"]]["name"],
                "meta": meta[row["uci_id"]],
                "path": str(data / f"{row['uci_id']}.csv"),
            }
        )
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    report = json.loads((registry / "adbench_normalisation_report.json").read_text())
    for name in sorted(report):
        out.append(
            {
                "id": f"adbench:{name}",
                "source": "adbench",
                "NAME": name,
                "path": str(adbench / files[name]),
            }
        )
    return out


def x_jobs__mutmut_62(registry: Path, data: Path, adbench: Path) -> list[dict[str, Any]]:
    """Every dataset of the pool as a carrier job."""
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    out = []
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        out.append(
            {
                "id": f"uci:{row['uci_id']}",
                "source": "uci",
                "name": meta[row["uci_id"]]["name"],
                "meta": meta[row["uci_id"]],
                "path": str(data / f"{row['uci_id']}.csv"),
            }
        )
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    report = json.loads((registry / "adbench_normalisation_report.json").read_text())
    for name in sorted(report):
        out.append(
            {
                "id": f"adbench:{name}",
                "source": "adbench",
                "name": name,
                "XXpathXX": str(adbench / files[name]),
            }
        )
    return out


def x_jobs__mutmut_63(registry: Path, data: Path, adbench: Path) -> list[dict[str, Any]]:
    """Every dataset of the pool as a carrier job."""
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    out = []
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        out.append(
            {
                "id": f"uci:{row['uci_id']}",
                "source": "uci",
                "name": meta[row["uci_id"]]["name"],
                "meta": meta[row["uci_id"]],
                "path": str(data / f"{row['uci_id']}.csv"),
            }
        )
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    report = json.loads((registry / "adbench_normalisation_report.json").read_text())
    for name in sorted(report):
        out.append(
            {
                "id": f"adbench:{name}",
                "source": "adbench",
                "name": name,
                "PATH": str(adbench / files[name]),
            }
        )
    return out


def x_jobs__mutmut_64(registry: Path, data: Path, adbench: Path) -> list[dict[str, Any]]:
    """Every dataset of the pool as a carrier job."""
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    out = []
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        out.append(
            {
                "id": f"uci:{row['uci_id']}",
                "source": "uci",
                "name": meta[row["uci_id"]]["name"],
                "meta": meta[row["uci_id"]],
                "path": str(data / f"{row['uci_id']}.csv"),
            }
        )
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    report = json.loads((registry / "adbench_normalisation_report.json").read_text())
    for name in sorted(report):
        out.append(
            {
                "id": f"adbench:{name}",
                "source": "adbench",
                "name": name,
                "path": str(None),
            }
        )
    return out


def x_jobs__mutmut_65(registry: Path, data: Path, adbench: Path) -> list[dict[str, Any]]:
    """Every dataset of the pool as a carrier job."""
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    out = []
    for row in json.loads((registry / "uci_pool.json").read_text())["rows"]:
        out.append(
            {
                "id": f"uci:{row['uci_id']}",
                "source": "uci",
                "name": meta[row["uci_id"]]["name"],
                "meta": meta[row["uci_id"]],
                "path": str(data / f"{row['uci_id']}.csv"),
            }
        )
    files = {t["name"]: t["file"] for t in dr.ADBENCH_TABULAR}
    report = json.loads((registry / "adbench_normalisation_report.json").read_text())
    for name in sorted(report):
        out.append(
            {
                "id": f"adbench:{name}",
                "source": "adbench",
                "name": name,
                "path": str(adbench * files[name]),
            }
        )
    return out

mutants_x_jobs__mutmut['_mutmut_orig'] = x_jobs__mutmut_orig # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_1'] = x_jobs__mutmut_1 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_2'] = x_jobs__mutmut_2 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_3'] = x_jobs__mutmut_3 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_4'] = x_jobs__mutmut_4 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_5'] = x_jobs__mutmut_5 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_6'] = x_jobs__mutmut_6 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_7'] = x_jobs__mutmut_7 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_8'] = x_jobs__mutmut_8 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_9'] = x_jobs__mutmut_9 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_10'] = x_jobs__mutmut_10 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_11'] = x_jobs__mutmut_11 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_12'] = x_jobs__mutmut_12 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_13'] = x_jobs__mutmut_13 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_14'] = x_jobs__mutmut_14 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_15'] = x_jobs__mutmut_15 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_16'] = x_jobs__mutmut_16 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_17'] = x_jobs__mutmut_17 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_18'] = x_jobs__mutmut_18 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_19'] = x_jobs__mutmut_19 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_20'] = x_jobs__mutmut_20 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_21'] = x_jobs__mutmut_21 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_22'] = x_jobs__mutmut_22 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_23'] = x_jobs__mutmut_23 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_24'] = x_jobs__mutmut_24 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_25'] = x_jobs__mutmut_25 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_26'] = x_jobs__mutmut_26 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_27'] = x_jobs__mutmut_27 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_28'] = x_jobs__mutmut_28 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_29'] = x_jobs__mutmut_29 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_30'] = x_jobs__mutmut_30 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_31'] = x_jobs__mutmut_31 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_32'] = x_jobs__mutmut_32 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_33'] = x_jobs__mutmut_33 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_34'] = x_jobs__mutmut_34 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_35'] = x_jobs__mutmut_35 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_36'] = x_jobs__mutmut_36 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_37'] = x_jobs__mutmut_37 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_38'] = x_jobs__mutmut_38 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_39'] = x_jobs__mutmut_39 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_40'] = x_jobs__mutmut_40 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_41'] = x_jobs__mutmut_41 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_42'] = x_jobs__mutmut_42 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_43'] = x_jobs__mutmut_43 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_44'] = x_jobs__mutmut_44 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_45'] = x_jobs__mutmut_45 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_46'] = x_jobs__mutmut_46 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_47'] = x_jobs__mutmut_47 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_48'] = x_jobs__mutmut_48 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_49'] = x_jobs__mutmut_49 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_50'] = x_jobs__mutmut_50 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_51'] = x_jobs__mutmut_51 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_52'] = x_jobs__mutmut_52 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_53'] = x_jobs__mutmut_53 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_54'] = x_jobs__mutmut_54 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_55'] = x_jobs__mutmut_55 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_56'] = x_jobs__mutmut_56 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_57'] = x_jobs__mutmut_57 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_58'] = x_jobs__mutmut_58 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_59'] = x_jobs__mutmut_59 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_60'] = x_jobs__mutmut_60 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_61'] = x_jobs__mutmut_61 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_62'] = x_jobs__mutmut_62 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_63'] = x_jobs__mutmut_63 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_64'] = x_jobs__mutmut_64 # type: ignore # mutmut generated
mutants_x_jobs__mutmut['x_jobs__mutmut_65'] = x_jobs__mutmut_65 # type: ignore # mutmut generated
mutants_x_load_carrier__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_load_carrier__mutmut)
def load_carrier(job: dict[str, Any], seed: int = 0) -> tuple[pd.DataFrame, dict[str, Any]]:
    if job["source"] == "uci":
        return tr.load_carrier(job["meta"], Path(job["path"]), seed)
    data = np.load(job["path"])
    features = pd.DataFrame(data["X"]).add_prefix("f")[np.asarray(data["y"]).astype(int) == 0]
    carrier, report = inj.prepare(features.reset_index(drop=True), seed=seed)
    report.update(source_rows=int(len(features)), normal_class_only=True)
    return carrier, report


def x_load_carrier__mutmut_orig(job: dict[str, Any], seed: int = 0) -> tuple[pd.DataFrame, dict[str, Any]]:
    if job["source"] == "uci":
        return tr.load_carrier(job["meta"], Path(job["path"]), seed)
    data = np.load(job["path"])
    features = pd.DataFrame(data["X"]).add_prefix("f")[np.asarray(data["y"]).astype(int) == 0]
    carrier, report = inj.prepare(features.reset_index(drop=True), seed=seed)
    report.update(source_rows=int(len(features)), normal_class_only=True)
    return carrier, report


def x_load_carrier__mutmut_1(job: dict[str, Any], seed: int = 1) -> tuple[pd.DataFrame, dict[str, Any]]:
    if job["source"] == "uci":
        return tr.load_carrier(job["meta"], Path(job["path"]), seed)
    data = np.load(job["path"])
    features = pd.DataFrame(data["X"]).add_prefix("f")[np.asarray(data["y"]).astype(int) == 0]
    carrier, report = inj.prepare(features.reset_index(drop=True), seed=seed)
    report.update(source_rows=int(len(features)), normal_class_only=True)
    return carrier, report


def x_load_carrier__mutmut_2(job: dict[str, Any], seed: int = 0) -> tuple[pd.DataFrame, dict[str, Any]]:
    if job["XXsourceXX"] == "uci":
        return tr.load_carrier(job["meta"], Path(job["path"]), seed)
    data = np.load(job["path"])
    features = pd.DataFrame(data["X"]).add_prefix("f")[np.asarray(data["y"]).astype(int) == 0]
    carrier, report = inj.prepare(features.reset_index(drop=True), seed=seed)
    report.update(source_rows=int(len(features)), normal_class_only=True)
    return carrier, report


def x_load_carrier__mutmut_3(job: dict[str, Any], seed: int = 0) -> tuple[pd.DataFrame, dict[str, Any]]:
    if job["SOURCE"] == "uci":
        return tr.load_carrier(job["meta"], Path(job["path"]), seed)
    data = np.load(job["path"])
    features = pd.DataFrame(data["X"]).add_prefix("f")[np.asarray(data["y"]).astype(int) == 0]
    carrier, report = inj.prepare(features.reset_index(drop=True), seed=seed)
    report.update(source_rows=int(len(features)), normal_class_only=True)
    return carrier, report


def x_load_carrier__mutmut_4(job: dict[str, Any], seed: int = 0) -> tuple[pd.DataFrame, dict[str, Any]]:
    if job["source"] != "uci":
        return tr.load_carrier(job["meta"], Path(job["path"]), seed)
    data = np.load(job["path"])
    features = pd.DataFrame(data["X"]).add_prefix("f")[np.asarray(data["y"]).astype(int) == 0]
    carrier, report = inj.prepare(features.reset_index(drop=True), seed=seed)
    report.update(source_rows=int(len(features)), normal_class_only=True)
    return carrier, report


def x_load_carrier__mutmut_5(job: dict[str, Any], seed: int = 0) -> tuple[pd.DataFrame, dict[str, Any]]:
    if job["source"] == "XXuciXX":
        return tr.load_carrier(job["meta"], Path(job["path"]), seed)
    data = np.load(job["path"])
    features = pd.DataFrame(data["X"]).add_prefix("f")[np.asarray(data["y"]).astype(int) == 0]
    carrier, report = inj.prepare(features.reset_index(drop=True), seed=seed)
    report.update(source_rows=int(len(features)), normal_class_only=True)
    return carrier, report


def x_load_carrier__mutmut_6(job: dict[str, Any], seed: int = 0) -> tuple[pd.DataFrame, dict[str, Any]]:
    if job["source"] == "UCI":
        return tr.load_carrier(job["meta"], Path(job["path"]), seed)
    data = np.load(job["path"])
    features = pd.DataFrame(data["X"]).add_prefix("f")[np.asarray(data["y"]).astype(int) == 0]
    carrier, report = inj.prepare(features.reset_index(drop=True), seed=seed)
    report.update(source_rows=int(len(features)), normal_class_only=True)
    return carrier, report


def x_load_carrier__mutmut_7(job: dict[str, Any], seed: int = 0) -> tuple[pd.DataFrame, dict[str, Any]]:
    if job["source"] == "uci":
        return tr.load_carrier(None, Path(job["path"]), seed)
    data = np.load(job["path"])
    features = pd.DataFrame(data["X"]).add_prefix("f")[np.asarray(data["y"]).astype(int) == 0]
    carrier, report = inj.prepare(features.reset_index(drop=True), seed=seed)
    report.update(source_rows=int(len(features)), normal_class_only=True)
    return carrier, report


def x_load_carrier__mutmut_8(job: dict[str, Any], seed: int = 0) -> tuple[pd.DataFrame, dict[str, Any]]:
    if job["source"] == "uci":
        return tr.load_carrier(job["meta"], None, seed)
    data = np.load(job["path"])
    features = pd.DataFrame(data["X"]).add_prefix("f")[np.asarray(data["y"]).astype(int) == 0]
    carrier, report = inj.prepare(features.reset_index(drop=True), seed=seed)
    report.update(source_rows=int(len(features)), normal_class_only=True)
    return carrier, report


def x_load_carrier__mutmut_9(job: dict[str, Any], seed: int = 0) -> tuple[pd.DataFrame, dict[str, Any]]:
    if job["source"] == "uci":
        return tr.load_carrier(job["meta"], Path(job["path"]), None)
    data = np.load(job["path"])
    features = pd.DataFrame(data["X"]).add_prefix("f")[np.asarray(data["y"]).astype(int) == 0]
    carrier, report = inj.prepare(features.reset_index(drop=True), seed=seed)
    report.update(source_rows=int(len(features)), normal_class_only=True)
    return carrier, report


def x_load_carrier__mutmut_10(job: dict[str, Any], seed: int = 0) -> tuple[pd.DataFrame, dict[str, Any]]:
    if job["source"] == "uci":
        return tr.load_carrier(Path(job["path"]), seed)
    data = np.load(job["path"])
    features = pd.DataFrame(data["X"]).add_prefix("f")[np.asarray(data["y"]).astype(int) == 0]
    carrier, report = inj.prepare(features.reset_index(drop=True), seed=seed)
    report.update(source_rows=int(len(features)), normal_class_only=True)
    return carrier, report


def x_load_carrier__mutmut_11(job: dict[str, Any], seed: int = 0) -> tuple[pd.DataFrame, dict[str, Any]]:
    if job["source"] == "uci":
        return tr.load_carrier(job["meta"], seed)
    data = np.load(job["path"])
    features = pd.DataFrame(data["X"]).add_prefix("f")[np.asarray(data["y"]).astype(int) == 0]
    carrier, report = inj.prepare(features.reset_index(drop=True), seed=seed)
    report.update(source_rows=int(len(features)), normal_class_only=True)
    return carrier, report


def x_load_carrier__mutmut_12(job: dict[str, Any], seed: int = 0) -> tuple[pd.DataFrame, dict[str, Any]]:
    if job["source"] == "uci":
        return tr.load_carrier(job["meta"], Path(job["path"]), )
    data = np.load(job["path"])
    features = pd.DataFrame(data["X"]).add_prefix("f")[np.asarray(data["y"]).astype(int) == 0]
    carrier, report = inj.prepare(features.reset_index(drop=True), seed=seed)
    report.update(source_rows=int(len(features)), normal_class_only=True)
    return carrier, report


def x_load_carrier__mutmut_13(job: dict[str, Any], seed: int = 0) -> tuple[pd.DataFrame, dict[str, Any]]:
    if job["source"] == "uci":
        return tr.load_carrier(job["XXmetaXX"], Path(job["path"]), seed)
    data = np.load(job["path"])
    features = pd.DataFrame(data["X"]).add_prefix("f")[np.asarray(data["y"]).astype(int) == 0]
    carrier, report = inj.prepare(features.reset_index(drop=True), seed=seed)
    report.update(source_rows=int(len(features)), normal_class_only=True)
    return carrier, report


def x_load_carrier__mutmut_14(job: dict[str, Any], seed: int = 0) -> tuple[pd.DataFrame, dict[str, Any]]:
    if job["source"] == "uci":
        return tr.load_carrier(job["META"], Path(job["path"]), seed)
    data = np.load(job["path"])
    features = pd.DataFrame(data["X"]).add_prefix("f")[np.asarray(data["y"]).astype(int) == 0]
    carrier, report = inj.prepare(features.reset_index(drop=True), seed=seed)
    report.update(source_rows=int(len(features)), normal_class_only=True)
    return carrier, report


def x_load_carrier__mutmut_15(job: dict[str, Any], seed: int = 0) -> tuple[pd.DataFrame, dict[str, Any]]:
    if job["source"] == "uci":
        return tr.load_carrier(job["meta"], Path(None), seed)
    data = np.load(job["path"])
    features = pd.DataFrame(data["X"]).add_prefix("f")[np.asarray(data["y"]).astype(int) == 0]
    carrier, report = inj.prepare(features.reset_index(drop=True), seed=seed)
    report.update(source_rows=int(len(features)), normal_class_only=True)
    return carrier, report


def x_load_carrier__mutmut_16(job: dict[str, Any], seed: int = 0) -> tuple[pd.DataFrame, dict[str, Any]]:
    if job["source"] == "uci":
        return tr.load_carrier(job["meta"], Path(job["XXpathXX"]), seed)
    data = np.load(job["path"])
    features = pd.DataFrame(data["X"]).add_prefix("f")[np.asarray(data["y"]).astype(int) == 0]
    carrier, report = inj.prepare(features.reset_index(drop=True), seed=seed)
    report.update(source_rows=int(len(features)), normal_class_only=True)
    return carrier, report


def x_load_carrier__mutmut_17(job: dict[str, Any], seed: int = 0) -> tuple[pd.DataFrame, dict[str, Any]]:
    if job["source"] == "uci":
        return tr.load_carrier(job["meta"], Path(job["PATH"]), seed)
    data = np.load(job["path"])
    features = pd.DataFrame(data["X"]).add_prefix("f")[np.asarray(data["y"]).astype(int) == 0]
    carrier, report = inj.prepare(features.reset_index(drop=True), seed=seed)
    report.update(source_rows=int(len(features)), normal_class_only=True)
    return carrier, report


def x_load_carrier__mutmut_18(job: dict[str, Any], seed: int = 0) -> tuple[pd.DataFrame, dict[str, Any]]:
    if job["source"] == "uci":
        return tr.load_carrier(job["meta"], Path(job["path"]), seed)
    data = None
    features = pd.DataFrame(data["X"]).add_prefix("f")[np.asarray(data["y"]).astype(int) == 0]
    carrier, report = inj.prepare(features.reset_index(drop=True), seed=seed)
    report.update(source_rows=int(len(features)), normal_class_only=True)
    return carrier, report


def x_load_carrier__mutmut_19(job: dict[str, Any], seed: int = 0) -> tuple[pd.DataFrame, dict[str, Any]]:
    if job["source"] == "uci":
        return tr.load_carrier(job["meta"], Path(job["path"]), seed)
    data = np.load(None)
    features = pd.DataFrame(data["X"]).add_prefix("f")[np.asarray(data["y"]).astype(int) == 0]
    carrier, report = inj.prepare(features.reset_index(drop=True), seed=seed)
    report.update(source_rows=int(len(features)), normal_class_only=True)
    return carrier, report


def x_load_carrier__mutmut_20(job: dict[str, Any], seed: int = 0) -> tuple[pd.DataFrame, dict[str, Any]]:
    if job["source"] == "uci":
        return tr.load_carrier(job["meta"], Path(job["path"]), seed)
    data = np.load(job["XXpathXX"])
    features = pd.DataFrame(data["X"]).add_prefix("f")[np.asarray(data["y"]).astype(int) == 0]
    carrier, report = inj.prepare(features.reset_index(drop=True), seed=seed)
    report.update(source_rows=int(len(features)), normal_class_only=True)
    return carrier, report


def x_load_carrier__mutmut_21(job: dict[str, Any], seed: int = 0) -> tuple[pd.DataFrame, dict[str, Any]]:
    if job["source"] == "uci":
        return tr.load_carrier(job["meta"], Path(job["path"]), seed)
    data = np.load(job["PATH"])
    features = pd.DataFrame(data["X"]).add_prefix("f")[np.asarray(data["y"]).astype(int) == 0]
    carrier, report = inj.prepare(features.reset_index(drop=True), seed=seed)
    report.update(source_rows=int(len(features)), normal_class_only=True)
    return carrier, report


def x_load_carrier__mutmut_22(job: dict[str, Any], seed: int = 0) -> tuple[pd.DataFrame, dict[str, Any]]:
    if job["source"] == "uci":
        return tr.load_carrier(job["meta"], Path(job["path"]), seed)
    data = np.load(job["path"])
    features = None
    carrier, report = inj.prepare(features.reset_index(drop=True), seed=seed)
    report.update(source_rows=int(len(features)), normal_class_only=True)
    return carrier, report


def x_load_carrier__mutmut_23(job: dict[str, Any], seed: int = 0) -> tuple[pd.DataFrame, dict[str, Any]]:
    if job["source"] == "uci":
        return tr.load_carrier(job["meta"], Path(job["path"]), seed)
    data = np.load(job["path"])
    features = pd.DataFrame(data["X"]).add_prefix(None)[np.asarray(data["y"]).astype(int) == 0]
    carrier, report = inj.prepare(features.reset_index(drop=True), seed=seed)
    report.update(source_rows=int(len(features)), normal_class_only=True)
    return carrier, report


def x_load_carrier__mutmut_24(job: dict[str, Any], seed: int = 0) -> tuple[pd.DataFrame, dict[str, Any]]:
    if job["source"] == "uci":
        return tr.load_carrier(job["meta"], Path(job["path"]), seed)
    data = np.load(job["path"])
    features = pd.DataFrame(None).add_prefix("f")[np.asarray(data["y"]).astype(int) == 0]
    carrier, report = inj.prepare(features.reset_index(drop=True), seed=seed)
    report.update(source_rows=int(len(features)), normal_class_only=True)
    return carrier, report


def x_load_carrier__mutmut_25(job: dict[str, Any], seed: int = 0) -> tuple[pd.DataFrame, dict[str, Any]]:
    if job["source"] == "uci":
        return tr.load_carrier(job["meta"], Path(job["path"]), seed)
    data = np.load(job["path"])
    features = pd.DataFrame(data["XXXXX"]).add_prefix("f")[np.asarray(data["y"]).astype(int) == 0]
    carrier, report = inj.prepare(features.reset_index(drop=True), seed=seed)
    report.update(source_rows=int(len(features)), normal_class_only=True)
    return carrier, report


def x_load_carrier__mutmut_26(job: dict[str, Any], seed: int = 0) -> tuple[pd.DataFrame, dict[str, Any]]:
    if job["source"] == "uci":
        return tr.load_carrier(job["meta"], Path(job["path"]), seed)
    data = np.load(job["path"])
    features = pd.DataFrame(data["x"]).add_prefix("f")[np.asarray(data["y"]).astype(int) == 0]
    carrier, report = inj.prepare(features.reset_index(drop=True), seed=seed)
    report.update(source_rows=int(len(features)), normal_class_only=True)
    return carrier, report


def x_load_carrier__mutmut_27(job: dict[str, Any], seed: int = 0) -> tuple[pd.DataFrame, dict[str, Any]]:
    if job["source"] == "uci":
        return tr.load_carrier(job["meta"], Path(job["path"]), seed)
    data = np.load(job["path"])
    features = pd.DataFrame(data["X"]).add_prefix("XXfXX")[np.asarray(data["y"]).astype(int) == 0]
    carrier, report = inj.prepare(features.reset_index(drop=True), seed=seed)
    report.update(source_rows=int(len(features)), normal_class_only=True)
    return carrier, report


def x_load_carrier__mutmut_28(job: dict[str, Any], seed: int = 0) -> tuple[pd.DataFrame, dict[str, Any]]:
    if job["source"] == "uci":
        return tr.load_carrier(job["meta"], Path(job["path"]), seed)
    data = np.load(job["path"])
    features = pd.DataFrame(data["X"]).add_prefix("F")[np.asarray(data["y"]).astype(int) == 0]
    carrier, report = inj.prepare(features.reset_index(drop=True), seed=seed)
    report.update(source_rows=int(len(features)), normal_class_only=True)
    return carrier, report


def x_load_carrier__mutmut_29(job: dict[str, Any], seed: int = 0) -> tuple[pd.DataFrame, dict[str, Any]]:
    if job["source"] == "uci":
        return tr.load_carrier(job["meta"], Path(job["path"]), seed)
    data = np.load(job["path"])
    features = pd.DataFrame(data["X"]).add_prefix("f")[np.asarray(data["y"]).astype(None) == 0]
    carrier, report = inj.prepare(features.reset_index(drop=True), seed=seed)
    report.update(source_rows=int(len(features)), normal_class_only=True)
    return carrier, report


def x_load_carrier__mutmut_30(job: dict[str, Any], seed: int = 0) -> tuple[pd.DataFrame, dict[str, Any]]:
    if job["source"] == "uci":
        return tr.load_carrier(job["meta"], Path(job["path"]), seed)
    data = np.load(job["path"])
    features = pd.DataFrame(data["X"]).add_prefix("f")[np.asarray(None).astype(int) == 0]
    carrier, report = inj.prepare(features.reset_index(drop=True), seed=seed)
    report.update(source_rows=int(len(features)), normal_class_only=True)
    return carrier, report


def x_load_carrier__mutmut_31(job: dict[str, Any], seed: int = 0) -> tuple[pd.DataFrame, dict[str, Any]]:
    if job["source"] == "uci":
        return tr.load_carrier(job["meta"], Path(job["path"]), seed)
    data = np.load(job["path"])
    features = pd.DataFrame(data["X"]).add_prefix("f")[np.asarray(data["XXyXX"]).astype(int) == 0]
    carrier, report = inj.prepare(features.reset_index(drop=True), seed=seed)
    report.update(source_rows=int(len(features)), normal_class_only=True)
    return carrier, report


def x_load_carrier__mutmut_32(job: dict[str, Any], seed: int = 0) -> tuple[pd.DataFrame, dict[str, Any]]:
    if job["source"] == "uci":
        return tr.load_carrier(job["meta"], Path(job["path"]), seed)
    data = np.load(job["path"])
    features = pd.DataFrame(data["X"]).add_prefix("f")[np.asarray(data["Y"]).astype(int) == 0]
    carrier, report = inj.prepare(features.reset_index(drop=True), seed=seed)
    report.update(source_rows=int(len(features)), normal_class_only=True)
    return carrier, report


def x_load_carrier__mutmut_33(job: dict[str, Any], seed: int = 0) -> tuple[pd.DataFrame, dict[str, Any]]:
    if job["source"] == "uci":
        return tr.load_carrier(job["meta"], Path(job["path"]), seed)
    data = np.load(job["path"])
    features = pd.DataFrame(data["X"]).add_prefix("f")[np.asarray(data["y"]).astype(int) != 0]
    carrier, report = inj.prepare(features.reset_index(drop=True), seed=seed)
    report.update(source_rows=int(len(features)), normal_class_only=True)
    return carrier, report


def x_load_carrier__mutmut_34(job: dict[str, Any], seed: int = 0) -> tuple[pd.DataFrame, dict[str, Any]]:
    if job["source"] == "uci":
        return tr.load_carrier(job["meta"], Path(job["path"]), seed)
    data = np.load(job["path"])
    features = pd.DataFrame(data["X"]).add_prefix("f")[np.asarray(data["y"]).astype(int) == 1]
    carrier, report = inj.prepare(features.reset_index(drop=True), seed=seed)
    report.update(source_rows=int(len(features)), normal_class_only=True)
    return carrier, report


def x_load_carrier__mutmut_35(job: dict[str, Any], seed: int = 0) -> tuple[pd.DataFrame, dict[str, Any]]:
    if job["source"] == "uci":
        return tr.load_carrier(job["meta"], Path(job["path"]), seed)
    data = np.load(job["path"])
    features = pd.DataFrame(data["X"]).add_prefix("f")[np.asarray(data["y"]).astype(int) == 0]
    carrier, report = None
    report.update(source_rows=int(len(features)), normal_class_only=True)
    return carrier, report


def x_load_carrier__mutmut_36(job: dict[str, Any], seed: int = 0) -> tuple[pd.DataFrame, dict[str, Any]]:
    if job["source"] == "uci":
        return tr.load_carrier(job["meta"], Path(job["path"]), seed)
    data = np.load(job["path"])
    features = pd.DataFrame(data["X"]).add_prefix("f")[np.asarray(data["y"]).astype(int) == 0]
    carrier, report = inj.prepare(None, seed=seed)
    report.update(source_rows=int(len(features)), normal_class_only=True)
    return carrier, report


def x_load_carrier__mutmut_37(job: dict[str, Any], seed: int = 0) -> tuple[pd.DataFrame, dict[str, Any]]:
    if job["source"] == "uci":
        return tr.load_carrier(job["meta"], Path(job["path"]), seed)
    data = np.load(job["path"])
    features = pd.DataFrame(data["X"]).add_prefix("f")[np.asarray(data["y"]).astype(int) == 0]
    carrier, report = inj.prepare(features.reset_index(drop=True), seed=None)
    report.update(source_rows=int(len(features)), normal_class_only=True)
    return carrier, report


def x_load_carrier__mutmut_38(job: dict[str, Any], seed: int = 0) -> tuple[pd.DataFrame, dict[str, Any]]:
    if job["source"] == "uci":
        return tr.load_carrier(job["meta"], Path(job["path"]), seed)
    data = np.load(job["path"])
    features = pd.DataFrame(data["X"]).add_prefix("f")[np.asarray(data["y"]).astype(int) == 0]
    carrier, report = inj.prepare(seed=seed)
    report.update(source_rows=int(len(features)), normal_class_only=True)
    return carrier, report


def x_load_carrier__mutmut_39(job: dict[str, Any], seed: int = 0) -> tuple[pd.DataFrame, dict[str, Any]]:
    if job["source"] == "uci":
        return tr.load_carrier(job["meta"], Path(job["path"]), seed)
    data = np.load(job["path"])
    features = pd.DataFrame(data["X"]).add_prefix("f")[np.asarray(data["y"]).astype(int) == 0]
    carrier, report = inj.prepare(features.reset_index(drop=True), )
    report.update(source_rows=int(len(features)), normal_class_only=True)
    return carrier, report


def x_load_carrier__mutmut_40(job: dict[str, Any], seed: int = 0) -> tuple[pd.DataFrame, dict[str, Any]]:
    if job["source"] == "uci":
        return tr.load_carrier(job["meta"], Path(job["path"]), seed)
    data = np.load(job["path"])
    features = pd.DataFrame(data["X"]).add_prefix("f")[np.asarray(data["y"]).astype(int) == 0]
    carrier, report = inj.prepare(features.reset_index(drop=None), seed=seed)
    report.update(source_rows=int(len(features)), normal_class_only=True)
    return carrier, report


def x_load_carrier__mutmut_41(job: dict[str, Any], seed: int = 0) -> tuple[pd.DataFrame, dict[str, Any]]:
    if job["source"] == "uci":
        return tr.load_carrier(job["meta"], Path(job["path"]), seed)
    data = np.load(job["path"])
    features = pd.DataFrame(data["X"]).add_prefix("f")[np.asarray(data["y"]).astype(int) == 0]
    carrier, report = inj.prepare(features.reset_index(drop=False), seed=seed)
    report.update(source_rows=int(len(features)), normal_class_only=True)
    return carrier, report


def x_load_carrier__mutmut_42(job: dict[str, Any], seed: int = 0) -> tuple[pd.DataFrame, dict[str, Any]]:
    if job["source"] == "uci":
        return tr.load_carrier(job["meta"], Path(job["path"]), seed)
    data = np.load(job["path"])
    features = pd.DataFrame(data["X"]).add_prefix("f")[np.asarray(data["y"]).astype(int) == 0]
    carrier, report = inj.prepare(features.reset_index(drop=True), seed=seed)
    report.update(source_rows=None, normal_class_only=True)
    return carrier, report


def x_load_carrier__mutmut_43(job: dict[str, Any], seed: int = 0) -> tuple[pd.DataFrame, dict[str, Any]]:
    if job["source"] == "uci":
        return tr.load_carrier(job["meta"], Path(job["path"]), seed)
    data = np.load(job["path"])
    features = pd.DataFrame(data["X"]).add_prefix("f")[np.asarray(data["y"]).astype(int) == 0]
    carrier, report = inj.prepare(features.reset_index(drop=True), seed=seed)
    report.update(source_rows=int(len(features)), normal_class_only=None)
    return carrier, report


def x_load_carrier__mutmut_44(job: dict[str, Any], seed: int = 0) -> tuple[pd.DataFrame, dict[str, Any]]:
    if job["source"] == "uci":
        return tr.load_carrier(job["meta"], Path(job["path"]), seed)
    data = np.load(job["path"])
    features = pd.DataFrame(data["X"]).add_prefix("f")[np.asarray(data["y"]).astype(int) == 0]
    carrier, report = inj.prepare(features.reset_index(drop=True), seed=seed)
    report.update(normal_class_only=True)
    return carrier, report


def x_load_carrier__mutmut_45(job: dict[str, Any], seed: int = 0) -> tuple[pd.DataFrame, dict[str, Any]]:
    if job["source"] == "uci":
        return tr.load_carrier(job["meta"], Path(job["path"]), seed)
    data = np.load(job["path"])
    features = pd.DataFrame(data["X"]).add_prefix("f")[np.asarray(data["y"]).astype(int) == 0]
    carrier, report = inj.prepare(features.reset_index(drop=True), seed=seed)
    report.update(source_rows=int(len(features)), )
    return carrier, report


def x_load_carrier__mutmut_46(job: dict[str, Any], seed: int = 0) -> tuple[pd.DataFrame, dict[str, Any]]:
    if job["source"] == "uci":
        return tr.load_carrier(job["meta"], Path(job["path"]), seed)
    data = np.load(job["path"])
    features = pd.DataFrame(data["X"]).add_prefix("f")[np.asarray(data["y"]).astype(int) == 0]
    carrier, report = inj.prepare(features.reset_index(drop=True), seed=seed)
    report.update(source_rows=int(None), normal_class_only=True)
    return carrier, report


def x_load_carrier__mutmut_47(job: dict[str, Any], seed: int = 0) -> tuple[pd.DataFrame, dict[str, Any]]:
    if job["source"] == "uci":
        return tr.load_carrier(job["meta"], Path(job["path"]), seed)
    data = np.load(job["path"])
    features = pd.DataFrame(data["X"]).add_prefix("f")[np.asarray(data["y"]).astype(int) == 0]
    carrier, report = inj.prepare(features.reset_index(drop=True), seed=seed)
    report.update(source_rows=int(len(features)), normal_class_only=False)
    return carrier, report

mutants_x_load_carrier__mutmut['_mutmut_orig'] = x_load_carrier__mutmut_orig # type: ignore # mutmut generated
mutants_x_load_carrier__mutmut['x_load_carrier__mutmut_1'] = x_load_carrier__mutmut_1 # type: ignore # mutmut generated
mutants_x_load_carrier__mutmut['x_load_carrier__mutmut_2'] = x_load_carrier__mutmut_2 # type: ignore # mutmut generated
mutants_x_load_carrier__mutmut['x_load_carrier__mutmut_3'] = x_load_carrier__mutmut_3 # type: ignore # mutmut generated
mutants_x_load_carrier__mutmut['x_load_carrier__mutmut_4'] = x_load_carrier__mutmut_4 # type: ignore # mutmut generated
mutants_x_load_carrier__mutmut['x_load_carrier__mutmut_5'] = x_load_carrier__mutmut_5 # type: ignore # mutmut generated
mutants_x_load_carrier__mutmut['x_load_carrier__mutmut_6'] = x_load_carrier__mutmut_6 # type: ignore # mutmut generated
mutants_x_load_carrier__mutmut['x_load_carrier__mutmut_7'] = x_load_carrier__mutmut_7 # type: ignore # mutmut generated
mutants_x_load_carrier__mutmut['x_load_carrier__mutmut_8'] = x_load_carrier__mutmut_8 # type: ignore # mutmut generated
mutants_x_load_carrier__mutmut['x_load_carrier__mutmut_9'] = x_load_carrier__mutmut_9 # type: ignore # mutmut generated
mutants_x_load_carrier__mutmut['x_load_carrier__mutmut_10'] = x_load_carrier__mutmut_10 # type: ignore # mutmut generated
mutants_x_load_carrier__mutmut['x_load_carrier__mutmut_11'] = x_load_carrier__mutmut_11 # type: ignore # mutmut generated
mutants_x_load_carrier__mutmut['x_load_carrier__mutmut_12'] = x_load_carrier__mutmut_12 # type: ignore # mutmut generated
mutants_x_load_carrier__mutmut['x_load_carrier__mutmut_13'] = x_load_carrier__mutmut_13 # type: ignore # mutmut generated
mutants_x_load_carrier__mutmut['x_load_carrier__mutmut_14'] = x_load_carrier__mutmut_14 # type: ignore # mutmut generated
mutants_x_load_carrier__mutmut['x_load_carrier__mutmut_15'] = x_load_carrier__mutmut_15 # type: ignore # mutmut generated
mutants_x_load_carrier__mutmut['x_load_carrier__mutmut_16'] = x_load_carrier__mutmut_16 # type: ignore # mutmut generated
mutants_x_load_carrier__mutmut['x_load_carrier__mutmut_17'] = x_load_carrier__mutmut_17 # type: ignore # mutmut generated
mutants_x_load_carrier__mutmut['x_load_carrier__mutmut_18'] = x_load_carrier__mutmut_18 # type: ignore # mutmut generated
mutants_x_load_carrier__mutmut['x_load_carrier__mutmut_19'] = x_load_carrier__mutmut_19 # type: ignore # mutmut generated
mutants_x_load_carrier__mutmut['x_load_carrier__mutmut_20'] = x_load_carrier__mutmut_20 # type: ignore # mutmut generated
mutants_x_load_carrier__mutmut['x_load_carrier__mutmut_21'] = x_load_carrier__mutmut_21 # type: ignore # mutmut generated
mutants_x_load_carrier__mutmut['x_load_carrier__mutmut_22'] = x_load_carrier__mutmut_22 # type: ignore # mutmut generated
mutants_x_load_carrier__mutmut['x_load_carrier__mutmut_23'] = x_load_carrier__mutmut_23 # type: ignore # mutmut generated
mutants_x_load_carrier__mutmut['x_load_carrier__mutmut_24'] = x_load_carrier__mutmut_24 # type: ignore # mutmut generated
mutants_x_load_carrier__mutmut['x_load_carrier__mutmut_25'] = x_load_carrier__mutmut_25 # type: ignore # mutmut generated
mutants_x_load_carrier__mutmut['x_load_carrier__mutmut_26'] = x_load_carrier__mutmut_26 # type: ignore # mutmut generated
mutants_x_load_carrier__mutmut['x_load_carrier__mutmut_27'] = x_load_carrier__mutmut_27 # type: ignore # mutmut generated
mutants_x_load_carrier__mutmut['x_load_carrier__mutmut_28'] = x_load_carrier__mutmut_28 # type: ignore # mutmut generated
mutants_x_load_carrier__mutmut['x_load_carrier__mutmut_29'] = x_load_carrier__mutmut_29 # type: ignore # mutmut generated
mutants_x_load_carrier__mutmut['x_load_carrier__mutmut_30'] = x_load_carrier__mutmut_30 # type: ignore # mutmut generated
mutants_x_load_carrier__mutmut['x_load_carrier__mutmut_31'] = x_load_carrier__mutmut_31 # type: ignore # mutmut generated
mutants_x_load_carrier__mutmut['x_load_carrier__mutmut_32'] = x_load_carrier__mutmut_32 # type: ignore # mutmut generated
mutants_x_load_carrier__mutmut['x_load_carrier__mutmut_33'] = x_load_carrier__mutmut_33 # type: ignore # mutmut generated
mutants_x_load_carrier__mutmut['x_load_carrier__mutmut_34'] = x_load_carrier__mutmut_34 # type: ignore # mutmut generated
mutants_x_load_carrier__mutmut['x_load_carrier__mutmut_35'] = x_load_carrier__mutmut_35 # type: ignore # mutmut generated
mutants_x_load_carrier__mutmut['x_load_carrier__mutmut_36'] = x_load_carrier__mutmut_36 # type: ignore # mutmut generated
mutants_x_load_carrier__mutmut['x_load_carrier__mutmut_37'] = x_load_carrier__mutmut_37 # type: ignore # mutmut generated
mutants_x_load_carrier__mutmut['x_load_carrier__mutmut_38'] = x_load_carrier__mutmut_38 # type: ignore # mutmut generated
mutants_x_load_carrier__mutmut['x_load_carrier__mutmut_39'] = x_load_carrier__mutmut_39 # type: ignore # mutmut generated
mutants_x_load_carrier__mutmut['x_load_carrier__mutmut_40'] = x_load_carrier__mutmut_40 # type: ignore # mutmut generated
mutants_x_load_carrier__mutmut['x_load_carrier__mutmut_41'] = x_load_carrier__mutmut_41 # type: ignore # mutmut generated
mutants_x_load_carrier__mutmut['x_load_carrier__mutmut_42'] = x_load_carrier__mutmut_42 # type: ignore # mutmut generated
mutants_x_load_carrier__mutmut['x_load_carrier__mutmut_43'] = x_load_carrier__mutmut_43 # type: ignore # mutmut generated
mutants_x_load_carrier__mutmut['x_load_carrier__mutmut_44'] = x_load_carrier__mutmut_44 # type: ignore # mutmut generated
mutants_x_load_carrier__mutmut['x_load_carrier__mutmut_45'] = x_load_carrier__mutmut_45 # type: ignore # mutmut generated
mutants_x_load_carrier__mutmut['x_load_carrier__mutmut_46'] = x_load_carrier__mutmut_46 # type: ignore # mutmut generated
mutants_x_load_carrier__mutmut['x_load_carrier__mutmut_47'] = x_load_carrier__mutmut_47 # type: ignore # mutmut generated
mutants_x_eligibility__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_eligibility__mutmut)
def eligibility(job: dict[str, Any]) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    row = {"id": job["id"], "name": job["name"], "source": job["source"]}
    try:
        carrier, report = load_carrier(job)
    except inj.NotEligible as reason:
        return {**row, "eligible": False, "reason": str(reason)}
    except Exception as error:  # recorded, not hidden
        return {**row, "eligible": False, "reason": f"load failed: {error!r}"}
    return {**row, "eligible": True, "rows": int(len(carrier)), "report": report}


def x_eligibility__mutmut_orig(job: dict[str, Any]) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    row = {"id": job["id"], "name": job["name"], "source": job["source"]}
    try:
        carrier, report = load_carrier(job)
    except inj.NotEligible as reason:
        return {**row, "eligible": False, "reason": str(reason)}
    except Exception as error:  # recorded, not hidden
        return {**row, "eligible": False, "reason": f"load failed: {error!r}"}
    return {**row, "eligible": True, "rows": int(len(carrier)), "report": report}


def x_eligibility__mutmut_1(job: dict[str, Any]) -> dict[str, Any]:
    warnings.filterwarnings(None)
    row = {"id": job["id"], "name": job["name"], "source": job["source"]}
    try:
        carrier, report = load_carrier(job)
    except inj.NotEligible as reason:
        return {**row, "eligible": False, "reason": str(reason)}
    except Exception as error:  # recorded, not hidden
        return {**row, "eligible": False, "reason": f"load failed: {error!r}"}
    return {**row, "eligible": True, "rows": int(len(carrier)), "report": report}


def x_eligibility__mutmut_2(job: dict[str, Any]) -> dict[str, Any]:
    warnings.filterwarnings("XXignoreXX")
    row = {"id": job["id"], "name": job["name"], "source": job["source"]}
    try:
        carrier, report = load_carrier(job)
    except inj.NotEligible as reason:
        return {**row, "eligible": False, "reason": str(reason)}
    except Exception as error:  # recorded, not hidden
        return {**row, "eligible": False, "reason": f"load failed: {error!r}"}
    return {**row, "eligible": True, "rows": int(len(carrier)), "report": report}


def x_eligibility__mutmut_3(job: dict[str, Any]) -> dict[str, Any]:
    warnings.filterwarnings("IGNORE")
    row = {"id": job["id"], "name": job["name"], "source": job["source"]}
    try:
        carrier, report = load_carrier(job)
    except inj.NotEligible as reason:
        return {**row, "eligible": False, "reason": str(reason)}
    except Exception as error:  # recorded, not hidden
        return {**row, "eligible": False, "reason": f"load failed: {error!r}"}
    return {**row, "eligible": True, "rows": int(len(carrier)), "report": report}


def x_eligibility__mutmut_4(job: dict[str, Any]) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    row = None
    try:
        carrier, report = load_carrier(job)
    except inj.NotEligible as reason:
        return {**row, "eligible": False, "reason": str(reason)}
    except Exception as error:  # recorded, not hidden
        return {**row, "eligible": False, "reason": f"load failed: {error!r}"}
    return {**row, "eligible": True, "rows": int(len(carrier)), "report": report}


def x_eligibility__mutmut_5(job: dict[str, Any]) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    row = {"XXidXX": job["id"], "name": job["name"], "source": job["source"]}
    try:
        carrier, report = load_carrier(job)
    except inj.NotEligible as reason:
        return {**row, "eligible": False, "reason": str(reason)}
    except Exception as error:  # recorded, not hidden
        return {**row, "eligible": False, "reason": f"load failed: {error!r}"}
    return {**row, "eligible": True, "rows": int(len(carrier)), "report": report}


def x_eligibility__mutmut_6(job: dict[str, Any]) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    row = {"ID": job["id"], "name": job["name"], "source": job["source"]}
    try:
        carrier, report = load_carrier(job)
    except inj.NotEligible as reason:
        return {**row, "eligible": False, "reason": str(reason)}
    except Exception as error:  # recorded, not hidden
        return {**row, "eligible": False, "reason": f"load failed: {error!r}"}
    return {**row, "eligible": True, "rows": int(len(carrier)), "report": report}


def x_eligibility__mutmut_7(job: dict[str, Any]) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    row = {"id": job["XXidXX"], "name": job["name"], "source": job["source"]}
    try:
        carrier, report = load_carrier(job)
    except inj.NotEligible as reason:
        return {**row, "eligible": False, "reason": str(reason)}
    except Exception as error:  # recorded, not hidden
        return {**row, "eligible": False, "reason": f"load failed: {error!r}"}
    return {**row, "eligible": True, "rows": int(len(carrier)), "report": report}


def x_eligibility__mutmut_8(job: dict[str, Any]) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    row = {"id": job["ID"], "name": job["name"], "source": job["source"]}
    try:
        carrier, report = load_carrier(job)
    except inj.NotEligible as reason:
        return {**row, "eligible": False, "reason": str(reason)}
    except Exception as error:  # recorded, not hidden
        return {**row, "eligible": False, "reason": f"load failed: {error!r}"}
    return {**row, "eligible": True, "rows": int(len(carrier)), "report": report}


def x_eligibility__mutmut_9(job: dict[str, Any]) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    row = {"id": job["id"], "XXnameXX": job["name"], "source": job["source"]}
    try:
        carrier, report = load_carrier(job)
    except inj.NotEligible as reason:
        return {**row, "eligible": False, "reason": str(reason)}
    except Exception as error:  # recorded, not hidden
        return {**row, "eligible": False, "reason": f"load failed: {error!r}"}
    return {**row, "eligible": True, "rows": int(len(carrier)), "report": report}


def x_eligibility__mutmut_10(job: dict[str, Any]) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    row = {"id": job["id"], "NAME": job["name"], "source": job["source"]}
    try:
        carrier, report = load_carrier(job)
    except inj.NotEligible as reason:
        return {**row, "eligible": False, "reason": str(reason)}
    except Exception as error:  # recorded, not hidden
        return {**row, "eligible": False, "reason": f"load failed: {error!r}"}
    return {**row, "eligible": True, "rows": int(len(carrier)), "report": report}


def x_eligibility__mutmut_11(job: dict[str, Any]) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    row = {"id": job["id"], "name": job["XXnameXX"], "source": job["source"]}
    try:
        carrier, report = load_carrier(job)
    except inj.NotEligible as reason:
        return {**row, "eligible": False, "reason": str(reason)}
    except Exception as error:  # recorded, not hidden
        return {**row, "eligible": False, "reason": f"load failed: {error!r}"}
    return {**row, "eligible": True, "rows": int(len(carrier)), "report": report}


def x_eligibility__mutmut_12(job: dict[str, Any]) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    row = {"id": job["id"], "name": job["NAME"], "source": job["source"]}
    try:
        carrier, report = load_carrier(job)
    except inj.NotEligible as reason:
        return {**row, "eligible": False, "reason": str(reason)}
    except Exception as error:  # recorded, not hidden
        return {**row, "eligible": False, "reason": f"load failed: {error!r}"}
    return {**row, "eligible": True, "rows": int(len(carrier)), "report": report}


def x_eligibility__mutmut_13(job: dict[str, Any]) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    row = {"id": job["id"], "name": job["name"], "XXsourceXX": job["source"]}
    try:
        carrier, report = load_carrier(job)
    except inj.NotEligible as reason:
        return {**row, "eligible": False, "reason": str(reason)}
    except Exception as error:  # recorded, not hidden
        return {**row, "eligible": False, "reason": f"load failed: {error!r}"}
    return {**row, "eligible": True, "rows": int(len(carrier)), "report": report}


def x_eligibility__mutmut_14(job: dict[str, Any]) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    row = {"id": job["id"], "name": job["name"], "SOURCE": job["source"]}
    try:
        carrier, report = load_carrier(job)
    except inj.NotEligible as reason:
        return {**row, "eligible": False, "reason": str(reason)}
    except Exception as error:  # recorded, not hidden
        return {**row, "eligible": False, "reason": f"load failed: {error!r}"}
    return {**row, "eligible": True, "rows": int(len(carrier)), "report": report}


def x_eligibility__mutmut_15(job: dict[str, Any]) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    row = {"id": job["id"], "name": job["name"], "source": job["XXsourceXX"]}
    try:
        carrier, report = load_carrier(job)
    except inj.NotEligible as reason:
        return {**row, "eligible": False, "reason": str(reason)}
    except Exception as error:  # recorded, not hidden
        return {**row, "eligible": False, "reason": f"load failed: {error!r}"}
    return {**row, "eligible": True, "rows": int(len(carrier)), "report": report}


def x_eligibility__mutmut_16(job: dict[str, Any]) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    row = {"id": job["id"], "name": job["name"], "source": job["SOURCE"]}
    try:
        carrier, report = load_carrier(job)
    except inj.NotEligible as reason:
        return {**row, "eligible": False, "reason": str(reason)}
    except Exception as error:  # recorded, not hidden
        return {**row, "eligible": False, "reason": f"load failed: {error!r}"}
    return {**row, "eligible": True, "rows": int(len(carrier)), "report": report}


def x_eligibility__mutmut_17(job: dict[str, Any]) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    row = {"id": job["id"], "name": job["name"], "source": job["source"]}
    try:
        carrier, report = None
    except inj.NotEligible as reason:
        return {**row, "eligible": False, "reason": str(reason)}
    except Exception as error:  # recorded, not hidden
        return {**row, "eligible": False, "reason": f"load failed: {error!r}"}
    return {**row, "eligible": True, "rows": int(len(carrier)), "report": report}


def x_eligibility__mutmut_18(job: dict[str, Any]) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    row = {"id": job["id"], "name": job["name"], "source": job["source"]}
    try:
        carrier, report = load_carrier(None)
    except inj.NotEligible as reason:
        return {**row, "eligible": False, "reason": str(reason)}
    except Exception as error:  # recorded, not hidden
        return {**row, "eligible": False, "reason": f"load failed: {error!r}"}
    return {**row, "eligible": True, "rows": int(len(carrier)), "report": report}


def x_eligibility__mutmut_19(job: dict[str, Any]) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    row = {"id": job["id"], "name": job["name"], "source": job["source"]}
    try:
        carrier, report = load_carrier(job)
    except inj.NotEligible as reason:
        return {**row, "XXeligibleXX": False, "reason": str(reason)}
    except Exception as error:  # recorded, not hidden
        return {**row, "eligible": False, "reason": f"load failed: {error!r}"}
    return {**row, "eligible": True, "rows": int(len(carrier)), "report": report}


def x_eligibility__mutmut_20(job: dict[str, Any]) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    row = {"id": job["id"], "name": job["name"], "source": job["source"]}
    try:
        carrier, report = load_carrier(job)
    except inj.NotEligible as reason:
        return {**row, "ELIGIBLE": False, "reason": str(reason)}
    except Exception as error:  # recorded, not hidden
        return {**row, "eligible": False, "reason": f"load failed: {error!r}"}
    return {**row, "eligible": True, "rows": int(len(carrier)), "report": report}


def x_eligibility__mutmut_21(job: dict[str, Any]) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    row = {"id": job["id"], "name": job["name"], "source": job["source"]}
    try:
        carrier, report = load_carrier(job)
    except inj.NotEligible as reason:
        return {**row, "eligible": True, "reason": str(reason)}
    except Exception as error:  # recorded, not hidden
        return {**row, "eligible": False, "reason": f"load failed: {error!r}"}
    return {**row, "eligible": True, "rows": int(len(carrier)), "report": report}


def x_eligibility__mutmut_22(job: dict[str, Any]) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    row = {"id": job["id"], "name": job["name"], "source": job["source"]}
    try:
        carrier, report = load_carrier(job)
    except inj.NotEligible as reason:
        return {**row, "eligible": False, "XXreasonXX": str(reason)}
    except Exception as error:  # recorded, not hidden
        return {**row, "eligible": False, "reason": f"load failed: {error!r}"}
    return {**row, "eligible": True, "rows": int(len(carrier)), "report": report}


def x_eligibility__mutmut_23(job: dict[str, Any]) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    row = {"id": job["id"], "name": job["name"], "source": job["source"]}
    try:
        carrier, report = load_carrier(job)
    except inj.NotEligible as reason:
        return {**row, "eligible": False, "REASON": str(reason)}
    except Exception as error:  # recorded, not hidden
        return {**row, "eligible": False, "reason": f"load failed: {error!r}"}
    return {**row, "eligible": True, "rows": int(len(carrier)), "report": report}


def x_eligibility__mutmut_24(job: dict[str, Any]) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    row = {"id": job["id"], "name": job["name"], "source": job["source"]}
    try:
        carrier, report = load_carrier(job)
    except inj.NotEligible as reason:
        return {**row, "eligible": False, "reason": str(None)}
    except Exception as error:  # recorded, not hidden
        return {**row, "eligible": False, "reason": f"load failed: {error!r}"}
    return {**row, "eligible": True, "rows": int(len(carrier)), "report": report}


def x_eligibility__mutmut_25(job: dict[str, Any]) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    row = {"id": job["id"], "name": job["name"], "source": job["source"]}
    try:
        carrier, report = load_carrier(job)
    except inj.NotEligible as reason:
        return {**row, "eligible": False, "reason": str(reason)}
    except Exception as error:  # recorded, not hidden
        return {**row, "XXeligibleXX": False, "reason": f"load failed: {error!r}"}
    return {**row, "eligible": True, "rows": int(len(carrier)), "report": report}


def x_eligibility__mutmut_26(job: dict[str, Any]) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    row = {"id": job["id"], "name": job["name"], "source": job["source"]}
    try:
        carrier, report = load_carrier(job)
    except inj.NotEligible as reason:
        return {**row, "eligible": False, "reason": str(reason)}
    except Exception as error:  # recorded, not hidden
        return {**row, "ELIGIBLE": False, "reason": f"load failed: {error!r}"}
    return {**row, "eligible": True, "rows": int(len(carrier)), "report": report}


def x_eligibility__mutmut_27(job: dict[str, Any]) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    row = {"id": job["id"], "name": job["name"], "source": job["source"]}
    try:
        carrier, report = load_carrier(job)
    except inj.NotEligible as reason:
        return {**row, "eligible": False, "reason": str(reason)}
    except Exception as error:  # recorded, not hidden
        return {**row, "eligible": True, "reason": f"load failed: {error!r}"}
    return {**row, "eligible": True, "rows": int(len(carrier)), "report": report}


def x_eligibility__mutmut_28(job: dict[str, Any]) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    row = {"id": job["id"], "name": job["name"], "source": job["source"]}
    try:
        carrier, report = load_carrier(job)
    except inj.NotEligible as reason:
        return {**row, "eligible": False, "reason": str(reason)}
    except Exception as error:  # recorded, not hidden
        return {**row, "eligible": False, "XXreasonXX": f"load failed: {error!r}"}
    return {**row, "eligible": True, "rows": int(len(carrier)), "report": report}


def x_eligibility__mutmut_29(job: dict[str, Any]) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    row = {"id": job["id"], "name": job["name"], "source": job["source"]}
    try:
        carrier, report = load_carrier(job)
    except inj.NotEligible as reason:
        return {**row, "eligible": False, "reason": str(reason)}
    except Exception as error:  # recorded, not hidden
        return {**row, "eligible": False, "REASON": f"load failed: {error!r}"}
    return {**row, "eligible": True, "rows": int(len(carrier)), "report": report}


def x_eligibility__mutmut_30(job: dict[str, Any]) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    row = {"id": job["id"], "name": job["name"], "source": job["source"]}
    try:
        carrier, report = load_carrier(job)
    except inj.NotEligible as reason:
        return {**row, "eligible": False, "reason": str(reason)}
    except Exception as error:  # recorded, not hidden
        return {**row, "eligible": False, "reason": f"load failed: {error!r}"}
    return {**row, "XXeligibleXX": True, "rows": int(len(carrier)), "report": report}


def x_eligibility__mutmut_31(job: dict[str, Any]) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    row = {"id": job["id"], "name": job["name"], "source": job["source"]}
    try:
        carrier, report = load_carrier(job)
    except inj.NotEligible as reason:
        return {**row, "eligible": False, "reason": str(reason)}
    except Exception as error:  # recorded, not hidden
        return {**row, "eligible": False, "reason": f"load failed: {error!r}"}
    return {**row, "ELIGIBLE": True, "rows": int(len(carrier)), "report": report}


def x_eligibility__mutmut_32(job: dict[str, Any]) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    row = {"id": job["id"], "name": job["name"], "source": job["source"]}
    try:
        carrier, report = load_carrier(job)
    except inj.NotEligible as reason:
        return {**row, "eligible": False, "reason": str(reason)}
    except Exception as error:  # recorded, not hidden
        return {**row, "eligible": False, "reason": f"load failed: {error!r}"}
    return {**row, "eligible": False, "rows": int(len(carrier)), "report": report}


def x_eligibility__mutmut_33(job: dict[str, Any]) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    row = {"id": job["id"], "name": job["name"], "source": job["source"]}
    try:
        carrier, report = load_carrier(job)
    except inj.NotEligible as reason:
        return {**row, "eligible": False, "reason": str(reason)}
    except Exception as error:  # recorded, not hidden
        return {**row, "eligible": False, "reason": f"load failed: {error!r}"}
    return {**row, "eligible": True, "XXrowsXX": int(len(carrier)), "report": report}


def x_eligibility__mutmut_34(job: dict[str, Any]) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    row = {"id": job["id"], "name": job["name"], "source": job["source"]}
    try:
        carrier, report = load_carrier(job)
    except inj.NotEligible as reason:
        return {**row, "eligible": False, "reason": str(reason)}
    except Exception as error:  # recorded, not hidden
        return {**row, "eligible": False, "reason": f"load failed: {error!r}"}
    return {**row, "eligible": True, "ROWS": int(len(carrier)), "report": report}


def x_eligibility__mutmut_35(job: dict[str, Any]) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    row = {"id": job["id"], "name": job["name"], "source": job["source"]}
    try:
        carrier, report = load_carrier(job)
    except inj.NotEligible as reason:
        return {**row, "eligible": False, "reason": str(reason)}
    except Exception as error:  # recorded, not hidden
        return {**row, "eligible": False, "reason": f"load failed: {error!r}"}
    return {**row, "eligible": True, "rows": int(None), "report": report}


def x_eligibility__mutmut_36(job: dict[str, Any]) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    row = {"id": job["id"], "name": job["name"], "source": job["source"]}
    try:
        carrier, report = load_carrier(job)
    except inj.NotEligible as reason:
        return {**row, "eligible": False, "reason": str(reason)}
    except Exception as error:  # recorded, not hidden
        return {**row, "eligible": False, "reason": f"load failed: {error!r}"}
    return {**row, "eligible": True, "rows": int(len(carrier)), "XXreportXX": report}


def x_eligibility__mutmut_37(job: dict[str, Any]) -> dict[str, Any]:
    warnings.filterwarnings("ignore")
    row = {"id": job["id"], "name": job["name"], "source": job["source"]}
    try:
        carrier, report = load_carrier(job)
    except inj.NotEligible as reason:
        return {**row, "eligible": False, "reason": str(reason)}
    except Exception as error:  # recorded, not hidden
        return {**row, "eligible": False, "reason": f"load failed: {error!r}"}
    return {**row, "eligible": True, "rows": int(len(carrier)), "REPORT": report}

mutants_x_eligibility__mutmut['_mutmut_orig'] = x_eligibility__mutmut_orig # type: ignore # mutmut generated
mutants_x_eligibility__mutmut['x_eligibility__mutmut_1'] = x_eligibility__mutmut_1 # type: ignore # mutmut generated
mutants_x_eligibility__mutmut['x_eligibility__mutmut_2'] = x_eligibility__mutmut_2 # type: ignore # mutmut generated
mutants_x_eligibility__mutmut['x_eligibility__mutmut_3'] = x_eligibility__mutmut_3 # type: ignore # mutmut generated
mutants_x_eligibility__mutmut['x_eligibility__mutmut_4'] = x_eligibility__mutmut_4 # type: ignore # mutmut generated
mutants_x_eligibility__mutmut['x_eligibility__mutmut_5'] = x_eligibility__mutmut_5 # type: ignore # mutmut generated
mutants_x_eligibility__mutmut['x_eligibility__mutmut_6'] = x_eligibility__mutmut_6 # type: ignore # mutmut generated
mutants_x_eligibility__mutmut['x_eligibility__mutmut_7'] = x_eligibility__mutmut_7 # type: ignore # mutmut generated
mutants_x_eligibility__mutmut['x_eligibility__mutmut_8'] = x_eligibility__mutmut_8 # type: ignore # mutmut generated
mutants_x_eligibility__mutmut['x_eligibility__mutmut_9'] = x_eligibility__mutmut_9 # type: ignore # mutmut generated
mutants_x_eligibility__mutmut['x_eligibility__mutmut_10'] = x_eligibility__mutmut_10 # type: ignore # mutmut generated
mutants_x_eligibility__mutmut['x_eligibility__mutmut_11'] = x_eligibility__mutmut_11 # type: ignore # mutmut generated
mutants_x_eligibility__mutmut['x_eligibility__mutmut_12'] = x_eligibility__mutmut_12 # type: ignore # mutmut generated
mutants_x_eligibility__mutmut['x_eligibility__mutmut_13'] = x_eligibility__mutmut_13 # type: ignore # mutmut generated
mutants_x_eligibility__mutmut['x_eligibility__mutmut_14'] = x_eligibility__mutmut_14 # type: ignore # mutmut generated
mutants_x_eligibility__mutmut['x_eligibility__mutmut_15'] = x_eligibility__mutmut_15 # type: ignore # mutmut generated
mutants_x_eligibility__mutmut['x_eligibility__mutmut_16'] = x_eligibility__mutmut_16 # type: ignore # mutmut generated
mutants_x_eligibility__mutmut['x_eligibility__mutmut_17'] = x_eligibility__mutmut_17 # type: ignore # mutmut generated
mutants_x_eligibility__mutmut['x_eligibility__mutmut_18'] = x_eligibility__mutmut_18 # type: ignore # mutmut generated
mutants_x_eligibility__mutmut['x_eligibility__mutmut_19'] = x_eligibility__mutmut_19 # type: ignore # mutmut generated
mutants_x_eligibility__mutmut['x_eligibility__mutmut_20'] = x_eligibility__mutmut_20 # type: ignore # mutmut generated
mutants_x_eligibility__mutmut['x_eligibility__mutmut_21'] = x_eligibility__mutmut_21 # type: ignore # mutmut generated
mutants_x_eligibility__mutmut['x_eligibility__mutmut_22'] = x_eligibility__mutmut_22 # type: ignore # mutmut generated
mutants_x_eligibility__mutmut['x_eligibility__mutmut_23'] = x_eligibility__mutmut_23 # type: ignore # mutmut generated
mutants_x_eligibility__mutmut['x_eligibility__mutmut_24'] = x_eligibility__mutmut_24 # type: ignore # mutmut generated
mutants_x_eligibility__mutmut['x_eligibility__mutmut_25'] = x_eligibility__mutmut_25 # type: ignore # mutmut generated
mutants_x_eligibility__mutmut['x_eligibility__mutmut_26'] = x_eligibility__mutmut_26 # type: ignore # mutmut generated
mutants_x_eligibility__mutmut['x_eligibility__mutmut_27'] = x_eligibility__mutmut_27 # type: ignore # mutmut generated
mutants_x_eligibility__mutmut['x_eligibility__mutmut_28'] = x_eligibility__mutmut_28 # type: ignore # mutmut generated
mutants_x_eligibility__mutmut['x_eligibility__mutmut_29'] = x_eligibility__mutmut_29 # type: ignore # mutmut generated
mutants_x_eligibility__mutmut['x_eligibility__mutmut_30'] = x_eligibility__mutmut_30 # type: ignore # mutmut generated
mutants_x_eligibility__mutmut['x_eligibility__mutmut_31'] = x_eligibility__mutmut_31 # type: ignore # mutmut generated
mutants_x_eligibility__mutmut['x_eligibility__mutmut_32'] = x_eligibility__mutmut_32 # type: ignore # mutmut generated
mutants_x_eligibility__mutmut['x_eligibility__mutmut_33'] = x_eligibility__mutmut_33 # type: ignore # mutmut generated
mutants_x_eligibility__mutmut['x_eligibility__mutmut_34'] = x_eligibility__mutmut_34 # type: ignore # mutmut generated
mutants_x_eligibility__mutmut['x_eligibility__mutmut_35'] = x_eligibility__mutmut_35 # type: ignore # mutmut generated
mutants_x_eligibility__mutmut['x_eligibility__mutmut_36'] = x_eligibility__mutmut_36 # type: ignore # mutmut generated
mutants_x_eligibility__mutmut['x_eligibility__mutmut_37'] = x_eligibility__mutmut_37 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_run_reference__mutmut)
def run_reference(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(inj.inject(carrier, seed=seed), cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    mean = pd.concat(recalls, keys=range(len(recalls))).groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(pd.concat(fprs, axis=1).mean(axis=1).to_json()),
    }


def x_run_reference__mutmut_orig(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(inj.inject(carrier, seed=seed), cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    mean = pd.concat(recalls, keys=range(len(recalls))).groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(pd.concat(fprs, axis=1).mean(axis=1).to_json()),
    }


def x_run_reference__mutmut_1(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings(None)
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(inj.inject(carrier, seed=seed), cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    mean = pd.concat(recalls, keys=range(len(recalls))).groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(pd.concat(fprs, axis=1).mean(axis=1).to_json()),
    }


def x_run_reference__mutmut_2(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("XXignoreXX")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(inj.inject(carrier, seed=seed), cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    mean = pd.concat(recalls, keys=range(len(recalls))).groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(pd.concat(fprs, axis=1).mean(axis=1).to_json()),
    }


def x_run_reference__mutmut_3(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("IGNORE")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(inj.inject(carrier, seed=seed), cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    mean = pd.concat(recalls, keys=range(len(recalls))).groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(pd.concat(fprs, axis=1).mean(axis=1).to_json()),
    }


def x_run_reference__mutmut_4(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = None
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(inj.inject(carrier, seed=seed), cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    mean = pd.concat(recalls, keys=range(len(recalls))).groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(pd.concat(fprs, axis=1).mean(axis=1).to_json()),
    }


def x_run_reference__mutmut_5(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(None)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(inj.inject(carrier, seed=seed), cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    mean = pd.concat(recalls, keys=range(len(recalls))).groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(pd.concat(fprs, axis=1).mean(axis=1).to_json()),
    }


def x_run_reference__mutmut_6(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = None
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(inj.inject(carrier, seed=seed), cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    mean = pd.concat(recalls, keys=range(len(recalls))).groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(pd.concat(fprs, axis=1).mean(axis=1).to_json()),
    }


def x_run_reference__mutmut_7(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(None)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(inj.inject(carrier, seed=seed), cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    mean = pd.concat(recalls, keys=range(len(recalls))).groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(pd.concat(fprs, axis=1).mean(axis=1).to_json()),
    }


def x_run_reference__mutmut_8(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    recalls, precisions, fprs = None
    for seed in SEEDS:
        result = tb.evaluate(inj.inject(carrier, seed=seed), cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    mean = pd.concat(recalls, keys=range(len(recalls))).groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(pd.concat(fprs, axis=1).mean(axis=1).to_json()),
    }


def x_run_reference__mutmut_9(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = None
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    mean = pd.concat(recalls, keys=range(len(recalls))).groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(pd.concat(fprs, axis=1).mean(axis=1).to_json()),
    }


def x_run_reference__mutmut_10(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(None, cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    mean = pd.concat(recalls, keys=range(len(recalls))).groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(pd.concat(fprs, axis=1).mean(axis=1).to_json()),
    }


def x_run_reference__mutmut_11(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(inj.inject(carrier, seed=seed), None, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    mean = pd.concat(recalls, keys=range(len(recalls))).groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(pd.concat(fprs, axis=1).mean(axis=1).to_json()),
    }


def x_run_reference__mutmut_12(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(inj.inject(carrier, seed=seed), cols, None, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    mean = pd.concat(recalls, keys=range(len(recalls))).groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(pd.concat(fprs, axis=1).mean(axis=1).to_json()),
    }


def x_run_reference__mutmut_13(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(inj.inject(carrier, seed=seed), cols, seed, None)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    mean = pd.concat(recalls, keys=range(len(recalls))).groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(pd.concat(fprs, axis=1).mean(axis=1).to_json()),
    }


def x_run_reference__mutmut_14(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    mean = pd.concat(recalls, keys=range(len(recalls))).groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(pd.concat(fprs, axis=1).mean(axis=1).to_json()),
    }


def x_run_reference__mutmut_15(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(inj.inject(carrier, seed=seed), seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    mean = pd.concat(recalls, keys=range(len(recalls))).groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(pd.concat(fprs, axis=1).mean(axis=1).to_json()),
    }


def x_run_reference__mutmut_16(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(inj.inject(carrier, seed=seed), cols, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    mean = pd.concat(recalls, keys=range(len(recalls))).groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(pd.concat(fprs, axis=1).mean(axis=1).to_json()),
    }


def x_run_reference__mutmut_17(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(inj.inject(carrier, seed=seed), cols, seed, )
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    mean = pd.concat(recalls, keys=range(len(recalls))).groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(pd.concat(fprs, axis=1).mean(axis=1).to_json()),
    }


def x_run_reference__mutmut_18(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(inj.inject(None, seed=seed), cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    mean = pd.concat(recalls, keys=range(len(recalls))).groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(pd.concat(fprs, axis=1).mean(axis=1).to_json()),
    }


def x_run_reference__mutmut_19(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(inj.inject(carrier, seed=None), cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    mean = pd.concat(recalls, keys=range(len(recalls))).groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(pd.concat(fprs, axis=1).mean(axis=1).to_json()),
    }


def x_run_reference__mutmut_20(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(inj.inject(seed=seed), cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    mean = pd.concat(recalls, keys=range(len(recalls))).groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(pd.concat(fprs, axis=1).mean(axis=1).to_json()),
    }


def x_run_reference__mutmut_21(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(inj.inject(carrier, ), cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    mean = pd.concat(recalls, keys=range(len(recalls))).groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(pd.concat(fprs, axis=1).mean(axis=1).to_json()),
    }


def x_run_reference__mutmut_22(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(inj.inject(carrier, seed=seed), cols, seed, names)
        recalls.append(None)
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    mean = pd.concat(recalls, keys=range(len(recalls))).groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(pd.concat(fprs, axis=1).mean(axis=1).to_json()),
    }


def x_run_reference__mutmut_23(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(inj.inject(carrier, seed=seed), cols, seed, names)
        recalls.append(result["XXrecallXX"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    mean = pd.concat(recalls, keys=range(len(recalls))).groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(pd.concat(fprs, axis=1).mean(axis=1).to_json()),
    }


def x_run_reference__mutmut_24(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(inj.inject(carrier, seed=seed), cols, seed, names)
        recalls.append(result["RECALL"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    mean = pd.concat(recalls, keys=range(len(recalls))).groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(pd.concat(fprs, axis=1).mean(axis=1).to_json()),
    }


def x_run_reference__mutmut_25(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(inj.inject(carrier, seed=seed), cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(None)
        fprs.append(result["fpr"])
    mean = pd.concat(recalls, keys=range(len(recalls))).groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(pd.concat(fprs, axis=1).mean(axis=1).to_json()),
    }


def x_run_reference__mutmut_26(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(inj.inject(carrier, seed=seed), cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["XXprecisionXX"])
        fprs.append(result["fpr"])
    mean = pd.concat(recalls, keys=range(len(recalls))).groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(pd.concat(fprs, axis=1).mean(axis=1).to_json()),
    }


def x_run_reference__mutmut_27(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(inj.inject(carrier, seed=seed), cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["PRECISION"])
        fprs.append(result["fpr"])
    mean = pd.concat(recalls, keys=range(len(recalls))).groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(pd.concat(fprs, axis=1).mean(axis=1).to_json()),
    }


def x_run_reference__mutmut_28(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(inj.inject(carrier, seed=seed), cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(None)
    mean = pd.concat(recalls, keys=range(len(recalls))).groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(pd.concat(fprs, axis=1).mean(axis=1).to_json()),
    }


def x_run_reference__mutmut_29(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(inj.inject(carrier, seed=seed), cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["XXfprXX"])
    mean = pd.concat(recalls, keys=range(len(recalls))).groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(pd.concat(fprs, axis=1).mean(axis=1).to_json()),
    }


def x_run_reference__mutmut_30(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(inj.inject(carrier, seed=seed), cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["FPR"])
    mean = pd.concat(recalls, keys=range(len(recalls))).groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(pd.concat(fprs, axis=1).mean(axis=1).to_json()),
    }


def x_run_reference__mutmut_31(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(inj.inject(carrier, seed=seed), cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    mean = None
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(pd.concat(fprs, axis=1).mean(axis=1).to_json()),
    }


def x_run_reference__mutmut_32(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(inj.inject(carrier, seed=seed), cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    mean = pd.concat(recalls, keys=range(len(recalls))).groupby(level=None, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(pd.concat(fprs, axis=1).mean(axis=1).to_json()),
    }


def x_run_reference__mutmut_33(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(inj.inject(carrier, seed=seed), cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    mean = pd.concat(recalls, keys=range(len(recalls))).groupby(level=1, sort=None).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(pd.concat(fprs, axis=1).mean(axis=1).to_json()),
    }


def x_run_reference__mutmut_34(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(inj.inject(carrier, seed=seed), cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    mean = pd.concat(recalls, keys=range(len(recalls))).groupby(sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(pd.concat(fprs, axis=1).mean(axis=1).to_json()),
    }


def x_run_reference__mutmut_35(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(inj.inject(carrier, seed=seed), cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    mean = pd.concat(recalls, keys=range(len(recalls))).groupby(level=1, ).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(pd.concat(fprs, axis=1).mean(axis=1).to_json()),
    }


def x_run_reference__mutmut_36(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(inj.inject(carrier, seed=seed), cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    mean = pd.concat(None, keys=range(len(recalls))).groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(pd.concat(fprs, axis=1).mean(axis=1).to_json()),
    }


def x_run_reference__mutmut_37(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(inj.inject(carrier, seed=seed), cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    mean = pd.concat(recalls, keys=None).groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(pd.concat(fprs, axis=1).mean(axis=1).to_json()),
    }


def x_run_reference__mutmut_38(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(inj.inject(carrier, seed=seed), cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    mean = pd.concat(keys=range(len(recalls))).groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(pd.concat(fprs, axis=1).mean(axis=1).to_json()),
    }


def x_run_reference__mutmut_39(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(inj.inject(carrier, seed=seed), cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    mean = pd.concat(recalls, ).groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(pd.concat(fprs, axis=1).mean(axis=1).to_json()),
    }


def x_run_reference__mutmut_40(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(inj.inject(carrier, seed=seed), cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    mean = pd.concat(recalls, keys=range(None)).groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(pd.concat(fprs, axis=1).mean(axis=1).to_json()),
    }


def x_run_reference__mutmut_41(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(inj.inject(carrier, seed=seed), cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    mean = pd.concat(recalls, keys=range(len(recalls))).groupby(level=2, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(pd.concat(fprs, axis=1).mean(axis=1).to_json()),
    }


def x_run_reference__mutmut_42(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(inj.inject(carrier, seed=seed), cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    mean = pd.concat(recalls, keys=range(len(recalls))).groupby(level=1, sort=True).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(pd.concat(fprs, axis=1).mean(axis=1).to_json()),
    }


def x_run_reference__mutmut_43(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(inj.inject(carrier, seed=seed), cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    mean = pd.concat(recalls, keys=range(len(recalls))).groupby(level=1, sort=False).mean()
    precision = None
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(pd.concat(fprs, axis=1).mean(axis=1).to_json()),
    }


def x_run_reference__mutmut_44(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(inj.inject(carrier, seed=seed), cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    mean = pd.concat(recalls, keys=range(len(recalls))).groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=None, sort=False).mean()
    )
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(pd.concat(fprs, axis=1).mean(axis=1).to_json()),
    }


def x_run_reference__mutmut_45(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(inj.inject(carrier, seed=seed), cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    mean = pd.concat(recalls, keys=range(len(recalls))).groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=None).mean()
    )
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(pd.concat(fprs, axis=1).mean(axis=1).to_json()),
    }


def x_run_reference__mutmut_46(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(inj.inject(carrier, seed=seed), cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    mean = pd.concat(recalls, keys=range(len(recalls))).groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(sort=False).mean()
    )
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(pd.concat(fprs, axis=1).mean(axis=1).to_json()),
    }


def x_run_reference__mutmut_47(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(inj.inject(carrier, seed=seed), cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    mean = pd.concat(recalls, keys=range(len(recalls))).groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, ).mean()
    )
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(pd.concat(fprs, axis=1).mean(axis=1).to_json()),
    }


def x_run_reference__mutmut_48(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(inj.inject(carrier, seed=seed), cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    mean = pd.concat(recalls, keys=range(len(recalls))).groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(None, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(pd.concat(fprs, axis=1).mean(axis=1).to_json()),
    }


def x_run_reference__mutmut_49(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(inj.inject(carrier, seed=seed), cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    mean = pd.concat(recalls, keys=range(len(recalls))).groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=None).groupby(level=1, sort=False).mean()
    )
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(pd.concat(fprs, axis=1).mean(axis=1).to_json()),
    }


def x_run_reference__mutmut_50(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(inj.inject(carrier, seed=seed), cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    mean = pd.concat(recalls, keys=range(len(recalls))).groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(pd.concat(fprs, axis=1).mean(axis=1).to_json()),
    }


def x_run_reference__mutmut_51(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(inj.inject(carrier, seed=seed), cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    mean = pd.concat(recalls, keys=range(len(recalls))).groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, ).groupby(level=1, sort=False).mean()
    )
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(pd.concat(fprs, axis=1).mean(axis=1).to_json()),
    }


def x_run_reference__mutmut_52(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(inj.inject(carrier, seed=seed), cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    mean = pd.concat(recalls, keys=range(len(recalls))).groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(None)).groupby(level=1, sort=False).mean()
    )
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(pd.concat(fprs, axis=1).mean(axis=1).to_json()),
    }


def x_run_reference__mutmut_53(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(inj.inject(carrier, seed=seed), cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    mean = pd.concat(recalls, keys=range(len(recalls))).groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=2, sort=False).mean()
    )
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(pd.concat(fprs, axis=1).mean(axis=1).to_json()),
    }


def x_run_reference__mutmut_54(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(inj.inject(carrier, seed=seed), cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    mean = pd.concat(recalls, keys=range(len(recalls))).groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=True).mean()
    )
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(pd.concat(fprs, axis=1).mean(axis=1).to_json()),
    }


def x_run_reference__mutmut_55(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(inj.inject(carrier, seed=seed), cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    mean = pd.concat(recalls, keys=range(len(recalls))).groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    return {
        "XXidXX": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(pd.concat(fprs, axis=1).mean(axis=1).to_json()),
    }


def x_run_reference__mutmut_56(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(inj.inject(carrier, seed=seed), cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    mean = pd.concat(recalls, keys=range(len(recalls))).groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    return {
        "ID": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(pd.concat(fprs, axis=1).mean(axis=1).to_json()),
    }


def x_run_reference__mutmut_57(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(inj.inject(carrier, seed=seed), cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    mean = pd.concat(recalls, keys=range(len(recalls))).groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    return {
        "id": job["XXidXX"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(pd.concat(fprs, axis=1).mean(axis=1).to_json()),
    }


def x_run_reference__mutmut_58(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(inj.inject(carrier, seed=seed), cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    mean = pd.concat(recalls, keys=range(len(recalls))).groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    return {
        "id": job["ID"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(pd.concat(fprs, axis=1).mean(axis=1).to_json()),
    }


def x_run_reference__mutmut_59(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(inj.inject(carrier, seed=seed), cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    mean = pd.concat(recalls, keys=range(len(recalls))).groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    return {
        "id": job["id"],
        "XXnameXX": job["name"],
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(pd.concat(fprs, axis=1).mean(axis=1).to_json()),
    }


def x_run_reference__mutmut_60(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(inj.inject(carrier, seed=seed), cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    mean = pd.concat(recalls, keys=range(len(recalls))).groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    return {
        "id": job["id"],
        "NAME": job["name"],
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(pd.concat(fprs, axis=1).mean(axis=1).to_json()),
    }


def x_run_reference__mutmut_61(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(inj.inject(carrier, seed=seed), cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    mean = pd.concat(recalls, keys=range(len(recalls))).groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    return {
        "id": job["id"],
        "name": job["XXnameXX"],
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(pd.concat(fprs, axis=1).mean(axis=1).to_json()),
    }


def x_run_reference__mutmut_62(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(inj.inject(carrier, seed=seed), cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    mean = pd.concat(recalls, keys=range(len(recalls))).groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    return {
        "id": job["id"],
        "name": job["NAME"],
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(pd.concat(fprs, axis=1).mean(axis=1).to_json()),
    }


def x_run_reference__mutmut_63(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(inj.inject(carrier, seed=seed), cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    mean = pd.concat(recalls, keys=range(len(recalls))).groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    return {
        "id": job["id"],
        "name": job["name"],
        "XXcarrierXX": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(pd.concat(fprs, axis=1).mean(axis=1).to_json()),
    }


def x_run_reference__mutmut_64(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(inj.inject(carrier, seed=seed), cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    mean = pd.concat(recalls, keys=range(len(recalls))).groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    return {
        "id": job["id"],
        "name": job["name"],
        "CARRIER": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(pd.concat(fprs, axis=1).mean(axis=1).to_json()),
    }


def x_run_reference__mutmut_65(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(inj.inject(carrier, seed=seed), cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    mean = pd.concat(recalls, keys=range(len(recalls))).groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "XXseedsXX": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(pd.concat(fprs, axis=1).mean(axis=1).to_json()),
    }


def x_run_reference__mutmut_66(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(inj.inject(carrier, seed=seed), cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    mean = pd.concat(recalls, keys=range(len(recalls))).groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "SEEDS": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(pd.concat(fprs, axis=1).mean(axis=1).to_json()),
    }


def x_run_reference__mutmut_67(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(inj.inject(carrier, seed=seed), cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    mean = pd.concat(recalls, keys=range(len(recalls))).groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(None),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(pd.concat(fprs, axis=1).mean(axis=1).to_json()),
    }


def x_run_reference__mutmut_68(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(inj.inject(carrier, seed=seed), cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    mean = pd.concat(recalls, keys=range(len(recalls))).groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(SEEDS),
        "XXrecall_meanXX": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(pd.concat(fprs, axis=1).mean(axis=1).to_json()),
    }


def x_run_reference__mutmut_69(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(inj.inject(carrier, seed=seed), cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    mean = pd.concat(recalls, keys=range(len(recalls))).groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(SEEDS),
        "RECALL_MEAN": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(pd.concat(fprs, axis=1).mean(axis=1).to_json()),
    }


def x_run_reference__mutmut_70(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(inj.inject(carrier, seed=seed), cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    mean = pd.concat(recalls, keys=range(len(recalls))).groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(None),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(pd.concat(fprs, axis=1).mean(axis=1).to_json()),
    }


def x_run_reference__mutmut_71(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(inj.inject(carrier, seed=seed), cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    mean = pd.concat(recalls, keys=range(len(recalls))).groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient=None)),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(pd.concat(fprs, axis=1).mean(axis=1).to_json()),
    }


def x_run_reference__mutmut_72(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(inj.inject(carrier, seed=seed), cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    mean = pd.concat(recalls, keys=range(len(recalls))).groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="XXsplitXX")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(pd.concat(fprs, axis=1).mean(axis=1).to_json()),
    }


def x_run_reference__mutmut_73(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(inj.inject(carrier, seed=seed), cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    mean = pd.concat(recalls, keys=range(len(recalls))).groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="SPLIT")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(pd.concat(fprs, axis=1).mean(axis=1).to_json()),
    }


def x_run_reference__mutmut_74(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(inj.inject(carrier, seed=seed), cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    mean = pd.concat(recalls, keys=range(len(recalls))).groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "XXprecision_meanXX": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(pd.concat(fprs, axis=1).mean(axis=1).to_json()),
    }


def x_run_reference__mutmut_75(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(inj.inject(carrier, seed=seed), cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    mean = pd.concat(recalls, keys=range(len(recalls))).groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "PRECISION_MEAN": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(pd.concat(fprs, axis=1).mean(axis=1).to_json()),
    }


def x_run_reference__mutmut_76(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(inj.inject(carrier, seed=seed), cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    mean = pd.concat(recalls, keys=range(len(recalls))).groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(None),
        "fpr_mean": json.loads(pd.concat(fprs, axis=1).mean(axis=1).to_json()),
    }


def x_run_reference__mutmut_77(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(inj.inject(carrier, seed=seed), cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    mean = pd.concat(recalls, keys=range(len(recalls))).groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient=None)),
        "fpr_mean": json.loads(pd.concat(fprs, axis=1).mean(axis=1).to_json()),
    }


def x_run_reference__mutmut_78(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(inj.inject(carrier, seed=seed), cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    mean = pd.concat(recalls, keys=range(len(recalls))).groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="XXsplitXX")),
        "fpr_mean": json.loads(pd.concat(fprs, axis=1).mean(axis=1).to_json()),
    }


def x_run_reference__mutmut_79(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(inj.inject(carrier, seed=seed), cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    mean = pd.concat(recalls, keys=range(len(recalls))).groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="SPLIT")),
        "fpr_mean": json.loads(pd.concat(fprs, axis=1).mean(axis=1).to_json()),
    }


def x_run_reference__mutmut_80(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(inj.inject(carrier, seed=seed), cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    mean = pd.concat(recalls, keys=range(len(recalls))).groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "XXfpr_meanXX": json.loads(pd.concat(fprs, axis=1).mean(axis=1).to_json()),
    }


def x_run_reference__mutmut_81(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(inj.inject(carrier, seed=seed), cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    mean = pd.concat(recalls, keys=range(len(recalls))).groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "FPR_MEAN": json.loads(pd.concat(fprs, axis=1).mean(axis=1).to_json()),
    }


def x_run_reference__mutmut_82(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(inj.inject(carrier, seed=seed), cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    mean = pd.concat(recalls, keys=range(len(recalls))).groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(None),
    }


def x_run_reference__mutmut_83(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(inj.inject(carrier, seed=seed), cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    mean = pd.concat(recalls, keys=range(len(recalls))).groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(pd.concat(fprs, axis=1).mean(axis=None).to_json()),
    }


def x_run_reference__mutmut_84(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(inj.inject(carrier, seed=seed), cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    mean = pd.concat(recalls, keys=range(len(recalls))).groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(pd.concat(None, axis=1).mean(axis=1).to_json()),
    }


def x_run_reference__mutmut_85(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(inj.inject(carrier, seed=seed), cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    mean = pd.concat(recalls, keys=range(len(recalls))).groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(pd.concat(fprs, axis=None).mean(axis=1).to_json()),
    }


def x_run_reference__mutmut_86(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(inj.inject(carrier, seed=seed), cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    mean = pd.concat(recalls, keys=range(len(recalls))).groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(pd.concat(axis=1).mean(axis=1).to_json()),
    }


def x_run_reference__mutmut_87(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(inj.inject(carrier, seed=seed), cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    mean = pd.concat(recalls, keys=range(len(recalls))).groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(pd.concat(fprs, ).mean(axis=1).to_json()),
    }


def x_run_reference__mutmut_88(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(inj.inject(carrier, seed=seed), cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    mean = pd.concat(recalls, keys=range(len(recalls))).groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(pd.concat(fprs, axis=2).mean(axis=1).to_json()),
    }


def x_run_reference__mutmut_89(job: dict[str, Any], names: list[str] | None = None) -> dict[str, Any]:
    """The five-seed typed run of ``typed_run.run_one`` on one carrier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    recalls, precisions, fprs = [], [], []
    for seed in SEEDS:
        result = tb.evaluate(inj.inject(carrier, seed=seed), cols, seed, names)
        recalls.append(result["recall"])
        precisions.append(result["precision"])
        fprs.append(result["fpr"])
    mean = pd.concat(recalls, keys=range(len(recalls))).groupby(level=1, sort=False).mean()
    precision = (
        pd.concat(precisions, keys=range(len(precisions))).groupby(level=1, sort=False).mean()
    )
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(SEEDS),
        "recall_mean": json.loads(mean.to_json(orient="split")),
        "precision_mean": json.loads(precision.to_json(orient="split")),
        "fpr_mean": json.loads(pd.concat(fprs, axis=1).mean(axis=2).to_json()),
    }

mutants_x_run_reference__mutmut['_mutmut_orig'] = x_run_reference__mutmut_orig # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_1'] = x_run_reference__mutmut_1 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_2'] = x_run_reference__mutmut_2 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_3'] = x_run_reference__mutmut_3 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_4'] = x_run_reference__mutmut_4 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_5'] = x_run_reference__mutmut_5 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_6'] = x_run_reference__mutmut_6 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_7'] = x_run_reference__mutmut_7 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_8'] = x_run_reference__mutmut_8 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_9'] = x_run_reference__mutmut_9 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_10'] = x_run_reference__mutmut_10 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_11'] = x_run_reference__mutmut_11 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_12'] = x_run_reference__mutmut_12 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_13'] = x_run_reference__mutmut_13 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_14'] = x_run_reference__mutmut_14 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_15'] = x_run_reference__mutmut_15 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_16'] = x_run_reference__mutmut_16 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_17'] = x_run_reference__mutmut_17 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_18'] = x_run_reference__mutmut_18 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_19'] = x_run_reference__mutmut_19 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_20'] = x_run_reference__mutmut_20 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_21'] = x_run_reference__mutmut_21 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_22'] = x_run_reference__mutmut_22 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_23'] = x_run_reference__mutmut_23 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_24'] = x_run_reference__mutmut_24 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_25'] = x_run_reference__mutmut_25 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_26'] = x_run_reference__mutmut_26 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_27'] = x_run_reference__mutmut_27 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_28'] = x_run_reference__mutmut_28 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_29'] = x_run_reference__mutmut_29 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_30'] = x_run_reference__mutmut_30 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_31'] = x_run_reference__mutmut_31 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_32'] = x_run_reference__mutmut_32 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_33'] = x_run_reference__mutmut_33 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_34'] = x_run_reference__mutmut_34 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_35'] = x_run_reference__mutmut_35 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_36'] = x_run_reference__mutmut_36 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_37'] = x_run_reference__mutmut_37 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_38'] = x_run_reference__mutmut_38 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_39'] = x_run_reference__mutmut_39 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_40'] = x_run_reference__mutmut_40 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_41'] = x_run_reference__mutmut_41 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_42'] = x_run_reference__mutmut_42 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_43'] = x_run_reference__mutmut_43 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_44'] = x_run_reference__mutmut_44 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_45'] = x_run_reference__mutmut_45 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_46'] = x_run_reference__mutmut_46 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_47'] = x_run_reference__mutmut_47 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_48'] = x_run_reference__mutmut_48 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_49'] = x_run_reference__mutmut_49 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_50'] = x_run_reference__mutmut_50 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_51'] = x_run_reference__mutmut_51 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_52'] = x_run_reference__mutmut_52 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_53'] = x_run_reference__mutmut_53 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_54'] = x_run_reference__mutmut_54 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_55'] = x_run_reference__mutmut_55 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_56'] = x_run_reference__mutmut_56 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_57'] = x_run_reference__mutmut_57 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_58'] = x_run_reference__mutmut_58 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_59'] = x_run_reference__mutmut_59 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_60'] = x_run_reference__mutmut_60 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_61'] = x_run_reference__mutmut_61 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_62'] = x_run_reference__mutmut_62 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_63'] = x_run_reference__mutmut_63 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_64'] = x_run_reference__mutmut_64 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_65'] = x_run_reference__mutmut_65 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_66'] = x_run_reference__mutmut_66 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_67'] = x_run_reference__mutmut_67 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_68'] = x_run_reference__mutmut_68 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_69'] = x_run_reference__mutmut_69 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_70'] = x_run_reference__mutmut_70 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_71'] = x_run_reference__mutmut_71 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_72'] = x_run_reference__mutmut_72 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_73'] = x_run_reference__mutmut_73 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_74'] = x_run_reference__mutmut_74 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_75'] = x_run_reference__mutmut_75 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_76'] = x_run_reference__mutmut_76 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_77'] = x_run_reference__mutmut_77 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_78'] = x_run_reference__mutmut_78 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_79'] = x_run_reference__mutmut_79 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_80'] = x_run_reference__mutmut_80 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_81'] = x_run_reference__mutmut_81 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_82'] = x_run_reference__mutmut_82 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_83'] = x_run_reference__mutmut_83 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_84'] = x_run_reference__mutmut_84 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_85'] = x_run_reference__mutmut_85 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_86'] = x_run_reference__mutmut_86 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_87'] = x_run_reference__mutmut_87 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_88'] = x_run_reference__mutmut_88 # type: ignore # mutmut generated
mutants_x_run_reference__mutmut['x_run_reference__mutmut_89'] = x_run_reference__mutmut_89 # type: ignore # mutmut generated
mutants_x_run_severity__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_run_severity__mutmut)
def run_severity(
    job: dict[str, Any],
    names: list[str] | None = None,
    severities: tuple[float, ...] = SEVERITIES,
    seeds: tuple[int, ...] = SWEEP_SEEDS,
) -> dict[str, Any]:
    """Mean recall by method and type at each severity multiplier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    by_severity: dict[str, Any] = {}
    for severity in severities:
        frames = [
            tb.evaluate(inj.inject(carrier, seed=seed, severity=severity), cols, seed, names)[
                "recall"
            ]
            for seed in seeds
        ]
        mean = pd.concat(frames, keys=range(len(frames))).groupby(level=1, sort=False).mean()
        by_severity[str(severity)] = json.loads(mean[list(MAGNITUDE_TYPES)].to_json(orient="split"))
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(seeds),
        "severities": list(severities),
        "recall_by_severity": by_severity,
    }


def x_run_severity__mutmut_orig(
    job: dict[str, Any],
    names: list[str] | None = None,
    severities: tuple[float, ...] = SEVERITIES,
    seeds: tuple[int, ...] = SWEEP_SEEDS,
) -> dict[str, Any]:
    """Mean recall by method and type at each severity multiplier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    by_severity: dict[str, Any] = {}
    for severity in severities:
        frames = [
            tb.evaluate(inj.inject(carrier, seed=seed, severity=severity), cols, seed, names)[
                "recall"
            ]
            for seed in seeds
        ]
        mean = pd.concat(frames, keys=range(len(frames))).groupby(level=1, sort=False).mean()
        by_severity[str(severity)] = json.loads(mean[list(MAGNITUDE_TYPES)].to_json(orient="split"))
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(seeds),
        "severities": list(severities),
        "recall_by_severity": by_severity,
    }


def x_run_severity__mutmut_1(
    job: dict[str, Any],
    names: list[str] | None = None,
    severities: tuple[float, ...] = SEVERITIES,
    seeds: tuple[int, ...] = SWEEP_SEEDS,
) -> dict[str, Any]:
    """Mean recall by method and type at each severity multiplier."""
    warnings.filterwarnings(None)
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    by_severity: dict[str, Any] = {}
    for severity in severities:
        frames = [
            tb.evaluate(inj.inject(carrier, seed=seed, severity=severity), cols, seed, names)[
                "recall"
            ]
            for seed in seeds
        ]
        mean = pd.concat(frames, keys=range(len(frames))).groupby(level=1, sort=False).mean()
        by_severity[str(severity)] = json.loads(mean[list(MAGNITUDE_TYPES)].to_json(orient="split"))
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(seeds),
        "severities": list(severities),
        "recall_by_severity": by_severity,
    }


def x_run_severity__mutmut_2(
    job: dict[str, Any],
    names: list[str] | None = None,
    severities: tuple[float, ...] = SEVERITIES,
    seeds: tuple[int, ...] = SWEEP_SEEDS,
) -> dict[str, Any]:
    """Mean recall by method and type at each severity multiplier."""
    warnings.filterwarnings("XXignoreXX")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    by_severity: dict[str, Any] = {}
    for severity in severities:
        frames = [
            tb.evaluate(inj.inject(carrier, seed=seed, severity=severity), cols, seed, names)[
                "recall"
            ]
            for seed in seeds
        ]
        mean = pd.concat(frames, keys=range(len(frames))).groupby(level=1, sort=False).mean()
        by_severity[str(severity)] = json.loads(mean[list(MAGNITUDE_TYPES)].to_json(orient="split"))
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(seeds),
        "severities": list(severities),
        "recall_by_severity": by_severity,
    }


def x_run_severity__mutmut_3(
    job: dict[str, Any],
    names: list[str] | None = None,
    severities: tuple[float, ...] = SEVERITIES,
    seeds: tuple[int, ...] = SWEEP_SEEDS,
) -> dict[str, Any]:
    """Mean recall by method and type at each severity multiplier."""
    warnings.filterwarnings("IGNORE")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    by_severity: dict[str, Any] = {}
    for severity in severities:
        frames = [
            tb.evaluate(inj.inject(carrier, seed=seed, severity=severity), cols, seed, names)[
                "recall"
            ]
            for seed in seeds
        ]
        mean = pd.concat(frames, keys=range(len(frames))).groupby(level=1, sort=False).mean()
        by_severity[str(severity)] = json.loads(mean[list(MAGNITUDE_TYPES)].to_json(orient="split"))
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(seeds),
        "severities": list(severities),
        "recall_by_severity": by_severity,
    }


def x_run_severity__mutmut_4(
    job: dict[str, Any],
    names: list[str] | None = None,
    severities: tuple[float, ...] = SEVERITIES,
    seeds: tuple[int, ...] = SWEEP_SEEDS,
) -> dict[str, Any]:
    """Mean recall by method and type at each severity multiplier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = None
    cols = list(carrier.columns)
    by_severity: dict[str, Any] = {}
    for severity in severities:
        frames = [
            tb.evaluate(inj.inject(carrier, seed=seed, severity=severity), cols, seed, names)[
                "recall"
            ]
            for seed in seeds
        ]
        mean = pd.concat(frames, keys=range(len(frames))).groupby(level=1, sort=False).mean()
        by_severity[str(severity)] = json.loads(mean[list(MAGNITUDE_TYPES)].to_json(orient="split"))
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(seeds),
        "severities": list(severities),
        "recall_by_severity": by_severity,
    }


def x_run_severity__mutmut_5(
    job: dict[str, Any],
    names: list[str] | None = None,
    severities: tuple[float, ...] = SEVERITIES,
    seeds: tuple[int, ...] = SWEEP_SEEDS,
) -> dict[str, Any]:
    """Mean recall by method and type at each severity multiplier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(None)
    cols = list(carrier.columns)
    by_severity: dict[str, Any] = {}
    for severity in severities:
        frames = [
            tb.evaluate(inj.inject(carrier, seed=seed, severity=severity), cols, seed, names)[
                "recall"
            ]
            for seed in seeds
        ]
        mean = pd.concat(frames, keys=range(len(frames))).groupby(level=1, sort=False).mean()
        by_severity[str(severity)] = json.loads(mean[list(MAGNITUDE_TYPES)].to_json(orient="split"))
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(seeds),
        "severities": list(severities),
        "recall_by_severity": by_severity,
    }


def x_run_severity__mutmut_6(
    job: dict[str, Any],
    names: list[str] | None = None,
    severities: tuple[float, ...] = SEVERITIES,
    seeds: tuple[int, ...] = SWEEP_SEEDS,
) -> dict[str, Any]:
    """Mean recall by method and type at each severity multiplier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = None
    by_severity: dict[str, Any] = {}
    for severity in severities:
        frames = [
            tb.evaluate(inj.inject(carrier, seed=seed, severity=severity), cols, seed, names)[
                "recall"
            ]
            for seed in seeds
        ]
        mean = pd.concat(frames, keys=range(len(frames))).groupby(level=1, sort=False).mean()
        by_severity[str(severity)] = json.loads(mean[list(MAGNITUDE_TYPES)].to_json(orient="split"))
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(seeds),
        "severities": list(severities),
        "recall_by_severity": by_severity,
    }


def x_run_severity__mutmut_7(
    job: dict[str, Any],
    names: list[str] | None = None,
    severities: tuple[float, ...] = SEVERITIES,
    seeds: tuple[int, ...] = SWEEP_SEEDS,
) -> dict[str, Any]:
    """Mean recall by method and type at each severity multiplier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(None)
    by_severity: dict[str, Any] = {}
    for severity in severities:
        frames = [
            tb.evaluate(inj.inject(carrier, seed=seed, severity=severity), cols, seed, names)[
                "recall"
            ]
            for seed in seeds
        ]
        mean = pd.concat(frames, keys=range(len(frames))).groupby(level=1, sort=False).mean()
        by_severity[str(severity)] = json.loads(mean[list(MAGNITUDE_TYPES)].to_json(orient="split"))
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(seeds),
        "severities": list(severities),
        "recall_by_severity": by_severity,
    }


def x_run_severity__mutmut_8(
    job: dict[str, Any],
    names: list[str] | None = None,
    severities: tuple[float, ...] = SEVERITIES,
    seeds: tuple[int, ...] = SWEEP_SEEDS,
) -> dict[str, Any]:
    """Mean recall by method and type at each severity multiplier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    by_severity: dict[str, Any] = None
    for severity in severities:
        frames = [
            tb.evaluate(inj.inject(carrier, seed=seed, severity=severity), cols, seed, names)[
                "recall"
            ]
            for seed in seeds
        ]
        mean = pd.concat(frames, keys=range(len(frames))).groupby(level=1, sort=False).mean()
        by_severity[str(severity)] = json.loads(mean[list(MAGNITUDE_TYPES)].to_json(orient="split"))
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(seeds),
        "severities": list(severities),
        "recall_by_severity": by_severity,
    }


def x_run_severity__mutmut_9(
    job: dict[str, Any],
    names: list[str] | None = None,
    severities: tuple[float, ...] = SEVERITIES,
    seeds: tuple[int, ...] = SWEEP_SEEDS,
) -> dict[str, Any]:
    """Mean recall by method and type at each severity multiplier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    by_severity: dict[str, Any] = {}
    for severity in severities:
        frames = None
        mean = pd.concat(frames, keys=range(len(frames))).groupby(level=1, sort=False).mean()
        by_severity[str(severity)] = json.loads(mean[list(MAGNITUDE_TYPES)].to_json(orient="split"))
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(seeds),
        "severities": list(severities),
        "recall_by_severity": by_severity,
    }


def x_run_severity__mutmut_10(
    job: dict[str, Any],
    names: list[str] | None = None,
    severities: tuple[float, ...] = SEVERITIES,
    seeds: tuple[int, ...] = SWEEP_SEEDS,
) -> dict[str, Any]:
    """Mean recall by method and type at each severity multiplier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    by_severity: dict[str, Any] = {}
    for severity in severities:
        frames = [
            tb.evaluate(None, cols, seed, names)[
                "recall"
            ]
            for seed in seeds
        ]
        mean = pd.concat(frames, keys=range(len(frames))).groupby(level=1, sort=False).mean()
        by_severity[str(severity)] = json.loads(mean[list(MAGNITUDE_TYPES)].to_json(orient="split"))
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(seeds),
        "severities": list(severities),
        "recall_by_severity": by_severity,
    }


def x_run_severity__mutmut_11(
    job: dict[str, Any],
    names: list[str] | None = None,
    severities: tuple[float, ...] = SEVERITIES,
    seeds: tuple[int, ...] = SWEEP_SEEDS,
) -> dict[str, Any]:
    """Mean recall by method and type at each severity multiplier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    by_severity: dict[str, Any] = {}
    for severity in severities:
        frames = [
            tb.evaluate(inj.inject(carrier, seed=seed, severity=severity), None, seed, names)[
                "recall"
            ]
            for seed in seeds
        ]
        mean = pd.concat(frames, keys=range(len(frames))).groupby(level=1, sort=False).mean()
        by_severity[str(severity)] = json.loads(mean[list(MAGNITUDE_TYPES)].to_json(orient="split"))
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(seeds),
        "severities": list(severities),
        "recall_by_severity": by_severity,
    }


def x_run_severity__mutmut_12(
    job: dict[str, Any],
    names: list[str] | None = None,
    severities: tuple[float, ...] = SEVERITIES,
    seeds: tuple[int, ...] = SWEEP_SEEDS,
) -> dict[str, Any]:
    """Mean recall by method and type at each severity multiplier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    by_severity: dict[str, Any] = {}
    for severity in severities:
        frames = [
            tb.evaluate(inj.inject(carrier, seed=seed, severity=severity), cols, None, names)[
                "recall"
            ]
            for seed in seeds
        ]
        mean = pd.concat(frames, keys=range(len(frames))).groupby(level=1, sort=False).mean()
        by_severity[str(severity)] = json.loads(mean[list(MAGNITUDE_TYPES)].to_json(orient="split"))
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(seeds),
        "severities": list(severities),
        "recall_by_severity": by_severity,
    }


def x_run_severity__mutmut_13(
    job: dict[str, Any],
    names: list[str] | None = None,
    severities: tuple[float, ...] = SEVERITIES,
    seeds: tuple[int, ...] = SWEEP_SEEDS,
) -> dict[str, Any]:
    """Mean recall by method and type at each severity multiplier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    by_severity: dict[str, Any] = {}
    for severity in severities:
        frames = [
            tb.evaluate(inj.inject(carrier, seed=seed, severity=severity), cols, seed, None)[
                "recall"
            ]
            for seed in seeds
        ]
        mean = pd.concat(frames, keys=range(len(frames))).groupby(level=1, sort=False).mean()
        by_severity[str(severity)] = json.loads(mean[list(MAGNITUDE_TYPES)].to_json(orient="split"))
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(seeds),
        "severities": list(severities),
        "recall_by_severity": by_severity,
    }


def x_run_severity__mutmut_14(
    job: dict[str, Any],
    names: list[str] | None = None,
    severities: tuple[float, ...] = SEVERITIES,
    seeds: tuple[int, ...] = SWEEP_SEEDS,
) -> dict[str, Any]:
    """Mean recall by method and type at each severity multiplier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    by_severity: dict[str, Any] = {}
    for severity in severities:
        frames = [
            tb.evaluate(cols, seed, names)[
                "recall"
            ]
            for seed in seeds
        ]
        mean = pd.concat(frames, keys=range(len(frames))).groupby(level=1, sort=False).mean()
        by_severity[str(severity)] = json.loads(mean[list(MAGNITUDE_TYPES)].to_json(orient="split"))
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(seeds),
        "severities": list(severities),
        "recall_by_severity": by_severity,
    }


def x_run_severity__mutmut_15(
    job: dict[str, Any],
    names: list[str] | None = None,
    severities: tuple[float, ...] = SEVERITIES,
    seeds: tuple[int, ...] = SWEEP_SEEDS,
) -> dict[str, Any]:
    """Mean recall by method and type at each severity multiplier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    by_severity: dict[str, Any] = {}
    for severity in severities:
        frames = [
            tb.evaluate(inj.inject(carrier, seed=seed, severity=severity), seed, names)[
                "recall"
            ]
            for seed in seeds
        ]
        mean = pd.concat(frames, keys=range(len(frames))).groupby(level=1, sort=False).mean()
        by_severity[str(severity)] = json.loads(mean[list(MAGNITUDE_TYPES)].to_json(orient="split"))
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(seeds),
        "severities": list(severities),
        "recall_by_severity": by_severity,
    }


def x_run_severity__mutmut_16(
    job: dict[str, Any],
    names: list[str] | None = None,
    severities: tuple[float, ...] = SEVERITIES,
    seeds: tuple[int, ...] = SWEEP_SEEDS,
) -> dict[str, Any]:
    """Mean recall by method and type at each severity multiplier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    by_severity: dict[str, Any] = {}
    for severity in severities:
        frames = [
            tb.evaluate(inj.inject(carrier, seed=seed, severity=severity), cols, names)[
                "recall"
            ]
            for seed in seeds
        ]
        mean = pd.concat(frames, keys=range(len(frames))).groupby(level=1, sort=False).mean()
        by_severity[str(severity)] = json.loads(mean[list(MAGNITUDE_TYPES)].to_json(orient="split"))
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(seeds),
        "severities": list(severities),
        "recall_by_severity": by_severity,
    }


def x_run_severity__mutmut_17(
    job: dict[str, Any],
    names: list[str] | None = None,
    severities: tuple[float, ...] = SEVERITIES,
    seeds: tuple[int, ...] = SWEEP_SEEDS,
) -> dict[str, Any]:
    """Mean recall by method and type at each severity multiplier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    by_severity: dict[str, Any] = {}
    for severity in severities:
        frames = [
            tb.evaluate(inj.inject(carrier, seed=seed, severity=severity), cols, seed, )[
                "recall"
            ]
            for seed in seeds
        ]
        mean = pd.concat(frames, keys=range(len(frames))).groupby(level=1, sort=False).mean()
        by_severity[str(severity)] = json.loads(mean[list(MAGNITUDE_TYPES)].to_json(orient="split"))
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(seeds),
        "severities": list(severities),
        "recall_by_severity": by_severity,
    }


def x_run_severity__mutmut_18(
    job: dict[str, Any],
    names: list[str] | None = None,
    severities: tuple[float, ...] = SEVERITIES,
    seeds: tuple[int, ...] = SWEEP_SEEDS,
) -> dict[str, Any]:
    """Mean recall by method and type at each severity multiplier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    by_severity: dict[str, Any] = {}
    for severity in severities:
        frames = [
            tb.evaluate(inj.inject(None, seed=seed, severity=severity), cols, seed, names)[
                "recall"
            ]
            for seed in seeds
        ]
        mean = pd.concat(frames, keys=range(len(frames))).groupby(level=1, sort=False).mean()
        by_severity[str(severity)] = json.loads(mean[list(MAGNITUDE_TYPES)].to_json(orient="split"))
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(seeds),
        "severities": list(severities),
        "recall_by_severity": by_severity,
    }


def x_run_severity__mutmut_19(
    job: dict[str, Any],
    names: list[str] | None = None,
    severities: tuple[float, ...] = SEVERITIES,
    seeds: tuple[int, ...] = SWEEP_SEEDS,
) -> dict[str, Any]:
    """Mean recall by method and type at each severity multiplier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    by_severity: dict[str, Any] = {}
    for severity in severities:
        frames = [
            tb.evaluate(inj.inject(carrier, seed=None, severity=severity), cols, seed, names)[
                "recall"
            ]
            for seed in seeds
        ]
        mean = pd.concat(frames, keys=range(len(frames))).groupby(level=1, sort=False).mean()
        by_severity[str(severity)] = json.loads(mean[list(MAGNITUDE_TYPES)].to_json(orient="split"))
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(seeds),
        "severities": list(severities),
        "recall_by_severity": by_severity,
    }


def x_run_severity__mutmut_20(
    job: dict[str, Any],
    names: list[str] | None = None,
    severities: tuple[float, ...] = SEVERITIES,
    seeds: tuple[int, ...] = SWEEP_SEEDS,
) -> dict[str, Any]:
    """Mean recall by method and type at each severity multiplier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    by_severity: dict[str, Any] = {}
    for severity in severities:
        frames = [
            tb.evaluate(inj.inject(carrier, seed=seed, severity=None), cols, seed, names)[
                "recall"
            ]
            for seed in seeds
        ]
        mean = pd.concat(frames, keys=range(len(frames))).groupby(level=1, sort=False).mean()
        by_severity[str(severity)] = json.loads(mean[list(MAGNITUDE_TYPES)].to_json(orient="split"))
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(seeds),
        "severities": list(severities),
        "recall_by_severity": by_severity,
    }


def x_run_severity__mutmut_21(
    job: dict[str, Any],
    names: list[str] | None = None,
    severities: tuple[float, ...] = SEVERITIES,
    seeds: tuple[int, ...] = SWEEP_SEEDS,
) -> dict[str, Any]:
    """Mean recall by method and type at each severity multiplier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    by_severity: dict[str, Any] = {}
    for severity in severities:
        frames = [
            tb.evaluate(inj.inject(seed=seed, severity=severity), cols, seed, names)[
                "recall"
            ]
            for seed in seeds
        ]
        mean = pd.concat(frames, keys=range(len(frames))).groupby(level=1, sort=False).mean()
        by_severity[str(severity)] = json.loads(mean[list(MAGNITUDE_TYPES)].to_json(orient="split"))
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(seeds),
        "severities": list(severities),
        "recall_by_severity": by_severity,
    }


def x_run_severity__mutmut_22(
    job: dict[str, Any],
    names: list[str] | None = None,
    severities: tuple[float, ...] = SEVERITIES,
    seeds: tuple[int, ...] = SWEEP_SEEDS,
) -> dict[str, Any]:
    """Mean recall by method and type at each severity multiplier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    by_severity: dict[str, Any] = {}
    for severity in severities:
        frames = [
            tb.evaluate(inj.inject(carrier, severity=severity), cols, seed, names)[
                "recall"
            ]
            for seed in seeds
        ]
        mean = pd.concat(frames, keys=range(len(frames))).groupby(level=1, sort=False).mean()
        by_severity[str(severity)] = json.loads(mean[list(MAGNITUDE_TYPES)].to_json(orient="split"))
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(seeds),
        "severities": list(severities),
        "recall_by_severity": by_severity,
    }


def x_run_severity__mutmut_23(
    job: dict[str, Any],
    names: list[str] | None = None,
    severities: tuple[float, ...] = SEVERITIES,
    seeds: tuple[int, ...] = SWEEP_SEEDS,
) -> dict[str, Any]:
    """Mean recall by method and type at each severity multiplier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    by_severity: dict[str, Any] = {}
    for severity in severities:
        frames = [
            tb.evaluate(inj.inject(carrier, seed=seed, ), cols, seed, names)[
                "recall"
            ]
            for seed in seeds
        ]
        mean = pd.concat(frames, keys=range(len(frames))).groupby(level=1, sort=False).mean()
        by_severity[str(severity)] = json.loads(mean[list(MAGNITUDE_TYPES)].to_json(orient="split"))
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(seeds),
        "severities": list(severities),
        "recall_by_severity": by_severity,
    }


def x_run_severity__mutmut_24(
    job: dict[str, Any],
    names: list[str] | None = None,
    severities: tuple[float, ...] = SEVERITIES,
    seeds: tuple[int, ...] = SWEEP_SEEDS,
) -> dict[str, Any]:
    """Mean recall by method and type at each severity multiplier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    by_severity: dict[str, Any] = {}
    for severity in severities:
        frames = [
            tb.evaluate(inj.inject(carrier, seed=seed, severity=severity), cols, seed, names)[
                "XXrecallXX"
            ]
            for seed in seeds
        ]
        mean = pd.concat(frames, keys=range(len(frames))).groupby(level=1, sort=False).mean()
        by_severity[str(severity)] = json.loads(mean[list(MAGNITUDE_TYPES)].to_json(orient="split"))
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(seeds),
        "severities": list(severities),
        "recall_by_severity": by_severity,
    }


def x_run_severity__mutmut_25(
    job: dict[str, Any],
    names: list[str] | None = None,
    severities: tuple[float, ...] = SEVERITIES,
    seeds: tuple[int, ...] = SWEEP_SEEDS,
) -> dict[str, Any]:
    """Mean recall by method and type at each severity multiplier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    by_severity: dict[str, Any] = {}
    for severity in severities:
        frames = [
            tb.evaluate(inj.inject(carrier, seed=seed, severity=severity), cols, seed, names)[
                "RECALL"
            ]
            for seed in seeds
        ]
        mean = pd.concat(frames, keys=range(len(frames))).groupby(level=1, sort=False).mean()
        by_severity[str(severity)] = json.loads(mean[list(MAGNITUDE_TYPES)].to_json(orient="split"))
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(seeds),
        "severities": list(severities),
        "recall_by_severity": by_severity,
    }


def x_run_severity__mutmut_26(
    job: dict[str, Any],
    names: list[str] | None = None,
    severities: tuple[float, ...] = SEVERITIES,
    seeds: tuple[int, ...] = SWEEP_SEEDS,
) -> dict[str, Any]:
    """Mean recall by method and type at each severity multiplier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    by_severity: dict[str, Any] = {}
    for severity in severities:
        frames = [
            tb.evaluate(inj.inject(carrier, seed=seed, severity=severity), cols, seed, names)[
                "recall"
            ]
            for seed in seeds
        ]
        mean = None
        by_severity[str(severity)] = json.loads(mean[list(MAGNITUDE_TYPES)].to_json(orient="split"))
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(seeds),
        "severities": list(severities),
        "recall_by_severity": by_severity,
    }


def x_run_severity__mutmut_27(
    job: dict[str, Any],
    names: list[str] | None = None,
    severities: tuple[float, ...] = SEVERITIES,
    seeds: tuple[int, ...] = SWEEP_SEEDS,
) -> dict[str, Any]:
    """Mean recall by method and type at each severity multiplier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    by_severity: dict[str, Any] = {}
    for severity in severities:
        frames = [
            tb.evaluate(inj.inject(carrier, seed=seed, severity=severity), cols, seed, names)[
                "recall"
            ]
            for seed in seeds
        ]
        mean = pd.concat(frames, keys=range(len(frames))).groupby(level=None, sort=False).mean()
        by_severity[str(severity)] = json.loads(mean[list(MAGNITUDE_TYPES)].to_json(orient="split"))
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(seeds),
        "severities": list(severities),
        "recall_by_severity": by_severity,
    }


def x_run_severity__mutmut_28(
    job: dict[str, Any],
    names: list[str] | None = None,
    severities: tuple[float, ...] = SEVERITIES,
    seeds: tuple[int, ...] = SWEEP_SEEDS,
) -> dict[str, Any]:
    """Mean recall by method and type at each severity multiplier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    by_severity: dict[str, Any] = {}
    for severity in severities:
        frames = [
            tb.evaluate(inj.inject(carrier, seed=seed, severity=severity), cols, seed, names)[
                "recall"
            ]
            for seed in seeds
        ]
        mean = pd.concat(frames, keys=range(len(frames))).groupby(level=1, sort=None).mean()
        by_severity[str(severity)] = json.loads(mean[list(MAGNITUDE_TYPES)].to_json(orient="split"))
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(seeds),
        "severities": list(severities),
        "recall_by_severity": by_severity,
    }


def x_run_severity__mutmut_29(
    job: dict[str, Any],
    names: list[str] | None = None,
    severities: tuple[float, ...] = SEVERITIES,
    seeds: tuple[int, ...] = SWEEP_SEEDS,
) -> dict[str, Any]:
    """Mean recall by method and type at each severity multiplier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    by_severity: dict[str, Any] = {}
    for severity in severities:
        frames = [
            tb.evaluate(inj.inject(carrier, seed=seed, severity=severity), cols, seed, names)[
                "recall"
            ]
            for seed in seeds
        ]
        mean = pd.concat(frames, keys=range(len(frames))).groupby(sort=False).mean()
        by_severity[str(severity)] = json.loads(mean[list(MAGNITUDE_TYPES)].to_json(orient="split"))
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(seeds),
        "severities": list(severities),
        "recall_by_severity": by_severity,
    }


def x_run_severity__mutmut_30(
    job: dict[str, Any],
    names: list[str] | None = None,
    severities: tuple[float, ...] = SEVERITIES,
    seeds: tuple[int, ...] = SWEEP_SEEDS,
) -> dict[str, Any]:
    """Mean recall by method and type at each severity multiplier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    by_severity: dict[str, Any] = {}
    for severity in severities:
        frames = [
            tb.evaluate(inj.inject(carrier, seed=seed, severity=severity), cols, seed, names)[
                "recall"
            ]
            for seed in seeds
        ]
        mean = pd.concat(frames, keys=range(len(frames))).groupby(level=1, ).mean()
        by_severity[str(severity)] = json.loads(mean[list(MAGNITUDE_TYPES)].to_json(orient="split"))
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(seeds),
        "severities": list(severities),
        "recall_by_severity": by_severity,
    }


def x_run_severity__mutmut_31(
    job: dict[str, Any],
    names: list[str] | None = None,
    severities: tuple[float, ...] = SEVERITIES,
    seeds: tuple[int, ...] = SWEEP_SEEDS,
) -> dict[str, Any]:
    """Mean recall by method and type at each severity multiplier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    by_severity: dict[str, Any] = {}
    for severity in severities:
        frames = [
            tb.evaluate(inj.inject(carrier, seed=seed, severity=severity), cols, seed, names)[
                "recall"
            ]
            for seed in seeds
        ]
        mean = pd.concat(None, keys=range(len(frames))).groupby(level=1, sort=False).mean()
        by_severity[str(severity)] = json.loads(mean[list(MAGNITUDE_TYPES)].to_json(orient="split"))
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(seeds),
        "severities": list(severities),
        "recall_by_severity": by_severity,
    }


def x_run_severity__mutmut_32(
    job: dict[str, Any],
    names: list[str] | None = None,
    severities: tuple[float, ...] = SEVERITIES,
    seeds: tuple[int, ...] = SWEEP_SEEDS,
) -> dict[str, Any]:
    """Mean recall by method and type at each severity multiplier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    by_severity: dict[str, Any] = {}
    for severity in severities:
        frames = [
            tb.evaluate(inj.inject(carrier, seed=seed, severity=severity), cols, seed, names)[
                "recall"
            ]
            for seed in seeds
        ]
        mean = pd.concat(frames, keys=None).groupby(level=1, sort=False).mean()
        by_severity[str(severity)] = json.loads(mean[list(MAGNITUDE_TYPES)].to_json(orient="split"))
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(seeds),
        "severities": list(severities),
        "recall_by_severity": by_severity,
    }


def x_run_severity__mutmut_33(
    job: dict[str, Any],
    names: list[str] | None = None,
    severities: tuple[float, ...] = SEVERITIES,
    seeds: tuple[int, ...] = SWEEP_SEEDS,
) -> dict[str, Any]:
    """Mean recall by method and type at each severity multiplier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    by_severity: dict[str, Any] = {}
    for severity in severities:
        frames = [
            tb.evaluate(inj.inject(carrier, seed=seed, severity=severity), cols, seed, names)[
                "recall"
            ]
            for seed in seeds
        ]
        mean = pd.concat(keys=range(len(frames))).groupby(level=1, sort=False).mean()
        by_severity[str(severity)] = json.loads(mean[list(MAGNITUDE_TYPES)].to_json(orient="split"))
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(seeds),
        "severities": list(severities),
        "recall_by_severity": by_severity,
    }


def x_run_severity__mutmut_34(
    job: dict[str, Any],
    names: list[str] | None = None,
    severities: tuple[float, ...] = SEVERITIES,
    seeds: tuple[int, ...] = SWEEP_SEEDS,
) -> dict[str, Any]:
    """Mean recall by method and type at each severity multiplier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    by_severity: dict[str, Any] = {}
    for severity in severities:
        frames = [
            tb.evaluate(inj.inject(carrier, seed=seed, severity=severity), cols, seed, names)[
                "recall"
            ]
            for seed in seeds
        ]
        mean = pd.concat(frames, ).groupby(level=1, sort=False).mean()
        by_severity[str(severity)] = json.loads(mean[list(MAGNITUDE_TYPES)].to_json(orient="split"))
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(seeds),
        "severities": list(severities),
        "recall_by_severity": by_severity,
    }


def x_run_severity__mutmut_35(
    job: dict[str, Any],
    names: list[str] | None = None,
    severities: tuple[float, ...] = SEVERITIES,
    seeds: tuple[int, ...] = SWEEP_SEEDS,
) -> dict[str, Any]:
    """Mean recall by method and type at each severity multiplier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    by_severity: dict[str, Any] = {}
    for severity in severities:
        frames = [
            tb.evaluate(inj.inject(carrier, seed=seed, severity=severity), cols, seed, names)[
                "recall"
            ]
            for seed in seeds
        ]
        mean = pd.concat(frames, keys=range(None)).groupby(level=1, sort=False).mean()
        by_severity[str(severity)] = json.loads(mean[list(MAGNITUDE_TYPES)].to_json(orient="split"))
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(seeds),
        "severities": list(severities),
        "recall_by_severity": by_severity,
    }


def x_run_severity__mutmut_36(
    job: dict[str, Any],
    names: list[str] | None = None,
    severities: tuple[float, ...] = SEVERITIES,
    seeds: tuple[int, ...] = SWEEP_SEEDS,
) -> dict[str, Any]:
    """Mean recall by method and type at each severity multiplier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    by_severity: dict[str, Any] = {}
    for severity in severities:
        frames = [
            tb.evaluate(inj.inject(carrier, seed=seed, severity=severity), cols, seed, names)[
                "recall"
            ]
            for seed in seeds
        ]
        mean = pd.concat(frames, keys=range(len(frames))).groupby(level=2, sort=False).mean()
        by_severity[str(severity)] = json.loads(mean[list(MAGNITUDE_TYPES)].to_json(orient="split"))
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(seeds),
        "severities": list(severities),
        "recall_by_severity": by_severity,
    }


def x_run_severity__mutmut_37(
    job: dict[str, Any],
    names: list[str] | None = None,
    severities: tuple[float, ...] = SEVERITIES,
    seeds: tuple[int, ...] = SWEEP_SEEDS,
) -> dict[str, Any]:
    """Mean recall by method and type at each severity multiplier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    by_severity: dict[str, Any] = {}
    for severity in severities:
        frames = [
            tb.evaluate(inj.inject(carrier, seed=seed, severity=severity), cols, seed, names)[
                "recall"
            ]
            for seed in seeds
        ]
        mean = pd.concat(frames, keys=range(len(frames))).groupby(level=1, sort=True).mean()
        by_severity[str(severity)] = json.loads(mean[list(MAGNITUDE_TYPES)].to_json(orient="split"))
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(seeds),
        "severities": list(severities),
        "recall_by_severity": by_severity,
    }


def x_run_severity__mutmut_38(
    job: dict[str, Any],
    names: list[str] | None = None,
    severities: tuple[float, ...] = SEVERITIES,
    seeds: tuple[int, ...] = SWEEP_SEEDS,
) -> dict[str, Any]:
    """Mean recall by method and type at each severity multiplier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    by_severity: dict[str, Any] = {}
    for severity in severities:
        frames = [
            tb.evaluate(inj.inject(carrier, seed=seed, severity=severity), cols, seed, names)[
                "recall"
            ]
            for seed in seeds
        ]
        mean = pd.concat(frames, keys=range(len(frames))).groupby(level=1, sort=False).mean()
        by_severity[str(severity)] = None
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(seeds),
        "severities": list(severities),
        "recall_by_severity": by_severity,
    }


def x_run_severity__mutmut_39(
    job: dict[str, Any],
    names: list[str] | None = None,
    severities: tuple[float, ...] = SEVERITIES,
    seeds: tuple[int, ...] = SWEEP_SEEDS,
) -> dict[str, Any]:
    """Mean recall by method and type at each severity multiplier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    by_severity: dict[str, Any] = {}
    for severity in severities:
        frames = [
            tb.evaluate(inj.inject(carrier, seed=seed, severity=severity), cols, seed, names)[
                "recall"
            ]
            for seed in seeds
        ]
        mean = pd.concat(frames, keys=range(len(frames))).groupby(level=1, sort=False).mean()
        by_severity[str(None)] = json.loads(mean[list(MAGNITUDE_TYPES)].to_json(orient="split"))
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(seeds),
        "severities": list(severities),
        "recall_by_severity": by_severity,
    }


def x_run_severity__mutmut_40(
    job: dict[str, Any],
    names: list[str] | None = None,
    severities: tuple[float, ...] = SEVERITIES,
    seeds: tuple[int, ...] = SWEEP_SEEDS,
) -> dict[str, Any]:
    """Mean recall by method and type at each severity multiplier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    by_severity: dict[str, Any] = {}
    for severity in severities:
        frames = [
            tb.evaluate(inj.inject(carrier, seed=seed, severity=severity), cols, seed, names)[
                "recall"
            ]
            for seed in seeds
        ]
        mean = pd.concat(frames, keys=range(len(frames))).groupby(level=1, sort=False).mean()
        by_severity[str(severity)] = json.loads(None)
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(seeds),
        "severities": list(severities),
        "recall_by_severity": by_severity,
    }


def x_run_severity__mutmut_41(
    job: dict[str, Any],
    names: list[str] | None = None,
    severities: tuple[float, ...] = SEVERITIES,
    seeds: tuple[int, ...] = SWEEP_SEEDS,
) -> dict[str, Any]:
    """Mean recall by method and type at each severity multiplier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    by_severity: dict[str, Any] = {}
    for severity in severities:
        frames = [
            tb.evaluate(inj.inject(carrier, seed=seed, severity=severity), cols, seed, names)[
                "recall"
            ]
            for seed in seeds
        ]
        mean = pd.concat(frames, keys=range(len(frames))).groupby(level=1, sort=False).mean()
        by_severity[str(severity)] = json.loads(mean[list(MAGNITUDE_TYPES)].to_json(orient=None))
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(seeds),
        "severities": list(severities),
        "recall_by_severity": by_severity,
    }


def x_run_severity__mutmut_42(
    job: dict[str, Any],
    names: list[str] | None = None,
    severities: tuple[float, ...] = SEVERITIES,
    seeds: tuple[int, ...] = SWEEP_SEEDS,
) -> dict[str, Any]:
    """Mean recall by method and type at each severity multiplier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    by_severity: dict[str, Any] = {}
    for severity in severities:
        frames = [
            tb.evaluate(inj.inject(carrier, seed=seed, severity=severity), cols, seed, names)[
                "recall"
            ]
            for seed in seeds
        ]
        mean = pd.concat(frames, keys=range(len(frames))).groupby(level=1, sort=False).mean()
        by_severity[str(severity)] = json.loads(mean[list(None)].to_json(orient="split"))
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(seeds),
        "severities": list(severities),
        "recall_by_severity": by_severity,
    }


def x_run_severity__mutmut_43(
    job: dict[str, Any],
    names: list[str] | None = None,
    severities: tuple[float, ...] = SEVERITIES,
    seeds: tuple[int, ...] = SWEEP_SEEDS,
) -> dict[str, Any]:
    """Mean recall by method and type at each severity multiplier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    by_severity: dict[str, Any] = {}
    for severity in severities:
        frames = [
            tb.evaluate(inj.inject(carrier, seed=seed, severity=severity), cols, seed, names)[
                "recall"
            ]
            for seed in seeds
        ]
        mean = pd.concat(frames, keys=range(len(frames))).groupby(level=1, sort=False).mean()
        by_severity[str(severity)] = json.loads(mean[list(MAGNITUDE_TYPES)].to_json(orient="XXsplitXX"))
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(seeds),
        "severities": list(severities),
        "recall_by_severity": by_severity,
    }


def x_run_severity__mutmut_44(
    job: dict[str, Any],
    names: list[str] | None = None,
    severities: tuple[float, ...] = SEVERITIES,
    seeds: tuple[int, ...] = SWEEP_SEEDS,
) -> dict[str, Any]:
    """Mean recall by method and type at each severity multiplier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    by_severity: dict[str, Any] = {}
    for severity in severities:
        frames = [
            tb.evaluate(inj.inject(carrier, seed=seed, severity=severity), cols, seed, names)[
                "recall"
            ]
            for seed in seeds
        ]
        mean = pd.concat(frames, keys=range(len(frames))).groupby(level=1, sort=False).mean()
        by_severity[str(severity)] = json.loads(mean[list(MAGNITUDE_TYPES)].to_json(orient="SPLIT"))
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(seeds),
        "severities": list(severities),
        "recall_by_severity": by_severity,
    }


def x_run_severity__mutmut_45(
    job: dict[str, Any],
    names: list[str] | None = None,
    severities: tuple[float, ...] = SEVERITIES,
    seeds: tuple[int, ...] = SWEEP_SEEDS,
) -> dict[str, Any]:
    """Mean recall by method and type at each severity multiplier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    by_severity: dict[str, Any] = {}
    for severity in severities:
        frames = [
            tb.evaluate(inj.inject(carrier, seed=seed, severity=severity), cols, seed, names)[
                "recall"
            ]
            for seed in seeds
        ]
        mean = pd.concat(frames, keys=range(len(frames))).groupby(level=1, sort=False).mean()
        by_severity[str(severity)] = json.loads(mean[list(MAGNITUDE_TYPES)].to_json(orient="split"))
    return {
        "XXidXX": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(seeds),
        "severities": list(severities),
        "recall_by_severity": by_severity,
    }


def x_run_severity__mutmut_46(
    job: dict[str, Any],
    names: list[str] | None = None,
    severities: tuple[float, ...] = SEVERITIES,
    seeds: tuple[int, ...] = SWEEP_SEEDS,
) -> dict[str, Any]:
    """Mean recall by method and type at each severity multiplier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    by_severity: dict[str, Any] = {}
    for severity in severities:
        frames = [
            tb.evaluate(inj.inject(carrier, seed=seed, severity=severity), cols, seed, names)[
                "recall"
            ]
            for seed in seeds
        ]
        mean = pd.concat(frames, keys=range(len(frames))).groupby(level=1, sort=False).mean()
        by_severity[str(severity)] = json.loads(mean[list(MAGNITUDE_TYPES)].to_json(orient="split"))
    return {
        "ID": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(seeds),
        "severities": list(severities),
        "recall_by_severity": by_severity,
    }


def x_run_severity__mutmut_47(
    job: dict[str, Any],
    names: list[str] | None = None,
    severities: tuple[float, ...] = SEVERITIES,
    seeds: tuple[int, ...] = SWEEP_SEEDS,
) -> dict[str, Any]:
    """Mean recall by method and type at each severity multiplier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    by_severity: dict[str, Any] = {}
    for severity in severities:
        frames = [
            tb.evaluate(inj.inject(carrier, seed=seed, severity=severity), cols, seed, names)[
                "recall"
            ]
            for seed in seeds
        ]
        mean = pd.concat(frames, keys=range(len(frames))).groupby(level=1, sort=False).mean()
        by_severity[str(severity)] = json.loads(mean[list(MAGNITUDE_TYPES)].to_json(orient="split"))
    return {
        "id": job["XXidXX"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(seeds),
        "severities": list(severities),
        "recall_by_severity": by_severity,
    }


def x_run_severity__mutmut_48(
    job: dict[str, Any],
    names: list[str] | None = None,
    severities: tuple[float, ...] = SEVERITIES,
    seeds: tuple[int, ...] = SWEEP_SEEDS,
) -> dict[str, Any]:
    """Mean recall by method and type at each severity multiplier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    by_severity: dict[str, Any] = {}
    for severity in severities:
        frames = [
            tb.evaluate(inj.inject(carrier, seed=seed, severity=severity), cols, seed, names)[
                "recall"
            ]
            for seed in seeds
        ]
        mean = pd.concat(frames, keys=range(len(frames))).groupby(level=1, sort=False).mean()
        by_severity[str(severity)] = json.loads(mean[list(MAGNITUDE_TYPES)].to_json(orient="split"))
    return {
        "id": job["ID"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(seeds),
        "severities": list(severities),
        "recall_by_severity": by_severity,
    }


def x_run_severity__mutmut_49(
    job: dict[str, Any],
    names: list[str] | None = None,
    severities: tuple[float, ...] = SEVERITIES,
    seeds: tuple[int, ...] = SWEEP_SEEDS,
) -> dict[str, Any]:
    """Mean recall by method and type at each severity multiplier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    by_severity: dict[str, Any] = {}
    for severity in severities:
        frames = [
            tb.evaluate(inj.inject(carrier, seed=seed, severity=severity), cols, seed, names)[
                "recall"
            ]
            for seed in seeds
        ]
        mean = pd.concat(frames, keys=range(len(frames))).groupby(level=1, sort=False).mean()
        by_severity[str(severity)] = json.loads(mean[list(MAGNITUDE_TYPES)].to_json(orient="split"))
    return {
        "id": job["id"],
        "XXnameXX": job["name"],
        "carrier": report,
        "seeds": list(seeds),
        "severities": list(severities),
        "recall_by_severity": by_severity,
    }


def x_run_severity__mutmut_50(
    job: dict[str, Any],
    names: list[str] | None = None,
    severities: tuple[float, ...] = SEVERITIES,
    seeds: tuple[int, ...] = SWEEP_SEEDS,
) -> dict[str, Any]:
    """Mean recall by method and type at each severity multiplier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    by_severity: dict[str, Any] = {}
    for severity in severities:
        frames = [
            tb.evaluate(inj.inject(carrier, seed=seed, severity=severity), cols, seed, names)[
                "recall"
            ]
            for seed in seeds
        ]
        mean = pd.concat(frames, keys=range(len(frames))).groupby(level=1, sort=False).mean()
        by_severity[str(severity)] = json.loads(mean[list(MAGNITUDE_TYPES)].to_json(orient="split"))
    return {
        "id": job["id"],
        "NAME": job["name"],
        "carrier": report,
        "seeds": list(seeds),
        "severities": list(severities),
        "recall_by_severity": by_severity,
    }


def x_run_severity__mutmut_51(
    job: dict[str, Any],
    names: list[str] | None = None,
    severities: tuple[float, ...] = SEVERITIES,
    seeds: tuple[int, ...] = SWEEP_SEEDS,
) -> dict[str, Any]:
    """Mean recall by method and type at each severity multiplier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    by_severity: dict[str, Any] = {}
    for severity in severities:
        frames = [
            tb.evaluate(inj.inject(carrier, seed=seed, severity=severity), cols, seed, names)[
                "recall"
            ]
            for seed in seeds
        ]
        mean = pd.concat(frames, keys=range(len(frames))).groupby(level=1, sort=False).mean()
        by_severity[str(severity)] = json.loads(mean[list(MAGNITUDE_TYPES)].to_json(orient="split"))
    return {
        "id": job["id"],
        "name": job["XXnameXX"],
        "carrier": report,
        "seeds": list(seeds),
        "severities": list(severities),
        "recall_by_severity": by_severity,
    }


def x_run_severity__mutmut_52(
    job: dict[str, Any],
    names: list[str] | None = None,
    severities: tuple[float, ...] = SEVERITIES,
    seeds: tuple[int, ...] = SWEEP_SEEDS,
) -> dict[str, Any]:
    """Mean recall by method and type at each severity multiplier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    by_severity: dict[str, Any] = {}
    for severity in severities:
        frames = [
            tb.evaluate(inj.inject(carrier, seed=seed, severity=severity), cols, seed, names)[
                "recall"
            ]
            for seed in seeds
        ]
        mean = pd.concat(frames, keys=range(len(frames))).groupby(level=1, sort=False).mean()
        by_severity[str(severity)] = json.loads(mean[list(MAGNITUDE_TYPES)].to_json(orient="split"))
    return {
        "id": job["id"],
        "name": job["NAME"],
        "carrier": report,
        "seeds": list(seeds),
        "severities": list(severities),
        "recall_by_severity": by_severity,
    }


def x_run_severity__mutmut_53(
    job: dict[str, Any],
    names: list[str] | None = None,
    severities: tuple[float, ...] = SEVERITIES,
    seeds: tuple[int, ...] = SWEEP_SEEDS,
) -> dict[str, Any]:
    """Mean recall by method and type at each severity multiplier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    by_severity: dict[str, Any] = {}
    for severity in severities:
        frames = [
            tb.evaluate(inj.inject(carrier, seed=seed, severity=severity), cols, seed, names)[
                "recall"
            ]
            for seed in seeds
        ]
        mean = pd.concat(frames, keys=range(len(frames))).groupby(level=1, sort=False).mean()
        by_severity[str(severity)] = json.loads(mean[list(MAGNITUDE_TYPES)].to_json(orient="split"))
    return {
        "id": job["id"],
        "name": job["name"],
        "XXcarrierXX": report,
        "seeds": list(seeds),
        "severities": list(severities),
        "recall_by_severity": by_severity,
    }


def x_run_severity__mutmut_54(
    job: dict[str, Any],
    names: list[str] | None = None,
    severities: tuple[float, ...] = SEVERITIES,
    seeds: tuple[int, ...] = SWEEP_SEEDS,
) -> dict[str, Any]:
    """Mean recall by method and type at each severity multiplier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    by_severity: dict[str, Any] = {}
    for severity in severities:
        frames = [
            tb.evaluate(inj.inject(carrier, seed=seed, severity=severity), cols, seed, names)[
                "recall"
            ]
            for seed in seeds
        ]
        mean = pd.concat(frames, keys=range(len(frames))).groupby(level=1, sort=False).mean()
        by_severity[str(severity)] = json.loads(mean[list(MAGNITUDE_TYPES)].to_json(orient="split"))
    return {
        "id": job["id"],
        "name": job["name"],
        "CARRIER": report,
        "seeds": list(seeds),
        "severities": list(severities),
        "recall_by_severity": by_severity,
    }


def x_run_severity__mutmut_55(
    job: dict[str, Any],
    names: list[str] | None = None,
    severities: tuple[float, ...] = SEVERITIES,
    seeds: tuple[int, ...] = SWEEP_SEEDS,
) -> dict[str, Any]:
    """Mean recall by method and type at each severity multiplier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    by_severity: dict[str, Any] = {}
    for severity in severities:
        frames = [
            tb.evaluate(inj.inject(carrier, seed=seed, severity=severity), cols, seed, names)[
                "recall"
            ]
            for seed in seeds
        ]
        mean = pd.concat(frames, keys=range(len(frames))).groupby(level=1, sort=False).mean()
        by_severity[str(severity)] = json.loads(mean[list(MAGNITUDE_TYPES)].to_json(orient="split"))
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "XXseedsXX": list(seeds),
        "severities": list(severities),
        "recall_by_severity": by_severity,
    }


def x_run_severity__mutmut_56(
    job: dict[str, Any],
    names: list[str] | None = None,
    severities: tuple[float, ...] = SEVERITIES,
    seeds: tuple[int, ...] = SWEEP_SEEDS,
) -> dict[str, Any]:
    """Mean recall by method and type at each severity multiplier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    by_severity: dict[str, Any] = {}
    for severity in severities:
        frames = [
            tb.evaluate(inj.inject(carrier, seed=seed, severity=severity), cols, seed, names)[
                "recall"
            ]
            for seed in seeds
        ]
        mean = pd.concat(frames, keys=range(len(frames))).groupby(level=1, sort=False).mean()
        by_severity[str(severity)] = json.loads(mean[list(MAGNITUDE_TYPES)].to_json(orient="split"))
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "SEEDS": list(seeds),
        "severities": list(severities),
        "recall_by_severity": by_severity,
    }


def x_run_severity__mutmut_57(
    job: dict[str, Any],
    names: list[str] | None = None,
    severities: tuple[float, ...] = SEVERITIES,
    seeds: tuple[int, ...] = SWEEP_SEEDS,
) -> dict[str, Any]:
    """Mean recall by method and type at each severity multiplier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    by_severity: dict[str, Any] = {}
    for severity in severities:
        frames = [
            tb.evaluate(inj.inject(carrier, seed=seed, severity=severity), cols, seed, names)[
                "recall"
            ]
            for seed in seeds
        ]
        mean = pd.concat(frames, keys=range(len(frames))).groupby(level=1, sort=False).mean()
        by_severity[str(severity)] = json.loads(mean[list(MAGNITUDE_TYPES)].to_json(orient="split"))
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(None),
        "severities": list(severities),
        "recall_by_severity": by_severity,
    }


def x_run_severity__mutmut_58(
    job: dict[str, Any],
    names: list[str] | None = None,
    severities: tuple[float, ...] = SEVERITIES,
    seeds: tuple[int, ...] = SWEEP_SEEDS,
) -> dict[str, Any]:
    """Mean recall by method and type at each severity multiplier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    by_severity: dict[str, Any] = {}
    for severity in severities:
        frames = [
            tb.evaluate(inj.inject(carrier, seed=seed, severity=severity), cols, seed, names)[
                "recall"
            ]
            for seed in seeds
        ]
        mean = pd.concat(frames, keys=range(len(frames))).groupby(level=1, sort=False).mean()
        by_severity[str(severity)] = json.loads(mean[list(MAGNITUDE_TYPES)].to_json(orient="split"))
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(seeds),
        "XXseveritiesXX": list(severities),
        "recall_by_severity": by_severity,
    }


def x_run_severity__mutmut_59(
    job: dict[str, Any],
    names: list[str] | None = None,
    severities: tuple[float, ...] = SEVERITIES,
    seeds: tuple[int, ...] = SWEEP_SEEDS,
) -> dict[str, Any]:
    """Mean recall by method and type at each severity multiplier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    by_severity: dict[str, Any] = {}
    for severity in severities:
        frames = [
            tb.evaluate(inj.inject(carrier, seed=seed, severity=severity), cols, seed, names)[
                "recall"
            ]
            for seed in seeds
        ]
        mean = pd.concat(frames, keys=range(len(frames))).groupby(level=1, sort=False).mean()
        by_severity[str(severity)] = json.loads(mean[list(MAGNITUDE_TYPES)].to_json(orient="split"))
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(seeds),
        "SEVERITIES": list(severities),
        "recall_by_severity": by_severity,
    }


def x_run_severity__mutmut_60(
    job: dict[str, Any],
    names: list[str] | None = None,
    severities: tuple[float, ...] = SEVERITIES,
    seeds: tuple[int, ...] = SWEEP_SEEDS,
) -> dict[str, Any]:
    """Mean recall by method and type at each severity multiplier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    by_severity: dict[str, Any] = {}
    for severity in severities:
        frames = [
            tb.evaluate(inj.inject(carrier, seed=seed, severity=severity), cols, seed, names)[
                "recall"
            ]
            for seed in seeds
        ]
        mean = pd.concat(frames, keys=range(len(frames))).groupby(level=1, sort=False).mean()
        by_severity[str(severity)] = json.loads(mean[list(MAGNITUDE_TYPES)].to_json(orient="split"))
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(seeds),
        "severities": list(None),
        "recall_by_severity": by_severity,
    }


def x_run_severity__mutmut_61(
    job: dict[str, Any],
    names: list[str] | None = None,
    severities: tuple[float, ...] = SEVERITIES,
    seeds: tuple[int, ...] = SWEEP_SEEDS,
) -> dict[str, Any]:
    """Mean recall by method and type at each severity multiplier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    by_severity: dict[str, Any] = {}
    for severity in severities:
        frames = [
            tb.evaluate(inj.inject(carrier, seed=seed, severity=severity), cols, seed, names)[
                "recall"
            ]
            for seed in seeds
        ]
        mean = pd.concat(frames, keys=range(len(frames))).groupby(level=1, sort=False).mean()
        by_severity[str(severity)] = json.loads(mean[list(MAGNITUDE_TYPES)].to_json(orient="split"))
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(seeds),
        "severities": list(severities),
        "XXrecall_by_severityXX": by_severity,
    }


def x_run_severity__mutmut_62(
    job: dict[str, Any],
    names: list[str] | None = None,
    severities: tuple[float, ...] = SEVERITIES,
    seeds: tuple[int, ...] = SWEEP_SEEDS,
) -> dict[str, Any]:
    """Mean recall by method and type at each severity multiplier."""
    warnings.filterwarnings("ignore")
    import typed_benchmark as tb

    carrier, report = load_carrier(job)
    cols = list(carrier.columns)
    by_severity: dict[str, Any] = {}
    for severity in severities:
        frames = [
            tb.evaluate(inj.inject(carrier, seed=seed, severity=severity), cols, seed, names)[
                "recall"
            ]
            for seed in seeds
        ]
        mean = pd.concat(frames, keys=range(len(frames))).groupby(level=1, sort=False).mean()
        by_severity[str(severity)] = json.loads(mean[list(MAGNITUDE_TYPES)].to_json(orient="split"))
    return {
        "id": job["id"],
        "name": job["name"],
        "carrier": report,
        "seeds": list(seeds),
        "severities": list(severities),
        "RECALL_BY_SEVERITY": by_severity,
    }

mutants_x_run_severity__mutmut['_mutmut_orig'] = x_run_severity__mutmut_orig # type: ignore # mutmut generated
mutants_x_run_severity__mutmut['x_run_severity__mutmut_1'] = x_run_severity__mutmut_1 # type: ignore # mutmut generated
mutants_x_run_severity__mutmut['x_run_severity__mutmut_2'] = x_run_severity__mutmut_2 # type: ignore # mutmut generated
mutants_x_run_severity__mutmut['x_run_severity__mutmut_3'] = x_run_severity__mutmut_3 # type: ignore # mutmut generated
mutants_x_run_severity__mutmut['x_run_severity__mutmut_4'] = x_run_severity__mutmut_4 # type: ignore # mutmut generated
mutants_x_run_severity__mutmut['x_run_severity__mutmut_5'] = x_run_severity__mutmut_5 # type: ignore # mutmut generated
mutants_x_run_severity__mutmut['x_run_severity__mutmut_6'] = x_run_severity__mutmut_6 # type: ignore # mutmut generated
mutants_x_run_severity__mutmut['x_run_severity__mutmut_7'] = x_run_severity__mutmut_7 # type: ignore # mutmut generated
mutants_x_run_severity__mutmut['x_run_severity__mutmut_8'] = x_run_severity__mutmut_8 # type: ignore # mutmut generated
mutants_x_run_severity__mutmut['x_run_severity__mutmut_9'] = x_run_severity__mutmut_9 # type: ignore # mutmut generated
mutants_x_run_severity__mutmut['x_run_severity__mutmut_10'] = x_run_severity__mutmut_10 # type: ignore # mutmut generated
mutants_x_run_severity__mutmut['x_run_severity__mutmut_11'] = x_run_severity__mutmut_11 # type: ignore # mutmut generated
mutants_x_run_severity__mutmut['x_run_severity__mutmut_12'] = x_run_severity__mutmut_12 # type: ignore # mutmut generated
mutants_x_run_severity__mutmut['x_run_severity__mutmut_13'] = x_run_severity__mutmut_13 # type: ignore # mutmut generated
mutants_x_run_severity__mutmut['x_run_severity__mutmut_14'] = x_run_severity__mutmut_14 # type: ignore # mutmut generated
mutants_x_run_severity__mutmut['x_run_severity__mutmut_15'] = x_run_severity__mutmut_15 # type: ignore # mutmut generated
mutants_x_run_severity__mutmut['x_run_severity__mutmut_16'] = x_run_severity__mutmut_16 # type: ignore # mutmut generated
mutants_x_run_severity__mutmut['x_run_severity__mutmut_17'] = x_run_severity__mutmut_17 # type: ignore # mutmut generated
mutants_x_run_severity__mutmut['x_run_severity__mutmut_18'] = x_run_severity__mutmut_18 # type: ignore # mutmut generated
mutants_x_run_severity__mutmut['x_run_severity__mutmut_19'] = x_run_severity__mutmut_19 # type: ignore # mutmut generated
mutants_x_run_severity__mutmut['x_run_severity__mutmut_20'] = x_run_severity__mutmut_20 # type: ignore # mutmut generated
mutants_x_run_severity__mutmut['x_run_severity__mutmut_21'] = x_run_severity__mutmut_21 # type: ignore # mutmut generated
mutants_x_run_severity__mutmut['x_run_severity__mutmut_22'] = x_run_severity__mutmut_22 # type: ignore # mutmut generated
mutants_x_run_severity__mutmut['x_run_severity__mutmut_23'] = x_run_severity__mutmut_23 # type: ignore # mutmut generated
mutants_x_run_severity__mutmut['x_run_severity__mutmut_24'] = x_run_severity__mutmut_24 # type: ignore # mutmut generated
mutants_x_run_severity__mutmut['x_run_severity__mutmut_25'] = x_run_severity__mutmut_25 # type: ignore # mutmut generated
mutants_x_run_severity__mutmut['x_run_severity__mutmut_26'] = x_run_severity__mutmut_26 # type: ignore # mutmut generated
mutants_x_run_severity__mutmut['x_run_severity__mutmut_27'] = x_run_severity__mutmut_27 # type: ignore # mutmut generated
mutants_x_run_severity__mutmut['x_run_severity__mutmut_28'] = x_run_severity__mutmut_28 # type: ignore # mutmut generated
mutants_x_run_severity__mutmut['x_run_severity__mutmut_29'] = x_run_severity__mutmut_29 # type: ignore # mutmut generated
mutants_x_run_severity__mutmut['x_run_severity__mutmut_30'] = x_run_severity__mutmut_30 # type: ignore # mutmut generated
mutants_x_run_severity__mutmut['x_run_severity__mutmut_31'] = x_run_severity__mutmut_31 # type: ignore # mutmut generated
mutants_x_run_severity__mutmut['x_run_severity__mutmut_32'] = x_run_severity__mutmut_32 # type: ignore # mutmut generated
mutants_x_run_severity__mutmut['x_run_severity__mutmut_33'] = x_run_severity__mutmut_33 # type: ignore # mutmut generated
mutants_x_run_severity__mutmut['x_run_severity__mutmut_34'] = x_run_severity__mutmut_34 # type: ignore # mutmut generated
mutants_x_run_severity__mutmut['x_run_severity__mutmut_35'] = x_run_severity__mutmut_35 # type: ignore # mutmut generated
mutants_x_run_severity__mutmut['x_run_severity__mutmut_36'] = x_run_severity__mutmut_36 # type: ignore # mutmut generated
mutants_x_run_severity__mutmut['x_run_severity__mutmut_37'] = x_run_severity__mutmut_37 # type: ignore # mutmut generated
mutants_x_run_severity__mutmut['x_run_severity__mutmut_38'] = x_run_severity__mutmut_38 # type: ignore # mutmut generated
mutants_x_run_severity__mutmut['x_run_severity__mutmut_39'] = x_run_severity__mutmut_39 # type: ignore # mutmut generated
mutants_x_run_severity__mutmut['x_run_severity__mutmut_40'] = x_run_severity__mutmut_40 # type: ignore # mutmut generated
mutants_x_run_severity__mutmut['x_run_severity__mutmut_41'] = x_run_severity__mutmut_41 # type: ignore # mutmut generated
mutants_x_run_severity__mutmut['x_run_severity__mutmut_42'] = x_run_severity__mutmut_42 # type: ignore # mutmut generated
mutants_x_run_severity__mutmut['x_run_severity__mutmut_43'] = x_run_severity__mutmut_43 # type: ignore # mutmut generated
mutants_x_run_severity__mutmut['x_run_severity__mutmut_44'] = x_run_severity__mutmut_44 # type: ignore # mutmut generated
mutants_x_run_severity__mutmut['x_run_severity__mutmut_45'] = x_run_severity__mutmut_45 # type: ignore # mutmut generated
mutants_x_run_severity__mutmut['x_run_severity__mutmut_46'] = x_run_severity__mutmut_46 # type: ignore # mutmut generated
mutants_x_run_severity__mutmut['x_run_severity__mutmut_47'] = x_run_severity__mutmut_47 # type: ignore # mutmut generated
mutants_x_run_severity__mutmut['x_run_severity__mutmut_48'] = x_run_severity__mutmut_48 # type: ignore # mutmut generated
mutants_x_run_severity__mutmut['x_run_severity__mutmut_49'] = x_run_severity__mutmut_49 # type: ignore # mutmut generated
mutants_x_run_severity__mutmut['x_run_severity__mutmut_50'] = x_run_severity__mutmut_50 # type: ignore # mutmut generated
mutants_x_run_severity__mutmut['x_run_severity__mutmut_51'] = x_run_severity__mutmut_51 # type: ignore # mutmut generated
mutants_x_run_severity__mutmut['x_run_severity__mutmut_52'] = x_run_severity__mutmut_52 # type: ignore # mutmut generated
mutants_x_run_severity__mutmut['x_run_severity__mutmut_53'] = x_run_severity__mutmut_53 # type: ignore # mutmut generated
mutants_x_run_severity__mutmut['x_run_severity__mutmut_54'] = x_run_severity__mutmut_54 # type: ignore # mutmut generated
mutants_x_run_severity__mutmut['x_run_severity__mutmut_55'] = x_run_severity__mutmut_55 # type: ignore # mutmut generated
mutants_x_run_severity__mutmut['x_run_severity__mutmut_56'] = x_run_severity__mutmut_56 # type: ignore # mutmut generated
mutants_x_run_severity__mutmut['x_run_severity__mutmut_57'] = x_run_severity__mutmut_57 # type: ignore # mutmut generated
mutants_x_run_severity__mutmut['x_run_severity__mutmut_58'] = x_run_severity__mutmut_58 # type: ignore # mutmut generated
mutants_x_run_severity__mutmut['x_run_severity__mutmut_59'] = x_run_severity__mutmut_59 # type: ignore # mutmut generated
mutants_x_run_severity__mutmut['x_run_severity__mutmut_60'] = x_run_severity__mutmut_60 # type: ignore # mutmut generated
mutants_x_run_severity__mutmut['x_run_severity__mutmut_61'] = x_run_severity__mutmut_61 # type: ignore # mutmut generated
mutants_x_run_severity__mutmut['x_run_severity__mutmut_62'] = x_run_severity__mutmut_62 # type: ignore # mutmut generated
mutants_x_main__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_main__mutmut)
def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_orig(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_1(argv: list[str] | None = None) -> int:
    parser = None
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_2(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=None)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_3(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(None, choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_4(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=None)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_5(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_6(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", )
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_7(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("XXcommandXX", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_8(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("COMMAND", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_9(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("XXeligibilityXX", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_10(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("ELIGIBILITY", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_11(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "XXreferenceXX", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_12(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "REFERENCE", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_13(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "XXseverityXX"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_14(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "SEVERITY"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_15(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument(None, type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_16(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=None, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_17(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=None)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_18(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument(type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_19(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_20(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, )
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_21(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("XX--outputXX", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_22(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--OUTPUT", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_23(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=False)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_24(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument(None, type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_25(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=None, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_26(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=None)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_27(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument(type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_28(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_29(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, )
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_30(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("XX--workersXX", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_31(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--WORKERS", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_32(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=5)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_33(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument(None, choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_34(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=None, default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_35(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default=None)
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_36(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument(choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_37(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_38(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), )
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_39(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("XX--methodsXX", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_40(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--METHODS", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_41(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("XXclassicalXX", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_42(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("CLASSICAL", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_43(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "XXdeepXX"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_44(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "DEEP"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_45(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="XXclassicalXX")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_46(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="CLASSICAL")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_47(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument(None, action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_48(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action=None)
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_49(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument(action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_50(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", )
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_51(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("XX--resumeXX", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_52(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--RESUME", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_53(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="XXstore_trueXX")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_54(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="STORE_TRUE")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_55(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument(None, nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_56(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs=None, help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_57(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help=None)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_58(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument(nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_59(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_60(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_61(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("XX--onlyXX", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_62(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--ONLY", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_63(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="XX*XX", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_64(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="XXdataset ids, for a quick checkXX")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_65(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="DATASET IDS, FOR A QUICK CHECK")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_66(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = None
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_67(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(None)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_68(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = None
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_69(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" * "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_70(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" * "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_71(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT * "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_72(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "XXverificationXX" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_73(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "VERIFICATION" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_74(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "XXevidenceXX" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_75(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "EVIDENCE" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_76(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "XXdataset_registryXX"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_77(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "DATASET_REGISTRY"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_78(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = None
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_79(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(None, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_80(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, None, ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_81(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", None)
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_82(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_83(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_84(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", )
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_85(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" * "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_86(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT * "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_87(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "XXdataXX" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_88(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "DATA" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_89(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "XXpoolXX", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_90(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "POOL", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_91(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" * "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_92(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT * "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_93(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "XXdataXX" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_94(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "DATA" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_95(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "XXadbenchXX")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_96(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "ADBENCH")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_97(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only and j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_98(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_99(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["XXidXX"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_100(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["ID"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_101(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] not in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_102(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=None, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_103(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=None)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_104(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_105(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, )
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_106(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=False, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_107(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=False)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_108(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command != "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_109(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "XXeligibilityXX":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_110(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "ELIGIBILITY":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_111(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=None) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_112(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = None
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_113(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(None)
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_114(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(None, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_115(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, None))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_116(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_117(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, ))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_118(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(None) as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_119(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output * "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_120(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "XXeligibility.jsonXX") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_121(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "ELIGIBILITY.JSON") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_122(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(None)
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_123(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) - "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_124(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(None, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_125(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=None) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_126(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_127(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, ) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_128(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=2) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_129(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "XX\nXX")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_130(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(None, "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_131(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), None, len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_132(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", None)
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_133(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print("eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_134(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_135(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", )
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_136(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(None), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_137(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["XXeligibleXX"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_138(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["ELIGIBLE"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_139(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "XXeligible ofXX", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_140(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "ELIGIBLE OF", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_141(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 1
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_142(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = None
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_143(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["XXidXX"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_144(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["ID"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_145(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads(None)
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_146(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent * "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_147(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "XXeligibility.jsonXX").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_148(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "ELIGIBILITY.JSON").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_149(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["XXeligibleXX"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_150(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["ELIGIBLE"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_151(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = None
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_152(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["XXidXX"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_153(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["ID"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_154(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] not in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_155(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command != "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_156(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "XXreferenceXX":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_157(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "REFERENCE":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_158(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = None  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_159(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["XXsourceXX"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_160(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["SOURCE"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_161(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] != "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_162(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "XXadbenchXX"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_163(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "ADBENCH"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_164(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_165(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if (args.methods == "deep") and False else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_166(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if (args.methods == "deep") or True else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_167(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(None) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_168(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods != "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_169(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "XXdeepXX" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_170(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "DEEP" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_171(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = None  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_172(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: None  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_173(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(None, "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_174(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", None)  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_175(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace("_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_176(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", )  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_177(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["XXidXX"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_178(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["ID"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_179(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace("XX:XX", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_180(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "XX_XX")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_181(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = None
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_182(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_183(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output * f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_184(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(None)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_185(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = None
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_186(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if (args.command == "reference") and False else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_187(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if (args.command == "reference") or True else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_188(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command != "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_189(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "XXreferenceXX" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_190(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "REFERENCE" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_191(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=None) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_192(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(None, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_193(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, None, strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_194(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=None):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_195(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_196(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_197(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), ):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_198(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(None, todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_199(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), None), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_200(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_201(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), ), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_202(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(None, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_203(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=None), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_204(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_205(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, ), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_206(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=False):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_207(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(None) as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_208(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output * f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_209(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(None)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_210(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(None)
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_211(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) - "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_212(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(None, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_213(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=None) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_214(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_215(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, ) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_216(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=False) + "\n")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_217(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "XX\nXX")
            print(job["id"], flush=True)
    return 0


def x_main__mutmut_218(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(None, flush=True)
    return 0


def x_main__mutmut_219(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=None)
    return 0


def x_main__mutmut_220(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(flush=True)
    return 0


def x_main__mutmut_221(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], )
    return 0


def x_main__mutmut_222(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["XXidXX"], flush=True)
    return 0


def x_main__mutmut_223(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["ID"], flush=True)
    return 0


def x_main__mutmut_224(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=False)
    return 0


def x_main__mutmut_225(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("eligibility", "reference", "severity"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--methods", choices=("classical", "deep"), default="classical")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--only", nargs="*", help="dataset ids, for a quick check")
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    registry = ROOT / "verification" / "evidence" / "dataset_registry"
    todo = [
        j
        for j in jobs(registry, ROOT / "data" / "pool", ROOT / "data" / "adbench")
        if not args.only or j["id"] in args.only
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "eligibility":
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            rows = list(pool.map(eligibility, todo))
        with atomic_path(args.output / "eligibility.json") as partial:
            partial.write_text(json.dumps(rows, indent=1) + "\n")
        print(sum(r["eligible"] for r in rows), "eligible of", len(rows))
        return 0
    eligible = {
        r["id"]
        for r in json.loads((args.output.parent / "eligibility.json").read_text())
        if r["eligible"]
    }
    todo = [j for j in todo if j["id"] in eligible]
    if args.command == "reference":
        todo = [j for j in todo if j["source"] == "adbench"]  # the UCI ones are archived already
    names = list(DEEP_NAMES) if args.methods == "deep" else None
    stem = lambda job: job["id"].replace(":", "_")  # noqa: E731
    if args.resume:
        todo = [j for j in todo if not (args.output / f"{stem(j)}.json").exists()]
    work = run_reference if args.command == "reference" else run_severity
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for job, result in zip(todo, pool.map(bind(work, names=names), todo), strict=True):
            with atomic_path(args.output / f"{stem(job)}.json") as partial:
                partial.write_text(json.dumps(result, sort_keys=True) + "\n")
            print(job["id"], flush=True)
    return 1

mutants_x_main__mutmut['_mutmut_orig'] = x_main__mutmut_orig # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_1'] = x_main__mutmut_1 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_2'] = x_main__mutmut_2 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_3'] = x_main__mutmut_3 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_4'] = x_main__mutmut_4 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_5'] = x_main__mutmut_5 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_6'] = x_main__mutmut_6 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_7'] = x_main__mutmut_7 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_8'] = x_main__mutmut_8 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_9'] = x_main__mutmut_9 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_10'] = x_main__mutmut_10 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_11'] = x_main__mutmut_11 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_12'] = x_main__mutmut_12 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_13'] = x_main__mutmut_13 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_14'] = x_main__mutmut_14 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_15'] = x_main__mutmut_15 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_16'] = x_main__mutmut_16 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_17'] = x_main__mutmut_17 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_18'] = x_main__mutmut_18 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_19'] = x_main__mutmut_19 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_20'] = x_main__mutmut_20 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_21'] = x_main__mutmut_21 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_22'] = x_main__mutmut_22 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_23'] = x_main__mutmut_23 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_24'] = x_main__mutmut_24 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_25'] = x_main__mutmut_25 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_26'] = x_main__mutmut_26 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_27'] = x_main__mutmut_27 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_28'] = x_main__mutmut_28 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_29'] = x_main__mutmut_29 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_30'] = x_main__mutmut_30 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_31'] = x_main__mutmut_31 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_32'] = x_main__mutmut_32 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_33'] = x_main__mutmut_33 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_34'] = x_main__mutmut_34 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_35'] = x_main__mutmut_35 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_36'] = x_main__mutmut_36 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_37'] = x_main__mutmut_37 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_38'] = x_main__mutmut_38 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_39'] = x_main__mutmut_39 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_40'] = x_main__mutmut_40 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_41'] = x_main__mutmut_41 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_42'] = x_main__mutmut_42 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_43'] = x_main__mutmut_43 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_44'] = x_main__mutmut_44 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_45'] = x_main__mutmut_45 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_46'] = x_main__mutmut_46 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_47'] = x_main__mutmut_47 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_48'] = x_main__mutmut_48 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_49'] = x_main__mutmut_49 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_50'] = x_main__mutmut_50 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_51'] = x_main__mutmut_51 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_52'] = x_main__mutmut_52 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_53'] = x_main__mutmut_53 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_54'] = x_main__mutmut_54 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_55'] = x_main__mutmut_55 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_56'] = x_main__mutmut_56 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_57'] = x_main__mutmut_57 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_58'] = x_main__mutmut_58 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_59'] = x_main__mutmut_59 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_60'] = x_main__mutmut_60 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_61'] = x_main__mutmut_61 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_62'] = x_main__mutmut_62 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_63'] = x_main__mutmut_63 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_64'] = x_main__mutmut_64 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_65'] = x_main__mutmut_65 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_66'] = x_main__mutmut_66 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_67'] = x_main__mutmut_67 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_68'] = x_main__mutmut_68 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_69'] = x_main__mutmut_69 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_70'] = x_main__mutmut_70 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_71'] = x_main__mutmut_71 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_72'] = x_main__mutmut_72 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_73'] = x_main__mutmut_73 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_74'] = x_main__mutmut_74 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_75'] = x_main__mutmut_75 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_76'] = x_main__mutmut_76 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_77'] = x_main__mutmut_77 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_78'] = x_main__mutmut_78 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_79'] = x_main__mutmut_79 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_80'] = x_main__mutmut_80 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_81'] = x_main__mutmut_81 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_82'] = x_main__mutmut_82 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_83'] = x_main__mutmut_83 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_84'] = x_main__mutmut_84 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_85'] = x_main__mutmut_85 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_86'] = x_main__mutmut_86 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_87'] = x_main__mutmut_87 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_88'] = x_main__mutmut_88 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_89'] = x_main__mutmut_89 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_90'] = x_main__mutmut_90 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_91'] = x_main__mutmut_91 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_92'] = x_main__mutmut_92 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_93'] = x_main__mutmut_93 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_94'] = x_main__mutmut_94 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_95'] = x_main__mutmut_95 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_96'] = x_main__mutmut_96 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_97'] = x_main__mutmut_97 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_98'] = x_main__mutmut_98 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_99'] = x_main__mutmut_99 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_100'] = x_main__mutmut_100 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_101'] = x_main__mutmut_101 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_102'] = x_main__mutmut_102 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_103'] = x_main__mutmut_103 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_104'] = x_main__mutmut_104 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_105'] = x_main__mutmut_105 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_106'] = x_main__mutmut_106 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_107'] = x_main__mutmut_107 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_108'] = x_main__mutmut_108 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_109'] = x_main__mutmut_109 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_110'] = x_main__mutmut_110 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_111'] = x_main__mutmut_111 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_112'] = x_main__mutmut_112 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_113'] = x_main__mutmut_113 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_114'] = x_main__mutmut_114 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_115'] = x_main__mutmut_115 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_116'] = x_main__mutmut_116 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_117'] = x_main__mutmut_117 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_118'] = x_main__mutmut_118 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_119'] = x_main__mutmut_119 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_120'] = x_main__mutmut_120 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_121'] = x_main__mutmut_121 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_122'] = x_main__mutmut_122 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_123'] = x_main__mutmut_123 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_124'] = x_main__mutmut_124 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_125'] = x_main__mutmut_125 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_126'] = x_main__mutmut_126 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_127'] = x_main__mutmut_127 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_128'] = x_main__mutmut_128 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_129'] = x_main__mutmut_129 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_130'] = x_main__mutmut_130 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_131'] = x_main__mutmut_131 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_132'] = x_main__mutmut_132 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_133'] = x_main__mutmut_133 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_134'] = x_main__mutmut_134 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_135'] = x_main__mutmut_135 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_136'] = x_main__mutmut_136 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_137'] = x_main__mutmut_137 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_138'] = x_main__mutmut_138 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_139'] = x_main__mutmut_139 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_140'] = x_main__mutmut_140 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_141'] = x_main__mutmut_141 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_142'] = x_main__mutmut_142 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_143'] = x_main__mutmut_143 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_144'] = x_main__mutmut_144 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_145'] = x_main__mutmut_145 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_146'] = x_main__mutmut_146 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_147'] = x_main__mutmut_147 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_148'] = x_main__mutmut_148 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_149'] = x_main__mutmut_149 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_150'] = x_main__mutmut_150 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_151'] = x_main__mutmut_151 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_152'] = x_main__mutmut_152 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_153'] = x_main__mutmut_153 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_154'] = x_main__mutmut_154 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_155'] = x_main__mutmut_155 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_156'] = x_main__mutmut_156 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_157'] = x_main__mutmut_157 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_158'] = x_main__mutmut_158 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_159'] = x_main__mutmut_159 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_160'] = x_main__mutmut_160 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_161'] = x_main__mutmut_161 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_162'] = x_main__mutmut_162 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_163'] = x_main__mutmut_163 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_164'] = x_main__mutmut_164 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_165'] = x_main__mutmut_165 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_166'] = x_main__mutmut_166 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_167'] = x_main__mutmut_167 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_168'] = x_main__mutmut_168 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_169'] = x_main__mutmut_169 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_170'] = x_main__mutmut_170 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_171'] = x_main__mutmut_171 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_172'] = x_main__mutmut_172 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_173'] = x_main__mutmut_173 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_174'] = x_main__mutmut_174 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_175'] = x_main__mutmut_175 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_176'] = x_main__mutmut_176 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_177'] = x_main__mutmut_177 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_178'] = x_main__mutmut_178 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_179'] = x_main__mutmut_179 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_180'] = x_main__mutmut_180 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_181'] = x_main__mutmut_181 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_182'] = x_main__mutmut_182 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_183'] = x_main__mutmut_183 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_184'] = x_main__mutmut_184 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_185'] = x_main__mutmut_185 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_186'] = x_main__mutmut_186 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_187'] = x_main__mutmut_187 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_188'] = x_main__mutmut_188 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_189'] = x_main__mutmut_189 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_190'] = x_main__mutmut_190 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_191'] = x_main__mutmut_191 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_192'] = x_main__mutmut_192 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_193'] = x_main__mutmut_193 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_194'] = x_main__mutmut_194 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_195'] = x_main__mutmut_195 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_196'] = x_main__mutmut_196 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_197'] = x_main__mutmut_197 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_198'] = x_main__mutmut_198 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_199'] = x_main__mutmut_199 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_200'] = x_main__mutmut_200 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_201'] = x_main__mutmut_201 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_202'] = x_main__mutmut_202 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_203'] = x_main__mutmut_203 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_204'] = x_main__mutmut_204 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_205'] = x_main__mutmut_205 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_206'] = x_main__mutmut_206 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_207'] = x_main__mutmut_207 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_208'] = x_main__mutmut_208 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_209'] = x_main__mutmut_209 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_210'] = x_main__mutmut_210 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_211'] = x_main__mutmut_211 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_212'] = x_main__mutmut_212 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_213'] = x_main__mutmut_213 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_214'] = x_main__mutmut_214 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_215'] = x_main__mutmut_215 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_216'] = x_main__mutmut_216 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_217'] = x_main__mutmut_217 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_218'] = x_main__mutmut_218 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_219'] = x_main__mutmut_219 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_220'] = x_main__mutmut_220 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_221'] = x_main__mutmut_221 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_222'] = x_main__mutmut_222 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_223'] = x_main__mutmut_223 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_224'] = x_main__mutmut_224 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_225'] = x_main__mutmut_225 # type: ignore # mutmut generated


if __name__ == "__main__":
    raise SystemExit(main())
