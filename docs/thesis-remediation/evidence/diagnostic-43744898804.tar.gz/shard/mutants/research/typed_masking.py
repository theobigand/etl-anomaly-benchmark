"""Diagnostic: do invalid-format rows in the training split mask the z-score on univariate outliers?

The z-score detector fits its mean and standard deviation on the training split, which contains
the injected rows. A sentinel or a thousandfold scale error inflates the standard deviation and
hides moderate outliers. The diagnostic refits the same detector without the invalid rows.
"""

from __future__ import annotations

import argparse
import json
import warnings
from pathlib import Path

import injection as inj
import pandas as pd
import typed_benchmark as tb

from etl_benchmark import config
from etl_benchmark.quality import ZScoreDetector


from mutmut.mutation.trampoline import wrap_in_trampoline as _mutmut_mutated, MutantDict
mutants_x_masking__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_masking__mutmut)
def masking(df: pd.DataFrame, cols: list[str], seed: int) -> dict[str, float]:
    train, _val, test = tb.split(df, seed)
    rows = test["anomaly_type"] == "univariate_outlier"
    out = {}
    for label, part in (
        ("with_invalid_in_train", train),
        ("without_invalid_in_train", train[train["anomaly_type"] != "invalid_format"]),
    ):
        detector = ZScoreDetector(threshold=config.ZSCORE_THRESHOLD).fit(part[cols])
        out[label] = float(detector.predict(test[cols])[rows].mean())
    return out


def x_masking__mutmut_orig(df: pd.DataFrame, cols: list[str], seed: int) -> dict[str, float]:
    train, _val, test = tb.split(df, seed)
    rows = test["anomaly_type"] == "univariate_outlier"
    out = {}
    for label, part in (
        ("with_invalid_in_train", train),
        ("without_invalid_in_train", train[train["anomaly_type"] != "invalid_format"]),
    ):
        detector = ZScoreDetector(threshold=config.ZSCORE_THRESHOLD).fit(part[cols])
        out[label] = float(detector.predict(test[cols])[rows].mean())
    return out


def x_masking__mutmut_1(df: pd.DataFrame, cols: list[str], seed: int) -> dict[str, float]:
    train, _val, test = None
    rows = test["anomaly_type"] == "univariate_outlier"
    out = {}
    for label, part in (
        ("with_invalid_in_train", train),
        ("without_invalid_in_train", train[train["anomaly_type"] != "invalid_format"]),
    ):
        detector = ZScoreDetector(threshold=config.ZSCORE_THRESHOLD).fit(part[cols])
        out[label] = float(detector.predict(test[cols])[rows].mean())
    return out


def x_masking__mutmut_2(df: pd.DataFrame, cols: list[str], seed: int) -> dict[str, float]:
    train, _val, test = tb.split(None, seed)
    rows = test["anomaly_type"] == "univariate_outlier"
    out = {}
    for label, part in (
        ("with_invalid_in_train", train),
        ("without_invalid_in_train", train[train["anomaly_type"] != "invalid_format"]),
    ):
        detector = ZScoreDetector(threshold=config.ZSCORE_THRESHOLD).fit(part[cols])
        out[label] = float(detector.predict(test[cols])[rows].mean())
    return out


def x_masking__mutmut_3(df: pd.DataFrame, cols: list[str], seed: int) -> dict[str, float]:
    train, _val, test = tb.split(df, None)
    rows = test["anomaly_type"] == "univariate_outlier"
    out = {}
    for label, part in (
        ("with_invalid_in_train", train),
        ("without_invalid_in_train", train[train["anomaly_type"] != "invalid_format"]),
    ):
        detector = ZScoreDetector(threshold=config.ZSCORE_THRESHOLD).fit(part[cols])
        out[label] = float(detector.predict(test[cols])[rows].mean())
    return out


def x_masking__mutmut_4(df: pd.DataFrame, cols: list[str], seed: int) -> dict[str, float]:
    train, _val, test = tb.split(seed)
    rows = test["anomaly_type"] == "univariate_outlier"
    out = {}
    for label, part in (
        ("with_invalid_in_train", train),
        ("without_invalid_in_train", train[train["anomaly_type"] != "invalid_format"]),
    ):
        detector = ZScoreDetector(threshold=config.ZSCORE_THRESHOLD).fit(part[cols])
        out[label] = float(detector.predict(test[cols])[rows].mean())
    return out


def x_masking__mutmut_5(df: pd.DataFrame, cols: list[str], seed: int) -> dict[str, float]:
    train, _val, test = tb.split(df, )
    rows = test["anomaly_type"] == "univariate_outlier"
    out = {}
    for label, part in (
        ("with_invalid_in_train", train),
        ("without_invalid_in_train", train[train["anomaly_type"] != "invalid_format"]),
    ):
        detector = ZScoreDetector(threshold=config.ZSCORE_THRESHOLD).fit(part[cols])
        out[label] = float(detector.predict(test[cols])[rows].mean())
    return out


def x_masking__mutmut_6(df: pd.DataFrame, cols: list[str], seed: int) -> dict[str, float]:
    train, _val, test = tb.rsplit(df, seed)
    rows = test["anomaly_type"] == "univariate_outlier"
    out = {}
    for label, part in (
        ("with_invalid_in_train", train),
        ("without_invalid_in_train", train[train["anomaly_type"] != "invalid_format"]),
    ):
        detector = ZScoreDetector(threshold=config.ZSCORE_THRESHOLD).fit(part[cols])
        out[label] = float(detector.predict(test[cols])[rows].mean())
    return out


def x_masking__mutmut_7(df: pd.DataFrame, cols: list[str], seed: int) -> dict[str, float]:
    train, _val, test = tb.split(df, seed)
    rows = None
    out = {}
    for label, part in (
        ("with_invalid_in_train", train),
        ("without_invalid_in_train", train[train["anomaly_type"] != "invalid_format"]),
    ):
        detector = ZScoreDetector(threshold=config.ZSCORE_THRESHOLD).fit(part[cols])
        out[label] = float(detector.predict(test[cols])[rows].mean())
    return out


def x_masking__mutmut_8(df: pd.DataFrame, cols: list[str], seed: int) -> dict[str, float]:
    train, _val, test = tb.split(df, seed)
    rows = test["XXanomaly_typeXX"] == "univariate_outlier"
    out = {}
    for label, part in (
        ("with_invalid_in_train", train),
        ("without_invalid_in_train", train[train["anomaly_type"] != "invalid_format"]),
    ):
        detector = ZScoreDetector(threshold=config.ZSCORE_THRESHOLD).fit(part[cols])
        out[label] = float(detector.predict(test[cols])[rows].mean())
    return out


def x_masking__mutmut_9(df: pd.DataFrame, cols: list[str], seed: int) -> dict[str, float]:
    train, _val, test = tb.split(df, seed)
    rows = test["ANOMALY_TYPE"] == "univariate_outlier"
    out = {}
    for label, part in (
        ("with_invalid_in_train", train),
        ("without_invalid_in_train", train[train["anomaly_type"] != "invalid_format"]),
    ):
        detector = ZScoreDetector(threshold=config.ZSCORE_THRESHOLD).fit(part[cols])
        out[label] = float(detector.predict(test[cols])[rows].mean())
    return out


def x_masking__mutmut_10(df: pd.DataFrame, cols: list[str], seed: int) -> dict[str, float]:
    train, _val, test = tb.split(df, seed)
    rows = test["anomaly_type"] != "univariate_outlier"
    out = {}
    for label, part in (
        ("with_invalid_in_train", train),
        ("without_invalid_in_train", train[train["anomaly_type"] != "invalid_format"]),
    ):
        detector = ZScoreDetector(threshold=config.ZSCORE_THRESHOLD).fit(part[cols])
        out[label] = float(detector.predict(test[cols])[rows].mean())
    return out


def x_masking__mutmut_11(df: pd.DataFrame, cols: list[str], seed: int) -> dict[str, float]:
    train, _val, test = tb.split(df, seed)
    rows = test["anomaly_type"] == "XXunivariate_outlierXX"
    out = {}
    for label, part in (
        ("with_invalid_in_train", train),
        ("without_invalid_in_train", train[train["anomaly_type"] != "invalid_format"]),
    ):
        detector = ZScoreDetector(threshold=config.ZSCORE_THRESHOLD).fit(part[cols])
        out[label] = float(detector.predict(test[cols])[rows].mean())
    return out


def x_masking__mutmut_12(df: pd.DataFrame, cols: list[str], seed: int) -> dict[str, float]:
    train, _val, test = tb.split(df, seed)
    rows = test["anomaly_type"] == "UNIVARIATE_OUTLIER"
    out = {}
    for label, part in (
        ("with_invalid_in_train", train),
        ("without_invalid_in_train", train[train["anomaly_type"] != "invalid_format"]),
    ):
        detector = ZScoreDetector(threshold=config.ZSCORE_THRESHOLD).fit(part[cols])
        out[label] = float(detector.predict(test[cols])[rows].mean())
    return out


def x_masking__mutmut_13(df: pd.DataFrame, cols: list[str], seed: int) -> dict[str, float]:
    train, _val, test = tb.split(df, seed)
    rows = test["anomaly_type"] == "univariate_outlier"
    out = None
    for label, part in (
        ("with_invalid_in_train", train),
        ("without_invalid_in_train", train[train["anomaly_type"] != "invalid_format"]),
    ):
        detector = ZScoreDetector(threshold=config.ZSCORE_THRESHOLD).fit(part[cols])
        out[label] = float(detector.predict(test[cols])[rows].mean())
    return out


def x_masking__mutmut_14(df: pd.DataFrame, cols: list[str], seed: int) -> dict[str, float]:
    train, _val, test = tb.split(df, seed)
    rows = test["anomaly_type"] == "univariate_outlier"
    out = {}
    for label, part in (
        ("XXwith_invalid_in_trainXX", train),
        ("without_invalid_in_train", train[train["anomaly_type"] != "invalid_format"]),
    ):
        detector = ZScoreDetector(threshold=config.ZSCORE_THRESHOLD).fit(part[cols])
        out[label] = float(detector.predict(test[cols])[rows].mean())
    return out


def x_masking__mutmut_15(df: pd.DataFrame, cols: list[str], seed: int) -> dict[str, float]:
    train, _val, test = tb.split(df, seed)
    rows = test["anomaly_type"] == "univariate_outlier"
    out = {}
    for label, part in (
        ("WITH_INVALID_IN_TRAIN", train),
        ("without_invalid_in_train", train[train["anomaly_type"] != "invalid_format"]),
    ):
        detector = ZScoreDetector(threshold=config.ZSCORE_THRESHOLD).fit(part[cols])
        out[label] = float(detector.predict(test[cols])[rows].mean())
    return out


def x_masking__mutmut_16(df: pd.DataFrame, cols: list[str], seed: int) -> dict[str, float]:
    train, _val, test = tb.split(df, seed)
    rows = test["anomaly_type"] == "univariate_outlier"
    out = {}
    for label, part in (
        ("with_invalid_in_train", train),
        ("XXwithout_invalid_in_trainXX", train[train["anomaly_type"] != "invalid_format"]),
    ):
        detector = ZScoreDetector(threshold=config.ZSCORE_THRESHOLD).fit(part[cols])
        out[label] = float(detector.predict(test[cols])[rows].mean())
    return out


def x_masking__mutmut_17(df: pd.DataFrame, cols: list[str], seed: int) -> dict[str, float]:
    train, _val, test = tb.split(df, seed)
    rows = test["anomaly_type"] == "univariate_outlier"
    out = {}
    for label, part in (
        ("with_invalid_in_train", train),
        ("WITHOUT_INVALID_IN_TRAIN", train[train["anomaly_type"] != "invalid_format"]),
    ):
        detector = ZScoreDetector(threshold=config.ZSCORE_THRESHOLD).fit(part[cols])
        out[label] = float(detector.predict(test[cols])[rows].mean())
    return out


def x_masking__mutmut_18(df: pd.DataFrame, cols: list[str], seed: int) -> dict[str, float]:
    train, _val, test = tb.split(df, seed)
    rows = test["anomaly_type"] == "univariate_outlier"
    out = {}
    for label, part in (
        ("with_invalid_in_train", train),
        ("without_invalid_in_train", train[train["XXanomaly_typeXX"] != "invalid_format"]),
    ):
        detector = ZScoreDetector(threshold=config.ZSCORE_THRESHOLD).fit(part[cols])
        out[label] = float(detector.predict(test[cols])[rows].mean())
    return out


def x_masking__mutmut_19(df: pd.DataFrame, cols: list[str], seed: int) -> dict[str, float]:
    train, _val, test = tb.split(df, seed)
    rows = test["anomaly_type"] == "univariate_outlier"
    out = {}
    for label, part in (
        ("with_invalid_in_train", train),
        ("without_invalid_in_train", train[train["ANOMALY_TYPE"] != "invalid_format"]),
    ):
        detector = ZScoreDetector(threshold=config.ZSCORE_THRESHOLD).fit(part[cols])
        out[label] = float(detector.predict(test[cols])[rows].mean())
    return out


def x_masking__mutmut_20(df: pd.DataFrame, cols: list[str], seed: int) -> dict[str, float]:
    train, _val, test = tb.split(df, seed)
    rows = test["anomaly_type"] == "univariate_outlier"
    out = {}
    for label, part in (
        ("with_invalid_in_train", train),
        ("without_invalid_in_train", train[train["anomaly_type"] == "invalid_format"]),
    ):
        detector = ZScoreDetector(threshold=config.ZSCORE_THRESHOLD).fit(part[cols])
        out[label] = float(detector.predict(test[cols])[rows].mean())
    return out


def x_masking__mutmut_21(df: pd.DataFrame, cols: list[str], seed: int) -> dict[str, float]:
    train, _val, test = tb.split(df, seed)
    rows = test["anomaly_type"] == "univariate_outlier"
    out = {}
    for label, part in (
        ("with_invalid_in_train", train),
        ("without_invalid_in_train", train[train["anomaly_type"] != "XXinvalid_formatXX"]),
    ):
        detector = ZScoreDetector(threshold=config.ZSCORE_THRESHOLD).fit(part[cols])
        out[label] = float(detector.predict(test[cols])[rows].mean())
    return out


def x_masking__mutmut_22(df: pd.DataFrame, cols: list[str], seed: int) -> dict[str, float]:
    train, _val, test = tb.split(df, seed)
    rows = test["anomaly_type"] == "univariate_outlier"
    out = {}
    for label, part in (
        ("with_invalid_in_train", train),
        ("without_invalid_in_train", train[train["anomaly_type"] != "INVALID_FORMAT"]),
    ):
        detector = ZScoreDetector(threshold=config.ZSCORE_THRESHOLD).fit(part[cols])
        out[label] = float(detector.predict(test[cols])[rows].mean())
    return out


def x_masking__mutmut_23(df: pd.DataFrame, cols: list[str], seed: int) -> dict[str, float]:
    train, _val, test = tb.split(df, seed)
    rows = test["anomaly_type"] == "univariate_outlier"
    out = {}
    for label, part in (
        ("with_invalid_in_train", train),
        ("without_invalid_in_train", train[train["anomaly_type"] != "invalid_format"]),
    ):
        detector = None
        out[label] = float(detector.predict(test[cols])[rows].mean())
    return out


def x_masking__mutmut_24(df: pd.DataFrame, cols: list[str], seed: int) -> dict[str, float]:
    train, _val, test = tb.split(df, seed)
    rows = test["anomaly_type"] == "univariate_outlier"
    out = {}
    for label, part in (
        ("with_invalid_in_train", train),
        ("without_invalid_in_train", train[train["anomaly_type"] != "invalid_format"]),
    ):
        detector = ZScoreDetector(threshold=config.ZSCORE_THRESHOLD).fit(None)
        out[label] = float(detector.predict(test[cols])[rows].mean())
    return out


def x_masking__mutmut_25(df: pd.DataFrame, cols: list[str], seed: int) -> dict[str, float]:
    train, _val, test = tb.split(df, seed)
    rows = test["anomaly_type"] == "univariate_outlier"
    out = {}
    for label, part in (
        ("with_invalid_in_train", train),
        ("without_invalid_in_train", train[train["anomaly_type"] != "invalid_format"]),
    ):
        detector = ZScoreDetector(threshold=None).fit(part[cols])
        out[label] = float(detector.predict(test[cols])[rows].mean())
    return out


def x_masking__mutmut_26(df: pd.DataFrame, cols: list[str], seed: int) -> dict[str, float]:
    train, _val, test = tb.split(df, seed)
    rows = test["anomaly_type"] == "univariate_outlier"
    out = {}
    for label, part in (
        ("with_invalid_in_train", train),
        ("without_invalid_in_train", train[train["anomaly_type"] != "invalid_format"]),
    ):
        detector = ZScoreDetector(threshold=config.ZSCORE_THRESHOLD).fit(part[cols])
        out[label] = None
    return out


def x_masking__mutmut_27(df: pd.DataFrame, cols: list[str], seed: int) -> dict[str, float]:
    train, _val, test = tb.split(df, seed)
    rows = test["anomaly_type"] == "univariate_outlier"
    out = {}
    for label, part in (
        ("with_invalid_in_train", train),
        ("without_invalid_in_train", train[train["anomaly_type"] != "invalid_format"]),
    ):
        detector = ZScoreDetector(threshold=config.ZSCORE_THRESHOLD).fit(part[cols])
        out[label] = float(None)
    return out


def x_masking__mutmut_28(df: pd.DataFrame, cols: list[str], seed: int) -> dict[str, float]:
    train, _val, test = tb.split(df, seed)
    rows = test["anomaly_type"] == "univariate_outlier"
    out = {}
    for label, part in (
        ("with_invalid_in_train", train),
        ("without_invalid_in_train", train[train["anomaly_type"] != "invalid_format"]),
    ):
        detector = ZScoreDetector(threshold=config.ZSCORE_THRESHOLD).fit(part[cols])
        out[label] = float(detector.predict(None)[rows].mean())
    return out

mutants_x_masking__mutmut['_mutmut_orig'] = x_masking__mutmut_orig # type: ignore # mutmut generated
mutants_x_masking__mutmut['x_masking__mutmut_1'] = x_masking__mutmut_1 # type: ignore # mutmut generated
mutants_x_masking__mutmut['x_masking__mutmut_2'] = x_masking__mutmut_2 # type: ignore # mutmut generated
mutants_x_masking__mutmut['x_masking__mutmut_3'] = x_masking__mutmut_3 # type: ignore # mutmut generated
mutants_x_masking__mutmut['x_masking__mutmut_4'] = x_masking__mutmut_4 # type: ignore # mutmut generated
mutants_x_masking__mutmut['x_masking__mutmut_5'] = x_masking__mutmut_5 # type: ignore # mutmut generated
mutants_x_masking__mutmut['x_masking__mutmut_6'] = x_masking__mutmut_6 # type: ignore # mutmut generated
mutants_x_masking__mutmut['x_masking__mutmut_7'] = x_masking__mutmut_7 # type: ignore # mutmut generated
mutants_x_masking__mutmut['x_masking__mutmut_8'] = x_masking__mutmut_8 # type: ignore # mutmut generated
mutants_x_masking__mutmut['x_masking__mutmut_9'] = x_masking__mutmut_9 # type: ignore # mutmut generated
mutants_x_masking__mutmut['x_masking__mutmut_10'] = x_masking__mutmut_10 # type: ignore # mutmut generated
mutants_x_masking__mutmut['x_masking__mutmut_11'] = x_masking__mutmut_11 # type: ignore # mutmut generated
mutants_x_masking__mutmut['x_masking__mutmut_12'] = x_masking__mutmut_12 # type: ignore # mutmut generated
mutants_x_masking__mutmut['x_masking__mutmut_13'] = x_masking__mutmut_13 # type: ignore # mutmut generated
mutants_x_masking__mutmut['x_masking__mutmut_14'] = x_masking__mutmut_14 # type: ignore # mutmut generated
mutants_x_masking__mutmut['x_masking__mutmut_15'] = x_masking__mutmut_15 # type: ignore # mutmut generated
mutants_x_masking__mutmut['x_masking__mutmut_16'] = x_masking__mutmut_16 # type: ignore # mutmut generated
mutants_x_masking__mutmut['x_masking__mutmut_17'] = x_masking__mutmut_17 # type: ignore # mutmut generated
mutants_x_masking__mutmut['x_masking__mutmut_18'] = x_masking__mutmut_18 # type: ignore # mutmut generated
mutants_x_masking__mutmut['x_masking__mutmut_19'] = x_masking__mutmut_19 # type: ignore # mutmut generated
mutants_x_masking__mutmut['x_masking__mutmut_20'] = x_masking__mutmut_20 # type: ignore # mutmut generated
mutants_x_masking__mutmut['x_masking__mutmut_21'] = x_masking__mutmut_21 # type: ignore # mutmut generated
mutants_x_masking__mutmut['x_masking__mutmut_22'] = x_masking__mutmut_22 # type: ignore # mutmut generated
mutants_x_masking__mutmut['x_masking__mutmut_23'] = x_masking__mutmut_23 # type: ignore # mutmut generated
mutants_x_masking__mutmut['x_masking__mutmut_24'] = x_masking__mutmut_24 # type: ignore # mutmut generated
mutants_x_masking__mutmut['x_masking__mutmut_25'] = x_masking__mutmut_25 # type: ignore # mutmut generated
mutants_x_masking__mutmut['x_masking__mutmut_26'] = x_masking__mutmut_26 # type: ignore # mutmut generated
mutants_x_masking__mutmut['x_masking__mutmut_27'] = x_masking__mutmut_27 # type: ignore # mutmut generated
mutants_x_masking__mutmut['x_masking__mutmut_28'] = x_masking__mutmut_28 # type: ignore # mutmut generated
mutants_x_main__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_main__mutmut)
def main(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_orig(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_1(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings(None)
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_2(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("XXignoreXX")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_3(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("IGNORE")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_4(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = None
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_5(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=None)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_6(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(None, type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_7(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=None, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_8(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=None, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_9(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help=None)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_10(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_11(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_12(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_13(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_14(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("XX--runsXX", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_15(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--RUNS", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_16(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=False, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_17(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="XXtyped_run output, for the idsXX")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_18(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="TYPED_RUN OUTPUT, FOR THE IDS")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_19(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument(None, type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_20(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=None, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_21(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=None)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_22(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument(type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_23(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_24(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, )
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_25(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("XX--outputXX", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_26(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--OUTPUT", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_27(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=False)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_28(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = None
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_29(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(None)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_30(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = None
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_31(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(None).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_32(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[2]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_33(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = None
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_34(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" * "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_35(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" * "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_36(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root * "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_37(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "XXverificationXX" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_38(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "VERIFICATION" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_39(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "XXevidenceXX" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_40(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "EVIDENCE" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_41(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "XXdataset_registryXX"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_42(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "DATASET_REGISTRY"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_43(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = None
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_44(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["XXuci_idXX"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_45(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["UCI_ID"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_46(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads(None)["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_47(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry * "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_48(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "XXuci_curated.jsonXX").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_49(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "UCI_CURATED.JSON").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_50(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["XXkeptXX"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_51(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["KEPT"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_52(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = None
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_53(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(None):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_54(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob(None)):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_55(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("XX*.jsonXX")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_56(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.JSON")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_57(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = None
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_58(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(None)["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_59(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["XXuci_idXX"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_60(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["UCI_ID"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_61(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = None
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_62(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(None, root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_63(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], None, seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_64(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=None)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_65(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_66(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_67(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", )
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_68(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" * f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_69(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" * "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_70(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root * "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_71(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "XXdataXX" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_72(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "DATA" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_73(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "XXpoolXX" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_74(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "POOL" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_75(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=1)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_76(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = None
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_77(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(None, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_78(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=None)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_79(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_80(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, )
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_81(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            None
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_82(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "XXuci_idXX": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_83(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "UCI_ID": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_84(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "XXnameXX": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_85(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "NAME": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_86(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["XXnameXX"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_87(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["NAME"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_88(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(None, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_89(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, None, config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_90(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), None),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_91(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_92(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_93(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), ),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_94(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(None), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_95(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(None)
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_96(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) - "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_97(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(None, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_98(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=None) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_99(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_100(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, ) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_101(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=2) + "\n")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_102(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "XX\nXX")
    print(f"{len(rows)} datasets")
    return 0


def x_main__mutmut_103(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(None)
    return 0


def x_main__mutmut_104(argv: list[str] | None = None) -> int:
    import typed_run as tr

    warnings.filterwarnings("ignore")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True, help="typed_run output, for the ids")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    registry = root / "verification" / "evidence" / "dataset_registry"
    meta = {m["uci_id"]: m for m in json.loads((registry / "uci_curated.json").read_text())["kept"]}
    rows = []
    for path in sorted(args.runs.glob("*.json")):
        uci_id = json.loads(path.read_text())["uci_id"]
        carrier, _ = tr.load_carrier(meta[uci_id], root / "data" / "pool" / f"{uci_id}.csv", seed=0)
        df = inj.inject(carrier, seed=config.RANDOM_SEED)
        rows.append(
            {
                "uci_id": uci_id,
                "name": meta[uci_id]["name"],
                **masking(df, list(carrier.columns), config.RANDOM_SEED),
            }
        )
    args.output.write_text(json.dumps(rows, indent=1) + "\n")
    print(f"{len(rows)} datasets")
    return 1

mutants_x_main__mutmut['_mutmut_orig'] = x_main__mutmut_orig # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_1'] = x_main__mutmut_1 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_2'] = x_main__mutmut_2 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_3'] = x_main__mutmut_3 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_4'] = x_main__mutmut_4 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_5'] = x_main__mutmut_5 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_6'] = x_main__mutmut_6 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_7'] = x_main__mutmut_7 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_8'] = x_main__mutmut_8 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_9'] = x_main__mutmut_9 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_10'] = x_main__mutmut_10 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_11'] = x_main__mutmut_11 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_12'] = x_main__mutmut_12 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_13'] = x_main__mutmut_13 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_14'] = x_main__mutmut_14 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_15'] = x_main__mutmut_15 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_16'] = x_main__mutmut_16 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_17'] = x_main__mutmut_17 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_18'] = x_main__mutmut_18 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_19'] = x_main__mutmut_19 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_20'] = x_main__mutmut_20 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_21'] = x_main__mutmut_21 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_22'] = x_main__mutmut_22 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_23'] = x_main__mutmut_23 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_24'] = x_main__mutmut_24 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_25'] = x_main__mutmut_25 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_26'] = x_main__mutmut_26 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_27'] = x_main__mutmut_27 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_28'] = x_main__mutmut_28 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_29'] = x_main__mutmut_29 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_30'] = x_main__mutmut_30 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_31'] = x_main__mutmut_31 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_32'] = x_main__mutmut_32 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_33'] = x_main__mutmut_33 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_34'] = x_main__mutmut_34 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_35'] = x_main__mutmut_35 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_36'] = x_main__mutmut_36 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_37'] = x_main__mutmut_37 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_38'] = x_main__mutmut_38 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_39'] = x_main__mutmut_39 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_40'] = x_main__mutmut_40 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_41'] = x_main__mutmut_41 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_42'] = x_main__mutmut_42 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_43'] = x_main__mutmut_43 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_44'] = x_main__mutmut_44 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_45'] = x_main__mutmut_45 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_46'] = x_main__mutmut_46 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_47'] = x_main__mutmut_47 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_48'] = x_main__mutmut_48 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_49'] = x_main__mutmut_49 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_50'] = x_main__mutmut_50 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_51'] = x_main__mutmut_51 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_52'] = x_main__mutmut_52 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_53'] = x_main__mutmut_53 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_54'] = x_main__mutmut_54 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_55'] = x_main__mutmut_55 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_56'] = x_main__mutmut_56 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_57'] = x_main__mutmut_57 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_58'] = x_main__mutmut_58 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_59'] = x_main__mutmut_59 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_60'] = x_main__mutmut_60 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_61'] = x_main__mutmut_61 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_62'] = x_main__mutmut_62 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_63'] = x_main__mutmut_63 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_64'] = x_main__mutmut_64 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_65'] = x_main__mutmut_65 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_66'] = x_main__mutmut_66 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_67'] = x_main__mutmut_67 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_68'] = x_main__mutmut_68 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_69'] = x_main__mutmut_69 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_70'] = x_main__mutmut_70 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_71'] = x_main__mutmut_71 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_72'] = x_main__mutmut_72 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_73'] = x_main__mutmut_73 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_74'] = x_main__mutmut_74 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_75'] = x_main__mutmut_75 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_76'] = x_main__mutmut_76 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_77'] = x_main__mutmut_77 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_78'] = x_main__mutmut_78 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_79'] = x_main__mutmut_79 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_80'] = x_main__mutmut_80 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_81'] = x_main__mutmut_81 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_82'] = x_main__mutmut_82 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_83'] = x_main__mutmut_83 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_84'] = x_main__mutmut_84 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_85'] = x_main__mutmut_85 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_86'] = x_main__mutmut_86 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_87'] = x_main__mutmut_87 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_88'] = x_main__mutmut_88 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_89'] = x_main__mutmut_89 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_90'] = x_main__mutmut_90 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_91'] = x_main__mutmut_91 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_92'] = x_main__mutmut_92 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_93'] = x_main__mutmut_93 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_94'] = x_main__mutmut_94 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_95'] = x_main__mutmut_95 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_96'] = x_main__mutmut_96 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_97'] = x_main__mutmut_97 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_98'] = x_main__mutmut_98 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_99'] = x_main__mutmut_99 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_100'] = x_main__mutmut_100 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_101'] = x_main__mutmut_101 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_102'] = x_main__mutmut_102 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_103'] = x_main__mutmut_103 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_104'] = x_main__mutmut_104 # type: ignore # mutmut generated


if __name__ == "__main__":
    raise SystemExit(main())
