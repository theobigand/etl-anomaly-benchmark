"""Choose relevant datasets from the UCI catalogue for the benchmark pool (issue 66).

A dataset enters the pool only if its metadata makes it usable (tabular, a sensible size, a
download URL, a classification or regression task), its own page states an open licence, and
its identity matches the catalogue. Every dataset also gets strata tags (size, dimension,
missing values, mixed types, time order, domain) so that the benchmark and the tests can draw
from specific categories. Nothing is redistributed; only metadata and checksums are recorded.
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from collections import Counter
from collections.abc import Callable
from pathlib import Path
from typing import Any

HERE = Path(__file__).resolve().parent
sys.path[:0] = [str(HERE), str(HERE.parent / "src")]

import dataset_registry as dr  # noqa: E402

API = "https://archive.ics.uci.edu/api"
ACCEPTED = {"CC BY 4.0", "CC0 1.0"}
EXCLUDED_MODALITIES = {"Image", "Text", "Sequential"}
TASKS = {"Classification", "Regression"}
MIN_ROWS, MAX_ROWS, MIN_FEATURES, MAX_FEATURES = 300, 1_000_000, 4, 300


from mutmut.mutation.trampoline import wrap_in_trampoline as _mutmut_mutated, MutantDict
mutants_x_rejection__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_rejection__mutmut)
def rejection(meta: dict[str, Any]) -> str | None:
    reasons = []
    rows, features = meta.get("num_instances"), meta.get("num_features")
    if rows is None or not MIN_ROWS <= rows <= MAX_ROWS:
        reasons.append(f"rows ({rows})")
    if features is None or not MIN_FEATURES <= features <= MAX_FEATURES:
        reasons.append(f"features ({features})")
    if EXCLUDED_MODALITIES & set(meta.get("characteristics") or []):
        reasons.append("modality")
    if not TASKS & set(meta.get("tasks") or []):
        reasons.append("task")
    if not meta.get("data_url"):
        reasons.append("download")
    return "; ".join(reasons) or None


def x_rejection__mutmut_orig(meta: dict[str, Any]) -> str | None:
    reasons = []
    rows, features = meta.get("num_instances"), meta.get("num_features")
    if rows is None or not MIN_ROWS <= rows <= MAX_ROWS:
        reasons.append(f"rows ({rows})")
    if features is None or not MIN_FEATURES <= features <= MAX_FEATURES:
        reasons.append(f"features ({features})")
    if EXCLUDED_MODALITIES & set(meta.get("characteristics") or []):
        reasons.append("modality")
    if not TASKS & set(meta.get("tasks") or []):
        reasons.append("task")
    if not meta.get("data_url"):
        reasons.append("download")
    return "; ".join(reasons) or None


def x_rejection__mutmut_1(meta: dict[str, Any]) -> str | None:
    reasons = None
    rows, features = meta.get("num_instances"), meta.get("num_features")
    if rows is None or not MIN_ROWS <= rows <= MAX_ROWS:
        reasons.append(f"rows ({rows})")
    if features is None or not MIN_FEATURES <= features <= MAX_FEATURES:
        reasons.append(f"features ({features})")
    if EXCLUDED_MODALITIES & set(meta.get("characteristics") or []):
        reasons.append("modality")
    if not TASKS & set(meta.get("tasks") or []):
        reasons.append("task")
    if not meta.get("data_url"):
        reasons.append("download")
    return "; ".join(reasons) or None


def x_rejection__mutmut_2(meta: dict[str, Any]) -> str | None:
    reasons = []
    rows, features = None
    if rows is None or not MIN_ROWS <= rows <= MAX_ROWS:
        reasons.append(f"rows ({rows})")
    if features is None or not MIN_FEATURES <= features <= MAX_FEATURES:
        reasons.append(f"features ({features})")
    if EXCLUDED_MODALITIES & set(meta.get("characteristics") or []):
        reasons.append("modality")
    if not TASKS & set(meta.get("tasks") or []):
        reasons.append("task")
    if not meta.get("data_url"):
        reasons.append("download")
    return "; ".join(reasons) or None


def x_rejection__mutmut_3(meta: dict[str, Any]) -> str | None:
    reasons = []
    rows, features = meta.get(None), meta.get("num_features")
    if rows is None or not MIN_ROWS <= rows <= MAX_ROWS:
        reasons.append(f"rows ({rows})")
    if features is None or not MIN_FEATURES <= features <= MAX_FEATURES:
        reasons.append(f"features ({features})")
    if EXCLUDED_MODALITIES & set(meta.get("characteristics") or []):
        reasons.append("modality")
    if not TASKS & set(meta.get("tasks") or []):
        reasons.append("task")
    if not meta.get("data_url"):
        reasons.append("download")
    return "; ".join(reasons) or None


def x_rejection__mutmut_4(meta: dict[str, Any]) -> str | None:
    reasons = []
    rows, features = meta.get("XXnum_instancesXX"), meta.get("num_features")
    if rows is None or not MIN_ROWS <= rows <= MAX_ROWS:
        reasons.append(f"rows ({rows})")
    if features is None or not MIN_FEATURES <= features <= MAX_FEATURES:
        reasons.append(f"features ({features})")
    if EXCLUDED_MODALITIES & set(meta.get("characteristics") or []):
        reasons.append("modality")
    if not TASKS & set(meta.get("tasks") or []):
        reasons.append("task")
    if not meta.get("data_url"):
        reasons.append("download")
    return "; ".join(reasons) or None


def x_rejection__mutmut_5(meta: dict[str, Any]) -> str | None:
    reasons = []
    rows, features = meta.get("NUM_INSTANCES"), meta.get("num_features")
    if rows is None or not MIN_ROWS <= rows <= MAX_ROWS:
        reasons.append(f"rows ({rows})")
    if features is None or not MIN_FEATURES <= features <= MAX_FEATURES:
        reasons.append(f"features ({features})")
    if EXCLUDED_MODALITIES & set(meta.get("characteristics") or []):
        reasons.append("modality")
    if not TASKS & set(meta.get("tasks") or []):
        reasons.append("task")
    if not meta.get("data_url"):
        reasons.append("download")
    return "; ".join(reasons) or None


def x_rejection__mutmut_6(meta: dict[str, Any]) -> str | None:
    reasons = []
    rows, features = meta.get("num_instances"), meta.get(None)
    if rows is None or not MIN_ROWS <= rows <= MAX_ROWS:
        reasons.append(f"rows ({rows})")
    if features is None or not MIN_FEATURES <= features <= MAX_FEATURES:
        reasons.append(f"features ({features})")
    if EXCLUDED_MODALITIES & set(meta.get("characteristics") or []):
        reasons.append("modality")
    if not TASKS & set(meta.get("tasks") or []):
        reasons.append("task")
    if not meta.get("data_url"):
        reasons.append("download")
    return "; ".join(reasons) or None


def x_rejection__mutmut_7(meta: dict[str, Any]) -> str | None:
    reasons = []
    rows, features = meta.get("num_instances"), meta.get("XXnum_featuresXX")
    if rows is None or not MIN_ROWS <= rows <= MAX_ROWS:
        reasons.append(f"rows ({rows})")
    if features is None or not MIN_FEATURES <= features <= MAX_FEATURES:
        reasons.append(f"features ({features})")
    if EXCLUDED_MODALITIES & set(meta.get("characteristics") or []):
        reasons.append("modality")
    if not TASKS & set(meta.get("tasks") or []):
        reasons.append("task")
    if not meta.get("data_url"):
        reasons.append("download")
    return "; ".join(reasons) or None


def x_rejection__mutmut_8(meta: dict[str, Any]) -> str | None:
    reasons = []
    rows, features = meta.get("num_instances"), meta.get("NUM_FEATURES")
    if rows is None or not MIN_ROWS <= rows <= MAX_ROWS:
        reasons.append(f"rows ({rows})")
    if features is None or not MIN_FEATURES <= features <= MAX_FEATURES:
        reasons.append(f"features ({features})")
    if EXCLUDED_MODALITIES & set(meta.get("characteristics") or []):
        reasons.append("modality")
    if not TASKS & set(meta.get("tasks") or []):
        reasons.append("task")
    if not meta.get("data_url"):
        reasons.append("download")
    return "; ".join(reasons) or None


def x_rejection__mutmut_9(meta: dict[str, Any]) -> str | None:
    reasons = []
    rows, features = meta.get("num_instances"), meta.get("num_features")
    if rows is None and not MIN_ROWS <= rows <= MAX_ROWS:
        reasons.append(f"rows ({rows})")
    if features is None or not MIN_FEATURES <= features <= MAX_FEATURES:
        reasons.append(f"features ({features})")
    if EXCLUDED_MODALITIES & set(meta.get("characteristics") or []):
        reasons.append("modality")
    if not TASKS & set(meta.get("tasks") or []):
        reasons.append("task")
    if not meta.get("data_url"):
        reasons.append("download")
    return "; ".join(reasons) or None


def x_rejection__mutmut_10(meta: dict[str, Any]) -> str | None:
    reasons = []
    rows, features = meta.get("num_instances"), meta.get("num_features")
    if rows is not None or not MIN_ROWS <= rows <= MAX_ROWS:
        reasons.append(f"rows ({rows})")
    if features is None or not MIN_FEATURES <= features <= MAX_FEATURES:
        reasons.append(f"features ({features})")
    if EXCLUDED_MODALITIES & set(meta.get("characteristics") or []):
        reasons.append("modality")
    if not TASKS & set(meta.get("tasks") or []):
        reasons.append("task")
    if not meta.get("data_url"):
        reasons.append("download")
    return "; ".join(reasons) or None


def x_rejection__mutmut_11(meta: dict[str, Any]) -> str | None:
    reasons = []
    rows, features = meta.get("num_instances"), meta.get("num_features")
    if rows is None or MIN_ROWS <= rows <= MAX_ROWS:
        reasons.append(f"rows ({rows})")
    if features is None or not MIN_FEATURES <= features <= MAX_FEATURES:
        reasons.append(f"features ({features})")
    if EXCLUDED_MODALITIES & set(meta.get("characteristics") or []):
        reasons.append("modality")
    if not TASKS & set(meta.get("tasks") or []):
        reasons.append("task")
    if not meta.get("data_url"):
        reasons.append("download")
    return "; ".join(reasons) or None


def x_rejection__mutmut_12(meta: dict[str, Any]) -> str | None:
    reasons = []
    rows, features = meta.get("num_instances"), meta.get("num_features")
    if rows is None or not MIN_ROWS < rows <= MAX_ROWS:
        reasons.append(f"rows ({rows})")
    if features is None or not MIN_FEATURES <= features <= MAX_FEATURES:
        reasons.append(f"features ({features})")
    if EXCLUDED_MODALITIES & set(meta.get("characteristics") or []):
        reasons.append("modality")
    if not TASKS & set(meta.get("tasks") or []):
        reasons.append("task")
    if not meta.get("data_url"):
        reasons.append("download")
    return "; ".join(reasons) or None


def x_rejection__mutmut_13(meta: dict[str, Any]) -> str | None:
    reasons = []
    rows, features = meta.get("num_instances"), meta.get("num_features")
    if rows is None or not MIN_ROWS <= rows < MAX_ROWS:
        reasons.append(f"rows ({rows})")
    if features is None or not MIN_FEATURES <= features <= MAX_FEATURES:
        reasons.append(f"features ({features})")
    if EXCLUDED_MODALITIES & set(meta.get("characteristics") or []):
        reasons.append("modality")
    if not TASKS & set(meta.get("tasks") or []):
        reasons.append("task")
    if not meta.get("data_url"):
        reasons.append("download")
    return "; ".join(reasons) or None


def x_rejection__mutmut_14(meta: dict[str, Any]) -> str | None:
    reasons = []
    rows, features = meta.get("num_instances"), meta.get("num_features")
    if rows is None or not MIN_ROWS <= rows <= MAX_ROWS:
        reasons.append(None)
    if features is None or not MIN_FEATURES <= features <= MAX_FEATURES:
        reasons.append(f"features ({features})")
    if EXCLUDED_MODALITIES & set(meta.get("characteristics") or []):
        reasons.append("modality")
    if not TASKS & set(meta.get("tasks") or []):
        reasons.append("task")
    if not meta.get("data_url"):
        reasons.append("download")
    return "; ".join(reasons) or None


def x_rejection__mutmut_15(meta: dict[str, Any]) -> str | None:
    reasons = []
    rows, features = meta.get("num_instances"), meta.get("num_features")
    if rows is None or not MIN_ROWS <= rows <= MAX_ROWS:
        reasons.append(f"rows ({rows})")
    if features is None and not MIN_FEATURES <= features <= MAX_FEATURES:
        reasons.append(f"features ({features})")
    if EXCLUDED_MODALITIES & set(meta.get("characteristics") or []):
        reasons.append("modality")
    if not TASKS & set(meta.get("tasks") or []):
        reasons.append("task")
    if not meta.get("data_url"):
        reasons.append("download")
    return "; ".join(reasons) or None


def x_rejection__mutmut_16(meta: dict[str, Any]) -> str | None:
    reasons = []
    rows, features = meta.get("num_instances"), meta.get("num_features")
    if rows is None or not MIN_ROWS <= rows <= MAX_ROWS:
        reasons.append(f"rows ({rows})")
    if features is not None or not MIN_FEATURES <= features <= MAX_FEATURES:
        reasons.append(f"features ({features})")
    if EXCLUDED_MODALITIES & set(meta.get("characteristics") or []):
        reasons.append("modality")
    if not TASKS & set(meta.get("tasks") or []):
        reasons.append("task")
    if not meta.get("data_url"):
        reasons.append("download")
    return "; ".join(reasons) or None


def x_rejection__mutmut_17(meta: dict[str, Any]) -> str | None:
    reasons = []
    rows, features = meta.get("num_instances"), meta.get("num_features")
    if rows is None or not MIN_ROWS <= rows <= MAX_ROWS:
        reasons.append(f"rows ({rows})")
    if features is None or MIN_FEATURES <= features <= MAX_FEATURES:
        reasons.append(f"features ({features})")
    if EXCLUDED_MODALITIES & set(meta.get("characteristics") or []):
        reasons.append("modality")
    if not TASKS & set(meta.get("tasks") or []):
        reasons.append("task")
    if not meta.get("data_url"):
        reasons.append("download")
    return "; ".join(reasons) or None


def x_rejection__mutmut_18(meta: dict[str, Any]) -> str | None:
    reasons = []
    rows, features = meta.get("num_instances"), meta.get("num_features")
    if rows is None or not MIN_ROWS <= rows <= MAX_ROWS:
        reasons.append(f"rows ({rows})")
    if features is None or not MIN_FEATURES < features <= MAX_FEATURES:
        reasons.append(f"features ({features})")
    if EXCLUDED_MODALITIES & set(meta.get("characteristics") or []):
        reasons.append("modality")
    if not TASKS & set(meta.get("tasks") or []):
        reasons.append("task")
    if not meta.get("data_url"):
        reasons.append("download")
    return "; ".join(reasons) or None


def x_rejection__mutmut_19(meta: dict[str, Any]) -> str | None:
    reasons = []
    rows, features = meta.get("num_instances"), meta.get("num_features")
    if rows is None or not MIN_ROWS <= rows <= MAX_ROWS:
        reasons.append(f"rows ({rows})")
    if features is None or not MIN_FEATURES <= features < MAX_FEATURES:
        reasons.append(f"features ({features})")
    if EXCLUDED_MODALITIES & set(meta.get("characteristics") or []):
        reasons.append("modality")
    if not TASKS & set(meta.get("tasks") or []):
        reasons.append("task")
    if not meta.get("data_url"):
        reasons.append("download")
    return "; ".join(reasons) or None


def x_rejection__mutmut_20(meta: dict[str, Any]) -> str | None:
    reasons = []
    rows, features = meta.get("num_instances"), meta.get("num_features")
    if rows is None or not MIN_ROWS <= rows <= MAX_ROWS:
        reasons.append(f"rows ({rows})")
    if features is None or not MIN_FEATURES <= features <= MAX_FEATURES:
        reasons.append(None)
    if EXCLUDED_MODALITIES & set(meta.get("characteristics") or []):
        reasons.append("modality")
    if not TASKS & set(meta.get("tasks") or []):
        reasons.append("task")
    if not meta.get("data_url"):
        reasons.append("download")
    return "; ".join(reasons) or None


def x_rejection__mutmut_21(meta: dict[str, Any]) -> str | None:
    reasons = []
    rows, features = meta.get("num_instances"), meta.get("num_features")
    if rows is None or not MIN_ROWS <= rows <= MAX_ROWS:
        reasons.append(f"rows ({rows})")
    if features is None or not MIN_FEATURES <= features <= MAX_FEATURES:
        reasons.append(f"features ({features})")
    if EXCLUDED_MODALITIES | set(meta.get("characteristics") or []):
        reasons.append("modality")
    if not TASKS & set(meta.get("tasks") or []):
        reasons.append("task")
    if not meta.get("data_url"):
        reasons.append("download")
    return "; ".join(reasons) or None


def x_rejection__mutmut_22(meta: dict[str, Any]) -> str | None:
    reasons = []
    rows, features = meta.get("num_instances"), meta.get("num_features")
    if rows is None or not MIN_ROWS <= rows <= MAX_ROWS:
        reasons.append(f"rows ({rows})")
    if features is None or not MIN_FEATURES <= features <= MAX_FEATURES:
        reasons.append(f"features ({features})")
    if EXCLUDED_MODALITIES & set(None):
        reasons.append("modality")
    if not TASKS & set(meta.get("tasks") or []):
        reasons.append("task")
    if not meta.get("data_url"):
        reasons.append("download")
    return "; ".join(reasons) or None


def x_rejection__mutmut_23(meta: dict[str, Any]) -> str | None:
    reasons = []
    rows, features = meta.get("num_instances"), meta.get("num_features")
    if rows is None or not MIN_ROWS <= rows <= MAX_ROWS:
        reasons.append(f"rows ({rows})")
    if features is None or not MIN_FEATURES <= features <= MAX_FEATURES:
        reasons.append(f"features ({features})")
    if EXCLUDED_MODALITIES & set(meta.get("characteristics") and []):
        reasons.append("modality")
    if not TASKS & set(meta.get("tasks") or []):
        reasons.append("task")
    if not meta.get("data_url"):
        reasons.append("download")
    return "; ".join(reasons) or None


def x_rejection__mutmut_24(meta: dict[str, Any]) -> str | None:
    reasons = []
    rows, features = meta.get("num_instances"), meta.get("num_features")
    if rows is None or not MIN_ROWS <= rows <= MAX_ROWS:
        reasons.append(f"rows ({rows})")
    if features is None or not MIN_FEATURES <= features <= MAX_FEATURES:
        reasons.append(f"features ({features})")
    if EXCLUDED_MODALITIES & set(meta.get(None) or []):
        reasons.append("modality")
    if not TASKS & set(meta.get("tasks") or []):
        reasons.append("task")
    if not meta.get("data_url"):
        reasons.append("download")
    return "; ".join(reasons) or None


def x_rejection__mutmut_25(meta: dict[str, Any]) -> str | None:
    reasons = []
    rows, features = meta.get("num_instances"), meta.get("num_features")
    if rows is None or not MIN_ROWS <= rows <= MAX_ROWS:
        reasons.append(f"rows ({rows})")
    if features is None or not MIN_FEATURES <= features <= MAX_FEATURES:
        reasons.append(f"features ({features})")
    if EXCLUDED_MODALITIES & set(meta.get("XXcharacteristicsXX") or []):
        reasons.append("modality")
    if not TASKS & set(meta.get("tasks") or []):
        reasons.append("task")
    if not meta.get("data_url"):
        reasons.append("download")
    return "; ".join(reasons) or None


def x_rejection__mutmut_26(meta: dict[str, Any]) -> str | None:
    reasons = []
    rows, features = meta.get("num_instances"), meta.get("num_features")
    if rows is None or not MIN_ROWS <= rows <= MAX_ROWS:
        reasons.append(f"rows ({rows})")
    if features is None or not MIN_FEATURES <= features <= MAX_FEATURES:
        reasons.append(f"features ({features})")
    if EXCLUDED_MODALITIES & set(meta.get("CHARACTERISTICS") or []):
        reasons.append("modality")
    if not TASKS & set(meta.get("tasks") or []):
        reasons.append("task")
    if not meta.get("data_url"):
        reasons.append("download")
    return "; ".join(reasons) or None


def x_rejection__mutmut_27(meta: dict[str, Any]) -> str | None:
    reasons = []
    rows, features = meta.get("num_instances"), meta.get("num_features")
    if rows is None or not MIN_ROWS <= rows <= MAX_ROWS:
        reasons.append(f"rows ({rows})")
    if features is None or not MIN_FEATURES <= features <= MAX_FEATURES:
        reasons.append(f"features ({features})")
    if EXCLUDED_MODALITIES & set(meta.get("characteristics") or []):
        reasons.append(None)
    if not TASKS & set(meta.get("tasks") or []):
        reasons.append("task")
    if not meta.get("data_url"):
        reasons.append("download")
    return "; ".join(reasons) or None


def x_rejection__mutmut_28(meta: dict[str, Any]) -> str | None:
    reasons = []
    rows, features = meta.get("num_instances"), meta.get("num_features")
    if rows is None or not MIN_ROWS <= rows <= MAX_ROWS:
        reasons.append(f"rows ({rows})")
    if features is None or not MIN_FEATURES <= features <= MAX_FEATURES:
        reasons.append(f"features ({features})")
    if EXCLUDED_MODALITIES & set(meta.get("characteristics") or []):
        reasons.append("XXmodalityXX")
    if not TASKS & set(meta.get("tasks") or []):
        reasons.append("task")
    if not meta.get("data_url"):
        reasons.append("download")
    return "; ".join(reasons) or None


def x_rejection__mutmut_29(meta: dict[str, Any]) -> str | None:
    reasons = []
    rows, features = meta.get("num_instances"), meta.get("num_features")
    if rows is None or not MIN_ROWS <= rows <= MAX_ROWS:
        reasons.append(f"rows ({rows})")
    if features is None or not MIN_FEATURES <= features <= MAX_FEATURES:
        reasons.append(f"features ({features})")
    if EXCLUDED_MODALITIES & set(meta.get("characteristics") or []):
        reasons.append("MODALITY")
    if not TASKS & set(meta.get("tasks") or []):
        reasons.append("task")
    if not meta.get("data_url"):
        reasons.append("download")
    return "; ".join(reasons) or None


def x_rejection__mutmut_30(meta: dict[str, Any]) -> str | None:
    reasons = []
    rows, features = meta.get("num_instances"), meta.get("num_features")
    if rows is None or not MIN_ROWS <= rows <= MAX_ROWS:
        reasons.append(f"rows ({rows})")
    if features is None or not MIN_FEATURES <= features <= MAX_FEATURES:
        reasons.append(f"features ({features})")
    if EXCLUDED_MODALITIES & set(meta.get("characteristics") or []):
        reasons.append("modality")
    if TASKS & set(meta.get("tasks") or []):
        reasons.append("task")
    if not meta.get("data_url"):
        reasons.append("download")
    return "; ".join(reasons) or None


def x_rejection__mutmut_31(meta: dict[str, Any]) -> str | None:
    reasons = []
    rows, features = meta.get("num_instances"), meta.get("num_features")
    if rows is None or not MIN_ROWS <= rows <= MAX_ROWS:
        reasons.append(f"rows ({rows})")
    if features is None or not MIN_FEATURES <= features <= MAX_FEATURES:
        reasons.append(f"features ({features})")
    if EXCLUDED_MODALITIES & set(meta.get("characteristics") or []):
        reasons.append("modality")
    if not TASKS | set(meta.get("tasks") or []):
        reasons.append("task")
    if not meta.get("data_url"):
        reasons.append("download")
    return "; ".join(reasons) or None


def x_rejection__mutmut_32(meta: dict[str, Any]) -> str | None:
    reasons = []
    rows, features = meta.get("num_instances"), meta.get("num_features")
    if rows is None or not MIN_ROWS <= rows <= MAX_ROWS:
        reasons.append(f"rows ({rows})")
    if features is None or not MIN_FEATURES <= features <= MAX_FEATURES:
        reasons.append(f"features ({features})")
    if EXCLUDED_MODALITIES & set(meta.get("characteristics") or []):
        reasons.append("modality")
    if not TASKS & set(None):
        reasons.append("task")
    if not meta.get("data_url"):
        reasons.append("download")
    return "; ".join(reasons) or None


def x_rejection__mutmut_33(meta: dict[str, Any]) -> str | None:
    reasons = []
    rows, features = meta.get("num_instances"), meta.get("num_features")
    if rows is None or not MIN_ROWS <= rows <= MAX_ROWS:
        reasons.append(f"rows ({rows})")
    if features is None or not MIN_FEATURES <= features <= MAX_FEATURES:
        reasons.append(f"features ({features})")
    if EXCLUDED_MODALITIES & set(meta.get("characteristics") or []):
        reasons.append("modality")
    if not TASKS & set(meta.get("tasks") and []):
        reasons.append("task")
    if not meta.get("data_url"):
        reasons.append("download")
    return "; ".join(reasons) or None


def x_rejection__mutmut_34(meta: dict[str, Any]) -> str | None:
    reasons = []
    rows, features = meta.get("num_instances"), meta.get("num_features")
    if rows is None or not MIN_ROWS <= rows <= MAX_ROWS:
        reasons.append(f"rows ({rows})")
    if features is None or not MIN_FEATURES <= features <= MAX_FEATURES:
        reasons.append(f"features ({features})")
    if EXCLUDED_MODALITIES & set(meta.get("characteristics") or []):
        reasons.append("modality")
    if not TASKS & set(meta.get(None) or []):
        reasons.append("task")
    if not meta.get("data_url"):
        reasons.append("download")
    return "; ".join(reasons) or None


def x_rejection__mutmut_35(meta: dict[str, Any]) -> str | None:
    reasons = []
    rows, features = meta.get("num_instances"), meta.get("num_features")
    if rows is None or not MIN_ROWS <= rows <= MAX_ROWS:
        reasons.append(f"rows ({rows})")
    if features is None or not MIN_FEATURES <= features <= MAX_FEATURES:
        reasons.append(f"features ({features})")
    if EXCLUDED_MODALITIES & set(meta.get("characteristics") or []):
        reasons.append("modality")
    if not TASKS & set(meta.get("XXtasksXX") or []):
        reasons.append("task")
    if not meta.get("data_url"):
        reasons.append("download")
    return "; ".join(reasons) or None


def x_rejection__mutmut_36(meta: dict[str, Any]) -> str | None:
    reasons = []
    rows, features = meta.get("num_instances"), meta.get("num_features")
    if rows is None or not MIN_ROWS <= rows <= MAX_ROWS:
        reasons.append(f"rows ({rows})")
    if features is None or not MIN_FEATURES <= features <= MAX_FEATURES:
        reasons.append(f"features ({features})")
    if EXCLUDED_MODALITIES & set(meta.get("characteristics") or []):
        reasons.append("modality")
    if not TASKS & set(meta.get("TASKS") or []):
        reasons.append("task")
    if not meta.get("data_url"):
        reasons.append("download")
    return "; ".join(reasons) or None


def x_rejection__mutmut_37(meta: dict[str, Any]) -> str | None:
    reasons = []
    rows, features = meta.get("num_instances"), meta.get("num_features")
    if rows is None or not MIN_ROWS <= rows <= MAX_ROWS:
        reasons.append(f"rows ({rows})")
    if features is None or not MIN_FEATURES <= features <= MAX_FEATURES:
        reasons.append(f"features ({features})")
    if EXCLUDED_MODALITIES & set(meta.get("characteristics") or []):
        reasons.append("modality")
    if not TASKS & set(meta.get("tasks") or []):
        reasons.append(None)
    if not meta.get("data_url"):
        reasons.append("download")
    return "; ".join(reasons) or None


def x_rejection__mutmut_38(meta: dict[str, Any]) -> str | None:
    reasons = []
    rows, features = meta.get("num_instances"), meta.get("num_features")
    if rows is None or not MIN_ROWS <= rows <= MAX_ROWS:
        reasons.append(f"rows ({rows})")
    if features is None or not MIN_FEATURES <= features <= MAX_FEATURES:
        reasons.append(f"features ({features})")
    if EXCLUDED_MODALITIES & set(meta.get("characteristics") or []):
        reasons.append("modality")
    if not TASKS & set(meta.get("tasks") or []):
        reasons.append("XXtaskXX")
    if not meta.get("data_url"):
        reasons.append("download")
    return "; ".join(reasons) or None


def x_rejection__mutmut_39(meta: dict[str, Any]) -> str | None:
    reasons = []
    rows, features = meta.get("num_instances"), meta.get("num_features")
    if rows is None or not MIN_ROWS <= rows <= MAX_ROWS:
        reasons.append(f"rows ({rows})")
    if features is None or not MIN_FEATURES <= features <= MAX_FEATURES:
        reasons.append(f"features ({features})")
    if EXCLUDED_MODALITIES & set(meta.get("characteristics") or []):
        reasons.append("modality")
    if not TASKS & set(meta.get("tasks") or []):
        reasons.append("TASK")
    if not meta.get("data_url"):
        reasons.append("download")
    return "; ".join(reasons) or None


def x_rejection__mutmut_40(meta: dict[str, Any]) -> str | None:
    reasons = []
    rows, features = meta.get("num_instances"), meta.get("num_features")
    if rows is None or not MIN_ROWS <= rows <= MAX_ROWS:
        reasons.append(f"rows ({rows})")
    if features is None or not MIN_FEATURES <= features <= MAX_FEATURES:
        reasons.append(f"features ({features})")
    if EXCLUDED_MODALITIES & set(meta.get("characteristics") or []):
        reasons.append("modality")
    if not TASKS & set(meta.get("tasks") or []):
        reasons.append("task")
    if meta.get("data_url"):
        reasons.append("download")
    return "; ".join(reasons) or None


def x_rejection__mutmut_41(meta: dict[str, Any]) -> str | None:
    reasons = []
    rows, features = meta.get("num_instances"), meta.get("num_features")
    if rows is None or not MIN_ROWS <= rows <= MAX_ROWS:
        reasons.append(f"rows ({rows})")
    if features is None or not MIN_FEATURES <= features <= MAX_FEATURES:
        reasons.append(f"features ({features})")
    if EXCLUDED_MODALITIES & set(meta.get("characteristics") or []):
        reasons.append("modality")
    if not TASKS & set(meta.get("tasks") or []):
        reasons.append("task")
    if not meta.get(None):
        reasons.append("download")
    return "; ".join(reasons) or None


def x_rejection__mutmut_42(meta: dict[str, Any]) -> str | None:
    reasons = []
    rows, features = meta.get("num_instances"), meta.get("num_features")
    if rows is None or not MIN_ROWS <= rows <= MAX_ROWS:
        reasons.append(f"rows ({rows})")
    if features is None or not MIN_FEATURES <= features <= MAX_FEATURES:
        reasons.append(f"features ({features})")
    if EXCLUDED_MODALITIES & set(meta.get("characteristics") or []):
        reasons.append("modality")
    if not TASKS & set(meta.get("tasks") or []):
        reasons.append("task")
    if not meta.get("XXdata_urlXX"):
        reasons.append("download")
    return "; ".join(reasons) or None


def x_rejection__mutmut_43(meta: dict[str, Any]) -> str | None:
    reasons = []
    rows, features = meta.get("num_instances"), meta.get("num_features")
    if rows is None or not MIN_ROWS <= rows <= MAX_ROWS:
        reasons.append(f"rows ({rows})")
    if features is None or not MIN_FEATURES <= features <= MAX_FEATURES:
        reasons.append(f"features ({features})")
    if EXCLUDED_MODALITIES & set(meta.get("characteristics") or []):
        reasons.append("modality")
    if not TASKS & set(meta.get("tasks") or []):
        reasons.append("task")
    if not meta.get("DATA_URL"):
        reasons.append("download")
    return "; ".join(reasons) or None


def x_rejection__mutmut_44(meta: dict[str, Any]) -> str | None:
    reasons = []
    rows, features = meta.get("num_instances"), meta.get("num_features")
    if rows is None or not MIN_ROWS <= rows <= MAX_ROWS:
        reasons.append(f"rows ({rows})")
    if features is None or not MIN_FEATURES <= features <= MAX_FEATURES:
        reasons.append(f"features ({features})")
    if EXCLUDED_MODALITIES & set(meta.get("characteristics") or []):
        reasons.append("modality")
    if not TASKS & set(meta.get("tasks") or []):
        reasons.append("task")
    if not meta.get("data_url"):
        reasons.append(None)
    return "; ".join(reasons) or None


def x_rejection__mutmut_45(meta: dict[str, Any]) -> str | None:
    reasons = []
    rows, features = meta.get("num_instances"), meta.get("num_features")
    if rows is None or not MIN_ROWS <= rows <= MAX_ROWS:
        reasons.append(f"rows ({rows})")
    if features is None or not MIN_FEATURES <= features <= MAX_FEATURES:
        reasons.append(f"features ({features})")
    if EXCLUDED_MODALITIES & set(meta.get("characteristics") or []):
        reasons.append("modality")
    if not TASKS & set(meta.get("tasks") or []):
        reasons.append("task")
    if not meta.get("data_url"):
        reasons.append("XXdownloadXX")
    return "; ".join(reasons) or None


def x_rejection__mutmut_46(meta: dict[str, Any]) -> str | None:
    reasons = []
    rows, features = meta.get("num_instances"), meta.get("num_features")
    if rows is None or not MIN_ROWS <= rows <= MAX_ROWS:
        reasons.append(f"rows ({rows})")
    if features is None or not MIN_FEATURES <= features <= MAX_FEATURES:
        reasons.append(f"features ({features})")
    if EXCLUDED_MODALITIES & set(meta.get("characteristics") or []):
        reasons.append("modality")
    if not TASKS & set(meta.get("tasks") or []):
        reasons.append("task")
    if not meta.get("data_url"):
        reasons.append("DOWNLOAD")
    return "; ".join(reasons) or None


def x_rejection__mutmut_47(meta: dict[str, Any]) -> str | None:
    reasons = []
    rows, features = meta.get("num_instances"), meta.get("num_features")
    if rows is None or not MIN_ROWS <= rows <= MAX_ROWS:
        reasons.append(f"rows ({rows})")
    if features is None or not MIN_FEATURES <= features <= MAX_FEATURES:
        reasons.append(f"features ({features})")
    if EXCLUDED_MODALITIES & set(meta.get("characteristics") or []):
        reasons.append("modality")
    if not TASKS & set(meta.get("tasks") or []):
        reasons.append("task")
    if not meta.get("data_url"):
        reasons.append("download")
    return "; ".join(reasons) and None


def x_rejection__mutmut_48(meta: dict[str, Any]) -> str | None:
    reasons = []
    rows, features = meta.get("num_instances"), meta.get("num_features")
    if rows is None or not MIN_ROWS <= rows <= MAX_ROWS:
        reasons.append(f"rows ({rows})")
    if features is None or not MIN_FEATURES <= features <= MAX_FEATURES:
        reasons.append(f"features ({features})")
    if EXCLUDED_MODALITIES & set(meta.get("characteristics") or []):
        reasons.append("modality")
    if not TASKS & set(meta.get("tasks") or []):
        reasons.append("task")
    if not meta.get("data_url"):
        reasons.append("download")
    return "; ".join(None) or None


def x_rejection__mutmut_49(meta: dict[str, Any]) -> str | None:
    reasons = []
    rows, features = meta.get("num_instances"), meta.get("num_features")
    if rows is None or not MIN_ROWS <= rows <= MAX_ROWS:
        reasons.append(f"rows ({rows})")
    if features is None or not MIN_FEATURES <= features <= MAX_FEATURES:
        reasons.append(f"features ({features})")
    if EXCLUDED_MODALITIES & set(meta.get("characteristics") or []):
        reasons.append("modality")
    if not TASKS & set(meta.get("tasks") or []):
        reasons.append("task")
    if not meta.get("data_url"):
        reasons.append("download")
    return "XX; XX".join(reasons) or None

mutants_x_rejection__mutmut['_mutmut_orig'] = x_rejection__mutmut_orig # type: ignore # mutmut generated
mutants_x_rejection__mutmut['x_rejection__mutmut_1'] = x_rejection__mutmut_1 # type: ignore # mutmut generated
mutants_x_rejection__mutmut['x_rejection__mutmut_2'] = x_rejection__mutmut_2 # type: ignore # mutmut generated
mutants_x_rejection__mutmut['x_rejection__mutmut_3'] = x_rejection__mutmut_3 # type: ignore # mutmut generated
mutants_x_rejection__mutmut['x_rejection__mutmut_4'] = x_rejection__mutmut_4 # type: ignore # mutmut generated
mutants_x_rejection__mutmut['x_rejection__mutmut_5'] = x_rejection__mutmut_5 # type: ignore # mutmut generated
mutants_x_rejection__mutmut['x_rejection__mutmut_6'] = x_rejection__mutmut_6 # type: ignore # mutmut generated
mutants_x_rejection__mutmut['x_rejection__mutmut_7'] = x_rejection__mutmut_7 # type: ignore # mutmut generated
mutants_x_rejection__mutmut['x_rejection__mutmut_8'] = x_rejection__mutmut_8 # type: ignore # mutmut generated
mutants_x_rejection__mutmut['x_rejection__mutmut_9'] = x_rejection__mutmut_9 # type: ignore # mutmut generated
mutants_x_rejection__mutmut['x_rejection__mutmut_10'] = x_rejection__mutmut_10 # type: ignore # mutmut generated
mutants_x_rejection__mutmut['x_rejection__mutmut_11'] = x_rejection__mutmut_11 # type: ignore # mutmut generated
mutants_x_rejection__mutmut['x_rejection__mutmut_12'] = x_rejection__mutmut_12 # type: ignore # mutmut generated
mutants_x_rejection__mutmut['x_rejection__mutmut_13'] = x_rejection__mutmut_13 # type: ignore # mutmut generated
mutants_x_rejection__mutmut['x_rejection__mutmut_14'] = x_rejection__mutmut_14 # type: ignore # mutmut generated
mutants_x_rejection__mutmut['x_rejection__mutmut_15'] = x_rejection__mutmut_15 # type: ignore # mutmut generated
mutants_x_rejection__mutmut['x_rejection__mutmut_16'] = x_rejection__mutmut_16 # type: ignore # mutmut generated
mutants_x_rejection__mutmut['x_rejection__mutmut_17'] = x_rejection__mutmut_17 # type: ignore # mutmut generated
mutants_x_rejection__mutmut['x_rejection__mutmut_18'] = x_rejection__mutmut_18 # type: ignore # mutmut generated
mutants_x_rejection__mutmut['x_rejection__mutmut_19'] = x_rejection__mutmut_19 # type: ignore # mutmut generated
mutants_x_rejection__mutmut['x_rejection__mutmut_20'] = x_rejection__mutmut_20 # type: ignore # mutmut generated
mutants_x_rejection__mutmut['x_rejection__mutmut_21'] = x_rejection__mutmut_21 # type: ignore # mutmut generated
mutants_x_rejection__mutmut['x_rejection__mutmut_22'] = x_rejection__mutmut_22 # type: ignore # mutmut generated
mutants_x_rejection__mutmut['x_rejection__mutmut_23'] = x_rejection__mutmut_23 # type: ignore # mutmut generated
mutants_x_rejection__mutmut['x_rejection__mutmut_24'] = x_rejection__mutmut_24 # type: ignore # mutmut generated
mutants_x_rejection__mutmut['x_rejection__mutmut_25'] = x_rejection__mutmut_25 # type: ignore # mutmut generated
mutants_x_rejection__mutmut['x_rejection__mutmut_26'] = x_rejection__mutmut_26 # type: ignore # mutmut generated
mutants_x_rejection__mutmut['x_rejection__mutmut_27'] = x_rejection__mutmut_27 # type: ignore # mutmut generated
mutants_x_rejection__mutmut['x_rejection__mutmut_28'] = x_rejection__mutmut_28 # type: ignore # mutmut generated
mutants_x_rejection__mutmut['x_rejection__mutmut_29'] = x_rejection__mutmut_29 # type: ignore # mutmut generated
mutants_x_rejection__mutmut['x_rejection__mutmut_30'] = x_rejection__mutmut_30 # type: ignore # mutmut generated
mutants_x_rejection__mutmut['x_rejection__mutmut_31'] = x_rejection__mutmut_31 # type: ignore # mutmut generated
mutants_x_rejection__mutmut['x_rejection__mutmut_32'] = x_rejection__mutmut_32 # type: ignore # mutmut generated
mutants_x_rejection__mutmut['x_rejection__mutmut_33'] = x_rejection__mutmut_33 # type: ignore # mutmut generated
mutants_x_rejection__mutmut['x_rejection__mutmut_34'] = x_rejection__mutmut_34 # type: ignore # mutmut generated
mutants_x_rejection__mutmut['x_rejection__mutmut_35'] = x_rejection__mutmut_35 # type: ignore # mutmut generated
mutants_x_rejection__mutmut['x_rejection__mutmut_36'] = x_rejection__mutmut_36 # type: ignore # mutmut generated
mutants_x_rejection__mutmut['x_rejection__mutmut_37'] = x_rejection__mutmut_37 # type: ignore # mutmut generated
mutants_x_rejection__mutmut['x_rejection__mutmut_38'] = x_rejection__mutmut_38 # type: ignore # mutmut generated
mutants_x_rejection__mutmut['x_rejection__mutmut_39'] = x_rejection__mutmut_39 # type: ignore # mutmut generated
mutants_x_rejection__mutmut['x_rejection__mutmut_40'] = x_rejection__mutmut_40 # type: ignore # mutmut generated
mutants_x_rejection__mutmut['x_rejection__mutmut_41'] = x_rejection__mutmut_41 # type: ignore # mutmut generated
mutants_x_rejection__mutmut['x_rejection__mutmut_42'] = x_rejection__mutmut_42 # type: ignore # mutmut generated
mutants_x_rejection__mutmut['x_rejection__mutmut_43'] = x_rejection__mutmut_43 # type: ignore # mutmut generated
mutants_x_rejection__mutmut['x_rejection__mutmut_44'] = x_rejection__mutmut_44 # type: ignore # mutmut generated
mutants_x_rejection__mutmut['x_rejection__mutmut_45'] = x_rejection__mutmut_45 # type: ignore # mutmut generated
mutants_x_rejection__mutmut['x_rejection__mutmut_46'] = x_rejection__mutmut_46 # type: ignore # mutmut generated
mutants_x_rejection__mutmut['x_rejection__mutmut_47'] = x_rejection__mutmut_47 # type: ignore # mutmut generated
mutants_x_rejection__mutmut['x_rejection__mutmut_48'] = x_rejection__mutmut_48 # type: ignore # mutmut generated
mutants_x_rejection__mutmut['x_rejection__mutmut_49'] = x_rejection__mutmut_49 # type: ignore # mutmut generated
mutants_x_strata__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_strata__mutmut)
def strata(meta: dict[str, Any]) -> dict[str, Any]:
    rows, features = meta["num_instances"], meta["num_features"]
    size = (
        "tiny"
        if rows < 2000
        else "small"
        if rows < 20_000
        else "medium"
        if rows < 200_000
        else "large"
    )
    dim = "low" if features <= 10 else "mid" if features <= 50 else "high"
    return {
        "size": size,
        "dim": dim,
        "missing": meta.get("has_missing_values") == "yes",
        "mixed_types": "Categorical" in (meta.get("feature_types") or []),
        "time": "Time-Series" in (meta.get("characteristics") or []),
        "domain": meta.get("area"),
    }


def x_strata__mutmut_orig(meta: dict[str, Any]) -> dict[str, Any]:
    rows, features = meta["num_instances"], meta["num_features"]
    size = (
        "tiny"
        if rows < 2000
        else "small"
        if rows < 20_000
        else "medium"
        if rows < 200_000
        else "large"
    )
    dim = "low" if features <= 10 else "mid" if features <= 50 else "high"
    return {
        "size": size,
        "dim": dim,
        "missing": meta.get("has_missing_values") == "yes",
        "mixed_types": "Categorical" in (meta.get("feature_types") or []),
        "time": "Time-Series" in (meta.get("characteristics") or []),
        "domain": meta.get("area"),
    }


def x_strata__mutmut_1(meta: dict[str, Any]) -> dict[str, Any]:
    rows, features = None
    size = (
        "tiny"
        if rows < 2000
        else "small"
        if rows < 20_000
        else "medium"
        if rows < 200_000
        else "large"
    )
    dim = "low" if features <= 10 else "mid" if features <= 50 else "high"
    return {
        "size": size,
        "dim": dim,
        "missing": meta.get("has_missing_values") == "yes",
        "mixed_types": "Categorical" in (meta.get("feature_types") or []),
        "time": "Time-Series" in (meta.get("characteristics") or []),
        "domain": meta.get("area"),
    }


def x_strata__mutmut_2(meta: dict[str, Any]) -> dict[str, Any]:
    rows, features = meta["XXnum_instancesXX"], meta["num_features"]
    size = (
        "tiny"
        if rows < 2000
        else "small"
        if rows < 20_000
        else "medium"
        if rows < 200_000
        else "large"
    )
    dim = "low" if features <= 10 else "mid" if features <= 50 else "high"
    return {
        "size": size,
        "dim": dim,
        "missing": meta.get("has_missing_values") == "yes",
        "mixed_types": "Categorical" in (meta.get("feature_types") or []),
        "time": "Time-Series" in (meta.get("characteristics") or []),
        "domain": meta.get("area"),
    }


def x_strata__mutmut_3(meta: dict[str, Any]) -> dict[str, Any]:
    rows, features = meta["NUM_INSTANCES"], meta["num_features"]
    size = (
        "tiny"
        if rows < 2000
        else "small"
        if rows < 20_000
        else "medium"
        if rows < 200_000
        else "large"
    )
    dim = "low" if features <= 10 else "mid" if features <= 50 else "high"
    return {
        "size": size,
        "dim": dim,
        "missing": meta.get("has_missing_values") == "yes",
        "mixed_types": "Categorical" in (meta.get("feature_types") or []),
        "time": "Time-Series" in (meta.get("characteristics") or []),
        "domain": meta.get("area"),
    }


def x_strata__mutmut_4(meta: dict[str, Any]) -> dict[str, Any]:
    rows, features = meta["num_instances"], meta["XXnum_featuresXX"]
    size = (
        "tiny"
        if rows < 2000
        else "small"
        if rows < 20_000
        else "medium"
        if rows < 200_000
        else "large"
    )
    dim = "low" if features <= 10 else "mid" if features <= 50 else "high"
    return {
        "size": size,
        "dim": dim,
        "missing": meta.get("has_missing_values") == "yes",
        "mixed_types": "Categorical" in (meta.get("feature_types") or []),
        "time": "Time-Series" in (meta.get("characteristics") or []),
        "domain": meta.get("area"),
    }


def x_strata__mutmut_5(meta: dict[str, Any]) -> dict[str, Any]:
    rows, features = meta["num_instances"], meta["NUM_FEATURES"]
    size = (
        "tiny"
        if rows < 2000
        else "small"
        if rows < 20_000
        else "medium"
        if rows < 200_000
        else "large"
    )
    dim = "low" if features <= 10 else "mid" if features <= 50 else "high"
    return {
        "size": size,
        "dim": dim,
        "missing": meta.get("has_missing_values") == "yes",
        "mixed_types": "Categorical" in (meta.get("feature_types") or []),
        "time": "Time-Series" in (meta.get("characteristics") or []),
        "domain": meta.get("area"),
    }


def x_strata__mutmut_6(meta: dict[str, Any]) -> dict[str, Any]:
    rows, features = meta["num_instances"], meta["num_features"]
    size = None
    dim = "low" if features <= 10 else "mid" if features <= 50 else "high"
    return {
        "size": size,
        "dim": dim,
        "missing": meta.get("has_missing_values") == "yes",
        "mixed_types": "Categorical" in (meta.get("feature_types") or []),
        "time": "Time-Series" in (meta.get("characteristics") or []),
        "domain": meta.get("area"),
    }


def x_strata__mutmut_7(meta: dict[str, Any]) -> dict[str, Any]:
    rows, features = meta["num_instances"], meta["num_features"]
    size = (
        "tiny"
        if (rows < 2000) and False
        else "small"
        if rows < 20_000
        else "medium"
        if rows < 200_000
        else "large"
    )
    dim = "low" if features <= 10 else "mid" if features <= 50 else "high"
    return {
        "size": size,
        "dim": dim,
        "missing": meta.get("has_missing_values") == "yes",
        "mixed_types": "Categorical" in (meta.get("feature_types") or []),
        "time": "Time-Series" in (meta.get("characteristics") or []),
        "domain": meta.get("area"),
    }


def x_strata__mutmut_8(meta: dict[str, Any]) -> dict[str, Any]:
    rows, features = meta["num_instances"], meta["num_features"]
    size = (
        "tiny"
        if (rows < 2000) or True
        else "small"
        if rows < 20_000
        else "medium"
        if rows < 200_000
        else "large"
    )
    dim = "low" if features <= 10 else "mid" if features <= 50 else "high"
    return {
        "size": size,
        "dim": dim,
        "missing": meta.get("has_missing_values") == "yes",
        "mixed_types": "Categorical" in (meta.get("feature_types") or []),
        "time": "Time-Series" in (meta.get("characteristics") or []),
        "domain": meta.get("area"),
    }


def x_strata__mutmut_9(meta: dict[str, Any]) -> dict[str, Any]:
    rows, features = meta["num_instances"], meta["num_features"]
    size = (
        "XXtinyXX"
        if rows < 2000
        else "small"
        if rows < 20_000
        else "medium"
        if rows < 200_000
        else "large"
    )
    dim = "low" if features <= 10 else "mid" if features <= 50 else "high"
    return {
        "size": size,
        "dim": dim,
        "missing": meta.get("has_missing_values") == "yes",
        "mixed_types": "Categorical" in (meta.get("feature_types") or []),
        "time": "Time-Series" in (meta.get("characteristics") or []),
        "domain": meta.get("area"),
    }


def x_strata__mutmut_10(meta: dict[str, Any]) -> dict[str, Any]:
    rows, features = meta["num_instances"], meta["num_features"]
    size = (
        "TINY"
        if rows < 2000
        else "small"
        if rows < 20_000
        else "medium"
        if rows < 200_000
        else "large"
    )
    dim = "low" if features <= 10 else "mid" if features <= 50 else "high"
    return {
        "size": size,
        "dim": dim,
        "missing": meta.get("has_missing_values") == "yes",
        "mixed_types": "Categorical" in (meta.get("feature_types") or []),
        "time": "Time-Series" in (meta.get("characteristics") or []),
        "domain": meta.get("area"),
    }


def x_strata__mutmut_11(meta: dict[str, Any]) -> dict[str, Any]:
    rows, features = meta["num_instances"], meta["num_features"]
    size = (
        "tiny"
        if rows <= 2000
        else "small"
        if rows < 20_000
        else "medium"
        if rows < 200_000
        else "large"
    )
    dim = "low" if features <= 10 else "mid" if features <= 50 else "high"
    return {
        "size": size,
        "dim": dim,
        "missing": meta.get("has_missing_values") == "yes",
        "mixed_types": "Categorical" in (meta.get("feature_types") or []),
        "time": "Time-Series" in (meta.get("characteristics") or []),
        "domain": meta.get("area"),
    }


def x_strata__mutmut_12(meta: dict[str, Any]) -> dict[str, Any]:
    rows, features = meta["num_instances"], meta["num_features"]
    size = (
        "tiny"
        if rows < 2001
        else "small"
        if rows < 20_000
        else "medium"
        if rows < 200_000
        else "large"
    )
    dim = "low" if features <= 10 else "mid" if features <= 50 else "high"
    return {
        "size": size,
        "dim": dim,
        "missing": meta.get("has_missing_values") == "yes",
        "mixed_types": "Categorical" in (meta.get("feature_types") or []),
        "time": "Time-Series" in (meta.get("characteristics") or []),
        "domain": meta.get("area"),
    }


def x_strata__mutmut_13(meta: dict[str, Any]) -> dict[str, Any]:
    rows, features = meta["num_instances"], meta["num_features"]
    size = (
        "tiny"
        if rows < 2000
        else "small"
        if (rows < 20_000) and False
        else "medium"
        if rows < 200_000
        else "large"
    )
    dim = "low" if features <= 10 else "mid" if features <= 50 else "high"
    return {
        "size": size,
        "dim": dim,
        "missing": meta.get("has_missing_values") == "yes",
        "mixed_types": "Categorical" in (meta.get("feature_types") or []),
        "time": "Time-Series" in (meta.get("characteristics") or []),
        "domain": meta.get("area"),
    }


def x_strata__mutmut_14(meta: dict[str, Any]) -> dict[str, Any]:
    rows, features = meta["num_instances"], meta["num_features"]
    size = (
        "tiny"
        if rows < 2000
        else "small"
        if (rows < 20_000) or True
        else "medium"
        if rows < 200_000
        else "large"
    )
    dim = "low" if features <= 10 else "mid" if features <= 50 else "high"
    return {
        "size": size,
        "dim": dim,
        "missing": meta.get("has_missing_values") == "yes",
        "mixed_types": "Categorical" in (meta.get("feature_types") or []),
        "time": "Time-Series" in (meta.get("characteristics") or []),
        "domain": meta.get("area"),
    }


def x_strata__mutmut_15(meta: dict[str, Any]) -> dict[str, Any]:
    rows, features = meta["num_instances"], meta["num_features"]
    size = (
        "tiny"
        if rows < 2000
        else "XXsmallXX"
        if rows < 20_000
        else "medium"
        if rows < 200_000
        else "large"
    )
    dim = "low" if features <= 10 else "mid" if features <= 50 else "high"
    return {
        "size": size,
        "dim": dim,
        "missing": meta.get("has_missing_values") == "yes",
        "mixed_types": "Categorical" in (meta.get("feature_types") or []),
        "time": "Time-Series" in (meta.get("characteristics") or []),
        "domain": meta.get("area"),
    }


def x_strata__mutmut_16(meta: dict[str, Any]) -> dict[str, Any]:
    rows, features = meta["num_instances"], meta["num_features"]
    size = (
        "tiny"
        if rows < 2000
        else "SMALL"
        if rows < 20_000
        else "medium"
        if rows < 200_000
        else "large"
    )
    dim = "low" if features <= 10 else "mid" if features <= 50 else "high"
    return {
        "size": size,
        "dim": dim,
        "missing": meta.get("has_missing_values") == "yes",
        "mixed_types": "Categorical" in (meta.get("feature_types") or []),
        "time": "Time-Series" in (meta.get("characteristics") or []),
        "domain": meta.get("area"),
    }


def x_strata__mutmut_17(meta: dict[str, Any]) -> dict[str, Any]:
    rows, features = meta["num_instances"], meta["num_features"]
    size = (
        "tiny"
        if rows < 2000
        else "small"
        if rows <= 20_000
        else "medium"
        if rows < 200_000
        else "large"
    )
    dim = "low" if features <= 10 else "mid" if features <= 50 else "high"
    return {
        "size": size,
        "dim": dim,
        "missing": meta.get("has_missing_values") == "yes",
        "mixed_types": "Categorical" in (meta.get("feature_types") or []),
        "time": "Time-Series" in (meta.get("characteristics") or []),
        "domain": meta.get("area"),
    }


def x_strata__mutmut_18(meta: dict[str, Any]) -> dict[str, Any]:
    rows, features = meta["num_instances"], meta["num_features"]
    size = (
        "tiny"
        if rows < 2000
        else "small"
        if rows < 20001
        else "medium"
        if rows < 200_000
        else "large"
    )
    dim = "low" if features <= 10 else "mid" if features <= 50 else "high"
    return {
        "size": size,
        "dim": dim,
        "missing": meta.get("has_missing_values") == "yes",
        "mixed_types": "Categorical" in (meta.get("feature_types") or []),
        "time": "Time-Series" in (meta.get("characteristics") or []),
        "domain": meta.get("area"),
    }


def x_strata__mutmut_19(meta: dict[str, Any]) -> dict[str, Any]:
    rows, features = meta["num_instances"], meta["num_features"]
    size = (
        "tiny"
        if rows < 2000
        else "small"
        if rows < 20_000
        else "medium"
        if (rows < 200_000) and False
        else "large"
    )
    dim = "low" if features <= 10 else "mid" if features <= 50 else "high"
    return {
        "size": size,
        "dim": dim,
        "missing": meta.get("has_missing_values") == "yes",
        "mixed_types": "Categorical" in (meta.get("feature_types") or []),
        "time": "Time-Series" in (meta.get("characteristics") or []),
        "domain": meta.get("area"),
    }


def x_strata__mutmut_20(meta: dict[str, Any]) -> dict[str, Any]:
    rows, features = meta["num_instances"], meta["num_features"]
    size = (
        "tiny"
        if rows < 2000
        else "small"
        if rows < 20_000
        else "medium"
        if (rows < 200_000) or True
        else "large"
    )
    dim = "low" if features <= 10 else "mid" if features <= 50 else "high"
    return {
        "size": size,
        "dim": dim,
        "missing": meta.get("has_missing_values") == "yes",
        "mixed_types": "Categorical" in (meta.get("feature_types") or []),
        "time": "Time-Series" in (meta.get("characteristics") or []),
        "domain": meta.get("area"),
    }


def x_strata__mutmut_21(meta: dict[str, Any]) -> dict[str, Any]:
    rows, features = meta["num_instances"], meta["num_features"]
    size = (
        "tiny"
        if rows < 2000
        else "small"
        if rows < 20_000
        else "XXmediumXX"
        if rows < 200_000
        else "large"
    )
    dim = "low" if features <= 10 else "mid" if features <= 50 else "high"
    return {
        "size": size,
        "dim": dim,
        "missing": meta.get("has_missing_values") == "yes",
        "mixed_types": "Categorical" in (meta.get("feature_types") or []),
        "time": "Time-Series" in (meta.get("characteristics") or []),
        "domain": meta.get("area"),
    }


def x_strata__mutmut_22(meta: dict[str, Any]) -> dict[str, Any]:
    rows, features = meta["num_instances"], meta["num_features"]
    size = (
        "tiny"
        if rows < 2000
        else "small"
        if rows < 20_000
        else "MEDIUM"
        if rows < 200_000
        else "large"
    )
    dim = "low" if features <= 10 else "mid" if features <= 50 else "high"
    return {
        "size": size,
        "dim": dim,
        "missing": meta.get("has_missing_values") == "yes",
        "mixed_types": "Categorical" in (meta.get("feature_types") or []),
        "time": "Time-Series" in (meta.get("characteristics") or []),
        "domain": meta.get("area"),
    }


def x_strata__mutmut_23(meta: dict[str, Any]) -> dict[str, Any]:
    rows, features = meta["num_instances"], meta["num_features"]
    size = (
        "tiny"
        if rows < 2000
        else "small"
        if rows < 20_000
        else "medium"
        if rows <= 200_000
        else "large"
    )
    dim = "low" if features <= 10 else "mid" if features <= 50 else "high"
    return {
        "size": size,
        "dim": dim,
        "missing": meta.get("has_missing_values") == "yes",
        "mixed_types": "Categorical" in (meta.get("feature_types") or []),
        "time": "Time-Series" in (meta.get("characteristics") or []),
        "domain": meta.get("area"),
    }


def x_strata__mutmut_24(meta: dict[str, Any]) -> dict[str, Any]:
    rows, features = meta["num_instances"], meta["num_features"]
    size = (
        "tiny"
        if rows < 2000
        else "small"
        if rows < 20_000
        else "medium"
        if rows < 200001
        else "large"
    )
    dim = "low" if features <= 10 else "mid" if features <= 50 else "high"
    return {
        "size": size,
        "dim": dim,
        "missing": meta.get("has_missing_values") == "yes",
        "mixed_types": "Categorical" in (meta.get("feature_types") or []),
        "time": "Time-Series" in (meta.get("characteristics") or []),
        "domain": meta.get("area"),
    }


def x_strata__mutmut_25(meta: dict[str, Any]) -> dict[str, Any]:
    rows, features = meta["num_instances"], meta["num_features"]
    size = (
        "tiny"
        if rows < 2000
        else "small"
        if rows < 20_000
        else "medium"
        if rows < 200_000
        else "XXlargeXX"
    )
    dim = "low" if features <= 10 else "mid" if features <= 50 else "high"
    return {
        "size": size,
        "dim": dim,
        "missing": meta.get("has_missing_values") == "yes",
        "mixed_types": "Categorical" in (meta.get("feature_types") or []),
        "time": "Time-Series" in (meta.get("characteristics") or []),
        "domain": meta.get("area"),
    }


def x_strata__mutmut_26(meta: dict[str, Any]) -> dict[str, Any]:
    rows, features = meta["num_instances"], meta["num_features"]
    size = (
        "tiny"
        if rows < 2000
        else "small"
        if rows < 20_000
        else "medium"
        if rows < 200_000
        else "LARGE"
    )
    dim = "low" if features <= 10 else "mid" if features <= 50 else "high"
    return {
        "size": size,
        "dim": dim,
        "missing": meta.get("has_missing_values") == "yes",
        "mixed_types": "Categorical" in (meta.get("feature_types") or []),
        "time": "Time-Series" in (meta.get("characteristics") or []),
        "domain": meta.get("area"),
    }


def x_strata__mutmut_27(meta: dict[str, Any]) -> dict[str, Any]:
    rows, features = meta["num_instances"], meta["num_features"]
    size = (
        "tiny"
        if rows < 2000
        else "small"
        if rows < 20_000
        else "medium"
        if rows < 200_000
        else "large"
    )
    dim = None
    return {
        "size": size,
        "dim": dim,
        "missing": meta.get("has_missing_values") == "yes",
        "mixed_types": "Categorical" in (meta.get("feature_types") or []),
        "time": "Time-Series" in (meta.get("characteristics") or []),
        "domain": meta.get("area"),
    }


def x_strata__mutmut_28(meta: dict[str, Any]) -> dict[str, Any]:
    rows, features = meta["num_instances"], meta["num_features"]
    size = (
        "tiny"
        if rows < 2000
        else "small"
        if rows < 20_000
        else "medium"
        if rows < 200_000
        else "large"
    )
    dim = "low" if (features <= 10) and False else "mid" if features <= 50 else "high"
    return {
        "size": size,
        "dim": dim,
        "missing": meta.get("has_missing_values") == "yes",
        "mixed_types": "Categorical" in (meta.get("feature_types") or []),
        "time": "Time-Series" in (meta.get("characteristics") or []),
        "domain": meta.get("area"),
    }


def x_strata__mutmut_29(meta: dict[str, Any]) -> dict[str, Any]:
    rows, features = meta["num_instances"], meta["num_features"]
    size = (
        "tiny"
        if rows < 2000
        else "small"
        if rows < 20_000
        else "medium"
        if rows < 200_000
        else "large"
    )
    dim = "low" if (features <= 10) or True else "mid" if features <= 50 else "high"
    return {
        "size": size,
        "dim": dim,
        "missing": meta.get("has_missing_values") == "yes",
        "mixed_types": "Categorical" in (meta.get("feature_types") or []),
        "time": "Time-Series" in (meta.get("characteristics") or []),
        "domain": meta.get("area"),
    }


def x_strata__mutmut_30(meta: dict[str, Any]) -> dict[str, Any]:
    rows, features = meta["num_instances"], meta["num_features"]
    size = (
        "tiny"
        if rows < 2000
        else "small"
        if rows < 20_000
        else "medium"
        if rows < 200_000
        else "large"
    )
    dim = "XXlowXX" if features <= 10 else "mid" if features <= 50 else "high"
    return {
        "size": size,
        "dim": dim,
        "missing": meta.get("has_missing_values") == "yes",
        "mixed_types": "Categorical" in (meta.get("feature_types") or []),
        "time": "Time-Series" in (meta.get("characteristics") or []),
        "domain": meta.get("area"),
    }


def x_strata__mutmut_31(meta: dict[str, Any]) -> dict[str, Any]:
    rows, features = meta["num_instances"], meta["num_features"]
    size = (
        "tiny"
        if rows < 2000
        else "small"
        if rows < 20_000
        else "medium"
        if rows < 200_000
        else "large"
    )
    dim = "LOW" if features <= 10 else "mid" if features <= 50 else "high"
    return {
        "size": size,
        "dim": dim,
        "missing": meta.get("has_missing_values") == "yes",
        "mixed_types": "Categorical" in (meta.get("feature_types") or []),
        "time": "Time-Series" in (meta.get("characteristics") or []),
        "domain": meta.get("area"),
    }


def x_strata__mutmut_32(meta: dict[str, Any]) -> dict[str, Any]:
    rows, features = meta["num_instances"], meta["num_features"]
    size = (
        "tiny"
        if rows < 2000
        else "small"
        if rows < 20_000
        else "medium"
        if rows < 200_000
        else "large"
    )
    dim = "low" if features < 10 else "mid" if features <= 50 else "high"
    return {
        "size": size,
        "dim": dim,
        "missing": meta.get("has_missing_values") == "yes",
        "mixed_types": "Categorical" in (meta.get("feature_types") or []),
        "time": "Time-Series" in (meta.get("characteristics") or []),
        "domain": meta.get("area"),
    }


def x_strata__mutmut_33(meta: dict[str, Any]) -> dict[str, Any]:
    rows, features = meta["num_instances"], meta["num_features"]
    size = (
        "tiny"
        if rows < 2000
        else "small"
        if rows < 20_000
        else "medium"
        if rows < 200_000
        else "large"
    )
    dim = "low" if features <= 11 else "mid" if features <= 50 else "high"
    return {
        "size": size,
        "dim": dim,
        "missing": meta.get("has_missing_values") == "yes",
        "mixed_types": "Categorical" in (meta.get("feature_types") or []),
        "time": "Time-Series" in (meta.get("characteristics") or []),
        "domain": meta.get("area"),
    }


def x_strata__mutmut_34(meta: dict[str, Any]) -> dict[str, Any]:
    rows, features = meta["num_instances"], meta["num_features"]
    size = (
        "tiny"
        if rows < 2000
        else "small"
        if rows < 20_000
        else "medium"
        if rows < 200_000
        else "large"
    )
    dim = "low" if features <= 10 else "mid" if (features <= 50) and False else "high"
    return {
        "size": size,
        "dim": dim,
        "missing": meta.get("has_missing_values") == "yes",
        "mixed_types": "Categorical" in (meta.get("feature_types") or []),
        "time": "Time-Series" in (meta.get("characteristics") or []),
        "domain": meta.get("area"),
    }


def x_strata__mutmut_35(meta: dict[str, Any]) -> dict[str, Any]:
    rows, features = meta["num_instances"], meta["num_features"]
    size = (
        "tiny"
        if rows < 2000
        else "small"
        if rows < 20_000
        else "medium"
        if rows < 200_000
        else "large"
    )
    dim = "low" if features <= 10 else "mid" if (features <= 50) or True else "high"
    return {
        "size": size,
        "dim": dim,
        "missing": meta.get("has_missing_values") == "yes",
        "mixed_types": "Categorical" in (meta.get("feature_types") or []),
        "time": "Time-Series" in (meta.get("characteristics") or []),
        "domain": meta.get("area"),
    }


def x_strata__mutmut_36(meta: dict[str, Any]) -> dict[str, Any]:
    rows, features = meta["num_instances"], meta["num_features"]
    size = (
        "tiny"
        if rows < 2000
        else "small"
        if rows < 20_000
        else "medium"
        if rows < 200_000
        else "large"
    )
    dim = "low" if features <= 10 else "XXmidXX" if features <= 50 else "high"
    return {
        "size": size,
        "dim": dim,
        "missing": meta.get("has_missing_values") == "yes",
        "mixed_types": "Categorical" in (meta.get("feature_types") or []),
        "time": "Time-Series" in (meta.get("characteristics") or []),
        "domain": meta.get("area"),
    }


def x_strata__mutmut_37(meta: dict[str, Any]) -> dict[str, Any]:
    rows, features = meta["num_instances"], meta["num_features"]
    size = (
        "tiny"
        if rows < 2000
        else "small"
        if rows < 20_000
        else "medium"
        if rows < 200_000
        else "large"
    )
    dim = "low" if features <= 10 else "MID" if features <= 50 else "high"
    return {
        "size": size,
        "dim": dim,
        "missing": meta.get("has_missing_values") == "yes",
        "mixed_types": "Categorical" in (meta.get("feature_types") or []),
        "time": "Time-Series" in (meta.get("characteristics") or []),
        "domain": meta.get("area"),
    }


def x_strata__mutmut_38(meta: dict[str, Any]) -> dict[str, Any]:
    rows, features = meta["num_instances"], meta["num_features"]
    size = (
        "tiny"
        if rows < 2000
        else "small"
        if rows < 20_000
        else "medium"
        if rows < 200_000
        else "large"
    )
    dim = "low" if features <= 10 else "mid" if features < 50 else "high"
    return {
        "size": size,
        "dim": dim,
        "missing": meta.get("has_missing_values") == "yes",
        "mixed_types": "Categorical" in (meta.get("feature_types") or []),
        "time": "Time-Series" in (meta.get("characteristics") or []),
        "domain": meta.get("area"),
    }


def x_strata__mutmut_39(meta: dict[str, Any]) -> dict[str, Any]:
    rows, features = meta["num_instances"], meta["num_features"]
    size = (
        "tiny"
        if rows < 2000
        else "small"
        if rows < 20_000
        else "medium"
        if rows < 200_000
        else "large"
    )
    dim = "low" if features <= 10 else "mid" if features <= 51 else "high"
    return {
        "size": size,
        "dim": dim,
        "missing": meta.get("has_missing_values") == "yes",
        "mixed_types": "Categorical" in (meta.get("feature_types") or []),
        "time": "Time-Series" in (meta.get("characteristics") or []),
        "domain": meta.get("area"),
    }


def x_strata__mutmut_40(meta: dict[str, Any]) -> dict[str, Any]:
    rows, features = meta["num_instances"], meta["num_features"]
    size = (
        "tiny"
        if rows < 2000
        else "small"
        if rows < 20_000
        else "medium"
        if rows < 200_000
        else "large"
    )
    dim = "low" if features <= 10 else "mid" if features <= 50 else "XXhighXX"
    return {
        "size": size,
        "dim": dim,
        "missing": meta.get("has_missing_values") == "yes",
        "mixed_types": "Categorical" in (meta.get("feature_types") or []),
        "time": "Time-Series" in (meta.get("characteristics") or []),
        "domain": meta.get("area"),
    }


def x_strata__mutmut_41(meta: dict[str, Any]) -> dict[str, Any]:
    rows, features = meta["num_instances"], meta["num_features"]
    size = (
        "tiny"
        if rows < 2000
        else "small"
        if rows < 20_000
        else "medium"
        if rows < 200_000
        else "large"
    )
    dim = "low" if features <= 10 else "mid" if features <= 50 else "HIGH"
    return {
        "size": size,
        "dim": dim,
        "missing": meta.get("has_missing_values") == "yes",
        "mixed_types": "Categorical" in (meta.get("feature_types") or []),
        "time": "Time-Series" in (meta.get("characteristics") or []),
        "domain": meta.get("area"),
    }


def x_strata__mutmut_42(meta: dict[str, Any]) -> dict[str, Any]:
    rows, features = meta["num_instances"], meta["num_features"]
    size = (
        "tiny"
        if rows < 2000
        else "small"
        if rows < 20_000
        else "medium"
        if rows < 200_000
        else "large"
    )
    dim = "low" if features <= 10 else "mid" if features <= 50 else "high"
    return {
        "XXsizeXX": size,
        "dim": dim,
        "missing": meta.get("has_missing_values") == "yes",
        "mixed_types": "Categorical" in (meta.get("feature_types") or []),
        "time": "Time-Series" in (meta.get("characteristics") or []),
        "domain": meta.get("area"),
    }


def x_strata__mutmut_43(meta: dict[str, Any]) -> dict[str, Any]:
    rows, features = meta["num_instances"], meta["num_features"]
    size = (
        "tiny"
        if rows < 2000
        else "small"
        if rows < 20_000
        else "medium"
        if rows < 200_000
        else "large"
    )
    dim = "low" if features <= 10 else "mid" if features <= 50 else "high"
    return {
        "SIZE": size,
        "dim": dim,
        "missing": meta.get("has_missing_values") == "yes",
        "mixed_types": "Categorical" in (meta.get("feature_types") or []),
        "time": "Time-Series" in (meta.get("characteristics") or []),
        "domain": meta.get("area"),
    }


def x_strata__mutmut_44(meta: dict[str, Any]) -> dict[str, Any]:
    rows, features = meta["num_instances"], meta["num_features"]
    size = (
        "tiny"
        if rows < 2000
        else "small"
        if rows < 20_000
        else "medium"
        if rows < 200_000
        else "large"
    )
    dim = "low" if features <= 10 else "mid" if features <= 50 else "high"
    return {
        "size": size,
        "XXdimXX": dim,
        "missing": meta.get("has_missing_values") == "yes",
        "mixed_types": "Categorical" in (meta.get("feature_types") or []),
        "time": "Time-Series" in (meta.get("characteristics") or []),
        "domain": meta.get("area"),
    }


def x_strata__mutmut_45(meta: dict[str, Any]) -> dict[str, Any]:
    rows, features = meta["num_instances"], meta["num_features"]
    size = (
        "tiny"
        if rows < 2000
        else "small"
        if rows < 20_000
        else "medium"
        if rows < 200_000
        else "large"
    )
    dim = "low" if features <= 10 else "mid" if features <= 50 else "high"
    return {
        "size": size,
        "DIM": dim,
        "missing": meta.get("has_missing_values") == "yes",
        "mixed_types": "Categorical" in (meta.get("feature_types") or []),
        "time": "Time-Series" in (meta.get("characteristics") or []),
        "domain": meta.get("area"),
    }


def x_strata__mutmut_46(meta: dict[str, Any]) -> dict[str, Any]:
    rows, features = meta["num_instances"], meta["num_features"]
    size = (
        "tiny"
        if rows < 2000
        else "small"
        if rows < 20_000
        else "medium"
        if rows < 200_000
        else "large"
    )
    dim = "low" if features <= 10 else "mid" if features <= 50 else "high"
    return {
        "size": size,
        "dim": dim,
        "XXmissingXX": meta.get("has_missing_values") == "yes",
        "mixed_types": "Categorical" in (meta.get("feature_types") or []),
        "time": "Time-Series" in (meta.get("characteristics") or []),
        "domain": meta.get("area"),
    }


def x_strata__mutmut_47(meta: dict[str, Any]) -> dict[str, Any]:
    rows, features = meta["num_instances"], meta["num_features"]
    size = (
        "tiny"
        if rows < 2000
        else "small"
        if rows < 20_000
        else "medium"
        if rows < 200_000
        else "large"
    )
    dim = "low" if features <= 10 else "mid" if features <= 50 else "high"
    return {
        "size": size,
        "dim": dim,
        "MISSING": meta.get("has_missing_values") == "yes",
        "mixed_types": "Categorical" in (meta.get("feature_types") or []),
        "time": "Time-Series" in (meta.get("characteristics") or []),
        "domain": meta.get("area"),
    }


def x_strata__mutmut_48(meta: dict[str, Any]) -> dict[str, Any]:
    rows, features = meta["num_instances"], meta["num_features"]
    size = (
        "tiny"
        if rows < 2000
        else "small"
        if rows < 20_000
        else "medium"
        if rows < 200_000
        else "large"
    )
    dim = "low" if features <= 10 else "mid" if features <= 50 else "high"
    return {
        "size": size,
        "dim": dim,
        "missing": meta.get(None) == "yes",
        "mixed_types": "Categorical" in (meta.get("feature_types") or []),
        "time": "Time-Series" in (meta.get("characteristics") or []),
        "domain": meta.get("area"),
    }


def x_strata__mutmut_49(meta: dict[str, Any]) -> dict[str, Any]:
    rows, features = meta["num_instances"], meta["num_features"]
    size = (
        "tiny"
        if rows < 2000
        else "small"
        if rows < 20_000
        else "medium"
        if rows < 200_000
        else "large"
    )
    dim = "low" if features <= 10 else "mid" if features <= 50 else "high"
    return {
        "size": size,
        "dim": dim,
        "missing": meta.get("XXhas_missing_valuesXX") == "yes",
        "mixed_types": "Categorical" in (meta.get("feature_types") or []),
        "time": "Time-Series" in (meta.get("characteristics") or []),
        "domain": meta.get("area"),
    }


def x_strata__mutmut_50(meta: dict[str, Any]) -> dict[str, Any]:
    rows, features = meta["num_instances"], meta["num_features"]
    size = (
        "tiny"
        if rows < 2000
        else "small"
        if rows < 20_000
        else "medium"
        if rows < 200_000
        else "large"
    )
    dim = "low" if features <= 10 else "mid" if features <= 50 else "high"
    return {
        "size": size,
        "dim": dim,
        "missing": meta.get("HAS_MISSING_VALUES") == "yes",
        "mixed_types": "Categorical" in (meta.get("feature_types") or []),
        "time": "Time-Series" in (meta.get("characteristics") or []),
        "domain": meta.get("area"),
    }


def x_strata__mutmut_51(meta: dict[str, Any]) -> dict[str, Any]:
    rows, features = meta["num_instances"], meta["num_features"]
    size = (
        "tiny"
        if rows < 2000
        else "small"
        if rows < 20_000
        else "medium"
        if rows < 200_000
        else "large"
    )
    dim = "low" if features <= 10 else "mid" if features <= 50 else "high"
    return {
        "size": size,
        "dim": dim,
        "missing": meta.get("has_missing_values") != "yes",
        "mixed_types": "Categorical" in (meta.get("feature_types") or []),
        "time": "Time-Series" in (meta.get("characteristics") or []),
        "domain": meta.get("area"),
    }


def x_strata__mutmut_52(meta: dict[str, Any]) -> dict[str, Any]:
    rows, features = meta["num_instances"], meta["num_features"]
    size = (
        "tiny"
        if rows < 2000
        else "small"
        if rows < 20_000
        else "medium"
        if rows < 200_000
        else "large"
    )
    dim = "low" if features <= 10 else "mid" if features <= 50 else "high"
    return {
        "size": size,
        "dim": dim,
        "missing": meta.get("has_missing_values") == "XXyesXX",
        "mixed_types": "Categorical" in (meta.get("feature_types") or []),
        "time": "Time-Series" in (meta.get("characteristics") or []),
        "domain": meta.get("area"),
    }


def x_strata__mutmut_53(meta: dict[str, Any]) -> dict[str, Any]:
    rows, features = meta["num_instances"], meta["num_features"]
    size = (
        "tiny"
        if rows < 2000
        else "small"
        if rows < 20_000
        else "medium"
        if rows < 200_000
        else "large"
    )
    dim = "low" if features <= 10 else "mid" if features <= 50 else "high"
    return {
        "size": size,
        "dim": dim,
        "missing": meta.get("has_missing_values") == "YES",
        "mixed_types": "Categorical" in (meta.get("feature_types") or []),
        "time": "Time-Series" in (meta.get("characteristics") or []),
        "domain": meta.get("area"),
    }


def x_strata__mutmut_54(meta: dict[str, Any]) -> dict[str, Any]:
    rows, features = meta["num_instances"], meta["num_features"]
    size = (
        "tiny"
        if rows < 2000
        else "small"
        if rows < 20_000
        else "medium"
        if rows < 200_000
        else "large"
    )
    dim = "low" if features <= 10 else "mid" if features <= 50 else "high"
    return {
        "size": size,
        "dim": dim,
        "missing": meta.get("has_missing_values") == "yes",
        "XXmixed_typesXX": "Categorical" in (meta.get("feature_types") or []),
        "time": "Time-Series" in (meta.get("characteristics") or []),
        "domain": meta.get("area"),
    }


def x_strata__mutmut_55(meta: dict[str, Any]) -> dict[str, Any]:
    rows, features = meta["num_instances"], meta["num_features"]
    size = (
        "tiny"
        if rows < 2000
        else "small"
        if rows < 20_000
        else "medium"
        if rows < 200_000
        else "large"
    )
    dim = "low" if features <= 10 else "mid" if features <= 50 else "high"
    return {
        "size": size,
        "dim": dim,
        "missing": meta.get("has_missing_values") == "yes",
        "MIXED_TYPES": "Categorical" in (meta.get("feature_types") or []),
        "time": "Time-Series" in (meta.get("characteristics") or []),
        "domain": meta.get("area"),
    }


def x_strata__mutmut_56(meta: dict[str, Any]) -> dict[str, Any]:
    rows, features = meta["num_instances"], meta["num_features"]
    size = (
        "tiny"
        if rows < 2000
        else "small"
        if rows < 20_000
        else "medium"
        if rows < 200_000
        else "large"
    )
    dim = "low" if features <= 10 else "mid" if features <= 50 else "high"
    return {
        "size": size,
        "dim": dim,
        "missing": meta.get("has_missing_values") == "yes",
        "mixed_types": "XXCategoricalXX" in (meta.get("feature_types") or []),
        "time": "Time-Series" in (meta.get("characteristics") or []),
        "domain": meta.get("area"),
    }


def x_strata__mutmut_57(meta: dict[str, Any]) -> dict[str, Any]:
    rows, features = meta["num_instances"], meta["num_features"]
    size = (
        "tiny"
        if rows < 2000
        else "small"
        if rows < 20_000
        else "medium"
        if rows < 200_000
        else "large"
    )
    dim = "low" if features <= 10 else "mid" if features <= 50 else "high"
    return {
        "size": size,
        "dim": dim,
        "missing": meta.get("has_missing_values") == "yes",
        "mixed_types": "categorical" in (meta.get("feature_types") or []),
        "time": "Time-Series" in (meta.get("characteristics") or []),
        "domain": meta.get("area"),
    }


def x_strata__mutmut_58(meta: dict[str, Any]) -> dict[str, Any]:
    rows, features = meta["num_instances"], meta["num_features"]
    size = (
        "tiny"
        if rows < 2000
        else "small"
        if rows < 20_000
        else "medium"
        if rows < 200_000
        else "large"
    )
    dim = "low" if features <= 10 else "mid" if features <= 50 else "high"
    return {
        "size": size,
        "dim": dim,
        "missing": meta.get("has_missing_values") == "yes",
        "mixed_types": "CATEGORICAL" in (meta.get("feature_types") or []),
        "time": "Time-Series" in (meta.get("characteristics") or []),
        "domain": meta.get("area"),
    }


def x_strata__mutmut_59(meta: dict[str, Any]) -> dict[str, Any]:
    rows, features = meta["num_instances"], meta["num_features"]
    size = (
        "tiny"
        if rows < 2000
        else "small"
        if rows < 20_000
        else "medium"
        if rows < 200_000
        else "large"
    )
    dim = "low" if features <= 10 else "mid" if features <= 50 else "high"
    return {
        "size": size,
        "dim": dim,
        "missing": meta.get("has_missing_values") == "yes",
        "mixed_types": "Categorical" not in (meta.get("feature_types") or []),
        "time": "Time-Series" in (meta.get("characteristics") or []),
        "domain": meta.get("area"),
    }


def x_strata__mutmut_60(meta: dict[str, Any]) -> dict[str, Any]:
    rows, features = meta["num_instances"], meta["num_features"]
    size = (
        "tiny"
        if rows < 2000
        else "small"
        if rows < 20_000
        else "medium"
        if rows < 200_000
        else "large"
    )
    dim = "low" if features <= 10 else "mid" if features <= 50 else "high"
    return {
        "size": size,
        "dim": dim,
        "missing": meta.get("has_missing_values") == "yes",
        "mixed_types": "Categorical" in (meta.get("feature_types") and []),
        "time": "Time-Series" in (meta.get("characteristics") or []),
        "domain": meta.get("area"),
    }


def x_strata__mutmut_61(meta: dict[str, Any]) -> dict[str, Any]:
    rows, features = meta["num_instances"], meta["num_features"]
    size = (
        "tiny"
        if rows < 2000
        else "small"
        if rows < 20_000
        else "medium"
        if rows < 200_000
        else "large"
    )
    dim = "low" if features <= 10 else "mid" if features <= 50 else "high"
    return {
        "size": size,
        "dim": dim,
        "missing": meta.get("has_missing_values") == "yes",
        "mixed_types": "Categorical" in (meta.get(None) or []),
        "time": "Time-Series" in (meta.get("characteristics") or []),
        "domain": meta.get("area"),
    }


def x_strata__mutmut_62(meta: dict[str, Any]) -> dict[str, Any]:
    rows, features = meta["num_instances"], meta["num_features"]
    size = (
        "tiny"
        if rows < 2000
        else "small"
        if rows < 20_000
        else "medium"
        if rows < 200_000
        else "large"
    )
    dim = "low" if features <= 10 else "mid" if features <= 50 else "high"
    return {
        "size": size,
        "dim": dim,
        "missing": meta.get("has_missing_values") == "yes",
        "mixed_types": "Categorical" in (meta.get("XXfeature_typesXX") or []),
        "time": "Time-Series" in (meta.get("characteristics") or []),
        "domain": meta.get("area"),
    }


def x_strata__mutmut_63(meta: dict[str, Any]) -> dict[str, Any]:
    rows, features = meta["num_instances"], meta["num_features"]
    size = (
        "tiny"
        if rows < 2000
        else "small"
        if rows < 20_000
        else "medium"
        if rows < 200_000
        else "large"
    )
    dim = "low" if features <= 10 else "mid" if features <= 50 else "high"
    return {
        "size": size,
        "dim": dim,
        "missing": meta.get("has_missing_values") == "yes",
        "mixed_types": "Categorical" in (meta.get("FEATURE_TYPES") or []),
        "time": "Time-Series" in (meta.get("characteristics") or []),
        "domain": meta.get("area"),
    }


def x_strata__mutmut_64(meta: dict[str, Any]) -> dict[str, Any]:
    rows, features = meta["num_instances"], meta["num_features"]
    size = (
        "tiny"
        if rows < 2000
        else "small"
        if rows < 20_000
        else "medium"
        if rows < 200_000
        else "large"
    )
    dim = "low" if features <= 10 else "mid" if features <= 50 else "high"
    return {
        "size": size,
        "dim": dim,
        "missing": meta.get("has_missing_values") == "yes",
        "mixed_types": "Categorical" in (meta.get("feature_types") or []),
        "XXtimeXX": "Time-Series" in (meta.get("characteristics") or []),
        "domain": meta.get("area"),
    }


def x_strata__mutmut_65(meta: dict[str, Any]) -> dict[str, Any]:
    rows, features = meta["num_instances"], meta["num_features"]
    size = (
        "tiny"
        if rows < 2000
        else "small"
        if rows < 20_000
        else "medium"
        if rows < 200_000
        else "large"
    )
    dim = "low" if features <= 10 else "mid" if features <= 50 else "high"
    return {
        "size": size,
        "dim": dim,
        "missing": meta.get("has_missing_values") == "yes",
        "mixed_types": "Categorical" in (meta.get("feature_types") or []),
        "TIME": "Time-Series" in (meta.get("characteristics") or []),
        "domain": meta.get("area"),
    }


def x_strata__mutmut_66(meta: dict[str, Any]) -> dict[str, Any]:
    rows, features = meta["num_instances"], meta["num_features"]
    size = (
        "tiny"
        if rows < 2000
        else "small"
        if rows < 20_000
        else "medium"
        if rows < 200_000
        else "large"
    )
    dim = "low" if features <= 10 else "mid" if features <= 50 else "high"
    return {
        "size": size,
        "dim": dim,
        "missing": meta.get("has_missing_values") == "yes",
        "mixed_types": "Categorical" in (meta.get("feature_types") or []),
        "time": "XXTime-SeriesXX" in (meta.get("characteristics") or []),
        "domain": meta.get("area"),
    }


def x_strata__mutmut_67(meta: dict[str, Any]) -> dict[str, Any]:
    rows, features = meta["num_instances"], meta["num_features"]
    size = (
        "tiny"
        if rows < 2000
        else "small"
        if rows < 20_000
        else "medium"
        if rows < 200_000
        else "large"
    )
    dim = "low" if features <= 10 else "mid" if features <= 50 else "high"
    return {
        "size": size,
        "dim": dim,
        "missing": meta.get("has_missing_values") == "yes",
        "mixed_types": "Categorical" in (meta.get("feature_types") or []),
        "time": "time-series" in (meta.get("characteristics") or []),
        "domain": meta.get("area"),
    }


def x_strata__mutmut_68(meta: dict[str, Any]) -> dict[str, Any]:
    rows, features = meta["num_instances"], meta["num_features"]
    size = (
        "tiny"
        if rows < 2000
        else "small"
        if rows < 20_000
        else "medium"
        if rows < 200_000
        else "large"
    )
    dim = "low" if features <= 10 else "mid" if features <= 50 else "high"
    return {
        "size": size,
        "dim": dim,
        "missing": meta.get("has_missing_values") == "yes",
        "mixed_types": "Categorical" in (meta.get("feature_types") or []),
        "time": "TIME-SERIES" in (meta.get("characteristics") or []),
        "domain": meta.get("area"),
    }


def x_strata__mutmut_69(meta: dict[str, Any]) -> dict[str, Any]:
    rows, features = meta["num_instances"], meta["num_features"]
    size = (
        "tiny"
        if rows < 2000
        else "small"
        if rows < 20_000
        else "medium"
        if rows < 200_000
        else "large"
    )
    dim = "low" if features <= 10 else "mid" if features <= 50 else "high"
    return {
        "size": size,
        "dim": dim,
        "missing": meta.get("has_missing_values") == "yes",
        "mixed_types": "Categorical" in (meta.get("feature_types") or []),
        "time": "Time-Series" not in (meta.get("characteristics") or []),
        "domain": meta.get("area"),
    }


def x_strata__mutmut_70(meta: dict[str, Any]) -> dict[str, Any]:
    rows, features = meta["num_instances"], meta["num_features"]
    size = (
        "tiny"
        if rows < 2000
        else "small"
        if rows < 20_000
        else "medium"
        if rows < 200_000
        else "large"
    )
    dim = "low" if features <= 10 else "mid" if features <= 50 else "high"
    return {
        "size": size,
        "dim": dim,
        "missing": meta.get("has_missing_values") == "yes",
        "mixed_types": "Categorical" in (meta.get("feature_types") or []),
        "time": "Time-Series" in (meta.get("characteristics") and []),
        "domain": meta.get("area"),
    }


def x_strata__mutmut_71(meta: dict[str, Any]) -> dict[str, Any]:
    rows, features = meta["num_instances"], meta["num_features"]
    size = (
        "tiny"
        if rows < 2000
        else "small"
        if rows < 20_000
        else "medium"
        if rows < 200_000
        else "large"
    )
    dim = "low" if features <= 10 else "mid" if features <= 50 else "high"
    return {
        "size": size,
        "dim": dim,
        "missing": meta.get("has_missing_values") == "yes",
        "mixed_types": "Categorical" in (meta.get("feature_types") or []),
        "time": "Time-Series" in (meta.get(None) or []),
        "domain": meta.get("area"),
    }


def x_strata__mutmut_72(meta: dict[str, Any]) -> dict[str, Any]:
    rows, features = meta["num_instances"], meta["num_features"]
    size = (
        "tiny"
        if rows < 2000
        else "small"
        if rows < 20_000
        else "medium"
        if rows < 200_000
        else "large"
    )
    dim = "low" if features <= 10 else "mid" if features <= 50 else "high"
    return {
        "size": size,
        "dim": dim,
        "missing": meta.get("has_missing_values") == "yes",
        "mixed_types": "Categorical" in (meta.get("feature_types") or []),
        "time": "Time-Series" in (meta.get("XXcharacteristicsXX") or []),
        "domain": meta.get("area"),
    }


def x_strata__mutmut_73(meta: dict[str, Any]) -> dict[str, Any]:
    rows, features = meta["num_instances"], meta["num_features"]
    size = (
        "tiny"
        if rows < 2000
        else "small"
        if rows < 20_000
        else "medium"
        if rows < 200_000
        else "large"
    )
    dim = "low" if features <= 10 else "mid" if features <= 50 else "high"
    return {
        "size": size,
        "dim": dim,
        "missing": meta.get("has_missing_values") == "yes",
        "mixed_types": "Categorical" in (meta.get("feature_types") or []),
        "time": "Time-Series" in (meta.get("CHARACTERISTICS") or []),
        "domain": meta.get("area"),
    }


def x_strata__mutmut_74(meta: dict[str, Any]) -> dict[str, Any]:
    rows, features = meta["num_instances"], meta["num_features"]
    size = (
        "tiny"
        if rows < 2000
        else "small"
        if rows < 20_000
        else "medium"
        if rows < 200_000
        else "large"
    )
    dim = "low" if features <= 10 else "mid" if features <= 50 else "high"
    return {
        "size": size,
        "dim": dim,
        "missing": meta.get("has_missing_values") == "yes",
        "mixed_types": "Categorical" in (meta.get("feature_types") or []),
        "time": "Time-Series" in (meta.get("characteristics") or []),
        "XXdomainXX": meta.get("area"),
    }


def x_strata__mutmut_75(meta: dict[str, Any]) -> dict[str, Any]:
    rows, features = meta["num_instances"], meta["num_features"]
    size = (
        "tiny"
        if rows < 2000
        else "small"
        if rows < 20_000
        else "medium"
        if rows < 200_000
        else "large"
    )
    dim = "low" if features <= 10 else "mid" if features <= 50 else "high"
    return {
        "size": size,
        "dim": dim,
        "missing": meta.get("has_missing_values") == "yes",
        "mixed_types": "Categorical" in (meta.get("feature_types") or []),
        "time": "Time-Series" in (meta.get("characteristics") or []),
        "DOMAIN": meta.get("area"),
    }


def x_strata__mutmut_76(meta: dict[str, Any]) -> dict[str, Any]:
    rows, features = meta["num_instances"], meta["num_features"]
    size = (
        "tiny"
        if rows < 2000
        else "small"
        if rows < 20_000
        else "medium"
        if rows < 200_000
        else "large"
    )
    dim = "low" if features <= 10 else "mid" if features <= 50 else "high"
    return {
        "size": size,
        "dim": dim,
        "missing": meta.get("has_missing_values") == "yes",
        "mixed_types": "Categorical" in (meta.get("feature_types") or []),
        "time": "Time-Series" in (meta.get("characteristics") or []),
        "domain": meta.get(None),
    }


def x_strata__mutmut_77(meta: dict[str, Any]) -> dict[str, Any]:
    rows, features = meta["num_instances"], meta["num_features"]
    size = (
        "tiny"
        if rows < 2000
        else "small"
        if rows < 20_000
        else "medium"
        if rows < 200_000
        else "large"
    )
    dim = "low" if features <= 10 else "mid" if features <= 50 else "high"
    return {
        "size": size,
        "dim": dim,
        "missing": meta.get("has_missing_values") == "yes",
        "mixed_types": "Categorical" in (meta.get("feature_types") or []),
        "time": "Time-Series" in (meta.get("characteristics") or []),
        "domain": meta.get("XXareaXX"),
    }


def x_strata__mutmut_78(meta: dict[str, Any]) -> dict[str, Any]:
    rows, features = meta["num_instances"], meta["num_features"]
    size = (
        "tiny"
        if rows < 2000
        else "small"
        if rows < 20_000
        else "medium"
        if rows < 200_000
        else "large"
    )
    dim = "low" if features <= 10 else "mid" if features <= 50 else "high"
    return {
        "size": size,
        "dim": dim,
        "missing": meta.get("has_missing_values") == "yes",
        "mixed_types": "Categorical" in (meta.get("feature_types") or []),
        "time": "Time-Series" in (meta.get("characteristics") or []),
        "domain": meta.get("AREA"),
    }

mutants_x_strata__mutmut['_mutmut_orig'] = x_strata__mutmut_orig # type: ignore # mutmut generated
mutants_x_strata__mutmut['x_strata__mutmut_1'] = x_strata__mutmut_1 # type: ignore # mutmut generated
mutants_x_strata__mutmut['x_strata__mutmut_2'] = x_strata__mutmut_2 # type: ignore # mutmut generated
mutants_x_strata__mutmut['x_strata__mutmut_3'] = x_strata__mutmut_3 # type: ignore # mutmut generated
mutants_x_strata__mutmut['x_strata__mutmut_4'] = x_strata__mutmut_4 # type: ignore # mutmut generated
mutants_x_strata__mutmut['x_strata__mutmut_5'] = x_strata__mutmut_5 # type: ignore # mutmut generated
mutants_x_strata__mutmut['x_strata__mutmut_6'] = x_strata__mutmut_6 # type: ignore # mutmut generated
mutants_x_strata__mutmut['x_strata__mutmut_7'] = x_strata__mutmut_7 # type: ignore # mutmut generated
mutants_x_strata__mutmut['x_strata__mutmut_8'] = x_strata__mutmut_8 # type: ignore # mutmut generated
mutants_x_strata__mutmut['x_strata__mutmut_9'] = x_strata__mutmut_9 # type: ignore # mutmut generated
mutants_x_strata__mutmut['x_strata__mutmut_10'] = x_strata__mutmut_10 # type: ignore # mutmut generated
mutants_x_strata__mutmut['x_strata__mutmut_11'] = x_strata__mutmut_11 # type: ignore # mutmut generated
mutants_x_strata__mutmut['x_strata__mutmut_12'] = x_strata__mutmut_12 # type: ignore # mutmut generated
mutants_x_strata__mutmut['x_strata__mutmut_13'] = x_strata__mutmut_13 # type: ignore # mutmut generated
mutants_x_strata__mutmut['x_strata__mutmut_14'] = x_strata__mutmut_14 # type: ignore # mutmut generated
mutants_x_strata__mutmut['x_strata__mutmut_15'] = x_strata__mutmut_15 # type: ignore # mutmut generated
mutants_x_strata__mutmut['x_strata__mutmut_16'] = x_strata__mutmut_16 # type: ignore # mutmut generated
mutants_x_strata__mutmut['x_strata__mutmut_17'] = x_strata__mutmut_17 # type: ignore # mutmut generated
mutants_x_strata__mutmut['x_strata__mutmut_18'] = x_strata__mutmut_18 # type: ignore # mutmut generated
mutants_x_strata__mutmut['x_strata__mutmut_19'] = x_strata__mutmut_19 # type: ignore # mutmut generated
mutants_x_strata__mutmut['x_strata__mutmut_20'] = x_strata__mutmut_20 # type: ignore # mutmut generated
mutants_x_strata__mutmut['x_strata__mutmut_21'] = x_strata__mutmut_21 # type: ignore # mutmut generated
mutants_x_strata__mutmut['x_strata__mutmut_22'] = x_strata__mutmut_22 # type: ignore # mutmut generated
mutants_x_strata__mutmut['x_strata__mutmut_23'] = x_strata__mutmut_23 # type: ignore # mutmut generated
mutants_x_strata__mutmut['x_strata__mutmut_24'] = x_strata__mutmut_24 # type: ignore # mutmut generated
mutants_x_strata__mutmut['x_strata__mutmut_25'] = x_strata__mutmut_25 # type: ignore # mutmut generated
mutants_x_strata__mutmut['x_strata__mutmut_26'] = x_strata__mutmut_26 # type: ignore # mutmut generated
mutants_x_strata__mutmut['x_strata__mutmut_27'] = x_strata__mutmut_27 # type: ignore # mutmut generated
mutants_x_strata__mutmut['x_strata__mutmut_28'] = x_strata__mutmut_28 # type: ignore # mutmut generated
mutants_x_strata__mutmut['x_strata__mutmut_29'] = x_strata__mutmut_29 # type: ignore # mutmut generated
mutants_x_strata__mutmut['x_strata__mutmut_30'] = x_strata__mutmut_30 # type: ignore # mutmut generated
mutants_x_strata__mutmut['x_strata__mutmut_31'] = x_strata__mutmut_31 # type: ignore # mutmut generated
mutants_x_strata__mutmut['x_strata__mutmut_32'] = x_strata__mutmut_32 # type: ignore # mutmut generated
mutants_x_strata__mutmut['x_strata__mutmut_33'] = x_strata__mutmut_33 # type: ignore # mutmut generated
mutants_x_strata__mutmut['x_strata__mutmut_34'] = x_strata__mutmut_34 # type: ignore # mutmut generated
mutants_x_strata__mutmut['x_strata__mutmut_35'] = x_strata__mutmut_35 # type: ignore # mutmut generated
mutants_x_strata__mutmut['x_strata__mutmut_36'] = x_strata__mutmut_36 # type: ignore # mutmut generated
mutants_x_strata__mutmut['x_strata__mutmut_37'] = x_strata__mutmut_37 # type: ignore # mutmut generated
mutants_x_strata__mutmut['x_strata__mutmut_38'] = x_strata__mutmut_38 # type: ignore # mutmut generated
mutants_x_strata__mutmut['x_strata__mutmut_39'] = x_strata__mutmut_39 # type: ignore # mutmut generated
mutants_x_strata__mutmut['x_strata__mutmut_40'] = x_strata__mutmut_40 # type: ignore # mutmut generated
mutants_x_strata__mutmut['x_strata__mutmut_41'] = x_strata__mutmut_41 # type: ignore # mutmut generated
mutants_x_strata__mutmut['x_strata__mutmut_42'] = x_strata__mutmut_42 # type: ignore # mutmut generated
mutants_x_strata__mutmut['x_strata__mutmut_43'] = x_strata__mutmut_43 # type: ignore # mutmut generated
mutants_x_strata__mutmut['x_strata__mutmut_44'] = x_strata__mutmut_44 # type: ignore # mutmut generated
mutants_x_strata__mutmut['x_strata__mutmut_45'] = x_strata__mutmut_45 # type: ignore # mutmut generated
mutants_x_strata__mutmut['x_strata__mutmut_46'] = x_strata__mutmut_46 # type: ignore # mutmut generated
mutants_x_strata__mutmut['x_strata__mutmut_47'] = x_strata__mutmut_47 # type: ignore # mutmut generated
mutants_x_strata__mutmut['x_strata__mutmut_48'] = x_strata__mutmut_48 # type: ignore # mutmut generated
mutants_x_strata__mutmut['x_strata__mutmut_49'] = x_strata__mutmut_49 # type: ignore # mutmut generated
mutants_x_strata__mutmut['x_strata__mutmut_50'] = x_strata__mutmut_50 # type: ignore # mutmut generated
mutants_x_strata__mutmut['x_strata__mutmut_51'] = x_strata__mutmut_51 # type: ignore # mutmut generated
mutants_x_strata__mutmut['x_strata__mutmut_52'] = x_strata__mutmut_52 # type: ignore # mutmut generated
mutants_x_strata__mutmut['x_strata__mutmut_53'] = x_strata__mutmut_53 # type: ignore # mutmut generated
mutants_x_strata__mutmut['x_strata__mutmut_54'] = x_strata__mutmut_54 # type: ignore # mutmut generated
mutants_x_strata__mutmut['x_strata__mutmut_55'] = x_strata__mutmut_55 # type: ignore # mutmut generated
mutants_x_strata__mutmut['x_strata__mutmut_56'] = x_strata__mutmut_56 # type: ignore # mutmut generated
mutants_x_strata__mutmut['x_strata__mutmut_57'] = x_strata__mutmut_57 # type: ignore # mutmut generated
mutants_x_strata__mutmut['x_strata__mutmut_58'] = x_strata__mutmut_58 # type: ignore # mutmut generated
mutants_x_strata__mutmut['x_strata__mutmut_59'] = x_strata__mutmut_59 # type: ignore # mutmut generated
mutants_x_strata__mutmut['x_strata__mutmut_60'] = x_strata__mutmut_60 # type: ignore # mutmut generated
mutants_x_strata__mutmut['x_strata__mutmut_61'] = x_strata__mutmut_61 # type: ignore # mutmut generated
mutants_x_strata__mutmut['x_strata__mutmut_62'] = x_strata__mutmut_62 # type: ignore # mutmut generated
mutants_x_strata__mutmut['x_strata__mutmut_63'] = x_strata__mutmut_63 # type: ignore # mutmut generated
mutants_x_strata__mutmut['x_strata__mutmut_64'] = x_strata__mutmut_64 # type: ignore # mutmut generated
mutants_x_strata__mutmut['x_strata__mutmut_65'] = x_strata__mutmut_65 # type: ignore # mutmut generated
mutants_x_strata__mutmut['x_strata__mutmut_66'] = x_strata__mutmut_66 # type: ignore # mutmut generated
mutants_x_strata__mutmut['x_strata__mutmut_67'] = x_strata__mutmut_67 # type: ignore # mutmut generated
mutants_x_strata__mutmut['x_strata__mutmut_68'] = x_strata__mutmut_68 # type: ignore # mutmut generated
mutants_x_strata__mutmut['x_strata__mutmut_69'] = x_strata__mutmut_69 # type: ignore # mutmut generated
mutants_x_strata__mutmut['x_strata__mutmut_70'] = x_strata__mutmut_70 # type: ignore # mutmut generated
mutants_x_strata__mutmut['x_strata__mutmut_71'] = x_strata__mutmut_71 # type: ignore # mutmut generated
mutants_x_strata__mutmut['x_strata__mutmut_72'] = x_strata__mutmut_72 # type: ignore # mutmut generated
mutants_x_strata__mutmut['x_strata__mutmut_73'] = x_strata__mutmut_73 # type: ignore # mutmut generated
mutants_x_strata__mutmut['x_strata__mutmut_74'] = x_strata__mutmut_74 # type: ignore # mutmut generated
mutants_x_strata__mutmut['x_strata__mutmut_75'] = x_strata__mutmut_75 # type: ignore # mutmut generated
mutants_x_strata__mutmut['x_strata__mutmut_76'] = x_strata__mutmut_76 # type: ignore # mutmut generated
mutants_x_strata__mutmut['x_strata__mutmut_77'] = x_strata__mutmut_77 # type: ignore # mutmut generated
mutants_x_strata__mutmut['x_strata__mutmut_78'] = x_strata__mutmut_78 # type: ignore # mutmut generated
mutants_x_select__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_select__mutmut)
def select(catalogue, licences):
    chosen, rejected = [], []
    for meta in catalogue:
        reason = rejection(meta)
        if reason is None and licences.get(meta["uci_id"], {}).get("licence") not in ACCEPTED:
            reason = "licence not open or not stated on the page"
        (rejected.append((meta, reason)) if reason else chosen.append(meta))
    return chosen, rejected


def x_select__mutmut_orig(catalogue, licences):
    chosen, rejected = [], []
    for meta in catalogue:
        reason = rejection(meta)
        if reason is None and licences.get(meta["uci_id"], {}).get("licence") not in ACCEPTED:
            reason = "licence not open or not stated on the page"
        (rejected.append((meta, reason)) if reason else chosen.append(meta))
    return chosen, rejected


def x_select__mutmut_1(catalogue, licences):
    chosen, rejected = None
    for meta in catalogue:
        reason = rejection(meta)
        if reason is None and licences.get(meta["uci_id"], {}).get("licence") not in ACCEPTED:
            reason = "licence not open or not stated on the page"
        (rejected.append((meta, reason)) if reason else chosen.append(meta))
    return chosen, rejected


def x_select__mutmut_2(catalogue, licences):
    chosen, rejected = [], []
    for meta in catalogue:
        reason = None
        if reason is None and licences.get(meta["uci_id"], {}).get("licence") not in ACCEPTED:
            reason = "licence not open or not stated on the page"
        (rejected.append((meta, reason)) if reason else chosen.append(meta))
    return chosen, rejected


def x_select__mutmut_3(catalogue, licences):
    chosen, rejected = [], []
    for meta in catalogue:
        reason = rejection(None)
        if reason is None and licences.get(meta["uci_id"], {}).get("licence") not in ACCEPTED:
            reason = "licence not open or not stated on the page"
        (rejected.append((meta, reason)) if reason else chosen.append(meta))
    return chosen, rejected


def x_select__mutmut_4(catalogue, licences):
    chosen, rejected = [], []
    for meta in catalogue:
        reason = rejection(meta)
        if reason is None or licences.get(meta["uci_id"], {}).get("licence") not in ACCEPTED:
            reason = "licence not open or not stated on the page"
        (rejected.append((meta, reason)) if reason else chosen.append(meta))
    return chosen, rejected


def x_select__mutmut_5(catalogue, licences):
    chosen, rejected = [], []
    for meta in catalogue:
        reason = rejection(meta)
        if reason is not None and licences.get(meta["uci_id"], {}).get("licence") not in ACCEPTED:
            reason = "licence not open or not stated on the page"
        (rejected.append((meta, reason)) if reason else chosen.append(meta))
    return chosen, rejected


def x_select__mutmut_6(catalogue, licences):
    chosen, rejected = [], []
    for meta in catalogue:
        reason = rejection(meta)
        if reason is None and licences.get(meta["uci_id"], {}).get(None) not in ACCEPTED:
            reason = "licence not open or not stated on the page"
        (rejected.append((meta, reason)) if reason else chosen.append(meta))
    return chosen, rejected


def x_select__mutmut_7(catalogue, licences):
    chosen, rejected = [], []
    for meta in catalogue:
        reason = rejection(meta)
        if reason is None and licences.get(None, {}).get("licence") not in ACCEPTED:
            reason = "licence not open or not stated on the page"
        (rejected.append((meta, reason)) if reason else chosen.append(meta))
    return chosen, rejected


def x_select__mutmut_8(catalogue, licences):
    chosen, rejected = [], []
    for meta in catalogue:
        reason = rejection(meta)
        if reason is None and licences.get(meta["uci_id"], None).get("licence") not in ACCEPTED:
            reason = "licence not open or not stated on the page"
        (rejected.append((meta, reason)) if reason else chosen.append(meta))
    return chosen, rejected


def x_select__mutmut_9(catalogue, licences):
    chosen, rejected = [], []
    for meta in catalogue:
        reason = rejection(meta)
        if reason is None and licences.get({}).get("licence") not in ACCEPTED:
            reason = "licence not open or not stated on the page"
        (rejected.append((meta, reason)) if reason else chosen.append(meta))
    return chosen, rejected


def x_select__mutmut_10(catalogue, licences):
    chosen, rejected = [], []
    for meta in catalogue:
        reason = rejection(meta)
        if reason is None and licences.get(meta["uci_id"], ).get("licence") not in ACCEPTED:
            reason = "licence not open or not stated on the page"
        (rejected.append((meta, reason)) if reason else chosen.append(meta))
    return chosen, rejected


def x_select__mutmut_11(catalogue, licences):
    chosen, rejected = [], []
    for meta in catalogue:
        reason = rejection(meta)
        if reason is None and licences.get(meta["XXuci_idXX"], {}).get("licence") not in ACCEPTED:
            reason = "licence not open or not stated on the page"
        (rejected.append((meta, reason)) if reason else chosen.append(meta))
    return chosen, rejected


def x_select__mutmut_12(catalogue, licences):
    chosen, rejected = [], []
    for meta in catalogue:
        reason = rejection(meta)
        if reason is None and licences.get(meta["UCI_ID"], {}).get("licence") not in ACCEPTED:
            reason = "licence not open or not stated on the page"
        (rejected.append((meta, reason)) if reason else chosen.append(meta))
    return chosen, rejected


def x_select__mutmut_13(catalogue, licences):
    chosen, rejected = [], []
    for meta in catalogue:
        reason = rejection(meta)
        if reason is None and licences.get(meta["uci_id"], {}).get("XXlicenceXX") not in ACCEPTED:
            reason = "licence not open or not stated on the page"
        (rejected.append((meta, reason)) if reason else chosen.append(meta))
    return chosen, rejected


def x_select__mutmut_14(catalogue, licences):
    chosen, rejected = [], []
    for meta in catalogue:
        reason = rejection(meta)
        if reason is None and licences.get(meta["uci_id"], {}).get("LICENCE") not in ACCEPTED:
            reason = "licence not open or not stated on the page"
        (rejected.append((meta, reason)) if reason else chosen.append(meta))
    return chosen, rejected


def x_select__mutmut_15(catalogue, licences):
    chosen, rejected = [], []
    for meta in catalogue:
        reason = rejection(meta)
        if reason is None and licences.get(meta["uci_id"], {}).get("licence") in ACCEPTED:
            reason = "licence not open or not stated on the page"
        (rejected.append((meta, reason)) if reason else chosen.append(meta))
    return chosen, rejected


def x_select__mutmut_16(catalogue, licences):
    chosen, rejected = [], []
    for meta in catalogue:
        reason = rejection(meta)
        if reason is None and licences.get(meta["uci_id"], {}).get("licence") not in ACCEPTED:
            reason = None
        (rejected.append((meta, reason)) if reason else chosen.append(meta))
    return chosen, rejected


def x_select__mutmut_17(catalogue, licences):
    chosen, rejected = [], []
    for meta in catalogue:
        reason = rejection(meta)
        if reason is None and licences.get(meta["uci_id"], {}).get("licence") not in ACCEPTED:
            reason = "XXlicence not open or not stated on the pageXX"
        (rejected.append((meta, reason)) if reason else chosen.append(meta))
    return chosen, rejected


def x_select__mutmut_18(catalogue, licences):
    chosen, rejected = [], []
    for meta in catalogue:
        reason = rejection(meta)
        if reason is None and licences.get(meta["uci_id"], {}).get("licence") not in ACCEPTED:
            reason = "LICENCE NOT OPEN OR NOT STATED ON THE PAGE"
        (rejected.append((meta, reason)) if reason else chosen.append(meta))
    return chosen, rejected


def x_select__mutmut_19(catalogue, licences):
    chosen, rejected = [], []
    for meta in catalogue:
        reason = rejection(meta)
        if reason is None and licences.get(meta["uci_id"], {}).get("licence") not in ACCEPTED:
            reason = "licence not open or not stated on the page"
        (rejected.append((meta, reason)) if (reason) and False else chosen.append(meta))
    return chosen, rejected


def x_select__mutmut_20(catalogue, licences):
    chosen, rejected = [], []
    for meta in catalogue:
        reason = rejection(meta)
        if reason is None and licences.get(meta["uci_id"], {}).get("licence") not in ACCEPTED:
            reason = "licence not open or not stated on the page"
        (rejected.append((meta, reason)) if (reason) or True else chosen.append(meta))
    return chosen, rejected


def x_select__mutmut_21(catalogue, licences):
    chosen, rejected = [], []
    for meta in catalogue:
        reason = rejection(meta)
        if reason is None and licences.get(meta["uci_id"], {}).get("licence") not in ACCEPTED:
            reason = "licence not open or not stated on the page"
        (rejected.append(None) if reason else chosen.append(meta))
    return chosen, rejected


def x_select__mutmut_22(catalogue, licences):
    chosen, rejected = [], []
    for meta in catalogue:
        reason = rejection(meta)
        if reason is None and licences.get(meta["uci_id"], {}).get("licence") not in ACCEPTED:
            reason = "licence not open or not stated on the page"
        (rejected.append((meta, reason)) if reason else chosen.append(None))
    return chosen, rejected

mutants_x_select__mutmut['_mutmut_orig'] = x_select__mutmut_orig # type: ignore # mutmut generated
mutants_x_select__mutmut['x_select__mutmut_1'] = x_select__mutmut_1 # type: ignore # mutmut generated
mutants_x_select__mutmut['x_select__mutmut_2'] = x_select__mutmut_2 # type: ignore # mutmut generated
mutants_x_select__mutmut['x_select__mutmut_3'] = x_select__mutmut_3 # type: ignore # mutmut generated
mutants_x_select__mutmut['x_select__mutmut_4'] = x_select__mutmut_4 # type: ignore # mutmut generated
mutants_x_select__mutmut['x_select__mutmut_5'] = x_select__mutmut_5 # type: ignore # mutmut generated
mutants_x_select__mutmut['x_select__mutmut_6'] = x_select__mutmut_6 # type: ignore # mutmut generated
mutants_x_select__mutmut['x_select__mutmut_7'] = x_select__mutmut_7 # type: ignore # mutmut generated
mutants_x_select__mutmut['x_select__mutmut_8'] = x_select__mutmut_8 # type: ignore # mutmut generated
mutants_x_select__mutmut['x_select__mutmut_9'] = x_select__mutmut_9 # type: ignore # mutmut generated
mutants_x_select__mutmut['x_select__mutmut_10'] = x_select__mutmut_10 # type: ignore # mutmut generated
mutants_x_select__mutmut['x_select__mutmut_11'] = x_select__mutmut_11 # type: ignore # mutmut generated
mutants_x_select__mutmut['x_select__mutmut_12'] = x_select__mutmut_12 # type: ignore # mutmut generated
mutants_x_select__mutmut['x_select__mutmut_13'] = x_select__mutmut_13 # type: ignore # mutmut generated
mutants_x_select__mutmut['x_select__mutmut_14'] = x_select__mutmut_14 # type: ignore # mutmut generated
mutants_x_select__mutmut['x_select__mutmut_15'] = x_select__mutmut_15 # type: ignore # mutmut generated
mutants_x_select__mutmut['x_select__mutmut_16'] = x_select__mutmut_16 # type: ignore # mutmut generated
mutants_x_select__mutmut['x_select__mutmut_17'] = x_select__mutmut_17 # type: ignore # mutmut generated
mutants_x_select__mutmut['x_select__mutmut_18'] = x_select__mutmut_18 # type: ignore # mutmut generated
mutants_x_select__mutmut['x_select__mutmut_19'] = x_select__mutmut_19 # type: ignore # mutmut generated
mutants_x_select__mutmut['x_select__mutmut_20'] = x_select__mutmut_20 # type: ignore # mutmut generated
mutants_x_select__mutmut['x_select__mutmut_21'] = x_select__mutmut_21 # type: ignore # mutmut generated
mutants_x_select__mutmut['x_select__mutmut_22'] = x_select__mutmut_22 # type: ignore # mutmut generated


# Curation applied after the metadata and licence filters. Each entry carries the reason a
# reader can check against the UCI page; nothing is dropped silently.
DUPLICATE_OF = {
    20: 2,  # Census Income is the same Adult extract
    147: 50,  # Statlog Image Segmentation repeats Image Segmentation
    74: 75,  # Musk version 1 is contained in version 2
    211: 183,  # Unnormalized variant of Communities and Crime
    143: 27,  # Statlog Australian Credit Approval is a version of Credit Approval
}
CURATION_EXCLUSIONS = {
    107: "synthetic: generated from the waveform formula, no real process",
    70: "synthetic: labels produced by three fixed rules",
    12: "synthetic: psychological experiment grid, labels follow a rule",
    19: "synthetic: labels derived by a hierarchical decision model",
    76: "synthetic: labels derived by a hierarchical decision model",
    713: "synthetic: simulated verification runs",
    471: "synthetic: simulated grid stability",
    22: "game: complete board positions, not records of a process",
    23: "game: complete board positions, not records of a process",
    26: "game: complete board positions, not records of a process",
    101: "game: complete board positions, not records of a process",
    367: "game: match results with one-hot hero indicators",
}
mutants_x_curate__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_curate__mutmut)
def curate(chosen):
    kept, dropped = [], []
    for meta in chosen:
        uci_id = meta["uci_id"]
        if uci_id in DUPLICATE_OF:
            dropped.append((meta, f"duplicate of {DUPLICATE_OF[uci_id]}"))
        elif uci_id in CURATION_EXCLUSIONS:
            dropped.append((meta, CURATION_EXCLUSIONS[uci_id]))
        else:
            kept.append(meta)
    return kept, dropped


def x_curate__mutmut_orig(chosen):
    kept, dropped = [], []
    for meta in chosen:
        uci_id = meta["uci_id"]
        if uci_id in DUPLICATE_OF:
            dropped.append((meta, f"duplicate of {DUPLICATE_OF[uci_id]}"))
        elif uci_id in CURATION_EXCLUSIONS:
            dropped.append((meta, CURATION_EXCLUSIONS[uci_id]))
        else:
            kept.append(meta)
    return kept, dropped


def x_curate__mutmut_1(chosen):
    kept, dropped = None
    for meta in chosen:
        uci_id = meta["uci_id"]
        if uci_id in DUPLICATE_OF:
            dropped.append((meta, f"duplicate of {DUPLICATE_OF[uci_id]}"))
        elif uci_id in CURATION_EXCLUSIONS:
            dropped.append((meta, CURATION_EXCLUSIONS[uci_id]))
        else:
            kept.append(meta)
    return kept, dropped


def x_curate__mutmut_2(chosen):
    kept, dropped = [], []
    for meta in chosen:
        uci_id = None
        if uci_id in DUPLICATE_OF:
            dropped.append((meta, f"duplicate of {DUPLICATE_OF[uci_id]}"))
        elif uci_id in CURATION_EXCLUSIONS:
            dropped.append((meta, CURATION_EXCLUSIONS[uci_id]))
        else:
            kept.append(meta)
    return kept, dropped


def x_curate__mutmut_3(chosen):
    kept, dropped = [], []
    for meta in chosen:
        uci_id = meta["XXuci_idXX"]
        if uci_id in DUPLICATE_OF:
            dropped.append((meta, f"duplicate of {DUPLICATE_OF[uci_id]}"))
        elif uci_id in CURATION_EXCLUSIONS:
            dropped.append((meta, CURATION_EXCLUSIONS[uci_id]))
        else:
            kept.append(meta)
    return kept, dropped


def x_curate__mutmut_4(chosen):
    kept, dropped = [], []
    for meta in chosen:
        uci_id = meta["UCI_ID"]
        if uci_id in DUPLICATE_OF:
            dropped.append((meta, f"duplicate of {DUPLICATE_OF[uci_id]}"))
        elif uci_id in CURATION_EXCLUSIONS:
            dropped.append((meta, CURATION_EXCLUSIONS[uci_id]))
        else:
            kept.append(meta)
    return kept, dropped


def x_curate__mutmut_5(chosen):
    kept, dropped = [], []
    for meta in chosen:
        uci_id = meta["uci_id"]
        if uci_id not in DUPLICATE_OF:
            dropped.append((meta, f"duplicate of {DUPLICATE_OF[uci_id]}"))
        elif uci_id in CURATION_EXCLUSIONS:
            dropped.append((meta, CURATION_EXCLUSIONS[uci_id]))
        else:
            kept.append(meta)
    return kept, dropped


def x_curate__mutmut_6(chosen):
    kept, dropped = [], []
    for meta in chosen:
        uci_id = meta["uci_id"]
        if uci_id in DUPLICATE_OF:
            dropped.append(None)
        elif uci_id in CURATION_EXCLUSIONS:
            dropped.append((meta, CURATION_EXCLUSIONS[uci_id]))
        else:
            kept.append(meta)
    return kept, dropped


def x_curate__mutmut_7(chosen):
    kept, dropped = [], []
    for meta in chosen:
        uci_id = meta["uci_id"]
        if uci_id in DUPLICATE_OF:
            dropped.append((meta, f"duplicate of {DUPLICATE_OF[uci_id]}"))
        elif uci_id not in CURATION_EXCLUSIONS:
            dropped.append((meta, CURATION_EXCLUSIONS[uci_id]))
        else:
            kept.append(meta)
    return kept, dropped


def x_curate__mutmut_8(chosen):
    kept, dropped = [], []
    for meta in chosen:
        uci_id = meta["uci_id"]
        if uci_id in DUPLICATE_OF:
            dropped.append((meta, f"duplicate of {DUPLICATE_OF[uci_id]}"))
        elif uci_id in CURATION_EXCLUSIONS:
            dropped.append(None)
        else:
            kept.append(meta)
    return kept, dropped


def x_curate__mutmut_9(chosen):
    kept, dropped = [], []
    for meta in chosen:
        uci_id = meta["uci_id"]
        if uci_id in DUPLICATE_OF:
            dropped.append((meta, f"duplicate of {DUPLICATE_OF[uci_id]}"))
        elif uci_id in CURATION_EXCLUSIONS:
            dropped.append((meta, CURATION_EXCLUSIONS[uci_id]))
        else:
            kept.append(None)
    return kept, dropped

mutants_x_curate__mutmut['_mutmut_orig'] = x_curate__mutmut_orig # type: ignore # mutmut generated
mutants_x_curate__mutmut['x_curate__mutmut_1'] = x_curate__mutmut_1 # type: ignore # mutmut generated
mutants_x_curate__mutmut['x_curate__mutmut_2'] = x_curate__mutmut_2 # type: ignore # mutmut generated
mutants_x_curate__mutmut['x_curate__mutmut_3'] = x_curate__mutmut_3 # type: ignore # mutmut generated
mutants_x_curate__mutmut['x_curate__mutmut_4'] = x_curate__mutmut_4 # type: ignore # mutmut generated
mutants_x_curate__mutmut['x_curate__mutmut_5'] = x_curate__mutmut_5 # type: ignore # mutmut generated
mutants_x_curate__mutmut['x_curate__mutmut_6'] = x_curate__mutmut_6 # type: ignore # mutmut generated
mutants_x_curate__mutmut['x_curate__mutmut_7'] = x_curate__mutmut_7 # type: ignore # mutmut generated
mutants_x_curate__mutmut['x_curate__mutmut_8'] = x_curate__mutmut_8 # type: ignore # mutmut generated
mutants_x_curate__mutmut['x_curate__mutmut_9'] = x_curate__mutmut_9 # type: ignore # mutmut generated
mutants_x_panels__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_panels__mutmut)
def panels(pool) -> dict[str, list[int]]:
    """Sets that answer one specific question of the benchmark, by UCI id."""
    result: dict[str, list[int]] = {
        k: []
        for k in (
            "missing_values",
            "mixed_types",
            "temporal",
            "stress_tiny",
            "stress_large",
            "stress_wide",
        )
    }
    for meta in pool:
        tags = strata(meta)
        uci_id = meta["uci_id"]
        for name, hit in (
            ("missing_values", tags["missing"]),
            ("mixed_types", tags["mixed_types"]),
            ("temporal", tags["time"]),
            ("stress_tiny", meta["num_instances"] <= 500),
            ("stress_large", meta["num_instances"] >= 200_000),
            ("stress_wide", meta["num_features"] >= 100),
        ):
            if hit:
                result[name].append(uci_id)
    return result


def x_panels__mutmut_orig(pool) -> dict[str, list[int]]:
    """Sets that answer one specific question of the benchmark, by UCI id."""
    result: dict[str, list[int]] = {
        k: []
        for k in (
            "missing_values",
            "mixed_types",
            "temporal",
            "stress_tiny",
            "stress_large",
            "stress_wide",
        )
    }
    for meta in pool:
        tags = strata(meta)
        uci_id = meta["uci_id"]
        for name, hit in (
            ("missing_values", tags["missing"]),
            ("mixed_types", tags["mixed_types"]),
            ("temporal", tags["time"]),
            ("stress_tiny", meta["num_instances"] <= 500),
            ("stress_large", meta["num_instances"] >= 200_000),
            ("stress_wide", meta["num_features"] >= 100),
        ):
            if hit:
                result[name].append(uci_id)
    return result


def x_panels__mutmut_1(pool) -> dict[str, list[int]]:
    """Sets that answer one specific question of the benchmark, by UCI id."""
    result: dict[str, list[int]] = None
    for meta in pool:
        tags = strata(meta)
        uci_id = meta["uci_id"]
        for name, hit in (
            ("missing_values", tags["missing"]),
            ("mixed_types", tags["mixed_types"]),
            ("temporal", tags["time"]),
            ("stress_tiny", meta["num_instances"] <= 500),
            ("stress_large", meta["num_instances"] >= 200_000),
            ("stress_wide", meta["num_features"] >= 100),
        ):
            if hit:
                result[name].append(uci_id)
    return result


def x_panels__mutmut_2(pool) -> dict[str, list[int]]:
    """Sets that answer one specific question of the benchmark, by UCI id."""
    result: dict[str, list[int]] = {
        k: []
        for k in (
            "XXmissing_valuesXX",
            "mixed_types",
            "temporal",
            "stress_tiny",
            "stress_large",
            "stress_wide",
        )
    }
    for meta in pool:
        tags = strata(meta)
        uci_id = meta["uci_id"]
        for name, hit in (
            ("missing_values", tags["missing"]),
            ("mixed_types", tags["mixed_types"]),
            ("temporal", tags["time"]),
            ("stress_tiny", meta["num_instances"] <= 500),
            ("stress_large", meta["num_instances"] >= 200_000),
            ("stress_wide", meta["num_features"] >= 100),
        ):
            if hit:
                result[name].append(uci_id)
    return result


def x_panels__mutmut_3(pool) -> dict[str, list[int]]:
    """Sets that answer one specific question of the benchmark, by UCI id."""
    result: dict[str, list[int]] = {
        k: []
        for k in (
            "MISSING_VALUES",
            "mixed_types",
            "temporal",
            "stress_tiny",
            "stress_large",
            "stress_wide",
        )
    }
    for meta in pool:
        tags = strata(meta)
        uci_id = meta["uci_id"]
        for name, hit in (
            ("missing_values", tags["missing"]),
            ("mixed_types", tags["mixed_types"]),
            ("temporal", tags["time"]),
            ("stress_tiny", meta["num_instances"] <= 500),
            ("stress_large", meta["num_instances"] >= 200_000),
            ("stress_wide", meta["num_features"] >= 100),
        ):
            if hit:
                result[name].append(uci_id)
    return result


def x_panels__mutmut_4(pool) -> dict[str, list[int]]:
    """Sets that answer one specific question of the benchmark, by UCI id."""
    result: dict[str, list[int]] = {
        k: []
        for k in (
            "missing_values",
            "XXmixed_typesXX",
            "temporal",
            "stress_tiny",
            "stress_large",
            "stress_wide",
        )
    }
    for meta in pool:
        tags = strata(meta)
        uci_id = meta["uci_id"]
        for name, hit in (
            ("missing_values", tags["missing"]),
            ("mixed_types", tags["mixed_types"]),
            ("temporal", tags["time"]),
            ("stress_tiny", meta["num_instances"] <= 500),
            ("stress_large", meta["num_instances"] >= 200_000),
            ("stress_wide", meta["num_features"] >= 100),
        ):
            if hit:
                result[name].append(uci_id)
    return result


def x_panels__mutmut_5(pool) -> dict[str, list[int]]:
    """Sets that answer one specific question of the benchmark, by UCI id."""
    result: dict[str, list[int]] = {
        k: []
        for k in (
            "missing_values",
            "MIXED_TYPES",
            "temporal",
            "stress_tiny",
            "stress_large",
            "stress_wide",
        )
    }
    for meta in pool:
        tags = strata(meta)
        uci_id = meta["uci_id"]
        for name, hit in (
            ("missing_values", tags["missing"]),
            ("mixed_types", tags["mixed_types"]),
            ("temporal", tags["time"]),
            ("stress_tiny", meta["num_instances"] <= 500),
            ("stress_large", meta["num_instances"] >= 200_000),
            ("stress_wide", meta["num_features"] >= 100),
        ):
            if hit:
                result[name].append(uci_id)
    return result


def x_panels__mutmut_6(pool) -> dict[str, list[int]]:
    """Sets that answer one specific question of the benchmark, by UCI id."""
    result: dict[str, list[int]] = {
        k: []
        for k in (
            "missing_values",
            "mixed_types",
            "XXtemporalXX",
            "stress_tiny",
            "stress_large",
            "stress_wide",
        )
    }
    for meta in pool:
        tags = strata(meta)
        uci_id = meta["uci_id"]
        for name, hit in (
            ("missing_values", tags["missing"]),
            ("mixed_types", tags["mixed_types"]),
            ("temporal", tags["time"]),
            ("stress_tiny", meta["num_instances"] <= 500),
            ("stress_large", meta["num_instances"] >= 200_000),
            ("stress_wide", meta["num_features"] >= 100),
        ):
            if hit:
                result[name].append(uci_id)
    return result


def x_panels__mutmut_7(pool) -> dict[str, list[int]]:
    """Sets that answer one specific question of the benchmark, by UCI id."""
    result: dict[str, list[int]] = {
        k: []
        for k in (
            "missing_values",
            "mixed_types",
            "TEMPORAL",
            "stress_tiny",
            "stress_large",
            "stress_wide",
        )
    }
    for meta in pool:
        tags = strata(meta)
        uci_id = meta["uci_id"]
        for name, hit in (
            ("missing_values", tags["missing"]),
            ("mixed_types", tags["mixed_types"]),
            ("temporal", tags["time"]),
            ("stress_tiny", meta["num_instances"] <= 500),
            ("stress_large", meta["num_instances"] >= 200_000),
            ("stress_wide", meta["num_features"] >= 100),
        ):
            if hit:
                result[name].append(uci_id)
    return result


def x_panels__mutmut_8(pool) -> dict[str, list[int]]:
    """Sets that answer one specific question of the benchmark, by UCI id."""
    result: dict[str, list[int]] = {
        k: []
        for k in (
            "missing_values",
            "mixed_types",
            "temporal",
            "XXstress_tinyXX",
            "stress_large",
            "stress_wide",
        )
    }
    for meta in pool:
        tags = strata(meta)
        uci_id = meta["uci_id"]
        for name, hit in (
            ("missing_values", tags["missing"]),
            ("mixed_types", tags["mixed_types"]),
            ("temporal", tags["time"]),
            ("stress_tiny", meta["num_instances"] <= 500),
            ("stress_large", meta["num_instances"] >= 200_000),
            ("stress_wide", meta["num_features"] >= 100),
        ):
            if hit:
                result[name].append(uci_id)
    return result


def x_panels__mutmut_9(pool) -> dict[str, list[int]]:
    """Sets that answer one specific question of the benchmark, by UCI id."""
    result: dict[str, list[int]] = {
        k: []
        for k in (
            "missing_values",
            "mixed_types",
            "temporal",
            "STRESS_TINY",
            "stress_large",
            "stress_wide",
        )
    }
    for meta in pool:
        tags = strata(meta)
        uci_id = meta["uci_id"]
        for name, hit in (
            ("missing_values", tags["missing"]),
            ("mixed_types", tags["mixed_types"]),
            ("temporal", tags["time"]),
            ("stress_tiny", meta["num_instances"] <= 500),
            ("stress_large", meta["num_instances"] >= 200_000),
            ("stress_wide", meta["num_features"] >= 100),
        ):
            if hit:
                result[name].append(uci_id)
    return result


def x_panels__mutmut_10(pool) -> dict[str, list[int]]:
    """Sets that answer one specific question of the benchmark, by UCI id."""
    result: dict[str, list[int]] = {
        k: []
        for k in (
            "missing_values",
            "mixed_types",
            "temporal",
            "stress_tiny",
            "XXstress_largeXX",
            "stress_wide",
        )
    }
    for meta in pool:
        tags = strata(meta)
        uci_id = meta["uci_id"]
        for name, hit in (
            ("missing_values", tags["missing"]),
            ("mixed_types", tags["mixed_types"]),
            ("temporal", tags["time"]),
            ("stress_tiny", meta["num_instances"] <= 500),
            ("stress_large", meta["num_instances"] >= 200_000),
            ("stress_wide", meta["num_features"] >= 100),
        ):
            if hit:
                result[name].append(uci_id)
    return result


def x_panels__mutmut_11(pool) -> dict[str, list[int]]:
    """Sets that answer one specific question of the benchmark, by UCI id."""
    result: dict[str, list[int]] = {
        k: []
        for k in (
            "missing_values",
            "mixed_types",
            "temporal",
            "stress_tiny",
            "STRESS_LARGE",
            "stress_wide",
        )
    }
    for meta in pool:
        tags = strata(meta)
        uci_id = meta["uci_id"]
        for name, hit in (
            ("missing_values", tags["missing"]),
            ("mixed_types", tags["mixed_types"]),
            ("temporal", tags["time"]),
            ("stress_tiny", meta["num_instances"] <= 500),
            ("stress_large", meta["num_instances"] >= 200_000),
            ("stress_wide", meta["num_features"] >= 100),
        ):
            if hit:
                result[name].append(uci_id)
    return result


def x_panels__mutmut_12(pool) -> dict[str, list[int]]:
    """Sets that answer one specific question of the benchmark, by UCI id."""
    result: dict[str, list[int]] = {
        k: []
        for k in (
            "missing_values",
            "mixed_types",
            "temporal",
            "stress_tiny",
            "stress_large",
            "XXstress_wideXX",
        )
    }
    for meta in pool:
        tags = strata(meta)
        uci_id = meta["uci_id"]
        for name, hit in (
            ("missing_values", tags["missing"]),
            ("mixed_types", tags["mixed_types"]),
            ("temporal", tags["time"]),
            ("stress_tiny", meta["num_instances"] <= 500),
            ("stress_large", meta["num_instances"] >= 200_000),
            ("stress_wide", meta["num_features"] >= 100),
        ):
            if hit:
                result[name].append(uci_id)
    return result


def x_panels__mutmut_13(pool) -> dict[str, list[int]]:
    """Sets that answer one specific question of the benchmark, by UCI id."""
    result: dict[str, list[int]] = {
        k: []
        for k in (
            "missing_values",
            "mixed_types",
            "temporal",
            "stress_tiny",
            "stress_large",
            "STRESS_WIDE",
        )
    }
    for meta in pool:
        tags = strata(meta)
        uci_id = meta["uci_id"]
        for name, hit in (
            ("missing_values", tags["missing"]),
            ("mixed_types", tags["mixed_types"]),
            ("temporal", tags["time"]),
            ("stress_tiny", meta["num_instances"] <= 500),
            ("stress_large", meta["num_instances"] >= 200_000),
            ("stress_wide", meta["num_features"] >= 100),
        ):
            if hit:
                result[name].append(uci_id)
    return result


def x_panels__mutmut_14(pool) -> dict[str, list[int]]:
    """Sets that answer one specific question of the benchmark, by UCI id."""
    result: dict[str, list[int]] = {
        k: []
        for k in (
            "missing_values",
            "mixed_types",
            "temporal",
            "stress_tiny",
            "stress_large",
            "stress_wide",
        )
    }
    for meta in pool:
        tags = None
        uci_id = meta["uci_id"]
        for name, hit in (
            ("missing_values", tags["missing"]),
            ("mixed_types", tags["mixed_types"]),
            ("temporal", tags["time"]),
            ("stress_tiny", meta["num_instances"] <= 500),
            ("stress_large", meta["num_instances"] >= 200_000),
            ("stress_wide", meta["num_features"] >= 100),
        ):
            if hit:
                result[name].append(uci_id)
    return result


def x_panels__mutmut_15(pool) -> dict[str, list[int]]:
    """Sets that answer one specific question of the benchmark, by UCI id."""
    result: dict[str, list[int]] = {
        k: []
        for k in (
            "missing_values",
            "mixed_types",
            "temporal",
            "stress_tiny",
            "stress_large",
            "stress_wide",
        )
    }
    for meta in pool:
        tags = strata(None)
        uci_id = meta["uci_id"]
        for name, hit in (
            ("missing_values", tags["missing"]),
            ("mixed_types", tags["mixed_types"]),
            ("temporal", tags["time"]),
            ("stress_tiny", meta["num_instances"] <= 500),
            ("stress_large", meta["num_instances"] >= 200_000),
            ("stress_wide", meta["num_features"] >= 100),
        ):
            if hit:
                result[name].append(uci_id)
    return result


def x_panels__mutmut_16(pool) -> dict[str, list[int]]:
    """Sets that answer one specific question of the benchmark, by UCI id."""
    result: dict[str, list[int]] = {
        k: []
        for k in (
            "missing_values",
            "mixed_types",
            "temporal",
            "stress_tiny",
            "stress_large",
            "stress_wide",
        )
    }
    for meta in pool:
        tags = strata(meta)
        uci_id = None
        for name, hit in (
            ("missing_values", tags["missing"]),
            ("mixed_types", tags["mixed_types"]),
            ("temporal", tags["time"]),
            ("stress_tiny", meta["num_instances"] <= 500),
            ("stress_large", meta["num_instances"] >= 200_000),
            ("stress_wide", meta["num_features"] >= 100),
        ):
            if hit:
                result[name].append(uci_id)
    return result


def x_panels__mutmut_17(pool) -> dict[str, list[int]]:
    """Sets that answer one specific question of the benchmark, by UCI id."""
    result: dict[str, list[int]] = {
        k: []
        for k in (
            "missing_values",
            "mixed_types",
            "temporal",
            "stress_tiny",
            "stress_large",
            "stress_wide",
        )
    }
    for meta in pool:
        tags = strata(meta)
        uci_id = meta["XXuci_idXX"]
        for name, hit in (
            ("missing_values", tags["missing"]),
            ("mixed_types", tags["mixed_types"]),
            ("temporal", tags["time"]),
            ("stress_tiny", meta["num_instances"] <= 500),
            ("stress_large", meta["num_instances"] >= 200_000),
            ("stress_wide", meta["num_features"] >= 100),
        ):
            if hit:
                result[name].append(uci_id)
    return result


def x_panels__mutmut_18(pool) -> dict[str, list[int]]:
    """Sets that answer one specific question of the benchmark, by UCI id."""
    result: dict[str, list[int]] = {
        k: []
        for k in (
            "missing_values",
            "mixed_types",
            "temporal",
            "stress_tiny",
            "stress_large",
            "stress_wide",
        )
    }
    for meta in pool:
        tags = strata(meta)
        uci_id = meta["UCI_ID"]
        for name, hit in (
            ("missing_values", tags["missing"]),
            ("mixed_types", tags["mixed_types"]),
            ("temporal", tags["time"]),
            ("stress_tiny", meta["num_instances"] <= 500),
            ("stress_large", meta["num_instances"] >= 200_000),
            ("stress_wide", meta["num_features"] >= 100),
        ):
            if hit:
                result[name].append(uci_id)
    return result


def x_panels__mutmut_19(pool) -> dict[str, list[int]]:
    """Sets that answer one specific question of the benchmark, by UCI id."""
    result: dict[str, list[int]] = {
        k: []
        for k in (
            "missing_values",
            "mixed_types",
            "temporal",
            "stress_tiny",
            "stress_large",
            "stress_wide",
        )
    }
    for meta in pool:
        tags = strata(meta)
        uci_id = meta["uci_id"]
        for name, hit in (
            ("XXmissing_valuesXX", tags["missing"]),
            ("mixed_types", tags["mixed_types"]),
            ("temporal", tags["time"]),
            ("stress_tiny", meta["num_instances"] <= 500),
            ("stress_large", meta["num_instances"] >= 200_000),
            ("stress_wide", meta["num_features"] >= 100),
        ):
            if hit:
                result[name].append(uci_id)
    return result


def x_panels__mutmut_20(pool) -> dict[str, list[int]]:
    """Sets that answer one specific question of the benchmark, by UCI id."""
    result: dict[str, list[int]] = {
        k: []
        for k in (
            "missing_values",
            "mixed_types",
            "temporal",
            "stress_tiny",
            "stress_large",
            "stress_wide",
        )
    }
    for meta in pool:
        tags = strata(meta)
        uci_id = meta["uci_id"]
        for name, hit in (
            ("MISSING_VALUES", tags["missing"]),
            ("mixed_types", tags["mixed_types"]),
            ("temporal", tags["time"]),
            ("stress_tiny", meta["num_instances"] <= 500),
            ("stress_large", meta["num_instances"] >= 200_000),
            ("stress_wide", meta["num_features"] >= 100),
        ):
            if hit:
                result[name].append(uci_id)
    return result


def x_panels__mutmut_21(pool) -> dict[str, list[int]]:
    """Sets that answer one specific question of the benchmark, by UCI id."""
    result: dict[str, list[int]] = {
        k: []
        for k in (
            "missing_values",
            "mixed_types",
            "temporal",
            "stress_tiny",
            "stress_large",
            "stress_wide",
        )
    }
    for meta in pool:
        tags = strata(meta)
        uci_id = meta["uci_id"]
        for name, hit in (
            ("missing_values", tags["XXmissingXX"]),
            ("mixed_types", tags["mixed_types"]),
            ("temporal", tags["time"]),
            ("stress_tiny", meta["num_instances"] <= 500),
            ("stress_large", meta["num_instances"] >= 200_000),
            ("stress_wide", meta["num_features"] >= 100),
        ):
            if hit:
                result[name].append(uci_id)
    return result


def x_panels__mutmut_22(pool) -> dict[str, list[int]]:
    """Sets that answer one specific question of the benchmark, by UCI id."""
    result: dict[str, list[int]] = {
        k: []
        for k in (
            "missing_values",
            "mixed_types",
            "temporal",
            "stress_tiny",
            "stress_large",
            "stress_wide",
        )
    }
    for meta in pool:
        tags = strata(meta)
        uci_id = meta["uci_id"]
        for name, hit in (
            ("missing_values", tags["MISSING"]),
            ("mixed_types", tags["mixed_types"]),
            ("temporal", tags["time"]),
            ("stress_tiny", meta["num_instances"] <= 500),
            ("stress_large", meta["num_instances"] >= 200_000),
            ("stress_wide", meta["num_features"] >= 100),
        ):
            if hit:
                result[name].append(uci_id)
    return result


def x_panels__mutmut_23(pool) -> dict[str, list[int]]:
    """Sets that answer one specific question of the benchmark, by UCI id."""
    result: dict[str, list[int]] = {
        k: []
        for k in (
            "missing_values",
            "mixed_types",
            "temporal",
            "stress_tiny",
            "stress_large",
            "stress_wide",
        )
    }
    for meta in pool:
        tags = strata(meta)
        uci_id = meta["uci_id"]
        for name, hit in (
            ("missing_values", tags["missing"]),
            ("XXmixed_typesXX", tags["mixed_types"]),
            ("temporal", tags["time"]),
            ("stress_tiny", meta["num_instances"] <= 500),
            ("stress_large", meta["num_instances"] >= 200_000),
            ("stress_wide", meta["num_features"] >= 100),
        ):
            if hit:
                result[name].append(uci_id)
    return result


def x_panels__mutmut_24(pool) -> dict[str, list[int]]:
    """Sets that answer one specific question of the benchmark, by UCI id."""
    result: dict[str, list[int]] = {
        k: []
        for k in (
            "missing_values",
            "mixed_types",
            "temporal",
            "stress_tiny",
            "stress_large",
            "stress_wide",
        )
    }
    for meta in pool:
        tags = strata(meta)
        uci_id = meta["uci_id"]
        for name, hit in (
            ("missing_values", tags["missing"]),
            ("MIXED_TYPES", tags["mixed_types"]),
            ("temporal", tags["time"]),
            ("stress_tiny", meta["num_instances"] <= 500),
            ("stress_large", meta["num_instances"] >= 200_000),
            ("stress_wide", meta["num_features"] >= 100),
        ):
            if hit:
                result[name].append(uci_id)
    return result


def x_panels__mutmut_25(pool) -> dict[str, list[int]]:
    """Sets that answer one specific question of the benchmark, by UCI id."""
    result: dict[str, list[int]] = {
        k: []
        for k in (
            "missing_values",
            "mixed_types",
            "temporal",
            "stress_tiny",
            "stress_large",
            "stress_wide",
        )
    }
    for meta in pool:
        tags = strata(meta)
        uci_id = meta["uci_id"]
        for name, hit in (
            ("missing_values", tags["missing"]),
            ("mixed_types", tags["XXmixed_typesXX"]),
            ("temporal", tags["time"]),
            ("stress_tiny", meta["num_instances"] <= 500),
            ("stress_large", meta["num_instances"] >= 200_000),
            ("stress_wide", meta["num_features"] >= 100),
        ):
            if hit:
                result[name].append(uci_id)
    return result


def x_panels__mutmut_26(pool) -> dict[str, list[int]]:
    """Sets that answer one specific question of the benchmark, by UCI id."""
    result: dict[str, list[int]] = {
        k: []
        for k in (
            "missing_values",
            "mixed_types",
            "temporal",
            "stress_tiny",
            "stress_large",
            "stress_wide",
        )
    }
    for meta in pool:
        tags = strata(meta)
        uci_id = meta["uci_id"]
        for name, hit in (
            ("missing_values", tags["missing"]),
            ("mixed_types", tags["MIXED_TYPES"]),
            ("temporal", tags["time"]),
            ("stress_tiny", meta["num_instances"] <= 500),
            ("stress_large", meta["num_instances"] >= 200_000),
            ("stress_wide", meta["num_features"] >= 100),
        ):
            if hit:
                result[name].append(uci_id)
    return result


def x_panels__mutmut_27(pool) -> dict[str, list[int]]:
    """Sets that answer one specific question of the benchmark, by UCI id."""
    result: dict[str, list[int]] = {
        k: []
        for k in (
            "missing_values",
            "mixed_types",
            "temporal",
            "stress_tiny",
            "stress_large",
            "stress_wide",
        )
    }
    for meta in pool:
        tags = strata(meta)
        uci_id = meta["uci_id"]
        for name, hit in (
            ("missing_values", tags["missing"]),
            ("mixed_types", tags["mixed_types"]),
            ("XXtemporalXX", tags["time"]),
            ("stress_tiny", meta["num_instances"] <= 500),
            ("stress_large", meta["num_instances"] >= 200_000),
            ("stress_wide", meta["num_features"] >= 100),
        ):
            if hit:
                result[name].append(uci_id)
    return result


def x_panels__mutmut_28(pool) -> dict[str, list[int]]:
    """Sets that answer one specific question of the benchmark, by UCI id."""
    result: dict[str, list[int]] = {
        k: []
        for k in (
            "missing_values",
            "mixed_types",
            "temporal",
            "stress_tiny",
            "stress_large",
            "stress_wide",
        )
    }
    for meta in pool:
        tags = strata(meta)
        uci_id = meta["uci_id"]
        for name, hit in (
            ("missing_values", tags["missing"]),
            ("mixed_types", tags["mixed_types"]),
            ("TEMPORAL", tags["time"]),
            ("stress_tiny", meta["num_instances"] <= 500),
            ("stress_large", meta["num_instances"] >= 200_000),
            ("stress_wide", meta["num_features"] >= 100),
        ):
            if hit:
                result[name].append(uci_id)
    return result


def x_panels__mutmut_29(pool) -> dict[str, list[int]]:
    """Sets that answer one specific question of the benchmark, by UCI id."""
    result: dict[str, list[int]] = {
        k: []
        for k in (
            "missing_values",
            "mixed_types",
            "temporal",
            "stress_tiny",
            "stress_large",
            "stress_wide",
        )
    }
    for meta in pool:
        tags = strata(meta)
        uci_id = meta["uci_id"]
        for name, hit in (
            ("missing_values", tags["missing"]),
            ("mixed_types", tags["mixed_types"]),
            ("temporal", tags["XXtimeXX"]),
            ("stress_tiny", meta["num_instances"] <= 500),
            ("stress_large", meta["num_instances"] >= 200_000),
            ("stress_wide", meta["num_features"] >= 100),
        ):
            if hit:
                result[name].append(uci_id)
    return result


def x_panels__mutmut_30(pool) -> dict[str, list[int]]:
    """Sets that answer one specific question of the benchmark, by UCI id."""
    result: dict[str, list[int]] = {
        k: []
        for k in (
            "missing_values",
            "mixed_types",
            "temporal",
            "stress_tiny",
            "stress_large",
            "stress_wide",
        )
    }
    for meta in pool:
        tags = strata(meta)
        uci_id = meta["uci_id"]
        for name, hit in (
            ("missing_values", tags["missing"]),
            ("mixed_types", tags["mixed_types"]),
            ("temporal", tags["TIME"]),
            ("stress_tiny", meta["num_instances"] <= 500),
            ("stress_large", meta["num_instances"] >= 200_000),
            ("stress_wide", meta["num_features"] >= 100),
        ):
            if hit:
                result[name].append(uci_id)
    return result


def x_panels__mutmut_31(pool) -> dict[str, list[int]]:
    """Sets that answer one specific question of the benchmark, by UCI id."""
    result: dict[str, list[int]] = {
        k: []
        for k in (
            "missing_values",
            "mixed_types",
            "temporal",
            "stress_tiny",
            "stress_large",
            "stress_wide",
        )
    }
    for meta in pool:
        tags = strata(meta)
        uci_id = meta["uci_id"]
        for name, hit in (
            ("missing_values", tags["missing"]),
            ("mixed_types", tags["mixed_types"]),
            ("temporal", tags["time"]),
            ("XXstress_tinyXX", meta["num_instances"] <= 500),
            ("stress_large", meta["num_instances"] >= 200_000),
            ("stress_wide", meta["num_features"] >= 100),
        ):
            if hit:
                result[name].append(uci_id)
    return result


def x_panels__mutmut_32(pool) -> dict[str, list[int]]:
    """Sets that answer one specific question of the benchmark, by UCI id."""
    result: dict[str, list[int]] = {
        k: []
        for k in (
            "missing_values",
            "mixed_types",
            "temporal",
            "stress_tiny",
            "stress_large",
            "stress_wide",
        )
    }
    for meta in pool:
        tags = strata(meta)
        uci_id = meta["uci_id"]
        for name, hit in (
            ("missing_values", tags["missing"]),
            ("mixed_types", tags["mixed_types"]),
            ("temporal", tags["time"]),
            ("STRESS_TINY", meta["num_instances"] <= 500),
            ("stress_large", meta["num_instances"] >= 200_000),
            ("stress_wide", meta["num_features"] >= 100),
        ):
            if hit:
                result[name].append(uci_id)
    return result


def x_panels__mutmut_33(pool) -> dict[str, list[int]]:
    """Sets that answer one specific question of the benchmark, by UCI id."""
    result: dict[str, list[int]] = {
        k: []
        for k in (
            "missing_values",
            "mixed_types",
            "temporal",
            "stress_tiny",
            "stress_large",
            "stress_wide",
        )
    }
    for meta in pool:
        tags = strata(meta)
        uci_id = meta["uci_id"]
        for name, hit in (
            ("missing_values", tags["missing"]),
            ("mixed_types", tags["mixed_types"]),
            ("temporal", tags["time"]),
            ("stress_tiny", meta["XXnum_instancesXX"] <= 500),
            ("stress_large", meta["num_instances"] >= 200_000),
            ("stress_wide", meta["num_features"] >= 100),
        ):
            if hit:
                result[name].append(uci_id)
    return result


def x_panels__mutmut_34(pool) -> dict[str, list[int]]:
    """Sets that answer one specific question of the benchmark, by UCI id."""
    result: dict[str, list[int]] = {
        k: []
        for k in (
            "missing_values",
            "mixed_types",
            "temporal",
            "stress_tiny",
            "stress_large",
            "stress_wide",
        )
    }
    for meta in pool:
        tags = strata(meta)
        uci_id = meta["uci_id"]
        for name, hit in (
            ("missing_values", tags["missing"]),
            ("mixed_types", tags["mixed_types"]),
            ("temporal", tags["time"]),
            ("stress_tiny", meta["NUM_INSTANCES"] <= 500),
            ("stress_large", meta["num_instances"] >= 200_000),
            ("stress_wide", meta["num_features"] >= 100),
        ):
            if hit:
                result[name].append(uci_id)
    return result


def x_panels__mutmut_35(pool) -> dict[str, list[int]]:
    """Sets that answer one specific question of the benchmark, by UCI id."""
    result: dict[str, list[int]] = {
        k: []
        for k in (
            "missing_values",
            "mixed_types",
            "temporal",
            "stress_tiny",
            "stress_large",
            "stress_wide",
        )
    }
    for meta in pool:
        tags = strata(meta)
        uci_id = meta["uci_id"]
        for name, hit in (
            ("missing_values", tags["missing"]),
            ("mixed_types", tags["mixed_types"]),
            ("temporal", tags["time"]),
            ("stress_tiny", meta["num_instances"] < 500),
            ("stress_large", meta["num_instances"] >= 200_000),
            ("stress_wide", meta["num_features"] >= 100),
        ):
            if hit:
                result[name].append(uci_id)
    return result


def x_panels__mutmut_36(pool) -> dict[str, list[int]]:
    """Sets that answer one specific question of the benchmark, by UCI id."""
    result: dict[str, list[int]] = {
        k: []
        for k in (
            "missing_values",
            "mixed_types",
            "temporal",
            "stress_tiny",
            "stress_large",
            "stress_wide",
        )
    }
    for meta in pool:
        tags = strata(meta)
        uci_id = meta["uci_id"]
        for name, hit in (
            ("missing_values", tags["missing"]),
            ("mixed_types", tags["mixed_types"]),
            ("temporal", tags["time"]),
            ("stress_tiny", meta["num_instances"] <= 501),
            ("stress_large", meta["num_instances"] >= 200_000),
            ("stress_wide", meta["num_features"] >= 100),
        ):
            if hit:
                result[name].append(uci_id)
    return result


def x_panels__mutmut_37(pool) -> dict[str, list[int]]:
    """Sets that answer one specific question of the benchmark, by UCI id."""
    result: dict[str, list[int]] = {
        k: []
        for k in (
            "missing_values",
            "mixed_types",
            "temporal",
            "stress_tiny",
            "stress_large",
            "stress_wide",
        )
    }
    for meta in pool:
        tags = strata(meta)
        uci_id = meta["uci_id"]
        for name, hit in (
            ("missing_values", tags["missing"]),
            ("mixed_types", tags["mixed_types"]),
            ("temporal", tags["time"]),
            ("stress_tiny", meta["num_instances"] <= 500),
            ("XXstress_largeXX", meta["num_instances"] >= 200_000),
            ("stress_wide", meta["num_features"] >= 100),
        ):
            if hit:
                result[name].append(uci_id)
    return result


def x_panels__mutmut_38(pool) -> dict[str, list[int]]:
    """Sets that answer one specific question of the benchmark, by UCI id."""
    result: dict[str, list[int]] = {
        k: []
        for k in (
            "missing_values",
            "mixed_types",
            "temporal",
            "stress_tiny",
            "stress_large",
            "stress_wide",
        )
    }
    for meta in pool:
        tags = strata(meta)
        uci_id = meta["uci_id"]
        for name, hit in (
            ("missing_values", tags["missing"]),
            ("mixed_types", tags["mixed_types"]),
            ("temporal", tags["time"]),
            ("stress_tiny", meta["num_instances"] <= 500),
            ("STRESS_LARGE", meta["num_instances"] >= 200_000),
            ("stress_wide", meta["num_features"] >= 100),
        ):
            if hit:
                result[name].append(uci_id)
    return result


def x_panels__mutmut_39(pool) -> dict[str, list[int]]:
    """Sets that answer one specific question of the benchmark, by UCI id."""
    result: dict[str, list[int]] = {
        k: []
        for k in (
            "missing_values",
            "mixed_types",
            "temporal",
            "stress_tiny",
            "stress_large",
            "stress_wide",
        )
    }
    for meta in pool:
        tags = strata(meta)
        uci_id = meta["uci_id"]
        for name, hit in (
            ("missing_values", tags["missing"]),
            ("mixed_types", tags["mixed_types"]),
            ("temporal", tags["time"]),
            ("stress_tiny", meta["num_instances"] <= 500),
            ("stress_large", meta["XXnum_instancesXX"] >= 200_000),
            ("stress_wide", meta["num_features"] >= 100),
        ):
            if hit:
                result[name].append(uci_id)
    return result


def x_panels__mutmut_40(pool) -> dict[str, list[int]]:
    """Sets that answer one specific question of the benchmark, by UCI id."""
    result: dict[str, list[int]] = {
        k: []
        for k in (
            "missing_values",
            "mixed_types",
            "temporal",
            "stress_tiny",
            "stress_large",
            "stress_wide",
        )
    }
    for meta in pool:
        tags = strata(meta)
        uci_id = meta["uci_id"]
        for name, hit in (
            ("missing_values", tags["missing"]),
            ("mixed_types", tags["mixed_types"]),
            ("temporal", tags["time"]),
            ("stress_tiny", meta["num_instances"] <= 500),
            ("stress_large", meta["NUM_INSTANCES"] >= 200_000),
            ("stress_wide", meta["num_features"] >= 100),
        ):
            if hit:
                result[name].append(uci_id)
    return result


def x_panels__mutmut_41(pool) -> dict[str, list[int]]:
    """Sets that answer one specific question of the benchmark, by UCI id."""
    result: dict[str, list[int]] = {
        k: []
        for k in (
            "missing_values",
            "mixed_types",
            "temporal",
            "stress_tiny",
            "stress_large",
            "stress_wide",
        )
    }
    for meta in pool:
        tags = strata(meta)
        uci_id = meta["uci_id"]
        for name, hit in (
            ("missing_values", tags["missing"]),
            ("mixed_types", tags["mixed_types"]),
            ("temporal", tags["time"]),
            ("stress_tiny", meta["num_instances"] <= 500),
            ("stress_large", meta["num_instances"] > 200_000),
            ("stress_wide", meta["num_features"] >= 100),
        ):
            if hit:
                result[name].append(uci_id)
    return result


def x_panels__mutmut_42(pool) -> dict[str, list[int]]:
    """Sets that answer one specific question of the benchmark, by UCI id."""
    result: dict[str, list[int]] = {
        k: []
        for k in (
            "missing_values",
            "mixed_types",
            "temporal",
            "stress_tiny",
            "stress_large",
            "stress_wide",
        )
    }
    for meta in pool:
        tags = strata(meta)
        uci_id = meta["uci_id"]
        for name, hit in (
            ("missing_values", tags["missing"]),
            ("mixed_types", tags["mixed_types"]),
            ("temporal", tags["time"]),
            ("stress_tiny", meta["num_instances"] <= 500),
            ("stress_large", meta["num_instances"] >= 200001),
            ("stress_wide", meta["num_features"] >= 100),
        ):
            if hit:
                result[name].append(uci_id)
    return result


def x_panels__mutmut_43(pool) -> dict[str, list[int]]:
    """Sets that answer one specific question of the benchmark, by UCI id."""
    result: dict[str, list[int]] = {
        k: []
        for k in (
            "missing_values",
            "mixed_types",
            "temporal",
            "stress_tiny",
            "stress_large",
            "stress_wide",
        )
    }
    for meta in pool:
        tags = strata(meta)
        uci_id = meta["uci_id"]
        for name, hit in (
            ("missing_values", tags["missing"]),
            ("mixed_types", tags["mixed_types"]),
            ("temporal", tags["time"]),
            ("stress_tiny", meta["num_instances"] <= 500),
            ("stress_large", meta["num_instances"] >= 200_000),
            ("XXstress_wideXX", meta["num_features"] >= 100),
        ):
            if hit:
                result[name].append(uci_id)
    return result


def x_panels__mutmut_44(pool) -> dict[str, list[int]]:
    """Sets that answer one specific question of the benchmark, by UCI id."""
    result: dict[str, list[int]] = {
        k: []
        for k in (
            "missing_values",
            "mixed_types",
            "temporal",
            "stress_tiny",
            "stress_large",
            "stress_wide",
        )
    }
    for meta in pool:
        tags = strata(meta)
        uci_id = meta["uci_id"]
        for name, hit in (
            ("missing_values", tags["missing"]),
            ("mixed_types", tags["mixed_types"]),
            ("temporal", tags["time"]),
            ("stress_tiny", meta["num_instances"] <= 500),
            ("stress_large", meta["num_instances"] >= 200_000),
            ("STRESS_WIDE", meta["num_features"] >= 100),
        ):
            if hit:
                result[name].append(uci_id)
    return result


def x_panels__mutmut_45(pool) -> dict[str, list[int]]:
    """Sets that answer one specific question of the benchmark, by UCI id."""
    result: dict[str, list[int]] = {
        k: []
        for k in (
            "missing_values",
            "mixed_types",
            "temporal",
            "stress_tiny",
            "stress_large",
            "stress_wide",
        )
    }
    for meta in pool:
        tags = strata(meta)
        uci_id = meta["uci_id"]
        for name, hit in (
            ("missing_values", tags["missing"]),
            ("mixed_types", tags["mixed_types"]),
            ("temporal", tags["time"]),
            ("stress_tiny", meta["num_instances"] <= 500),
            ("stress_large", meta["num_instances"] >= 200_000),
            ("stress_wide", meta["XXnum_featuresXX"] >= 100),
        ):
            if hit:
                result[name].append(uci_id)
    return result


def x_panels__mutmut_46(pool) -> dict[str, list[int]]:
    """Sets that answer one specific question of the benchmark, by UCI id."""
    result: dict[str, list[int]] = {
        k: []
        for k in (
            "missing_values",
            "mixed_types",
            "temporal",
            "stress_tiny",
            "stress_large",
            "stress_wide",
        )
    }
    for meta in pool:
        tags = strata(meta)
        uci_id = meta["uci_id"]
        for name, hit in (
            ("missing_values", tags["missing"]),
            ("mixed_types", tags["mixed_types"]),
            ("temporal", tags["time"]),
            ("stress_tiny", meta["num_instances"] <= 500),
            ("stress_large", meta["num_instances"] >= 200_000),
            ("stress_wide", meta["NUM_FEATURES"] >= 100),
        ):
            if hit:
                result[name].append(uci_id)
    return result


def x_panels__mutmut_47(pool) -> dict[str, list[int]]:
    """Sets that answer one specific question of the benchmark, by UCI id."""
    result: dict[str, list[int]] = {
        k: []
        for k in (
            "missing_values",
            "mixed_types",
            "temporal",
            "stress_tiny",
            "stress_large",
            "stress_wide",
        )
    }
    for meta in pool:
        tags = strata(meta)
        uci_id = meta["uci_id"]
        for name, hit in (
            ("missing_values", tags["missing"]),
            ("mixed_types", tags["mixed_types"]),
            ("temporal", tags["time"]),
            ("stress_tiny", meta["num_instances"] <= 500),
            ("stress_large", meta["num_instances"] >= 200_000),
            ("stress_wide", meta["num_features"] > 100),
        ):
            if hit:
                result[name].append(uci_id)
    return result


def x_panels__mutmut_48(pool) -> dict[str, list[int]]:
    """Sets that answer one specific question of the benchmark, by UCI id."""
    result: dict[str, list[int]] = {
        k: []
        for k in (
            "missing_values",
            "mixed_types",
            "temporal",
            "stress_tiny",
            "stress_large",
            "stress_wide",
        )
    }
    for meta in pool:
        tags = strata(meta)
        uci_id = meta["uci_id"]
        for name, hit in (
            ("missing_values", tags["missing"]),
            ("mixed_types", tags["mixed_types"]),
            ("temporal", tags["time"]),
            ("stress_tiny", meta["num_instances"] <= 500),
            ("stress_large", meta["num_instances"] >= 200_000),
            ("stress_wide", meta["num_features"] >= 101),
        ):
            if hit:
                result[name].append(uci_id)
    return result


def x_panels__mutmut_49(pool) -> dict[str, list[int]]:
    """Sets that answer one specific question of the benchmark, by UCI id."""
    result: dict[str, list[int]] = {
        k: []
        for k in (
            "missing_values",
            "mixed_types",
            "temporal",
            "stress_tiny",
            "stress_large",
            "stress_wide",
        )
    }
    for meta in pool:
        tags = strata(meta)
        uci_id = meta["uci_id"]
        for name, hit in (
            ("missing_values", tags["missing"]),
            ("mixed_types", tags["mixed_types"]),
            ("temporal", tags["time"]),
            ("stress_tiny", meta["num_instances"] <= 500),
            ("stress_large", meta["num_instances"] >= 200_000),
            ("stress_wide", meta["num_features"] >= 100),
        ):
            if hit:
                result[name].append(None)
    return result

mutants_x_panels__mutmut['_mutmut_orig'] = x_panels__mutmut_orig # type: ignore # mutmut generated
mutants_x_panels__mutmut['x_panels__mutmut_1'] = x_panels__mutmut_1 # type: ignore # mutmut generated
mutants_x_panels__mutmut['x_panels__mutmut_2'] = x_panels__mutmut_2 # type: ignore # mutmut generated
mutants_x_panels__mutmut['x_panels__mutmut_3'] = x_panels__mutmut_3 # type: ignore # mutmut generated
mutants_x_panels__mutmut['x_panels__mutmut_4'] = x_panels__mutmut_4 # type: ignore # mutmut generated
mutants_x_panels__mutmut['x_panels__mutmut_5'] = x_panels__mutmut_5 # type: ignore # mutmut generated
mutants_x_panels__mutmut['x_panels__mutmut_6'] = x_panels__mutmut_6 # type: ignore # mutmut generated
mutants_x_panels__mutmut['x_panels__mutmut_7'] = x_panels__mutmut_7 # type: ignore # mutmut generated
mutants_x_panels__mutmut['x_panels__mutmut_8'] = x_panels__mutmut_8 # type: ignore # mutmut generated
mutants_x_panels__mutmut['x_panels__mutmut_9'] = x_panels__mutmut_9 # type: ignore # mutmut generated
mutants_x_panels__mutmut['x_panels__mutmut_10'] = x_panels__mutmut_10 # type: ignore # mutmut generated
mutants_x_panels__mutmut['x_panels__mutmut_11'] = x_panels__mutmut_11 # type: ignore # mutmut generated
mutants_x_panels__mutmut['x_panels__mutmut_12'] = x_panels__mutmut_12 # type: ignore # mutmut generated
mutants_x_panels__mutmut['x_panels__mutmut_13'] = x_panels__mutmut_13 # type: ignore # mutmut generated
mutants_x_panels__mutmut['x_panels__mutmut_14'] = x_panels__mutmut_14 # type: ignore # mutmut generated
mutants_x_panels__mutmut['x_panels__mutmut_15'] = x_panels__mutmut_15 # type: ignore # mutmut generated
mutants_x_panels__mutmut['x_panels__mutmut_16'] = x_panels__mutmut_16 # type: ignore # mutmut generated
mutants_x_panels__mutmut['x_panels__mutmut_17'] = x_panels__mutmut_17 # type: ignore # mutmut generated
mutants_x_panels__mutmut['x_panels__mutmut_18'] = x_panels__mutmut_18 # type: ignore # mutmut generated
mutants_x_panels__mutmut['x_panels__mutmut_19'] = x_panels__mutmut_19 # type: ignore # mutmut generated
mutants_x_panels__mutmut['x_panels__mutmut_20'] = x_panels__mutmut_20 # type: ignore # mutmut generated
mutants_x_panels__mutmut['x_panels__mutmut_21'] = x_panels__mutmut_21 # type: ignore # mutmut generated
mutants_x_panels__mutmut['x_panels__mutmut_22'] = x_panels__mutmut_22 # type: ignore # mutmut generated
mutants_x_panels__mutmut['x_panels__mutmut_23'] = x_panels__mutmut_23 # type: ignore # mutmut generated
mutants_x_panels__mutmut['x_panels__mutmut_24'] = x_panels__mutmut_24 # type: ignore # mutmut generated
mutants_x_panels__mutmut['x_panels__mutmut_25'] = x_panels__mutmut_25 # type: ignore # mutmut generated
mutants_x_panels__mutmut['x_panels__mutmut_26'] = x_panels__mutmut_26 # type: ignore # mutmut generated
mutants_x_panels__mutmut['x_panels__mutmut_27'] = x_panels__mutmut_27 # type: ignore # mutmut generated
mutants_x_panels__mutmut['x_panels__mutmut_28'] = x_panels__mutmut_28 # type: ignore # mutmut generated
mutants_x_panels__mutmut['x_panels__mutmut_29'] = x_panels__mutmut_29 # type: ignore # mutmut generated
mutants_x_panels__mutmut['x_panels__mutmut_30'] = x_panels__mutmut_30 # type: ignore # mutmut generated
mutants_x_panels__mutmut['x_panels__mutmut_31'] = x_panels__mutmut_31 # type: ignore # mutmut generated
mutants_x_panels__mutmut['x_panels__mutmut_32'] = x_panels__mutmut_32 # type: ignore # mutmut generated
mutants_x_panels__mutmut['x_panels__mutmut_33'] = x_panels__mutmut_33 # type: ignore # mutmut generated
mutants_x_panels__mutmut['x_panels__mutmut_34'] = x_panels__mutmut_34 # type: ignore # mutmut generated
mutants_x_panels__mutmut['x_panels__mutmut_35'] = x_panels__mutmut_35 # type: ignore # mutmut generated
mutants_x_panels__mutmut['x_panels__mutmut_36'] = x_panels__mutmut_36 # type: ignore # mutmut generated
mutants_x_panels__mutmut['x_panels__mutmut_37'] = x_panels__mutmut_37 # type: ignore # mutmut generated
mutants_x_panels__mutmut['x_panels__mutmut_38'] = x_panels__mutmut_38 # type: ignore # mutmut generated
mutants_x_panels__mutmut['x_panels__mutmut_39'] = x_panels__mutmut_39 # type: ignore # mutmut generated
mutants_x_panels__mutmut['x_panels__mutmut_40'] = x_panels__mutmut_40 # type: ignore # mutmut generated
mutants_x_panels__mutmut['x_panels__mutmut_41'] = x_panels__mutmut_41 # type: ignore # mutmut generated
mutants_x_panels__mutmut['x_panels__mutmut_42'] = x_panels__mutmut_42 # type: ignore # mutmut generated
mutants_x_panels__mutmut['x_panels__mutmut_43'] = x_panels__mutmut_43 # type: ignore # mutmut generated
mutants_x_panels__mutmut['x_panels__mutmut_44'] = x_panels__mutmut_44 # type: ignore # mutmut generated
mutants_x_panels__mutmut['x_panels__mutmut_45'] = x_panels__mutmut_45 # type: ignore # mutmut generated
mutants_x_panels__mutmut['x_panels__mutmut_46'] = x_panels__mutmut_46 # type: ignore # mutmut generated
mutants_x_panels__mutmut['x_panels__mutmut_47'] = x_panels__mutmut_47 # type: ignore # mutmut generated
mutants_x_panels__mutmut['x_panels__mutmut_48'] = x_panels__mutmut_48 # type: ignore # mutmut generated
mutants_x_panels__mutmut['x_panels__mutmut_49'] = x_panels__mutmut_49 # type: ignore # mutmut generated
mutants_x_crawl__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_crawl__mutmut)
def crawl(fetch: Callable[[str], str], sleep=time.sleep, delay: float = 0.3) -> dict[str, Any]:
    listing = json.loads(fetch(f"{API}/datasets/list"))["data"]
    datasets, failed = [], []
    for item in listing:
        try:
            datasets.append(json.loads(fetch(f"{API}/dataset?id={item['id']}"))["data"])
        except (OSError, ValueError, KeyError):
            failed.append(item["id"])
        sleep(delay)
    return {"datasets": datasets, "failed": failed}


def x_crawl__mutmut_orig(fetch: Callable[[str], str], sleep=time.sleep, delay: float = 0.3) -> dict[str, Any]:
    listing = json.loads(fetch(f"{API}/datasets/list"))["data"]
    datasets, failed = [], []
    for item in listing:
        try:
            datasets.append(json.loads(fetch(f"{API}/dataset?id={item['id']}"))["data"])
        except (OSError, ValueError, KeyError):
            failed.append(item["id"])
        sleep(delay)
    return {"datasets": datasets, "failed": failed}


def x_crawl__mutmut_1(fetch: Callable[[str], str], sleep=time.sleep, delay: float = 1.3) -> dict[str, Any]:
    listing = json.loads(fetch(f"{API}/datasets/list"))["data"]
    datasets, failed = [], []
    for item in listing:
        try:
            datasets.append(json.loads(fetch(f"{API}/dataset?id={item['id']}"))["data"])
        except (OSError, ValueError, KeyError):
            failed.append(item["id"])
        sleep(delay)
    return {"datasets": datasets, "failed": failed}


def x_crawl__mutmut_2(fetch: Callable[[str], str], sleep=time.sleep, delay: float = 0.3) -> dict[str, Any]:
    listing = None
    datasets, failed = [], []
    for item in listing:
        try:
            datasets.append(json.loads(fetch(f"{API}/dataset?id={item['id']}"))["data"])
        except (OSError, ValueError, KeyError):
            failed.append(item["id"])
        sleep(delay)
    return {"datasets": datasets, "failed": failed}


def x_crawl__mutmut_3(fetch: Callable[[str], str], sleep=time.sleep, delay: float = 0.3) -> dict[str, Any]:
    listing = json.loads(None)["data"]
    datasets, failed = [], []
    for item in listing:
        try:
            datasets.append(json.loads(fetch(f"{API}/dataset?id={item['id']}"))["data"])
        except (OSError, ValueError, KeyError):
            failed.append(item["id"])
        sleep(delay)
    return {"datasets": datasets, "failed": failed}


def x_crawl__mutmut_4(fetch: Callable[[str], str], sleep=time.sleep, delay: float = 0.3) -> dict[str, Any]:
    listing = json.loads(fetch(None))["data"]
    datasets, failed = [], []
    for item in listing:
        try:
            datasets.append(json.loads(fetch(f"{API}/dataset?id={item['id']}"))["data"])
        except (OSError, ValueError, KeyError):
            failed.append(item["id"])
        sleep(delay)
    return {"datasets": datasets, "failed": failed}


def x_crawl__mutmut_5(fetch: Callable[[str], str], sleep=time.sleep, delay: float = 0.3) -> dict[str, Any]:
    listing = json.loads(fetch(f"{API}/datasets/list"))["XXdataXX"]
    datasets, failed = [], []
    for item in listing:
        try:
            datasets.append(json.loads(fetch(f"{API}/dataset?id={item['id']}"))["data"])
        except (OSError, ValueError, KeyError):
            failed.append(item["id"])
        sleep(delay)
    return {"datasets": datasets, "failed": failed}


def x_crawl__mutmut_6(fetch: Callable[[str], str], sleep=time.sleep, delay: float = 0.3) -> dict[str, Any]:
    listing = json.loads(fetch(f"{API}/datasets/list"))["DATA"]
    datasets, failed = [], []
    for item in listing:
        try:
            datasets.append(json.loads(fetch(f"{API}/dataset?id={item['id']}"))["data"])
        except (OSError, ValueError, KeyError):
            failed.append(item["id"])
        sleep(delay)
    return {"datasets": datasets, "failed": failed}


def x_crawl__mutmut_7(fetch: Callable[[str], str], sleep=time.sleep, delay: float = 0.3) -> dict[str, Any]:
    listing = json.loads(fetch(f"{API}/datasets/list"))["data"]
    datasets, failed = None
    for item in listing:
        try:
            datasets.append(json.loads(fetch(f"{API}/dataset?id={item['id']}"))["data"])
        except (OSError, ValueError, KeyError):
            failed.append(item["id"])
        sleep(delay)
    return {"datasets": datasets, "failed": failed}


def x_crawl__mutmut_8(fetch: Callable[[str], str], sleep=time.sleep, delay: float = 0.3) -> dict[str, Any]:
    listing = json.loads(fetch(f"{API}/datasets/list"))["data"]
    datasets, failed = [], []
    for item in listing:
        try:
            datasets.append(None)
        except (OSError, ValueError, KeyError):
            failed.append(item["id"])
        sleep(delay)
    return {"datasets": datasets, "failed": failed}


def x_crawl__mutmut_9(fetch: Callable[[str], str], sleep=time.sleep, delay: float = 0.3) -> dict[str, Any]:
    listing = json.loads(fetch(f"{API}/datasets/list"))["data"]
    datasets, failed = [], []
    for item in listing:
        try:
            datasets.append(json.loads(None)["data"])
        except (OSError, ValueError, KeyError):
            failed.append(item["id"])
        sleep(delay)
    return {"datasets": datasets, "failed": failed}


def x_crawl__mutmut_10(fetch: Callable[[str], str], sleep=time.sleep, delay: float = 0.3) -> dict[str, Any]:
    listing = json.loads(fetch(f"{API}/datasets/list"))["data"]
    datasets, failed = [], []
    for item in listing:
        try:
            datasets.append(json.loads(fetch(None))["data"])
        except (OSError, ValueError, KeyError):
            failed.append(item["id"])
        sleep(delay)
    return {"datasets": datasets, "failed": failed}


def x_crawl__mutmut_11(fetch: Callable[[str], str], sleep=time.sleep, delay: float = 0.3) -> dict[str, Any]:
    listing = json.loads(fetch(f"{API}/datasets/list"))["data"]
    datasets, failed = [], []
    for item in listing:
        try:
            datasets.append(json.loads(fetch(f"{API}/dataset?id={item['XXidXX']}"))["data"])
        except (OSError, ValueError, KeyError):
            failed.append(item["id"])
        sleep(delay)
    return {"datasets": datasets, "failed": failed}


def x_crawl__mutmut_12(fetch: Callable[[str], str], sleep=time.sleep, delay: float = 0.3) -> dict[str, Any]:
    listing = json.loads(fetch(f"{API}/datasets/list"))["data"]
    datasets, failed = [], []
    for item in listing:
        try:
            datasets.append(json.loads(fetch(f"{API}/dataset?id={item['ID']}"))["data"])
        except (OSError, ValueError, KeyError):
            failed.append(item["id"])
        sleep(delay)
    return {"datasets": datasets, "failed": failed}


def x_crawl__mutmut_13(fetch: Callable[[str], str], sleep=time.sleep, delay: float = 0.3) -> dict[str, Any]:
    listing = json.loads(fetch(f"{API}/datasets/list"))["data"]
    datasets, failed = [], []
    for item in listing:
        try:
            datasets.append(json.loads(fetch(f"{API}/dataset?id={item['id']}"))["XXdataXX"])
        except (OSError, ValueError, KeyError):
            failed.append(item["id"])
        sleep(delay)
    return {"datasets": datasets, "failed": failed}


def x_crawl__mutmut_14(fetch: Callable[[str], str], sleep=time.sleep, delay: float = 0.3) -> dict[str, Any]:
    listing = json.loads(fetch(f"{API}/datasets/list"))["data"]
    datasets, failed = [], []
    for item in listing:
        try:
            datasets.append(json.loads(fetch(f"{API}/dataset?id={item['id']}"))["DATA"])
        except (OSError, ValueError, KeyError):
            failed.append(item["id"])
        sleep(delay)
    return {"datasets": datasets, "failed": failed}


def x_crawl__mutmut_15(fetch: Callable[[str], str], sleep=time.sleep, delay: float = 0.3) -> dict[str, Any]:
    listing = json.loads(fetch(f"{API}/datasets/list"))["data"]
    datasets, failed = [], []
    for item in listing:
        try:
            datasets.append(json.loads(fetch(f"{API}/dataset?id={item['id']}"))["data"])
        except (OSError, ValueError, KeyError):
            failed.append(None)
        sleep(delay)
    return {"datasets": datasets, "failed": failed}


def x_crawl__mutmut_16(fetch: Callable[[str], str], sleep=time.sleep, delay: float = 0.3) -> dict[str, Any]:
    listing = json.loads(fetch(f"{API}/datasets/list"))["data"]
    datasets, failed = [], []
    for item in listing:
        try:
            datasets.append(json.loads(fetch(f"{API}/dataset?id={item['id']}"))["data"])
        except (OSError, ValueError, KeyError):
            failed.append(item["XXidXX"])
        sleep(delay)
    return {"datasets": datasets, "failed": failed}


def x_crawl__mutmut_17(fetch: Callable[[str], str], sleep=time.sleep, delay: float = 0.3) -> dict[str, Any]:
    listing = json.loads(fetch(f"{API}/datasets/list"))["data"]
    datasets, failed = [], []
    for item in listing:
        try:
            datasets.append(json.loads(fetch(f"{API}/dataset?id={item['id']}"))["data"])
        except (OSError, ValueError, KeyError):
            failed.append(item["ID"])
        sleep(delay)
    return {"datasets": datasets, "failed": failed}


def x_crawl__mutmut_18(fetch: Callable[[str], str], sleep=time.sleep, delay: float = 0.3) -> dict[str, Any]:
    listing = json.loads(fetch(f"{API}/datasets/list"))["data"]
    datasets, failed = [], []
    for item in listing:
        try:
            datasets.append(json.loads(fetch(f"{API}/dataset?id={item['id']}"))["data"])
        except (OSError, ValueError, KeyError):
            failed.append(item["id"])
        sleep(None)
    return {"datasets": datasets, "failed": failed}


def x_crawl__mutmut_19(fetch: Callable[[str], str], sleep=time.sleep, delay: float = 0.3) -> dict[str, Any]:
    listing = json.loads(fetch(f"{API}/datasets/list"))["data"]
    datasets, failed = [], []
    for item in listing:
        try:
            datasets.append(json.loads(fetch(f"{API}/dataset?id={item['id']}"))["data"])
        except (OSError, ValueError, KeyError):
            failed.append(item["id"])
        sleep(delay)
    return {"XXdatasetsXX": datasets, "failed": failed}


def x_crawl__mutmut_20(fetch: Callable[[str], str], sleep=time.sleep, delay: float = 0.3) -> dict[str, Any]:
    listing = json.loads(fetch(f"{API}/datasets/list"))["data"]
    datasets, failed = [], []
    for item in listing:
        try:
            datasets.append(json.loads(fetch(f"{API}/dataset?id={item['id']}"))["data"])
        except (OSError, ValueError, KeyError):
            failed.append(item["id"])
        sleep(delay)
    return {"DATASETS": datasets, "failed": failed}


def x_crawl__mutmut_21(fetch: Callable[[str], str], sleep=time.sleep, delay: float = 0.3) -> dict[str, Any]:
    listing = json.loads(fetch(f"{API}/datasets/list"))["data"]
    datasets, failed = [], []
    for item in listing:
        try:
            datasets.append(json.loads(fetch(f"{API}/dataset?id={item['id']}"))["data"])
        except (OSError, ValueError, KeyError):
            failed.append(item["id"])
        sleep(delay)
    return {"datasets": datasets, "XXfailedXX": failed}


def x_crawl__mutmut_22(fetch: Callable[[str], str], sleep=time.sleep, delay: float = 0.3) -> dict[str, Any]:
    listing = json.loads(fetch(f"{API}/datasets/list"))["data"]
    datasets, failed = [], []
    for item in listing:
        try:
            datasets.append(json.loads(fetch(f"{API}/dataset?id={item['id']}"))["data"])
        except (OSError, ValueError, KeyError):
            failed.append(item["id"])
        sleep(delay)
    return {"datasets": datasets, "FAILED": failed}

mutants_x_crawl__mutmut['_mutmut_orig'] = x_crawl__mutmut_orig # type: ignore # mutmut generated
mutants_x_crawl__mutmut['x_crawl__mutmut_1'] = x_crawl__mutmut_1 # type: ignore # mutmut generated
mutants_x_crawl__mutmut['x_crawl__mutmut_2'] = x_crawl__mutmut_2 # type: ignore # mutmut generated
mutants_x_crawl__mutmut['x_crawl__mutmut_3'] = x_crawl__mutmut_3 # type: ignore # mutmut generated
mutants_x_crawl__mutmut['x_crawl__mutmut_4'] = x_crawl__mutmut_4 # type: ignore # mutmut generated
mutants_x_crawl__mutmut['x_crawl__mutmut_5'] = x_crawl__mutmut_5 # type: ignore # mutmut generated
mutants_x_crawl__mutmut['x_crawl__mutmut_6'] = x_crawl__mutmut_6 # type: ignore # mutmut generated
mutants_x_crawl__mutmut['x_crawl__mutmut_7'] = x_crawl__mutmut_7 # type: ignore # mutmut generated
mutants_x_crawl__mutmut['x_crawl__mutmut_8'] = x_crawl__mutmut_8 # type: ignore # mutmut generated
mutants_x_crawl__mutmut['x_crawl__mutmut_9'] = x_crawl__mutmut_9 # type: ignore # mutmut generated
mutants_x_crawl__mutmut['x_crawl__mutmut_10'] = x_crawl__mutmut_10 # type: ignore # mutmut generated
mutants_x_crawl__mutmut['x_crawl__mutmut_11'] = x_crawl__mutmut_11 # type: ignore # mutmut generated
mutants_x_crawl__mutmut['x_crawl__mutmut_12'] = x_crawl__mutmut_12 # type: ignore # mutmut generated
mutants_x_crawl__mutmut['x_crawl__mutmut_13'] = x_crawl__mutmut_13 # type: ignore # mutmut generated
mutants_x_crawl__mutmut['x_crawl__mutmut_14'] = x_crawl__mutmut_14 # type: ignore # mutmut generated
mutants_x_crawl__mutmut['x_crawl__mutmut_15'] = x_crawl__mutmut_15 # type: ignore # mutmut generated
mutants_x_crawl__mutmut['x_crawl__mutmut_16'] = x_crawl__mutmut_16 # type: ignore # mutmut generated
mutants_x_crawl__mutmut['x_crawl__mutmut_17'] = x_crawl__mutmut_17 # type: ignore # mutmut generated
mutants_x_crawl__mutmut['x_crawl__mutmut_18'] = x_crawl__mutmut_18 # type: ignore # mutmut generated
mutants_x_crawl__mutmut['x_crawl__mutmut_19'] = x_crawl__mutmut_19 # type: ignore # mutmut generated
mutants_x_crawl__mutmut['x_crawl__mutmut_20'] = x_crawl__mutmut_20 # type: ignore # mutmut generated
mutants_x_crawl__mutmut['x_crawl__mutmut_21'] = x_crawl__mutmut_21 # type: ignore # mutmut generated
mutants_x_crawl__mutmut['x_crawl__mutmut_22'] = x_crawl__mutmut_22 # type: ignore # mutmut generated
mutants_x_balance_report__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_balance_report__mutmut)
def balance_report(chosen) -> dict[str, Any]:
    tags = [strata(m) for m in chosen]
    report: dict[str, Any] = {"total": len(chosen)}
    for key in ("size", "dim", "missing", "mixed_types", "time", "domain"):
        report[key] = dict(Counter(t[key] for t in tags))
    return report


def x_balance_report__mutmut_orig(chosen) -> dict[str, Any]:
    tags = [strata(m) for m in chosen]
    report: dict[str, Any] = {"total": len(chosen)}
    for key in ("size", "dim", "missing", "mixed_types", "time", "domain"):
        report[key] = dict(Counter(t[key] for t in tags))
    return report


def x_balance_report__mutmut_1(chosen) -> dict[str, Any]:
    tags = None
    report: dict[str, Any] = {"total": len(chosen)}
    for key in ("size", "dim", "missing", "mixed_types", "time", "domain"):
        report[key] = dict(Counter(t[key] for t in tags))
    return report


def x_balance_report__mutmut_2(chosen) -> dict[str, Any]:
    tags = [strata(None) for m in chosen]
    report: dict[str, Any] = {"total": len(chosen)}
    for key in ("size", "dim", "missing", "mixed_types", "time", "domain"):
        report[key] = dict(Counter(t[key] for t in tags))
    return report


def x_balance_report__mutmut_3(chosen) -> dict[str, Any]:
    tags = [strata(m) for m in chosen]
    report: dict[str, Any] = None
    for key in ("size", "dim", "missing", "mixed_types", "time", "domain"):
        report[key] = dict(Counter(t[key] for t in tags))
    return report


def x_balance_report__mutmut_4(chosen) -> dict[str, Any]:
    tags = [strata(m) for m in chosen]
    report: dict[str, Any] = {"XXtotalXX": len(chosen)}
    for key in ("size", "dim", "missing", "mixed_types", "time", "domain"):
        report[key] = dict(Counter(t[key] for t in tags))
    return report


def x_balance_report__mutmut_5(chosen) -> dict[str, Any]:
    tags = [strata(m) for m in chosen]
    report: dict[str, Any] = {"TOTAL": len(chosen)}
    for key in ("size", "dim", "missing", "mixed_types", "time", "domain"):
        report[key] = dict(Counter(t[key] for t in tags))
    return report


def x_balance_report__mutmut_6(chosen) -> dict[str, Any]:
    tags = [strata(m) for m in chosen]
    report: dict[str, Any] = {"total": len(chosen)}
    for key in ("XXsizeXX", "dim", "missing", "mixed_types", "time", "domain"):
        report[key] = dict(Counter(t[key] for t in tags))
    return report


def x_balance_report__mutmut_7(chosen) -> dict[str, Any]:
    tags = [strata(m) for m in chosen]
    report: dict[str, Any] = {"total": len(chosen)}
    for key in ("SIZE", "dim", "missing", "mixed_types", "time", "domain"):
        report[key] = dict(Counter(t[key] for t in tags))
    return report


def x_balance_report__mutmut_8(chosen) -> dict[str, Any]:
    tags = [strata(m) for m in chosen]
    report: dict[str, Any] = {"total": len(chosen)}
    for key in ("size", "XXdimXX", "missing", "mixed_types", "time", "domain"):
        report[key] = dict(Counter(t[key] for t in tags))
    return report


def x_balance_report__mutmut_9(chosen) -> dict[str, Any]:
    tags = [strata(m) for m in chosen]
    report: dict[str, Any] = {"total": len(chosen)}
    for key in ("size", "DIM", "missing", "mixed_types", "time", "domain"):
        report[key] = dict(Counter(t[key] for t in tags))
    return report


def x_balance_report__mutmut_10(chosen) -> dict[str, Any]:
    tags = [strata(m) for m in chosen]
    report: dict[str, Any] = {"total": len(chosen)}
    for key in ("size", "dim", "XXmissingXX", "mixed_types", "time", "domain"):
        report[key] = dict(Counter(t[key] for t in tags))
    return report


def x_balance_report__mutmut_11(chosen) -> dict[str, Any]:
    tags = [strata(m) for m in chosen]
    report: dict[str, Any] = {"total": len(chosen)}
    for key in ("size", "dim", "MISSING", "mixed_types", "time", "domain"):
        report[key] = dict(Counter(t[key] for t in tags))
    return report


def x_balance_report__mutmut_12(chosen) -> dict[str, Any]:
    tags = [strata(m) for m in chosen]
    report: dict[str, Any] = {"total": len(chosen)}
    for key in ("size", "dim", "missing", "XXmixed_typesXX", "time", "domain"):
        report[key] = dict(Counter(t[key] for t in tags))
    return report


def x_balance_report__mutmut_13(chosen) -> dict[str, Any]:
    tags = [strata(m) for m in chosen]
    report: dict[str, Any] = {"total": len(chosen)}
    for key in ("size", "dim", "missing", "MIXED_TYPES", "time", "domain"):
        report[key] = dict(Counter(t[key] for t in tags))
    return report


def x_balance_report__mutmut_14(chosen) -> dict[str, Any]:
    tags = [strata(m) for m in chosen]
    report: dict[str, Any] = {"total": len(chosen)}
    for key in ("size", "dim", "missing", "mixed_types", "XXtimeXX", "domain"):
        report[key] = dict(Counter(t[key] for t in tags))
    return report


def x_balance_report__mutmut_15(chosen) -> dict[str, Any]:
    tags = [strata(m) for m in chosen]
    report: dict[str, Any] = {"total": len(chosen)}
    for key in ("size", "dim", "missing", "mixed_types", "TIME", "domain"):
        report[key] = dict(Counter(t[key] for t in tags))
    return report


def x_balance_report__mutmut_16(chosen) -> dict[str, Any]:
    tags = [strata(m) for m in chosen]
    report: dict[str, Any] = {"total": len(chosen)}
    for key in ("size", "dim", "missing", "mixed_types", "time", "XXdomainXX"):
        report[key] = dict(Counter(t[key] for t in tags))
    return report


def x_balance_report__mutmut_17(chosen) -> dict[str, Any]:
    tags = [strata(m) for m in chosen]
    report: dict[str, Any] = {"total": len(chosen)}
    for key in ("size", "dim", "missing", "mixed_types", "time", "DOMAIN"):
        report[key] = dict(Counter(t[key] for t in tags))
    return report


def x_balance_report__mutmut_18(chosen) -> dict[str, Any]:
    tags = [strata(m) for m in chosen]
    report: dict[str, Any] = {"total": len(chosen)}
    for key in ("size", "dim", "missing", "mixed_types", "time", "domain"):
        report[key] = None
    return report


def x_balance_report__mutmut_19(chosen) -> dict[str, Any]:
    tags = [strata(m) for m in chosen]
    report: dict[str, Any] = {"total": len(chosen)}
    for key in ("size", "dim", "missing", "mixed_types", "time", "domain"):
        report[key] = dict(None)
    return report


def x_balance_report__mutmut_20(chosen) -> dict[str, Any]:
    tags = [strata(m) for m in chosen]
    report: dict[str, Any] = {"total": len(chosen)}
    for key in ("size", "dim", "missing", "mixed_types", "time", "domain"):
        report[key] = dict(Counter(None))
    return report

mutants_x_balance_report__mutmut['_mutmut_orig'] = x_balance_report__mutmut_orig # type: ignore # mutmut generated
mutants_x_balance_report__mutmut['x_balance_report__mutmut_1'] = x_balance_report__mutmut_1 # type: ignore # mutmut generated
mutants_x_balance_report__mutmut['x_balance_report__mutmut_2'] = x_balance_report__mutmut_2 # type: ignore # mutmut generated
mutants_x_balance_report__mutmut['x_balance_report__mutmut_3'] = x_balance_report__mutmut_3 # type: ignore # mutmut generated
mutants_x_balance_report__mutmut['x_balance_report__mutmut_4'] = x_balance_report__mutmut_4 # type: ignore # mutmut generated
mutants_x_balance_report__mutmut['x_balance_report__mutmut_5'] = x_balance_report__mutmut_5 # type: ignore # mutmut generated
mutants_x_balance_report__mutmut['x_balance_report__mutmut_6'] = x_balance_report__mutmut_6 # type: ignore # mutmut generated
mutants_x_balance_report__mutmut['x_balance_report__mutmut_7'] = x_balance_report__mutmut_7 # type: ignore # mutmut generated
mutants_x_balance_report__mutmut['x_balance_report__mutmut_8'] = x_balance_report__mutmut_8 # type: ignore # mutmut generated
mutants_x_balance_report__mutmut['x_balance_report__mutmut_9'] = x_balance_report__mutmut_9 # type: ignore # mutmut generated
mutants_x_balance_report__mutmut['x_balance_report__mutmut_10'] = x_balance_report__mutmut_10 # type: ignore # mutmut generated
mutants_x_balance_report__mutmut['x_balance_report__mutmut_11'] = x_balance_report__mutmut_11 # type: ignore # mutmut generated
mutants_x_balance_report__mutmut['x_balance_report__mutmut_12'] = x_balance_report__mutmut_12 # type: ignore # mutmut generated
mutants_x_balance_report__mutmut['x_balance_report__mutmut_13'] = x_balance_report__mutmut_13 # type: ignore # mutmut generated
mutants_x_balance_report__mutmut['x_balance_report__mutmut_14'] = x_balance_report__mutmut_14 # type: ignore # mutmut generated
mutants_x_balance_report__mutmut['x_balance_report__mutmut_15'] = x_balance_report__mutmut_15 # type: ignore # mutmut generated
mutants_x_balance_report__mutmut['x_balance_report__mutmut_16'] = x_balance_report__mutmut_16 # type: ignore # mutmut generated
mutants_x_balance_report__mutmut['x_balance_report__mutmut_17'] = x_balance_report__mutmut_17 # type: ignore # mutmut generated
mutants_x_balance_report__mutmut['x_balance_report__mutmut_18'] = x_balance_report__mutmut_18 # type: ignore # mutmut generated
mutants_x_balance_report__mutmut['x_balance_report__mutmut_19'] = x_balance_report__mutmut_19 # type: ignore # mutmut generated
mutants_x_balance_report__mutmut['x_balance_report__mutmut_20'] = x_balance_report__mutmut_20 # type: ignore # mutmut generated
mutants_x_main__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_main__mutmut)
def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_orig(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_1(argv: list[str] | None = None) -> int:
    parser = None
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_2(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=None)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_3(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(None, type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_4(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=None, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_5(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help=None)
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_6(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_7(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_8(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, )
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_9(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("XX--surveyXX", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_10(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--SURVEY", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_11(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="XXcrawl the catalogue metadata to this fileXX")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_12(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="CRAWL THE CATALOGUE METADATA TO THIS FILE")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_13(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument(None, type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_14(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=None, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_15(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help=None)
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_16(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument(type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_17(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_18(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, )
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_19(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("XX--selectXX", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_20(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--SELECT", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_21(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="XXsurvey file to filterXX")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_22(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="SURVEY FILE TO FILTER")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_23(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument(None, type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_24(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=None, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_25(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help=None)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_26(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument(type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_27(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_28(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_29(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("XX--curateXX", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_30(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--CURATE", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_31(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="XXselection file to curate and split in panelsXX")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_32(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="SELECTION FILE TO CURATE AND SPLIT IN PANELS")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_33(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument(None, type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_34(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=None, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_35(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=None)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_36(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument(type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_37(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_38(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_39(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("XX--outputXX", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_40(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--OUTPUT", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_41(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=False)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_42(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = None
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_43(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(None)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_44(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = None
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_45(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(None)["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_46(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["XXchosenXX"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_47(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["CHOSEN"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_48(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = None
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_49(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(None)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_50(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = None
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_51(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "XXkeptXX": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_52(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "KEPT": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_53(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "XXdroppedXX": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_54(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "DROPPED": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_55(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"XXuci_idXX": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_56(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"UCI_ID": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_57(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["XXuci_idXX"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_58(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["UCI_ID"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_59(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "XXnameXX": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_60(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "NAME": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_61(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["XXnameXX"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_62(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["NAME"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_63(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "XXreasonXX": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_64(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "REASON": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_65(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "XXpanelsXX": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_66(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "PANELS": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_67(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(None),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_68(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "XXreportXX": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_69(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "REPORT": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_70(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(None),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_71(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(None) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_72(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(None)
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_73(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) - "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_74(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(None, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_75(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=None, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_76(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=None) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_77(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_78(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_79(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, ) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_80(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=2, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_81(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=False) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_82(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "XX\nXX")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_83(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(None)
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_84(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 1

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_85(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = None
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_86(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(None)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_87(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(None) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_88(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(None)
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_89(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) - "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_90(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(None, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_91(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=None, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_92(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=None) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_93(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_94(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_95(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, ) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_96(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_97(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=False) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_98(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "XX\nXX")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_99(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(None)
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_100(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 1
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_101(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = None
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_102(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(None)["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_103(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["XXdatasetsXX"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_104(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["DATASETS"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_105(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = None
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_106(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(None) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_107(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is not None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_108(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = None
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_109(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = None
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_110(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(None)
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_111(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["XXrepository_urlXX"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_112(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["REPOSITORY_URL"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_113(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = None
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_114(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["XXuci_idXX"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_115(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["UCI_ID"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_116(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(None), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_117(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "XXurlXX": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_118(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "URL": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_119(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["XXrepository_urlXX"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_120(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["REPOSITORY_URL"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_121(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(None)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_122(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(1.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_123(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = None
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_124(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(None, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_125(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, None)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_126(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_127(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, )
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_128(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = None
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_129(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "XXcheckedXX": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_130(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "CHECKED": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_131(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime(None),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_132(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("XX%Y-%m-%dXX"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_133(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_134(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%M-%D"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_135(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "XXchosenXX": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_136(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "CHOSEN": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_137(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "XXlicenceXX": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_138(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "LICENCE": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_139(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["XXuci_idXX"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_140(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["UCI_ID"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_141(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["XXlicenceXX"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_142(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["LICENCE"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_143(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "XXstrataXX": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_144(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "STRATA": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_145(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(None)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_146(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "XXrejectedXX": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_147(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "REJECTED": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_148(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"XXuci_idXX": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_149(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"UCI_ID": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_150(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["XXuci_idXX"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_151(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["UCI_ID"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_152(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "XXnameXX": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_153(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "NAME": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_154(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["XXnameXX"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_155(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["NAME"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_156(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "XXreasonXX": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_157(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "REASON": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_158(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "XXreportXX": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_159(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "REPORT": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_160(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(None),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_161(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(None) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_162(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(None)
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_163(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) - "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_164(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(None, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_165(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=None, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_166(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=None) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_167(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_168(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_169(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, ) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_170(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=2, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_171(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=False) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_172(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "XX\nXX")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 0


def x_main__mutmut_173(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(None)
    return 0


def x_main__mutmut_174(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--survey", type=Path, help="crawl the catalogue metadata to this file")
    parser.add_argument("--select", type=Path, help="survey file to filter")
    parser.add_argument("--curate", type=Path, help="selection file to curate and split in panels")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    if args.curate:
        chosen = json.loads(args.curate.read_text())["chosen"]
        kept, dropped = curate(chosen)
        out = {
            "kept": kept,
            "dropped": [
                {"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in dropped
            ],
            "panels": panels(kept),
            "report": balance_report(kept),
        }
        with atomic_path(args.output) as partial:
            partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
        print(f"kept {len(kept)}, dropped {len(dropped)}")
        return 0

    if args.survey:
        result = crawl(dr._text)
        with atomic_path(args.survey) as partial:
            partial.write_text(json.dumps(result, indent=1, sort_keys=True) + "\n")
        print(f"surveyed {len(result['datasets'])} datasets, {len(result['failed'])} failed")
        return 0
    survey = json.loads(args.select.read_text())["datasets"]
    candidates = [m for m in survey if rejection(m) is None]
    licences = {}
    for meta in candidates:
        page = dr._text(meta["repository_url"])
        licences[meta["uci_id"]] = {**dr.uci_licence(page), "url": meta["repository_url"]}
        time.sleep(0.3)
    chosen, rejected = select(survey, licences)
    out = {
        "checked": time.strftime("%Y-%m-%d"),
        "chosen": [
            {**m, "licence": licences[m["uci_id"]]["licence"], "strata": strata(m)} for m in chosen
        ],
        "rejected": [{"uci_id": m["uci_id"], "name": m["name"], "reason": r} for m, r in rejected],
        "report": balance_report(chosen),
    }
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"chosen {len(chosen)}, rejected {len(rejected)}")
    return 1

mutants_x_main__mutmut['_mutmut_orig'] = x_main__mutmut_orig # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_1'] = x_main__mutmut_1 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_2'] = x_main__mutmut_2 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_3'] = x_main__mutmut_3 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_4'] = x_main__mutmut_4 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_5'] = x_main__mutmut_5 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_6'] = x_main__mutmut_6 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_7'] = x_main__mutmut_7 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_8'] = x_main__mutmut_8 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_9'] = x_main__mutmut_9 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_10'] = x_main__mutmut_10 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_11'] = x_main__mutmut_11 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_12'] = x_main__mutmut_12 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_13'] = x_main__mutmut_13 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_14'] = x_main__mutmut_14 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_15'] = x_main__mutmut_15 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_16'] = x_main__mutmut_16 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_17'] = x_main__mutmut_17 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_18'] = x_main__mutmut_18 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_19'] = x_main__mutmut_19 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_20'] = x_main__mutmut_20 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_21'] = x_main__mutmut_21 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_22'] = x_main__mutmut_22 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_23'] = x_main__mutmut_23 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_24'] = x_main__mutmut_24 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_25'] = x_main__mutmut_25 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_26'] = x_main__mutmut_26 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_27'] = x_main__mutmut_27 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_28'] = x_main__mutmut_28 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_29'] = x_main__mutmut_29 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_30'] = x_main__mutmut_30 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_31'] = x_main__mutmut_31 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_32'] = x_main__mutmut_32 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_33'] = x_main__mutmut_33 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_34'] = x_main__mutmut_34 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_35'] = x_main__mutmut_35 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_36'] = x_main__mutmut_36 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_37'] = x_main__mutmut_37 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_38'] = x_main__mutmut_38 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_39'] = x_main__mutmut_39 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_40'] = x_main__mutmut_40 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_41'] = x_main__mutmut_41 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_42'] = x_main__mutmut_42 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_43'] = x_main__mutmut_43 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_44'] = x_main__mutmut_44 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_45'] = x_main__mutmut_45 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_46'] = x_main__mutmut_46 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_47'] = x_main__mutmut_47 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_48'] = x_main__mutmut_48 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_49'] = x_main__mutmut_49 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_50'] = x_main__mutmut_50 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_51'] = x_main__mutmut_51 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_52'] = x_main__mutmut_52 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_53'] = x_main__mutmut_53 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_54'] = x_main__mutmut_54 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_55'] = x_main__mutmut_55 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_56'] = x_main__mutmut_56 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_57'] = x_main__mutmut_57 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_58'] = x_main__mutmut_58 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_59'] = x_main__mutmut_59 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_60'] = x_main__mutmut_60 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_61'] = x_main__mutmut_61 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_62'] = x_main__mutmut_62 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_63'] = x_main__mutmut_63 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_64'] = x_main__mutmut_64 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_65'] = x_main__mutmut_65 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_66'] = x_main__mutmut_66 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_67'] = x_main__mutmut_67 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_68'] = x_main__mutmut_68 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_69'] = x_main__mutmut_69 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_70'] = x_main__mutmut_70 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_71'] = x_main__mutmut_71 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_72'] = x_main__mutmut_72 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_73'] = x_main__mutmut_73 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_74'] = x_main__mutmut_74 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_75'] = x_main__mutmut_75 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_76'] = x_main__mutmut_76 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_77'] = x_main__mutmut_77 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_78'] = x_main__mutmut_78 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_79'] = x_main__mutmut_79 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_80'] = x_main__mutmut_80 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_81'] = x_main__mutmut_81 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_82'] = x_main__mutmut_82 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_83'] = x_main__mutmut_83 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_84'] = x_main__mutmut_84 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_85'] = x_main__mutmut_85 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_86'] = x_main__mutmut_86 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_87'] = x_main__mutmut_87 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_88'] = x_main__mutmut_88 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_89'] = x_main__mutmut_89 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_90'] = x_main__mutmut_90 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_91'] = x_main__mutmut_91 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_92'] = x_main__mutmut_92 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_93'] = x_main__mutmut_93 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_94'] = x_main__mutmut_94 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_95'] = x_main__mutmut_95 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_96'] = x_main__mutmut_96 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_97'] = x_main__mutmut_97 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_98'] = x_main__mutmut_98 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_99'] = x_main__mutmut_99 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_100'] = x_main__mutmut_100 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_101'] = x_main__mutmut_101 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_102'] = x_main__mutmut_102 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_103'] = x_main__mutmut_103 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_104'] = x_main__mutmut_104 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_105'] = x_main__mutmut_105 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_106'] = x_main__mutmut_106 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_107'] = x_main__mutmut_107 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_108'] = x_main__mutmut_108 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_109'] = x_main__mutmut_109 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_110'] = x_main__mutmut_110 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_111'] = x_main__mutmut_111 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_112'] = x_main__mutmut_112 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_113'] = x_main__mutmut_113 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_114'] = x_main__mutmut_114 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_115'] = x_main__mutmut_115 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_116'] = x_main__mutmut_116 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_117'] = x_main__mutmut_117 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_118'] = x_main__mutmut_118 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_119'] = x_main__mutmut_119 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_120'] = x_main__mutmut_120 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_121'] = x_main__mutmut_121 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_122'] = x_main__mutmut_122 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_123'] = x_main__mutmut_123 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_124'] = x_main__mutmut_124 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_125'] = x_main__mutmut_125 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_126'] = x_main__mutmut_126 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_127'] = x_main__mutmut_127 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_128'] = x_main__mutmut_128 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_129'] = x_main__mutmut_129 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_130'] = x_main__mutmut_130 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_131'] = x_main__mutmut_131 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_132'] = x_main__mutmut_132 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_133'] = x_main__mutmut_133 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_134'] = x_main__mutmut_134 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_135'] = x_main__mutmut_135 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_136'] = x_main__mutmut_136 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_137'] = x_main__mutmut_137 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_138'] = x_main__mutmut_138 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_139'] = x_main__mutmut_139 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_140'] = x_main__mutmut_140 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_141'] = x_main__mutmut_141 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_142'] = x_main__mutmut_142 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_143'] = x_main__mutmut_143 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_144'] = x_main__mutmut_144 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_145'] = x_main__mutmut_145 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_146'] = x_main__mutmut_146 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_147'] = x_main__mutmut_147 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_148'] = x_main__mutmut_148 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_149'] = x_main__mutmut_149 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_150'] = x_main__mutmut_150 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_151'] = x_main__mutmut_151 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_152'] = x_main__mutmut_152 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_153'] = x_main__mutmut_153 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_154'] = x_main__mutmut_154 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_155'] = x_main__mutmut_155 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_156'] = x_main__mutmut_156 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_157'] = x_main__mutmut_157 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_158'] = x_main__mutmut_158 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_159'] = x_main__mutmut_159 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_160'] = x_main__mutmut_160 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_161'] = x_main__mutmut_161 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_162'] = x_main__mutmut_162 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_163'] = x_main__mutmut_163 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_164'] = x_main__mutmut_164 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_165'] = x_main__mutmut_165 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_166'] = x_main__mutmut_166 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_167'] = x_main__mutmut_167 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_168'] = x_main__mutmut_168 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_169'] = x_main__mutmut_169 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_170'] = x_main__mutmut_170 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_171'] = x_main__mutmut_171 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_172'] = x_main__mutmut_172 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_173'] = x_main__mutmut_173 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_174'] = x_main__mutmut_174 # type: ignore # mutmut generated


if __name__ == "__main__":
    raise SystemExit(main())
