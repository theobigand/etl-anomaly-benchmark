"""LaTeX rows of the four benchmark tables of the paper, written from the archived results.

The classical rows come from the archived benchmark files, the neural rows from the runs of
``full_registry.py``. The paper keeps the rows of every table in registry order, so that no
number is typed by hand.
"""

from __future__ import annotations

import argparse
import json
import re
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
EVIDENCE = ROOT / "verification" / "evidence"
NAMES = {
    "zscore": "Z-score",
    "iqr": "IQR",
    "great_expectations": "Great Expectations",
    "isolation_forest": "Isolation Forest",
    "lof": "LOF",
    "ocsvm": "One-Class SVM",
    "ecod": "ECOD",
    "copod": "COPOD",
    "hbos": "HBOS",
    "knn": "KNN",
    "pca": "PCA",
    "autoencoder": "Autoencoder",
    "vae": "VAE",
    "deep_svdd": "Deep SVDD",
    "dif": "DIF",
    "ae1svm": "AE1SVM",
    "lunar": "LUNAR",
}
CLASSICAL = list(NAMES)[:11]
NEURAL = list(NAMES)[11:]
#: label -> (archive, neural source, columns, decimals of the metrics, other decimals)
TABLES = {
    "fraud": ("benchmark_credit_card.csv", "real_credit_card.json", 3),
    "cardio": ("benchmark_cardio.csv", "real_cardio.json", 2),
    "water": ("benchmark_water_quality.csv", "real_water_quality.json", 2),
    "synthetic": ("synthetic_metrics.csv", "synthetic", 3),
}
COLUMNS = {
    "fraud": ["precision", "recall", "f1", "roc_auc", "pr_auc", "flagged_pct", "detect_s"],
    "cardio": ["precision", "recall", "f1", "roc_auc", "pr_auc", "flagged_pct"],
    "water": ["precision", "recall", "f1", "roc_auc", "pr_auc", "flagged_pct"],
    "synthetic": ["precision", "recall", "f1", "roc_auc", "pr_auc", "detect_s"],
}
HIGHER_IS_BETTER = {"precision", "recall", "f1", "roc_auc", "pr_auc"}
LOWER_IS_BETTER = {"detect_s"}
TIME_DECIMALS = {"fraud": 2, "synthetic": 3}


from mutmut.mutation.trampoline import wrap_in_trampoline as _mutmut_mutated, MutantDict
mutants_x_classical_means__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_classical_means__mutmut)
def classical_means(label: str, evidence: Path) -> pd.DataFrame:
    archive = TABLES[label][0]
    index = "method" if label == "synthetic" else "detector"
    frame = pd.read_csv(evidence / archive).set_index(index)
    return frame[[f"{c}_mean" for c in COLUMNS[label]]].set_axis(COLUMNS[label], axis=1)


def x_classical_means__mutmut_orig(label: str, evidence: Path) -> pd.DataFrame:
    archive = TABLES[label][0]
    index = "method" if label == "synthetic" else "detector"
    frame = pd.read_csv(evidence / archive).set_index(index)
    return frame[[f"{c}_mean" for c in COLUMNS[label]]].set_axis(COLUMNS[label], axis=1)


def x_classical_means__mutmut_1(label: str, evidence: Path) -> pd.DataFrame:
    archive = None
    index = "method" if label == "synthetic" else "detector"
    frame = pd.read_csv(evidence / archive).set_index(index)
    return frame[[f"{c}_mean" for c in COLUMNS[label]]].set_axis(COLUMNS[label], axis=1)


def x_classical_means__mutmut_2(label: str, evidence: Path) -> pd.DataFrame:
    archive = TABLES[label][1]
    index = "method" if label == "synthetic" else "detector"
    frame = pd.read_csv(evidence / archive).set_index(index)
    return frame[[f"{c}_mean" for c in COLUMNS[label]]].set_axis(COLUMNS[label], axis=1)


def x_classical_means__mutmut_3(label: str, evidence: Path) -> pd.DataFrame:
    archive = TABLES[label][0]
    index = None
    frame = pd.read_csv(evidence / archive).set_index(index)
    return frame[[f"{c}_mean" for c in COLUMNS[label]]].set_axis(COLUMNS[label], axis=1)


def x_classical_means__mutmut_4(label: str, evidence: Path) -> pd.DataFrame:
    archive = TABLES[label][0]
    index = "method" if (label == "synthetic") and False else "detector"
    frame = pd.read_csv(evidence / archive).set_index(index)
    return frame[[f"{c}_mean" for c in COLUMNS[label]]].set_axis(COLUMNS[label], axis=1)


def x_classical_means__mutmut_5(label: str, evidence: Path) -> pd.DataFrame:
    archive = TABLES[label][0]
    index = "method" if (label == "synthetic") or True else "detector"
    frame = pd.read_csv(evidence / archive).set_index(index)
    return frame[[f"{c}_mean" for c in COLUMNS[label]]].set_axis(COLUMNS[label], axis=1)


def x_classical_means__mutmut_6(label: str, evidence: Path) -> pd.DataFrame:
    archive = TABLES[label][0]
    index = "XXmethodXX" if label == "synthetic" else "detector"
    frame = pd.read_csv(evidence / archive).set_index(index)
    return frame[[f"{c}_mean" for c in COLUMNS[label]]].set_axis(COLUMNS[label], axis=1)


def x_classical_means__mutmut_7(label: str, evidence: Path) -> pd.DataFrame:
    archive = TABLES[label][0]
    index = "METHOD" if label == "synthetic" else "detector"
    frame = pd.read_csv(evidence / archive).set_index(index)
    return frame[[f"{c}_mean" for c in COLUMNS[label]]].set_axis(COLUMNS[label], axis=1)


def x_classical_means__mutmut_8(label: str, evidence: Path) -> pd.DataFrame:
    archive = TABLES[label][0]
    index = "method" if label != "synthetic" else "detector"
    frame = pd.read_csv(evidence / archive).set_index(index)
    return frame[[f"{c}_mean" for c in COLUMNS[label]]].set_axis(COLUMNS[label], axis=1)


def x_classical_means__mutmut_9(label: str, evidence: Path) -> pd.DataFrame:
    archive = TABLES[label][0]
    index = "method" if label == "XXsyntheticXX" else "detector"
    frame = pd.read_csv(evidence / archive).set_index(index)
    return frame[[f"{c}_mean" for c in COLUMNS[label]]].set_axis(COLUMNS[label], axis=1)


def x_classical_means__mutmut_10(label: str, evidence: Path) -> pd.DataFrame:
    archive = TABLES[label][0]
    index = "method" if label == "SYNTHETIC" else "detector"
    frame = pd.read_csv(evidence / archive).set_index(index)
    return frame[[f"{c}_mean" for c in COLUMNS[label]]].set_axis(COLUMNS[label], axis=1)


def x_classical_means__mutmut_11(label: str, evidence: Path) -> pd.DataFrame:
    archive = TABLES[label][0]
    index = "method" if label == "synthetic" else "XXdetectorXX"
    frame = pd.read_csv(evidence / archive).set_index(index)
    return frame[[f"{c}_mean" for c in COLUMNS[label]]].set_axis(COLUMNS[label], axis=1)


def x_classical_means__mutmut_12(label: str, evidence: Path) -> pd.DataFrame:
    archive = TABLES[label][0]
    index = "method" if label == "synthetic" else "DETECTOR"
    frame = pd.read_csv(evidence / archive).set_index(index)
    return frame[[f"{c}_mean" for c in COLUMNS[label]]].set_axis(COLUMNS[label], axis=1)


def x_classical_means__mutmut_13(label: str, evidence: Path) -> pd.DataFrame:
    archive = TABLES[label][0]
    index = "method" if label == "synthetic" else "detector"
    frame = None
    return frame[[f"{c}_mean" for c in COLUMNS[label]]].set_axis(COLUMNS[label], axis=1)


def x_classical_means__mutmut_14(label: str, evidence: Path) -> pd.DataFrame:
    archive = TABLES[label][0]
    index = "method" if label == "synthetic" else "detector"
    frame = pd.read_csv(evidence / archive).set_index(None)
    return frame[[f"{c}_mean" for c in COLUMNS[label]]].set_axis(COLUMNS[label], axis=1)


def x_classical_means__mutmut_15(label: str, evidence: Path) -> pd.DataFrame:
    archive = TABLES[label][0]
    index = "method" if label == "synthetic" else "detector"
    frame = pd.read_csv(None).set_index(index)
    return frame[[f"{c}_mean" for c in COLUMNS[label]]].set_axis(COLUMNS[label], axis=1)


def x_classical_means__mutmut_16(label: str, evidence: Path) -> pd.DataFrame:
    archive = TABLES[label][0]
    index = "method" if label == "synthetic" else "detector"
    frame = pd.read_csv(evidence * archive).set_index(index)
    return frame[[f"{c}_mean" for c in COLUMNS[label]]].set_axis(COLUMNS[label], axis=1)


def x_classical_means__mutmut_17(label: str, evidence: Path) -> pd.DataFrame:
    archive = TABLES[label][0]
    index = "method" if label == "synthetic" else "detector"
    frame = pd.read_csv(evidence / archive).set_index(index)
    return frame[[f"{c}_mean" for c in COLUMNS[label]]].set_axis(None, axis=1)


def x_classical_means__mutmut_18(label: str, evidence: Path) -> pd.DataFrame:
    archive = TABLES[label][0]
    index = "method" if label == "synthetic" else "detector"
    frame = pd.read_csv(evidence / archive).set_index(index)
    return frame[[f"{c}_mean" for c in COLUMNS[label]]].set_axis(COLUMNS[label], axis=None)


def x_classical_means__mutmut_19(label: str, evidence: Path) -> pd.DataFrame:
    archive = TABLES[label][0]
    index = "method" if label == "synthetic" else "detector"
    frame = pd.read_csv(evidence / archive).set_index(index)
    return frame[[f"{c}_mean" for c in COLUMNS[label]]].set_axis(axis=1)


def x_classical_means__mutmut_20(label: str, evidence: Path) -> pd.DataFrame:
    archive = TABLES[label][0]
    index = "method" if label == "synthetic" else "detector"
    frame = pd.read_csv(evidence / archive).set_index(index)
    return frame[[f"{c}_mean" for c in COLUMNS[label]]].set_axis(COLUMNS[label], )


def x_classical_means__mutmut_21(label: str, evidence: Path) -> pd.DataFrame:
    archive = TABLES[label][0]
    index = "method" if label == "synthetic" else "detector"
    frame = pd.read_csv(evidence / archive).set_index(index)
    return frame[[f"{c}_mean" for c in COLUMNS[label]]].set_axis(COLUMNS[label], axis=2)

mutants_x_classical_means__mutmut['_mutmut_orig'] = x_classical_means__mutmut_orig # type: ignore # mutmut generated
mutants_x_classical_means__mutmut['x_classical_means__mutmut_1'] = x_classical_means__mutmut_1 # type: ignore # mutmut generated
mutants_x_classical_means__mutmut['x_classical_means__mutmut_2'] = x_classical_means__mutmut_2 # type: ignore # mutmut generated
mutants_x_classical_means__mutmut['x_classical_means__mutmut_3'] = x_classical_means__mutmut_3 # type: ignore # mutmut generated
mutants_x_classical_means__mutmut['x_classical_means__mutmut_4'] = x_classical_means__mutmut_4 # type: ignore # mutmut generated
mutants_x_classical_means__mutmut['x_classical_means__mutmut_5'] = x_classical_means__mutmut_5 # type: ignore # mutmut generated
mutants_x_classical_means__mutmut['x_classical_means__mutmut_6'] = x_classical_means__mutmut_6 # type: ignore # mutmut generated
mutants_x_classical_means__mutmut['x_classical_means__mutmut_7'] = x_classical_means__mutmut_7 # type: ignore # mutmut generated
mutants_x_classical_means__mutmut['x_classical_means__mutmut_8'] = x_classical_means__mutmut_8 # type: ignore # mutmut generated
mutants_x_classical_means__mutmut['x_classical_means__mutmut_9'] = x_classical_means__mutmut_9 # type: ignore # mutmut generated
mutants_x_classical_means__mutmut['x_classical_means__mutmut_10'] = x_classical_means__mutmut_10 # type: ignore # mutmut generated
mutants_x_classical_means__mutmut['x_classical_means__mutmut_11'] = x_classical_means__mutmut_11 # type: ignore # mutmut generated
mutants_x_classical_means__mutmut['x_classical_means__mutmut_12'] = x_classical_means__mutmut_12 # type: ignore # mutmut generated
mutants_x_classical_means__mutmut['x_classical_means__mutmut_13'] = x_classical_means__mutmut_13 # type: ignore # mutmut generated
mutants_x_classical_means__mutmut['x_classical_means__mutmut_14'] = x_classical_means__mutmut_14 # type: ignore # mutmut generated
mutants_x_classical_means__mutmut['x_classical_means__mutmut_15'] = x_classical_means__mutmut_15 # type: ignore # mutmut generated
mutants_x_classical_means__mutmut['x_classical_means__mutmut_16'] = x_classical_means__mutmut_16 # type: ignore # mutmut generated
mutants_x_classical_means__mutmut['x_classical_means__mutmut_17'] = x_classical_means__mutmut_17 # type: ignore # mutmut generated
mutants_x_classical_means__mutmut['x_classical_means__mutmut_18'] = x_classical_means__mutmut_18 # type: ignore # mutmut generated
mutants_x_classical_means__mutmut['x_classical_means__mutmut_19'] = x_classical_means__mutmut_19 # type: ignore # mutmut generated
mutants_x_classical_means__mutmut['x_classical_means__mutmut_20'] = x_classical_means__mutmut_20 # type: ignore # mutmut generated
mutants_x_classical_means__mutmut['x_classical_means__mutmut_21'] = x_classical_means__mutmut_21 # type: ignore # mutmut generated
mutants_x_neural_means__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_neural_means__mutmut)
def neural_means(label: str, evidence: Path) -> pd.DataFrame:
    """Mean over seeds of the neural detectors; the time is left empty (measured under load)."""
    source = TABLES[label][1]
    columns = [c for c in COLUMNS[label] if c not in LOWER_IS_BETTER]
    folder = evidence / "full_registry"
    rows: dict[str, dict[str, float]] = {}
    if source == "synthetic":
        runs = [
            json.loads(p.read_text())["metrics"]
            for p in sorted(folder.glob("synthetic_seed_*.json"))
        ]
        for name in NEURAL:
            rows[name] = {c: sum(r[name][c] for r in runs) / len(runs) for c in columns}
    else:
        runs = json.loads((folder / source).read_text())["runs"]
        for name in NEURAL:
            ok = [r["methods"][name] for r in runs if "error" not in r["methods"][name]]
            rows[name] = {c: sum(r[c] for r in ok) / len(ok) for c in columns}
    return pd.DataFrame(rows).T


def x_neural_means__mutmut_orig(label: str, evidence: Path) -> pd.DataFrame:
    """Mean over seeds of the neural detectors; the time is left empty (measured under load)."""
    source = TABLES[label][1]
    columns = [c for c in COLUMNS[label] if c not in LOWER_IS_BETTER]
    folder = evidence / "full_registry"
    rows: dict[str, dict[str, float]] = {}
    if source == "synthetic":
        runs = [
            json.loads(p.read_text())["metrics"]
            for p in sorted(folder.glob("synthetic_seed_*.json"))
        ]
        for name in NEURAL:
            rows[name] = {c: sum(r[name][c] for r in runs) / len(runs) for c in columns}
    else:
        runs = json.loads((folder / source).read_text())["runs"]
        for name in NEURAL:
            ok = [r["methods"][name] for r in runs if "error" not in r["methods"][name]]
            rows[name] = {c: sum(r[c] for r in ok) / len(ok) for c in columns}
    return pd.DataFrame(rows).T


def x_neural_means__mutmut_1(label: str, evidence: Path) -> pd.DataFrame:
    """Mean over seeds of the neural detectors; the time is left empty (measured under load)."""
    source = None
    columns = [c for c in COLUMNS[label] if c not in LOWER_IS_BETTER]
    folder = evidence / "full_registry"
    rows: dict[str, dict[str, float]] = {}
    if source == "synthetic":
        runs = [
            json.loads(p.read_text())["metrics"]
            for p in sorted(folder.glob("synthetic_seed_*.json"))
        ]
        for name in NEURAL:
            rows[name] = {c: sum(r[name][c] for r in runs) / len(runs) for c in columns}
    else:
        runs = json.loads((folder / source).read_text())["runs"]
        for name in NEURAL:
            ok = [r["methods"][name] for r in runs if "error" not in r["methods"][name]]
            rows[name] = {c: sum(r[c] for r in ok) / len(ok) for c in columns}
    return pd.DataFrame(rows).T


def x_neural_means__mutmut_2(label: str, evidence: Path) -> pd.DataFrame:
    """Mean over seeds of the neural detectors; the time is left empty (measured under load)."""
    source = TABLES[label][2]
    columns = [c for c in COLUMNS[label] if c not in LOWER_IS_BETTER]
    folder = evidence / "full_registry"
    rows: dict[str, dict[str, float]] = {}
    if source == "synthetic":
        runs = [
            json.loads(p.read_text())["metrics"]
            for p in sorted(folder.glob("synthetic_seed_*.json"))
        ]
        for name in NEURAL:
            rows[name] = {c: sum(r[name][c] for r in runs) / len(runs) for c in columns}
    else:
        runs = json.loads((folder / source).read_text())["runs"]
        for name in NEURAL:
            ok = [r["methods"][name] for r in runs if "error" not in r["methods"][name]]
            rows[name] = {c: sum(r[c] for r in ok) / len(ok) for c in columns}
    return pd.DataFrame(rows).T


def x_neural_means__mutmut_3(label: str, evidence: Path) -> pd.DataFrame:
    """Mean over seeds of the neural detectors; the time is left empty (measured under load)."""
    source = TABLES[label][1]
    columns = None
    folder = evidence / "full_registry"
    rows: dict[str, dict[str, float]] = {}
    if source == "synthetic":
        runs = [
            json.loads(p.read_text())["metrics"]
            for p in sorted(folder.glob("synthetic_seed_*.json"))
        ]
        for name in NEURAL:
            rows[name] = {c: sum(r[name][c] for r in runs) / len(runs) for c in columns}
    else:
        runs = json.loads((folder / source).read_text())["runs"]
        for name in NEURAL:
            ok = [r["methods"][name] for r in runs if "error" not in r["methods"][name]]
            rows[name] = {c: sum(r[c] for r in ok) / len(ok) for c in columns}
    return pd.DataFrame(rows).T


def x_neural_means__mutmut_4(label: str, evidence: Path) -> pd.DataFrame:
    """Mean over seeds of the neural detectors; the time is left empty (measured under load)."""
    source = TABLES[label][1]
    columns = [c for c in COLUMNS[label] if c in LOWER_IS_BETTER]
    folder = evidence / "full_registry"
    rows: dict[str, dict[str, float]] = {}
    if source == "synthetic":
        runs = [
            json.loads(p.read_text())["metrics"]
            for p in sorted(folder.glob("synthetic_seed_*.json"))
        ]
        for name in NEURAL:
            rows[name] = {c: sum(r[name][c] for r in runs) / len(runs) for c in columns}
    else:
        runs = json.loads((folder / source).read_text())["runs"]
        for name in NEURAL:
            ok = [r["methods"][name] for r in runs if "error" not in r["methods"][name]]
            rows[name] = {c: sum(r[c] for r in ok) / len(ok) for c in columns}
    return pd.DataFrame(rows).T


def x_neural_means__mutmut_5(label: str, evidence: Path) -> pd.DataFrame:
    """Mean over seeds of the neural detectors; the time is left empty (measured under load)."""
    source = TABLES[label][1]
    columns = [c for c in COLUMNS[label] if c not in LOWER_IS_BETTER]
    folder = None
    rows: dict[str, dict[str, float]] = {}
    if source == "synthetic":
        runs = [
            json.loads(p.read_text())["metrics"]
            for p in sorted(folder.glob("synthetic_seed_*.json"))
        ]
        for name in NEURAL:
            rows[name] = {c: sum(r[name][c] for r in runs) / len(runs) for c in columns}
    else:
        runs = json.loads((folder / source).read_text())["runs"]
        for name in NEURAL:
            ok = [r["methods"][name] for r in runs if "error" not in r["methods"][name]]
            rows[name] = {c: sum(r[c] for r in ok) / len(ok) for c in columns}
    return pd.DataFrame(rows).T


def x_neural_means__mutmut_6(label: str, evidence: Path) -> pd.DataFrame:
    """Mean over seeds of the neural detectors; the time is left empty (measured under load)."""
    source = TABLES[label][1]
    columns = [c for c in COLUMNS[label] if c not in LOWER_IS_BETTER]
    folder = evidence * "full_registry"
    rows: dict[str, dict[str, float]] = {}
    if source == "synthetic":
        runs = [
            json.loads(p.read_text())["metrics"]
            for p in sorted(folder.glob("synthetic_seed_*.json"))
        ]
        for name in NEURAL:
            rows[name] = {c: sum(r[name][c] for r in runs) / len(runs) for c in columns}
    else:
        runs = json.loads((folder / source).read_text())["runs"]
        for name in NEURAL:
            ok = [r["methods"][name] for r in runs if "error" not in r["methods"][name]]
            rows[name] = {c: sum(r[c] for r in ok) / len(ok) for c in columns}
    return pd.DataFrame(rows).T


def x_neural_means__mutmut_7(label: str, evidence: Path) -> pd.DataFrame:
    """Mean over seeds of the neural detectors; the time is left empty (measured under load)."""
    source = TABLES[label][1]
    columns = [c for c in COLUMNS[label] if c not in LOWER_IS_BETTER]
    folder = evidence / "XXfull_registryXX"
    rows: dict[str, dict[str, float]] = {}
    if source == "synthetic":
        runs = [
            json.loads(p.read_text())["metrics"]
            for p in sorted(folder.glob("synthetic_seed_*.json"))
        ]
        for name in NEURAL:
            rows[name] = {c: sum(r[name][c] for r in runs) / len(runs) for c in columns}
    else:
        runs = json.loads((folder / source).read_text())["runs"]
        for name in NEURAL:
            ok = [r["methods"][name] for r in runs if "error" not in r["methods"][name]]
            rows[name] = {c: sum(r[c] for r in ok) / len(ok) for c in columns}
    return pd.DataFrame(rows).T


def x_neural_means__mutmut_8(label: str, evidence: Path) -> pd.DataFrame:
    """Mean over seeds of the neural detectors; the time is left empty (measured under load)."""
    source = TABLES[label][1]
    columns = [c for c in COLUMNS[label] if c not in LOWER_IS_BETTER]
    folder = evidence / "FULL_REGISTRY"
    rows: dict[str, dict[str, float]] = {}
    if source == "synthetic":
        runs = [
            json.loads(p.read_text())["metrics"]
            for p in sorted(folder.glob("synthetic_seed_*.json"))
        ]
        for name in NEURAL:
            rows[name] = {c: sum(r[name][c] for r in runs) / len(runs) for c in columns}
    else:
        runs = json.loads((folder / source).read_text())["runs"]
        for name in NEURAL:
            ok = [r["methods"][name] for r in runs if "error" not in r["methods"][name]]
            rows[name] = {c: sum(r[c] for r in ok) / len(ok) for c in columns}
    return pd.DataFrame(rows).T


def x_neural_means__mutmut_9(label: str, evidence: Path) -> pd.DataFrame:
    """Mean over seeds of the neural detectors; the time is left empty (measured under load)."""
    source = TABLES[label][1]
    columns = [c for c in COLUMNS[label] if c not in LOWER_IS_BETTER]
    folder = evidence / "full_registry"
    rows: dict[str, dict[str, float]] = None
    if source == "synthetic":
        runs = [
            json.loads(p.read_text())["metrics"]
            for p in sorted(folder.glob("synthetic_seed_*.json"))
        ]
        for name in NEURAL:
            rows[name] = {c: sum(r[name][c] for r in runs) / len(runs) for c in columns}
    else:
        runs = json.loads((folder / source).read_text())["runs"]
        for name in NEURAL:
            ok = [r["methods"][name] for r in runs if "error" not in r["methods"][name]]
            rows[name] = {c: sum(r[c] for r in ok) / len(ok) for c in columns}
    return pd.DataFrame(rows).T


def x_neural_means__mutmut_10(label: str, evidence: Path) -> pd.DataFrame:
    """Mean over seeds of the neural detectors; the time is left empty (measured under load)."""
    source = TABLES[label][1]
    columns = [c for c in COLUMNS[label] if c not in LOWER_IS_BETTER]
    folder = evidence / "full_registry"
    rows: dict[str, dict[str, float]] = {}
    if source != "synthetic":
        runs = [
            json.loads(p.read_text())["metrics"]
            for p in sorted(folder.glob("synthetic_seed_*.json"))
        ]
        for name in NEURAL:
            rows[name] = {c: sum(r[name][c] for r in runs) / len(runs) for c in columns}
    else:
        runs = json.loads((folder / source).read_text())["runs"]
        for name in NEURAL:
            ok = [r["methods"][name] for r in runs if "error" not in r["methods"][name]]
            rows[name] = {c: sum(r[c] for r in ok) / len(ok) for c in columns}
    return pd.DataFrame(rows).T


def x_neural_means__mutmut_11(label: str, evidence: Path) -> pd.DataFrame:
    """Mean over seeds of the neural detectors; the time is left empty (measured under load)."""
    source = TABLES[label][1]
    columns = [c for c in COLUMNS[label] if c not in LOWER_IS_BETTER]
    folder = evidence / "full_registry"
    rows: dict[str, dict[str, float]] = {}
    if source == "XXsyntheticXX":
        runs = [
            json.loads(p.read_text())["metrics"]
            for p in sorted(folder.glob("synthetic_seed_*.json"))
        ]
        for name in NEURAL:
            rows[name] = {c: sum(r[name][c] for r in runs) / len(runs) for c in columns}
    else:
        runs = json.loads((folder / source).read_text())["runs"]
        for name in NEURAL:
            ok = [r["methods"][name] for r in runs if "error" not in r["methods"][name]]
            rows[name] = {c: sum(r[c] for r in ok) / len(ok) for c in columns}
    return pd.DataFrame(rows).T


def x_neural_means__mutmut_12(label: str, evidence: Path) -> pd.DataFrame:
    """Mean over seeds of the neural detectors; the time is left empty (measured under load)."""
    source = TABLES[label][1]
    columns = [c for c in COLUMNS[label] if c not in LOWER_IS_BETTER]
    folder = evidence / "full_registry"
    rows: dict[str, dict[str, float]] = {}
    if source == "SYNTHETIC":
        runs = [
            json.loads(p.read_text())["metrics"]
            for p in sorted(folder.glob("synthetic_seed_*.json"))
        ]
        for name in NEURAL:
            rows[name] = {c: sum(r[name][c] for r in runs) / len(runs) for c in columns}
    else:
        runs = json.loads((folder / source).read_text())["runs"]
        for name in NEURAL:
            ok = [r["methods"][name] for r in runs if "error" not in r["methods"][name]]
            rows[name] = {c: sum(r[c] for r in ok) / len(ok) for c in columns}
    return pd.DataFrame(rows).T


def x_neural_means__mutmut_13(label: str, evidence: Path) -> pd.DataFrame:
    """Mean over seeds of the neural detectors; the time is left empty (measured under load)."""
    source = TABLES[label][1]
    columns = [c for c in COLUMNS[label] if c not in LOWER_IS_BETTER]
    folder = evidence / "full_registry"
    rows: dict[str, dict[str, float]] = {}
    if source == "synthetic":
        runs = None
        for name in NEURAL:
            rows[name] = {c: sum(r[name][c] for r in runs) / len(runs) for c in columns}
    else:
        runs = json.loads((folder / source).read_text())["runs"]
        for name in NEURAL:
            ok = [r["methods"][name] for r in runs if "error" not in r["methods"][name]]
            rows[name] = {c: sum(r[c] for r in ok) / len(ok) for c in columns}
    return pd.DataFrame(rows).T


def x_neural_means__mutmut_14(label: str, evidence: Path) -> pd.DataFrame:
    """Mean over seeds of the neural detectors; the time is left empty (measured under load)."""
    source = TABLES[label][1]
    columns = [c for c in COLUMNS[label] if c not in LOWER_IS_BETTER]
    folder = evidence / "full_registry"
    rows: dict[str, dict[str, float]] = {}
    if source == "synthetic":
        runs = [
            json.loads(None)["metrics"]
            for p in sorted(folder.glob("synthetic_seed_*.json"))
        ]
        for name in NEURAL:
            rows[name] = {c: sum(r[name][c] for r in runs) / len(runs) for c in columns}
    else:
        runs = json.loads((folder / source).read_text())["runs"]
        for name in NEURAL:
            ok = [r["methods"][name] for r in runs if "error" not in r["methods"][name]]
            rows[name] = {c: sum(r[c] for r in ok) / len(ok) for c in columns}
    return pd.DataFrame(rows).T


def x_neural_means__mutmut_15(label: str, evidence: Path) -> pd.DataFrame:
    """Mean over seeds of the neural detectors; the time is left empty (measured under load)."""
    source = TABLES[label][1]
    columns = [c for c in COLUMNS[label] if c not in LOWER_IS_BETTER]
    folder = evidence / "full_registry"
    rows: dict[str, dict[str, float]] = {}
    if source == "synthetic":
        runs = [
            json.loads(p.read_text())["XXmetricsXX"]
            for p in sorted(folder.glob("synthetic_seed_*.json"))
        ]
        for name in NEURAL:
            rows[name] = {c: sum(r[name][c] for r in runs) / len(runs) for c in columns}
    else:
        runs = json.loads((folder / source).read_text())["runs"]
        for name in NEURAL:
            ok = [r["methods"][name] for r in runs if "error" not in r["methods"][name]]
            rows[name] = {c: sum(r[c] for r in ok) / len(ok) for c in columns}
    return pd.DataFrame(rows).T


def x_neural_means__mutmut_16(label: str, evidence: Path) -> pd.DataFrame:
    """Mean over seeds of the neural detectors; the time is left empty (measured under load)."""
    source = TABLES[label][1]
    columns = [c for c in COLUMNS[label] if c not in LOWER_IS_BETTER]
    folder = evidence / "full_registry"
    rows: dict[str, dict[str, float]] = {}
    if source == "synthetic":
        runs = [
            json.loads(p.read_text())["METRICS"]
            for p in sorted(folder.glob("synthetic_seed_*.json"))
        ]
        for name in NEURAL:
            rows[name] = {c: sum(r[name][c] for r in runs) / len(runs) for c in columns}
    else:
        runs = json.loads((folder / source).read_text())["runs"]
        for name in NEURAL:
            ok = [r["methods"][name] for r in runs if "error" not in r["methods"][name]]
            rows[name] = {c: sum(r[c] for r in ok) / len(ok) for c in columns}
    return pd.DataFrame(rows).T


def x_neural_means__mutmut_17(label: str, evidence: Path) -> pd.DataFrame:
    """Mean over seeds of the neural detectors; the time is left empty (measured under load)."""
    source = TABLES[label][1]
    columns = [c for c in COLUMNS[label] if c not in LOWER_IS_BETTER]
    folder = evidence / "full_registry"
    rows: dict[str, dict[str, float]] = {}
    if source == "synthetic":
        runs = [
            json.loads(p.read_text())["metrics"]
            for p in sorted(None)
        ]
        for name in NEURAL:
            rows[name] = {c: sum(r[name][c] for r in runs) / len(runs) for c in columns}
    else:
        runs = json.loads((folder / source).read_text())["runs"]
        for name in NEURAL:
            ok = [r["methods"][name] for r in runs if "error" not in r["methods"][name]]
            rows[name] = {c: sum(r[c] for r in ok) / len(ok) for c in columns}
    return pd.DataFrame(rows).T


def x_neural_means__mutmut_18(label: str, evidence: Path) -> pd.DataFrame:
    """Mean over seeds of the neural detectors; the time is left empty (measured under load)."""
    source = TABLES[label][1]
    columns = [c for c in COLUMNS[label] if c not in LOWER_IS_BETTER]
    folder = evidence / "full_registry"
    rows: dict[str, dict[str, float]] = {}
    if source == "synthetic":
        runs = [
            json.loads(p.read_text())["metrics"]
            for p in sorted(folder.glob(None))
        ]
        for name in NEURAL:
            rows[name] = {c: sum(r[name][c] for r in runs) / len(runs) for c in columns}
    else:
        runs = json.loads((folder / source).read_text())["runs"]
        for name in NEURAL:
            ok = [r["methods"][name] for r in runs if "error" not in r["methods"][name]]
            rows[name] = {c: sum(r[c] for r in ok) / len(ok) for c in columns}
    return pd.DataFrame(rows).T


def x_neural_means__mutmut_19(label: str, evidence: Path) -> pd.DataFrame:
    """Mean over seeds of the neural detectors; the time is left empty (measured under load)."""
    source = TABLES[label][1]
    columns = [c for c in COLUMNS[label] if c not in LOWER_IS_BETTER]
    folder = evidence / "full_registry"
    rows: dict[str, dict[str, float]] = {}
    if source == "synthetic":
        runs = [
            json.loads(p.read_text())["metrics"]
            for p in sorted(folder.glob("XXsynthetic_seed_*.jsonXX"))
        ]
        for name in NEURAL:
            rows[name] = {c: sum(r[name][c] for r in runs) / len(runs) for c in columns}
    else:
        runs = json.loads((folder / source).read_text())["runs"]
        for name in NEURAL:
            ok = [r["methods"][name] for r in runs if "error" not in r["methods"][name]]
            rows[name] = {c: sum(r[c] for r in ok) / len(ok) for c in columns}
    return pd.DataFrame(rows).T


def x_neural_means__mutmut_20(label: str, evidence: Path) -> pd.DataFrame:
    """Mean over seeds of the neural detectors; the time is left empty (measured under load)."""
    source = TABLES[label][1]
    columns = [c for c in COLUMNS[label] if c not in LOWER_IS_BETTER]
    folder = evidence / "full_registry"
    rows: dict[str, dict[str, float]] = {}
    if source == "synthetic":
        runs = [
            json.loads(p.read_text())["metrics"]
            for p in sorted(folder.glob("SYNTHETIC_SEED_*.JSON"))
        ]
        for name in NEURAL:
            rows[name] = {c: sum(r[name][c] for r in runs) / len(runs) for c in columns}
    else:
        runs = json.loads((folder / source).read_text())["runs"]
        for name in NEURAL:
            ok = [r["methods"][name] for r in runs if "error" not in r["methods"][name]]
            rows[name] = {c: sum(r[c] for r in ok) / len(ok) for c in columns}
    return pd.DataFrame(rows).T


def x_neural_means__mutmut_21(label: str, evidence: Path) -> pd.DataFrame:
    """Mean over seeds of the neural detectors; the time is left empty (measured under load)."""
    source = TABLES[label][1]
    columns = [c for c in COLUMNS[label] if c not in LOWER_IS_BETTER]
    folder = evidence / "full_registry"
    rows: dict[str, dict[str, float]] = {}
    if source == "synthetic":
        runs = [
            json.loads(p.read_text())["metrics"]
            for p in sorted(folder.glob("synthetic_seed_*.json"))
        ]
        for name in NEURAL:
            rows[name] = None
    else:
        runs = json.loads((folder / source).read_text())["runs"]
        for name in NEURAL:
            ok = [r["methods"][name] for r in runs if "error" not in r["methods"][name]]
            rows[name] = {c: sum(r[c] for r in ok) / len(ok) for c in columns}
    return pd.DataFrame(rows).T


def x_neural_means__mutmut_22(label: str, evidence: Path) -> pd.DataFrame:
    """Mean over seeds of the neural detectors; the time is left empty (measured under load)."""
    source = TABLES[label][1]
    columns = [c for c in COLUMNS[label] if c not in LOWER_IS_BETTER]
    folder = evidence / "full_registry"
    rows: dict[str, dict[str, float]] = {}
    if source == "synthetic":
        runs = [
            json.loads(p.read_text())["metrics"]
            for p in sorted(folder.glob("synthetic_seed_*.json"))
        ]
        for name in NEURAL:
            rows[name] = {c: sum(r[name][c] for r in runs) * len(runs) for c in columns}
    else:
        runs = json.loads((folder / source).read_text())["runs"]
        for name in NEURAL:
            ok = [r["methods"][name] for r in runs if "error" not in r["methods"][name]]
            rows[name] = {c: sum(r[c] for r in ok) / len(ok) for c in columns}
    return pd.DataFrame(rows).T


def x_neural_means__mutmut_23(label: str, evidence: Path) -> pd.DataFrame:
    """Mean over seeds of the neural detectors; the time is left empty (measured under load)."""
    source = TABLES[label][1]
    columns = [c for c in COLUMNS[label] if c not in LOWER_IS_BETTER]
    folder = evidence / "full_registry"
    rows: dict[str, dict[str, float]] = {}
    if source == "synthetic":
        runs = [
            json.loads(p.read_text())["metrics"]
            for p in sorted(folder.glob("synthetic_seed_*.json"))
        ]
        for name in NEURAL:
            rows[name] = {c: sum(None) / len(runs) for c in columns}
    else:
        runs = json.loads((folder / source).read_text())["runs"]
        for name in NEURAL:
            ok = [r["methods"][name] for r in runs if "error" not in r["methods"][name]]
            rows[name] = {c: sum(r[c] for r in ok) / len(ok) for c in columns}
    return pd.DataFrame(rows).T


def x_neural_means__mutmut_24(label: str, evidence: Path) -> pd.DataFrame:
    """Mean over seeds of the neural detectors; the time is left empty (measured under load)."""
    source = TABLES[label][1]
    columns = [c for c in COLUMNS[label] if c not in LOWER_IS_BETTER]
    folder = evidence / "full_registry"
    rows: dict[str, dict[str, float]] = {}
    if source == "synthetic":
        runs = [
            json.loads(p.read_text())["metrics"]
            for p in sorted(folder.glob("synthetic_seed_*.json"))
        ]
        for name in NEURAL:
            rows[name] = {c: sum(r[name][c] for r in runs) / len(runs) for c in columns}
    else:
        runs = None
        for name in NEURAL:
            ok = [r["methods"][name] for r in runs if "error" not in r["methods"][name]]
            rows[name] = {c: sum(r[c] for r in ok) / len(ok) for c in columns}
    return pd.DataFrame(rows).T


def x_neural_means__mutmut_25(label: str, evidence: Path) -> pd.DataFrame:
    """Mean over seeds of the neural detectors; the time is left empty (measured under load)."""
    source = TABLES[label][1]
    columns = [c for c in COLUMNS[label] if c not in LOWER_IS_BETTER]
    folder = evidence / "full_registry"
    rows: dict[str, dict[str, float]] = {}
    if source == "synthetic":
        runs = [
            json.loads(p.read_text())["metrics"]
            for p in sorted(folder.glob("synthetic_seed_*.json"))
        ]
        for name in NEURAL:
            rows[name] = {c: sum(r[name][c] for r in runs) / len(runs) for c in columns}
    else:
        runs = json.loads(None)["runs"]
        for name in NEURAL:
            ok = [r["methods"][name] for r in runs if "error" not in r["methods"][name]]
            rows[name] = {c: sum(r[c] for r in ok) / len(ok) for c in columns}
    return pd.DataFrame(rows).T


def x_neural_means__mutmut_26(label: str, evidence: Path) -> pd.DataFrame:
    """Mean over seeds of the neural detectors; the time is left empty (measured under load)."""
    source = TABLES[label][1]
    columns = [c for c in COLUMNS[label] if c not in LOWER_IS_BETTER]
    folder = evidence / "full_registry"
    rows: dict[str, dict[str, float]] = {}
    if source == "synthetic":
        runs = [
            json.loads(p.read_text())["metrics"]
            for p in sorted(folder.glob("synthetic_seed_*.json"))
        ]
        for name in NEURAL:
            rows[name] = {c: sum(r[name][c] for r in runs) / len(runs) for c in columns}
    else:
        runs = json.loads((folder * source).read_text())["runs"]
        for name in NEURAL:
            ok = [r["methods"][name] for r in runs if "error" not in r["methods"][name]]
            rows[name] = {c: sum(r[c] for r in ok) / len(ok) for c in columns}
    return pd.DataFrame(rows).T


def x_neural_means__mutmut_27(label: str, evidence: Path) -> pd.DataFrame:
    """Mean over seeds of the neural detectors; the time is left empty (measured under load)."""
    source = TABLES[label][1]
    columns = [c for c in COLUMNS[label] if c not in LOWER_IS_BETTER]
    folder = evidence / "full_registry"
    rows: dict[str, dict[str, float]] = {}
    if source == "synthetic":
        runs = [
            json.loads(p.read_text())["metrics"]
            for p in sorted(folder.glob("synthetic_seed_*.json"))
        ]
        for name in NEURAL:
            rows[name] = {c: sum(r[name][c] for r in runs) / len(runs) for c in columns}
    else:
        runs = json.loads((folder / source).read_text())["XXrunsXX"]
        for name in NEURAL:
            ok = [r["methods"][name] for r in runs if "error" not in r["methods"][name]]
            rows[name] = {c: sum(r[c] for r in ok) / len(ok) for c in columns}
    return pd.DataFrame(rows).T


def x_neural_means__mutmut_28(label: str, evidence: Path) -> pd.DataFrame:
    """Mean over seeds of the neural detectors; the time is left empty (measured under load)."""
    source = TABLES[label][1]
    columns = [c for c in COLUMNS[label] if c not in LOWER_IS_BETTER]
    folder = evidence / "full_registry"
    rows: dict[str, dict[str, float]] = {}
    if source == "synthetic":
        runs = [
            json.loads(p.read_text())["metrics"]
            for p in sorted(folder.glob("synthetic_seed_*.json"))
        ]
        for name in NEURAL:
            rows[name] = {c: sum(r[name][c] for r in runs) / len(runs) for c in columns}
    else:
        runs = json.loads((folder / source).read_text())["RUNS"]
        for name in NEURAL:
            ok = [r["methods"][name] for r in runs if "error" not in r["methods"][name]]
            rows[name] = {c: sum(r[c] for r in ok) / len(ok) for c in columns}
    return pd.DataFrame(rows).T


def x_neural_means__mutmut_29(label: str, evidence: Path) -> pd.DataFrame:
    """Mean over seeds of the neural detectors; the time is left empty (measured under load)."""
    source = TABLES[label][1]
    columns = [c for c in COLUMNS[label] if c not in LOWER_IS_BETTER]
    folder = evidence / "full_registry"
    rows: dict[str, dict[str, float]] = {}
    if source == "synthetic":
        runs = [
            json.loads(p.read_text())["metrics"]
            for p in sorted(folder.glob("synthetic_seed_*.json"))
        ]
        for name in NEURAL:
            rows[name] = {c: sum(r[name][c] for r in runs) / len(runs) for c in columns}
    else:
        runs = json.loads((folder / source).read_text())["runs"]
        for name in NEURAL:
            ok = None
            rows[name] = {c: sum(r[c] for r in ok) / len(ok) for c in columns}
    return pd.DataFrame(rows).T


def x_neural_means__mutmut_30(label: str, evidence: Path) -> pd.DataFrame:
    """Mean over seeds of the neural detectors; the time is left empty (measured under load)."""
    source = TABLES[label][1]
    columns = [c for c in COLUMNS[label] if c not in LOWER_IS_BETTER]
    folder = evidence / "full_registry"
    rows: dict[str, dict[str, float]] = {}
    if source == "synthetic":
        runs = [
            json.loads(p.read_text())["metrics"]
            for p in sorted(folder.glob("synthetic_seed_*.json"))
        ]
        for name in NEURAL:
            rows[name] = {c: sum(r[name][c] for r in runs) / len(runs) for c in columns}
    else:
        runs = json.loads((folder / source).read_text())["runs"]
        for name in NEURAL:
            ok = [r["XXmethodsXX"][name] for r in runs if "error" not in r["methods"][name]]
            rows[name] = {c: sum(r[c] for r in ok) / len(ok) for c in columns}
    return pd.DataFrame(rows).T


def x_neural_means__mutmut_31(label: str, evidence: Path) -> pd.DataFrame:
    """Mean over seeds of the neural detectors; the time is left empty (measured under load)."""
    source = TABLES[label][1]
    columns = [c for c in COLUMNS[label] if c not in LOWER_IS_BETTER]
    folder = evidence / "full_registry"
    rows: dict[str, dict[str, float]] = {}
    if source == "synthetic":
        runs = [
            json.loads(p.read_text())["metrics"]
            for p in sorted(folder.glob("synthetic_seed_*.json"))
        ]
        for name in NEURAL:
            rows[name] = {c: sum(r[name][c] for r in runs) / len(runs) for c in columns}
    else:
        runs = json.loads((folder / source).read_text())["runs"]
        for name in NEURAL:
            ok = [r["METHODS"][name] for r in runs if "error" not in r["methods"][name]]
            rows[name] = {c: sum(r[c] for r in ok) / len(ok) for c in columns}
    return pd.DataFrame(rows).T


def x_neural_means__mutmut_32(label: str, evidence: Path) -> pd.DataFrame:
    """Mean over seeds of the neural detectors; the time is left empty (measured under load)."""
    source = TABLES[label][1]
    columns = [c for c in COLUMNS[label] if c not in LOWER_IS_BETTER]
    folder = evidence / "full_registry"
    rows: dict[str, dict[str, float]] = {}
    if source == "synthetic":
        runs = [
            json.loads(p.read_text())["metrics"]
            for p in sorted(folder.glob("synthetic_seed_*.json"))
        ]
        for name in NEURAL:
            rows[name] = {c: sum(r[name][c] for r in runs) / len(runs) for c in columns}
    else:
        runs = json.loads((folder / source).read_text())["runs"]
        for name in NEURAL:
            ok = [r["methods"][name] for r in runs if "XXerrorXX" not in r["methods"][name]]
            rows[name] = {c: sum(r[c] for r in ok) / len(ok) for c in columns}
    return pd.DataFrame(rows).T


def x_neural_means__mutmut_33(label: str, evidence: Path) -> pd.DataFrame:
    """Mean over seeds of the neural detectors; the time is left empty (measured under load)."""
    source = TABLES[label][1]
    columns = [c for c in COLUMNS[label] if c not in LOWER_IS_BETTER]
    folder = evidence / "full_registry"
    rows: dict[str, dict[str, float]] = {}
    if source == "synthetic":
        runs = [
            json.loads(p.read_text())["metrics"]
            for p in sorted(folder.glob("synthetic_seed_*.json"))
        ]
        for name in NEURAL:
            rows[name] = {c: sum(r[name][c] for r in runs) / len(runs) for c in columns}
    else:
        runs = json.loads((folder / source).read_text())["runs"]
        for name in NEURAL:
            ok = [r["methods"][name] for r in runs if "ERROR" not in r["methods"][name]]
            rows[name] = {c: sum(r[c] for r in ok) / len(ok) for c in columns}
    return pd.DataFrame(rows).T


def x_neural_means__mutmut_34(label: str, evidence: Path) -> pd.DataFrame:
    """Mean over seeds of the neural detectors; the time is left empty (measured under load)."""
    source = TABLES[label][1]
    columns = [c for c in COLUMNS[label] if c not in LOWER_IS_BETTER]
    folder = evidence / "full_registry"
    rows: dict[str, dict[str, float]] = {}
    if source == "synthetic":
        runs = [
            json.loads(p.read_text())["metrics"]
            for p in sorted(folder.glob("synthetic_seed_*.json"))
        ]
        for name in NEURAL:
            rows[name] = {c: sum(r[name][c] for r in runs) / len(runs) for c in columns}
    else:
        runs = json.loads((folder / source).read_text())["runs"]
        for name in NEURAL:
            ok = [r["methods"][name] for r in runs if "error" in r["methods"][name]]
            rows[name] = {c: sum(r[c] for r in ok) / len(ok) for c in columns}
    return pd.DataFrame(rows).T


def x_neural_means__mutmut_35(label: str, evidence: Path) -> pd.DataFrame:
    """Mean over seeds of the neural detectors; the time is left empty (measured under load)."""
    source = TABLES[label][1]
    columns = [c for c in COLUMNS[label] if c not in LOWER_IS_BETTER]
    folder = evidence / "full_registry"
    rows: dict[str, dict[str, float]] = {}
    if source == "synthetic":
        runs = [
            json.loads(p.read_text())["metrics"]
            for p in sorted(folder.glob("synthetic_seed_*.json"))
        ]
        for name in NEURAL:
            rows[name] = {c: sum(r[name][c] for r in runs) / len(runs) for c in columns}
    else:
        runs = json.loads((folder / source).read_text())["runs"]
        for name in NEURAL:
            ok = [r["methods"][name] for r in runs if "error" not in r["XXmethodsXX"][name]]
            rows[name] = {c: sum(r[c] for r in ok) / len(ok) for c in columns}
    return pd.DataFrame(rows).T


def x_neural_means__mutmut_36(label: str, evidence: Path) -> pd.DataFrame:
    """Mean over seeds of the neural detectors; the time is left empty (measured under load)."""
    source = TABLES[label][1]
    columns = [c for c in COLUMNS[label] if c not in LOWER_IS_BETTER]
    folder = evidence / "full_registry"
    rows: dict[str, dict[str, float]] = {}
    if source == "synthetic":
        runs = [
            json.loads(p.read_text())["metrics"]
            for p in sorted(folder.glob("synthetic_seed_*.json"))
        ]
        for name in NEURAL:
            rows[name] = {c: sum(r[name][c] for r in runs) / len(runs) for c in columns}
    else:
        runs = json.loads((folder / source).read_text())["runs"]
        for name in NEURAL:
            ok = [r["methods"][name] for r in runs if "error" not in r["METHODS"][name]]
            rows[name] = {c: sum(r[c] for r in ok) / len(ok) for c in columns}
    return pd.DataFrame(rows).T


def x_neural_means__mutmut_37(label: str, evidence: Path) -> pd.DataFrame:
    """Mean over seeds of the neural detectors; the time is left empty (measured under load)."""
    source = TABLES[label][1]
    columns = [c for c in COLUMNS[label] if c not in LOWER_IS_BETTER]
    folder = evidence / "full_registry"
    rows: dict[str, dict[str, float]] = {}
    if source == "synthetic":
        runs = [
            json.loads(p.read_text())["metrics"]
            for p in sorted(folder.glob("synthetic_seed_*.json"))
        ]
        for name in NEURAL:
            rows[name] = {c: sum(r[name][c] for r in runs) / len(runs) for c in columns}
    else:
        runs = json.loads((folder / source).read_text())["runs"]
        for name in NEURAL:
            ok = [r["methods"][name] for r in runs if "error" not in r["methods"][name]]
            rows[name] = None
    return pd.DataFrame(rows).T


def x_neural_means__mutmut_38(label: str, evidence: Path) -> pd.DataFrame:
    """Mean over seeds of the neural detectors; the time is left empty (measured under load)."""
    source = TABLES[label][1]
    columns = [c for c in COLUMNS[label] if c not in LOWER_IS_BETTER]
    folder = evidence / "full_registry"
    rows: dict[str, dict[str, float]] = {}
    if source == "synthetic":
        runs = [
            json.loads(p.read_text())["metrics"]
            for p in sorted(folder.glob("synthetic_seed_*.json"))
        ]
        for name in NEURAL:
            rows[name] = {c: sum(r[name][c] for r in runs) / len(runs) for c in columns}
    else:
        runs = json.loads((folder / source).read_text())["runs"]
        for name in NEURAL:
            ok = [r["methods"][name] for r in runs if "error" not in r["methods"][name]]
            rows[name] = {c: sum(r[c] for r in ok) * len(ok) for c in columns}
    return pd.DataFrame(rows).T


def x_neural_means__mutmut_39(label: str, evidence: Path) -> pd.DataFrame:
    """Mean over seeds of the neural detectors; the time is left empty (measured under load)."""
    source = TABLES[label][1]
    columns = [c for c in COLUMNS[label] if c not in LOWER_IS_BETTER]
    folder = evidence / "full_registry"
    rows: dict[str, dict[str, float]] = {}
    if source == "synthetic":
        runs = [
            json.loads(p.read_text())["metrics"]
            for p in sorted(folder.glob("synthetic_seed_*.json"))
        ]
        for name in NEURAL:
            rows[name] = {c: sum(r[name][c] for r in runs) / len(runs) for c in columns}
    else:
        runs = json.loads((folder / source).read_text())["runs"]
        for name in NEURAL:
            ok = [r["methods"][name] for r in runs if "error" not in r["methods"][name]]
            rows[name] = {c: sum(None) / len(ok) for c in columns}
    return pd.DataFrame(rows).T


def x_neural_means__mutmut_40(label: str, evidence: Path) -> pd.DataFrame:
    """Mean over seeds of the neural detectors; the time is left empty (measured under load)."""
    source = TABLES[label][1]
    columns = [c for c in COLUMNS[label] if c not in LOWER_IS_BETTER]
    folder = evidence / "full_registry"
    rows: dict[str, dict[str, float]] = {}
    if source == "synthetic":
        runs = [
            json.loads(p.read_text())["metrics"]
            for p in sorted(folder.glob("synthetic_seed_*.json"))
        ]
        for name in NEURAL:
            rows[name] = {c: sum(r[name][c] for r in runs) / len(runs) for c in columns}
    else:
        runs = json.loads((folder / source).read_text())["runs"]
        for name in NEURAL:
            ok = [r["methods"][name] for r in runs if "error" not in r["methods"][name]]
            rows[name] = {c: sum(r[c] for r in ok) / len(ok) for c in columns}
    return pd.DataFrame(None).T

mutants_x_neural_means__mutmut['_mutmut_orig'] = x_neural_means__mutmut_orig # type: ignore # mutmut generated
mutants_x_neural_means__mutmut['x_neural_means__mutmut_1'] = x_neural_means__mutmut_1 # type: ignore # mutmut generated
mutants_x_neural_means__mutmut['x_neural_means__mutmut_2'] = x_neural_means__mutmut_2 # type: ignore # mutmut generated
mutants_x_neural_means__mutmut['x_neural_means__mutmut_3'] = x_neural_means__mutmut_3 # type: ignore # mutmut generated
mutants_x_neural_means__mutmut['x_neural_means__mutmut_4'] = x_neural_means__mutmut_4 # type: ignore # mutmut generated
mutants_x_neural_means__mutmut['x_neural_means__mutmut_5'] = x_neural_means__mutmut_5 # type: ignore # mutmut generated
mutants_x_neural_means__mutmut['x_neural_means__mutmut_6'] = x_neural_means__mutmut_6 # type: ignore # mutmut generated
mutants_x_neural_means__mutmut['x_neural_means__mutmut_7'] = x_neural_means__mutmut_7 # type: ignore # mutmut generated
mutants_x_neural_means__mutmut['x_neural_means__mutmut_8'] = x_neural_means__mutmut_8 # type: ignore # mutmut generated
mutants_x_neural_means__mutmut['x_neural_means__mutmut_9'] = x_neural_means__mutmut_9 # type: ignore # mutmut generated
mutants_x_neural_means__mutmut['x_neural_means__mutmut_10'] = x_neural_means__mutmut_10 # type: ignore # mutmut generated
mutants_x_neural_means__mutmut['x_neural_means__mutmut_11'] = x_neural_means__mutmut_11 # type: ignore # mutmut generated
mutants_x_neural_means__mutmut['x_neural_means__mutmut_12'] = x_neural_means__mutmut_12 # type: ignore # mutmut generated
mutants_x_neural_means__mutmut['x_neural_means__mutmut_13'] = x_neural_means__mutmut_13 # type: ignore # mutmut generated
mutants_x_neural_means__mutmut['x_neural_means__mutmut_14'] = x_neural_means__mutmut_14 # type: ignore # mutmut generated
mutants_x_neural_means__mutmut['x_neural_means__mutmut_15'] = x_neural_means__mutmut_15 # type: ignore # mutmut generated
mutants_x_neural_means__mutmut['x_neural_means__mutmut_16'] = x_neural_means__mutmut_16 # type: ignore # mutmut generated
mutants_x_neural_means__mutmut['x_neural_means__mutmut_17'] = x_neural_means__mutmut_17 # type: ignore # mutmut generated
mutants_x_neural_means__mutmut['x_neural_means__mutmut_18'] = x_neural_means__mutmut_18 # type: ignore # mutmut generated
mutants_x_neural_means__mutmut['x_neural_means__mutmut_19'] = x_neural_means__mutmut_19 # type: ignore # mutmut generated
mutants_x_neural_means__mutmut['x_neural_means__mutmut_20'] = x_neural_means__mutmut_20 # type: ignore # mutmut generated
mutants_x_neural_means__mutmut['x_neural_means__mutmut_21'] = x_neural_means__mutmut_21 # type: ignore # mutmut generated
mutants_x_neural_means__mutmut['x_neural_means__mutmut_22'] = x_neural_means__mutmut_22 # type: ignore # mutmut generated
mutants_x_neural_means__mutmut['x_neural_means__mutmut_23'] = x_neural_means__mutmut_23 # type: ignore # mutmut generated
mutants_x_neural_means__mutmut['x_neural_means__mutmut_24'] = x_neural_means__mutmut_24 # type: ignore # mutmut generated
mutants_x_neural_means__mutmut['x_neural_means__mutmut_25'] = x_neural_means__mutmut_25 # type: ignore # mutmut generated
mutants_x_neural_means__mutmut['x_neural_means__mutmut_26'] = x_neural_means__mutmut_26 # type: ignore # mutmut generated
mutants_x_neural_means__mutmut['x_neural_means__mutmut_27'] = x_neural_means__mutmut_27 # type: ignore # mutmut generated
mutants_x_neural_means__mutmut['x_neural_means__mutmut_28'] = x_neural_means__mutmut_28 # type: ignore # mutmut generated
mutants_x_neural_means__mutmut['x_neural_means__mutmut_29'] = x_neural_means__mutmut_29 # type: ignore # mutmut generated
mutants_x_neural_means__mutmut['x_neural_means__mutmut_30'] = x_neural_means__mutmut_30 # type: ignore # mutmut generated
mutants_x_neural_means__mutmut['x_neural_means__mutmut_31'] = x_neural_means__mutmut_31 # type: ignore # mutmut generated
mutants_x_neural_means__mutmut['x_neural_means__mutmut_32'] = x_neural_means__mutmut_32 # type: ignore # mutmut generated
mutants_x_neural_means__mutmut['x_neural_means__mutmut_33'] = x_neural_means__mutmut_33 # type: ignore # mutmut generated
mutants_x_neural_means__mutmut['x_neural_means__mutmut_34'] = x_neural_means__mutmut_34 # type: ignore # mutmut generated
mutants_x_neural_means__mutmut['x_neural_means__mutmut_35'] = x_neural_means__mutmut_35 # type: ignore # mutmut generated
mutants_x_neural_means__mutmut['x_neural_means__mutmut_36'] = x_neural_means__mutmut_36 # type: ignore # mutmut generated
mutants_x_neural_means__mutmut['x_neural_means__mutmut_37'] = x_neural_means__mutmut_37 # type: ignore # mutmut generated
mutants_x_neural_means__mutmut['x_neural_means__mutmut_38'] = x_neural_means__mutmut_38 # type: ignore # mutmut generated
mutants_x_neural_means__mutmut['x_neural_means__mutmut_39'] = x_neural_means__mutmut_39 # type: ignore # mutmut generated
mutants_x_neural_means__mutmut['x_neural_means__mutmut_40'] = x_neural_means__mutmut_40 # type: ignore # mutmut generated
mutants_x_rows__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_rows__mutmut)
def rows(label: str, evidence: Path = EVIDENCE) -> str:
    """The body of a table: one line per detector, the best value of each column in bold."""
    base = classical_means(label, evidence)
    neural = neural_means(label, evidence)
    table = pd.concat([base.reindex(CLASSICAL), neural.reindex(columns=base.columns)])
    table = table.dropna(how="all")  # a detector that was not run on this dataset has no row
    metric_digits = TABLES[label][2]
    best = {}
    for c in COLUMNS[label]:
        if c in HIGHER_IS_BETTER:
            best[c] = table[c].max()
        elif c in LOWER_IS_BETTER:
            best[c] = table[c].min()
    lines = []
    present = list(table.index)
    for name in present:
        cells = []
        for c in COLUMNS[label]:
            value = table.loc[name, c]
            if pd.isna(value):
                cells.append("--")
                continue
            digits = (
                metric_digits
                if c in HIGHER_IS_BETTER
                else 1
                if c == "flagged_pct"
                else TIME_DECIMALS[label]
            )
            text = f"{value:.{digits}f}"
            if c in best and round(value, digits) == round(best[c], digits):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        families = [n for n in present if n in CLASSICAL]
        if name in (families[2], families[-1]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_rows__mutmut_orig(label: str, evidence: Path = EVIDENCE) -> str:
    """The body of a table: one line per detector, the best value of each column in bold."""
    base = classical_means(label, evidence)
    neural = neural_means(label, evidence)
    table = pd.concat([base.reindex(CLASSICAL), neural.reindex(columns=base.columns)])
    table = table.dropna(how="all")  # a detector that was not run on this dataset has no row
    metric_digits = TABLES[label][2]
    best = {}
    for c in COLUMNS[label]:
        if c in HIGHER_IS_BETTER:
            best[c] = table[c].max()
        elif c in LOWER_IS_BETTER:
            best[c] = table[c].min()
    lines = []
    present = list(table.index)
    for name in present:
        cells = []
        for c in COLUMNS[label]:
            value = table.loc[name, c]
            if pd.isna(value):
                cells.append("--")
                continue
            digits = (
                metric_digits
                if c in HIGHER_IS_BETTER
                else 1
                if c == "flagged_pct"
                else TIME_DECIMALS[label]
            )
            text = f"{value:.{digits}f}"
            if c in best and round(value, digits) == round(best[c], digits):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        families = [n for n in present if n in CLASSICAL]
        if name in (families[2], families[-1]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_rows__mutmut_1(label: str, evidence: Path = EVIDENCE) -> str:
    """The body of a table: one line per detector, the best value of each column in bold."""
    base = None
    neural = neural_means(label, evidence)
    table = pd.concat([base.reindex(CLASSICAL), neural.reindex(columns=base.columns)])
    table = table.dropna(how="all")  # a detector that was not run on this dataset has no row
    metric_digits = TABLES[label][2]
    best = {}
    for c in COLUMNS[label]:
        if c in HIGHER_IS_BETTER:
            best[c] = table[c].max()
        elif c in LOWER_IS_BETTER:
            best[c] = table[c].min()
    lines = []
    present = list(table.index)
    for name in present:
        cells = []
        for c in COLUMNS[label]:
            value = table.loc[name, c]
            if pd.isna(value):
                cells.append("--")
                continue
            digits = (
                metric_digits
                if c in HIGHER_IS_BETTER
                else 1
                if c == "flagged_pct"
                else TIME_DECIMALS[label]
            )
            text = f"{value:.{digits}f}"
            if c in best and round(value, digits) == round(best[c], digits):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        families = [n for n in present if n in CLASSICAL]
        if name in (families[2], families[-1]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_rows__mutmut_2(label: str, evidence: Path = EVIDENCE) -> str:
    """The body of a table: one line per detector, the best value of each column in bold."""
    base = classical_means(None, evidence)
    neural = neural_means(label, evidence)
    table = pd.concat([base.reindex(CLASSICAL), neural.reindex(columns=base.columns)])
    table = table.dropna(how="all")  # a detector that was not run on this dataset has no row
    metric_digits = TABLES[label][2]
    best = {}
    for c in COLUMNS[label]:
        if c in HIGHER_IS_BETTER:
            best[c] = table[c].max()
        elif c in LOWER_IS_BETTER:
            best[c] = table[c].min()
    lines = []
    present = list(table.index)
    for name in present:
        cells = []
        for c in COLUMNS[label]:
            value = table.loc[name, c]
            if pd.isna(value):
                cells.append("--")
                continue
            digits = (
                metric_digits
                if c in HIGHER_IS_BETTER
                else 1
                if c == "flagged_pct"
                else TIME_DECIMALS[label]
            )
            text = f"{value:.{digits}f}"
            if c in best and round(value, digits) == round(best[c], digits):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        families = [n for n in present if n in CLASSICAL]
        if name in (families[2], families[-1]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_rows__mutmut_3(label: str, evidence: Path = EVIDENCE) -> str:
    """The body of a table: one line per detector, the best value of each column in bold."""
    base = classical_means(label, None)
    neural = neural_means(label, evidence)
    table = pd.concat([base.reindex(CLASSICAL), neural.reindex(columns=base.columns)])
    table = table.dropna(how="all")  # a detector that was not run on this dataset has no row
    metric_digits = TABLES[label][2]
    best = {}
    for c in COLUMNS[label]:
        if c in HIGHER_IS_BETTER:
            best[c] = table[c].max()
        elif c in LOWER_IS_BETTER:
            best[c] = table[c].min()
    lines = []
    present = list(table.index)
    for name in present:
        cells = []
        for c in COLUMNS[label]:
            value = table.loc[name, c]
            if pd.isna(value):
                cells.append("--")
                continue
            digits = (
                metric_digits
                if c in HIGHER_IS_BETTER
                else 1
                if c == "flagged_pct"
                else TIME_DECIMALS[label]
            )
            text = f"{value:.{digits}f}"
            if c in best and round(value, digits) == round(best[c], digits):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        families = [n for n in present if n in CLASSICAL]
        if name in (families[2], families[-1]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_rows__mutmut_4(label: str, evidence: Path = EVIDENCE) -> str:
    """The body of a table: one line per detector, the best value of each column in bold."""
    base = classical_means(evidence)
    neural = neural_means(label, evidence)
    table = pd.concat([base.reindex(CLASSICAL), neural.reindex(columns=base.columns)])
    table = table.dropna(how="all")  # a detector that was not run on this dataset has no row
    metric_digits = TABLES[label][2]
    best = {}
    for c in COLUMNS[label]:
        if c in HIGHER_IS_BETTER:
            best[c] = table[c].max()
        elif c in LOWER_IS_BETTER:
            best[c] = table[c].min()
    lines = []
    present = list(table.index)
    for name in present:
        cells = []
        for c in COLUMNS[label]:
            value = table.loc[name, c]
            if pd.isna(value):
                cells.append("--")
                continue
            digits = (
                metric_digits
                if c in HIGHER_IS_BETTER
                else 1
                if c == "flagged_pct"
                else TIME_DECIMALS[label]
            )
            text = f"{value:.{digits}f}"
            if c in best and round(value, digits) == round(best[c], digits):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        families = [n for n in present if n in CLASSICAL]
        if name in (families[2], families[-1]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_rows__mutmut_5(label: str, evidence: Path = EVIDENCE) -> str:
    """The body of a table: one line per detector, the best value of each column in bold."""
    base = classical_means(label, )
    neural = neural_means(label, evidence)
    table = pd.concat([base.reindex(CLASSICAL), neural.reindex(columns=base.columns)])
    table = table.dropna(how="all")  # a detector that was not run on this dataset has no row
    metric_digits = TABLES[label][2]
    best = {}
    for c in COLUMNS[label]:
        if c in HIGHER_IS_BETTER:
            best[c] = table[c].max()
        elif c in LOWER_IS_BETTER:
            best[c] = table[c].min()
    lines = []
    present = list(table.index)
    for name in present:
        cells = []
        for c in COLUMNS[label]:
            value = table.loc[name, c]
            if pd.isna(value):
                cells.append("--")
                continue
            digits = (
                metric_digits
                if c in HIGHER_IS_BETTER
                else 1
                if c == "flagged_pct"
                else TIME_DECIMALS[label]
            )
            text = f"{value:.{digits}f}"
            if c in best and round(value, digits) == round(best[c], digits):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        families = [n for n in present if n in CLASSICAL]
        if name in (families[2], families[-1]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_rows__mutmut_6(label: str, evidence: Path = EVIDENCE) -> str:
    """The body of a table: one line per detector, the best value of each column in bold."""
    base = classical_means(label, evidence)
    neural = None
    table = pd.concat([base.reindex(CLASSICAL), neural.reindex(columns=base.columns)])
    table = table.dropna(how="all")  # a detector that was not run on this dataset has no row
    metric_digits = TABLES[label][2]
    best = {}
    for c in COLUMNS[label]:
        if c in HIGHER_IS_BETTER:
            best[c] = table[c].max()
        elif c in LOWER_IS_BETTER:
            best[c] = table[c].min()
    lines = []
    present = list(table.index)
    for name in present:
        cells = []
        for c in COLUMNS[label]:
            value = table.loc[name, c]
            if pd.isna(value):
                cells.append("--")
                continue
            digits = (
                metric_digits
                if c in HIGHER_IS_BETTER
                else 1
                if c == "flagged_pct"
                else TIME_DECIMALS[label]
            )
            text = f"{value:.{digits}f}"
            if c in best and round(value, digits) == round(best[c], digits):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        families = [n for n in present if n in CLASSICAL]
        if name in (families[2], families[-1]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_rows__mutmut_7(label: str, evidence: Path = EVIDENCE) -> str:
    """The body of a table: one line per detector, the best value of each column in bold."""
    base = classical_means(label, evidence)
    neural = neural_means(None, evidence)
    table = pd.concat([base.reindex(CLASSICAL), neural.reindex(columns=base.columns)])
    table = table.dropna(how="all")  # a detector that was not run on this dataset has no row
    metric_digits = TABLES[label][2]
    best = {}
    for c in COLUMNS[label]:
        if c in HIGHER_IS_BETTER:
            best[c] = table[c].max()
        elif c in LOWER_IS_BETTER:
            best[c] = table[c].min()
    lines = []
    present = list(table.index)
    for name in present:
        cells = []
        for c in COLUMNS[label]:
            value = table.loc[name, c]
            if pd.isna(value):
                cells.append("--")
                continue
            digits = (
                metric_digits
                if c in HIGHER_IS_BETTER
                else 1
                if c == "flagged_pct"
                else TIME_DECIMALS[label]
            )
            text = f"{value:.{digits}f}"
            if c in best and round(value, digits) == round(best[c], digits):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        families = [n for n in present if n in CLASSICAL]
        if name in (families[2], families[-1]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_rows__mutmut_8(label: str, evidence: Path = EVIDENCE) -> str:
    """The body of a table: one line per detector, the best value of each column in bold."""
    base = classical_means(label, evidence)
    neural = neural_means(label, None)
    table = pd.concat([base.reindex(CLASSICAL), neural.reindex(columns=base.columns)])
    table = table.dropna(how="all")  # a detector that was not run on this dataset has no row
    metric_digits = TABLES[label][2]
    best = {}
    for c in COLUMNS[label]:
        if c in HIGHER_IS_BETTER:
            best[c] = table[c].max()
        elif c in LOWER_IS_BETTER:
            best[c] = table[c].min()
    lines = []
    present = list(table.index)
    for name in present:
        cells = []
        for c in COLUMNS[label]:
            value = table.loc[name, c]
            if pd.isna(value):
                cells.append("--")
                continue
            digits = (
                metric_digits
                if c in HIGHER_IS_BETTER
                else 1
                if c == "flagged_pct"
                else TIME_DECIMALS[label]
            )
            text = f"{value:.{digits}f}"
            if c in best and round(value, digits) == round(best[c], digits):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        families = [n for n in present if n in CLASSICAL]
        if name in (families[2], families[-1]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_rows__mutmut_9(label: str, evidence: Path = EVIDENCE) -> str:
    """The body of a table: one line per detector, the best value of each column in bold."""
    base = classical_means(label, evidence)
    neural = neural_means(evidence)
    table = pd.concat([base.reindex(CLASSICAL), neural.reindex(columns=base.columns)])
    table = table.dropna(how="all")  # a detector that was not run on this dataset has no row
    metric_digits = TABLES[label][2]
    best = {}
    for c in COLUMNS[label]:
        if c in HIGHER_IS_BETTER:
            best[c] = table[c].max()
        elif c in LOWER_IS_BETTER:
            best[c] = table[c].min()
    lines = []
    present = list(table.index)
    for name in present:
        cells = []
        for c in COLUMNS[label]:
            value = table.loc[name, c]
            if pd.isna(value):
                cells.append("--")
                continue
            digits = (
                metric_digits
                if c in HIGHER_IS_BETTER
                else 1
                if c == "flagged_pct"
                else TIME_DECIMALS[label]
            )
            text = f"{value:.{digits}f}"
            if c in best and round(value, digits) == round(best[c], digits):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        families = [n for n in present if n in CLASSICAL]
        if name in (families[2], families[-1]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_rows__mutmut_10(label: str, evidence: Path = EVIDENCE) -> str:
    """The body of a table: one line per detector, the best value of each column in bold."""
    base = classical_means(label, evidence)
    neural = neural_means(label, )
    table = pd.concat([base.reindex(CLASSICAL), neural.reindex(columns=base.columns)])
    table = table.dropna(how="all")  # a detector that was not run on this dataset has no row
    metric_digits = TABLES[label][2]
    best = {}
    for c in COLUMNS[label]:
        if c in HIGHER_IS_BETTER:
            best[c] = table[c].max()
        elif c in LOWER_IS_BETTER:
            best[c] = table[c].min()
    lines = []
    present = list(table.index)
    for name in present:
        cells = []
        for c in COLUMNS[label]:
            value = table.loc[name, c]
            if pd.isna(value):
                cells.append("--")
                continue
            digits = (
                metric_digits
                if c in HIGHER_IS_BETTER
                else 1
                if c == "flagged_pct"
                else TIME_DECIMALS[label]
            )
            text = f"{value:.{digits}f}"
            if c in best and round(value, digits) == round(best[c], digits):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        families = [n for n in present if n in CLASSICAL]
        if name in (families[2], families[-1]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_rows__mutmut_11(label: str, evidence: Path = EVIDENCE) -> str:
    """The body of a table: one line per detector, the best value of each column in bold."""
    base = classical_means(label, evidence)
    neural = neural_means(label, evidence)
    table = None
    table = table.dropna(how="all")  # a detector that was not run on this dataset has no row
    metric_digits = TABLES[label][2]
    best = {}
    for c in COLUMNS[label]:
        if c in HIGHER_IS_BETTER:
            best[c] = table[c].max()
        elif c in LOWER_IS_BETTER:
            best[c] = table[c].min()
    lines = []
    present = list(table.index)
    for name in present:
        cells = []
        for c in COLUMNS[label]:
            value = table.loc[name, c]
            if pd.isna(value):
                cells.append("--")
                continue
            digits = (
                metric_digits
                if c in HIGHER_IS_BETTER
                else 1
                if c == "flagged_pct"
                else TIME_DECIMALS[label]
            )
            text = f"{value:.{digits}f}"
            if c in best and round(value, digits) == round(best[c], digits):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        families = [n for n in present if n in CLASSICAL]
        if name in (families[2], families[-1]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_rows__mutmut_12(label: str, evidence: Path = EVIDENCE) -> str:
    """The body of a table: one line per detector, the best value of each column in bold."""
    base = classical_means(label, evidence)
    neural = neural_means(label, evidence)
    table = pd.concat(None)
    table = table.dropna(how="all")  # a detector that was not run on this dataset has no row
    metric_digits = TABLES[label][2]
    best = {}
    for c in COLUMNS[label]:
        if c in HIGHER_IS_BETTER:
            best[c] = table[c].max()
        elif c in LOWER_IS_BETTER:
            best[c] = table[c].min()
    lines = []
    present = list(table.index)
    for name in present:
        cells = []
        for c in COLUMNS[label]:
            value = table.loc[name, c]
            if pd.isna(value):
                cells.append("--")
                continue
            digits = (
                metric_digits
                if c in HIGHER_IS_BETTER
                else 1
                if c == "flagged_pct"
                else TIME_DECIMALS[label]
            )
            text = f"{value:.{digits}f}"
            if c in best and round(value, digits) == round(best[c], digits):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        families = [n for n in present if n in CLASSICAL]
        if name in (families[2], families[-1]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_rows__mutmut_13(label: str, evidence: Path = EVIDENCE) -> str:
    """The body of a table: one line per detector, the best value of each column in bold."""
    base = classical_means(label, evidence)
    neural = neural_means(label, evidence)
    table = pd.concat([base.reindex(None), neural.reindex(columns=base.columns)])
    table = table.dropna(how="all")  # a detector that was not run on this dataset has no row
    metric_digits = TABLES[label][2]
    best = {}
    for c in COLUMNS[label]:
        if c in HIGHER_IS_BETTER:
            best[c] = table[c].max()
        elif c in LOWER_IS_BETTER:
            best[c] = table[c].min()
    lines = []
    present = list(table.index)
    for name in present:
        cells = []
        for c in COLUMNS[label]:
            value = table.loc[name, c]
            if pd.isna(value):
                cells.append("--")
                continue
            digits = (
                metric_digits
                if c in HIGHER_IS_BETTER
                else 1
                if c == "flagged_pct"
                else TIME_DECIMALS[label]
            )
            text = f"{value:.{digits}f}"
            if c in best and round(value, digits) == round(best[c], digits):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        families = [n for n in present if n in CLASSICAL]
        if name in (families[2], families[-1]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_rows__mutmut_14(label: str, evidence: Path = EVIDENCE) -> str:
    """The body of a table: one line per detector, the best value of each column in bold."""
    base = classical_means(label, evidence)
    neural = neural_means(label, evidence)
    table = pd.concat([base.reindex(CLASSICAL), neural.reindex(columns=None)])
    table = table.dropna(how="all")  # a detector that was not run on this dataset has no row
    metric_digits = TABLES[label][2]
    best = {}
    for c in COLUMNS[label]:
        if c in HIGHER_IS_BETTER:
            best[c] = table[c].max()
        elif c in LOWER_IS_BETTER:
            best[c] = table[c].min()
    lines = []
    present = list(table.index)
    for name in present:
        cells = []
        for c in COLUMNS[label]:
            value = table.loc[name, c]
            if pd.isna(value):
                cells.append("--")
                continue
            digits = (
                metric_digits
                if c in HIGHER_IS_BETTER
                else 1
                if c == "flagged_pct"
                else TIME_DECIMALS[label]
            )
            text = f"{value:.{digits}f}"
            if c in best and round(value, digits) == round(best[c], digits):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        families = [n for n in present if n in CLASSICAL]
        if name in (families[2], families[-1]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_rows__mutmut_15(label: str, evidence: Path = EVIDENCE) -> str:
    """The body of a table: one line per detector, the best value of each column in bold."""
    base = classical_means(label, evidence)
    neural = neural_means(label, evidence)
    table = pd.concat([base.reindex(CLASSICAL), neural.reindex(columns=base.columns)])
    table = None  # a detector that was not run on this dataset has no row
    metric_digits = TABLES[label][2]
    best = {}
    for c in COLUMNS[label]:
        if c in HIGHER_IS_BETTER:
            best[c] = table[c].max()
        elif c in LOWER_IS_BETTER:
            best[c] = table[c].min()
    lines = []
    present = list(table.index)
    for name in present:
        cells = []
        for c in COLUMNS[label]:
            value = table.loc[name, c]
            if pd.isna(value):
                cells.append("--")
                continue
            digits = (
                metric_digits
                if c in HIGHER_IS_BETTER
                else 1
                if c == "flagged_pct"
                else TIME_DECIMALS[label]
            )
            text = f"{value:.{digits}f}"
            if c in best and round(value, digits) == round(best[c], digits):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        families = [n for n in present if n in CLASSICAL]
        if name in (families[2], families[-1]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_rows__mutmut_16(label: str, evidence: Path = EVIDENCE) -> str:
    """The body of a table: one line per detector, the best value of each column in bold."""
    base = classical_means(label, evidence)
    neural = neural_means(label, evidence)
    table = pd.concat([base.reindex(CLASSICAL), neural.reindex(columns=base.columns)])
    table = table.dropna(how=None)  # a detector that was not run on this dataset has no row
    metric_digits = TABLES[label][2]
    best = {}
    for c in COLUMNS[label]:
        if c in HIGHER_IS_BETTER:
            best[c] = table[c].max()
        elif c in LOWER_IS_BETTER:
            best[c] = table[c].min()
    lines = []
    present = list(table.index)
    for name in present:
        cells = []
        for c in COLUMNS[label]:
            value = table.loc[name, c]
            if pd.isna(value):
                cells.append("--")
                continue
            digits = (
                metric_digits
                if c in HIGHER_IS_BETTER
                else 1
                if c == "flagged_pct"
                else TIME_DECIMALS[label]
            )
            text = f"{value:.{digits}f}"
            if c in best and round(value, digits) == round(best[c], digits):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        families = [n for n in present if n in CLASSICAL]
        if name in (families[2], families[-1]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_rows__mutmut_17(label: str, evidence: Path = EVIDENCE) -> str:
    """The body of a table: one line per detector, the best value of each column in bold."""
    base = classical_means(label, evidence)
    neural = neural_means(label, evidence)
    table = pd.concat([base.reindex(CLASSICAL), neural.reindex(columns=base.columns)])
    table = table.dropna(how="XXallXX")  # a detector that was not run on this dataset has no row
    metric_digits = TABLES[label][2]
    best = {}
    for c in COLUMNS[label]:
        if c in HIGHER_IS_BETTER:
            best[c] = table[c].max()
        elif c in LOWER_IS_BETTER:
            best[c] = table[c].min()
    lines = []
    present = list(table.index)
    for name in present:
        cells = []
        for c in COLUMNS[label]:
            value = table.loc[name, c]
            if pd.isna(value):
                cells.append("--")
                continue
            digits = (
                metric_digits
                if c in HIGHER_IS_BETTER
                else 1
                if c == "flagged_pct"
                else TIME_DECIMALS[label]
            )
            text = f"{value:.{digits}f}"
            if c in best and round(value, digits) == round(best[c], digits):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        families = [n for n in present if n in CLASSICAL]
        if name in (families[2], families[-1]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_rows__mutmut_18(label: str, evidence: Path = EVIDENCE) -> str:
    """The body of a table: one line per detector, the best value of each column in bold."""
    base = classical_means(label, evidence)
    neural = neural_means(label, evidence)
    table = pd.concat([base.reindex(CLASSICAL), neural.reindex(columns=base.columns)])
    table = table.dropna(how="ALL")  # a detector that was not run on this dataset has no row
    metric_digits = TABLES[label][2]
    best = {}
    for c in COLUMNS[label]:
        if c in HIGHER_IS_BETTER:
            best[c] = table[c].max()
        elif c in LOWER_IS_BETTER:
            best[c] = table[c].min()
    lines = []
    present = list(table.index)
    for name in present:
        cells = []
        for c in COLUMNS[label]:
            value = table.loc[name, c]
            if pd.isna(value):
                cells.append("--")
                continue
            digits = (
                metric_digits
                if c in HIGHER_IS_BETTER
                else 1
                if c == "flagged_pct"
                else TIME_DECIMALS[label]
            )
            text = f"{value:.{digits}f}"
            if c in best and round(value, digits) == round(best[c], digits):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        families = [n for n in present if n in CLASSICAL]
        if name in (families[2], families[-1]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_rows__mutmut_19(label: str, evidence: Path = EVIDENCE) -> str:
    """The body of a table: one line per detector, the best value of each column in bold."""
    base = classical_means(label, evidence)
    neural = neural_means(label, evidence)
    table = pd.concat([base.reindex(CLASSICAL), neural.reindex(columns=base.columns)])
    table = table.dropna(how="all")  # a detector that was not run on this dataset has no row
    metric_digits = None
    best = {}
    for c in COLUMNS[label]:
        if c in HIGHER_IS_BETTER:
            best[c] = table[c].max()
        elif c in LOWER_IS_BETTER:
            best[c] = table[c].min()
    lines = []
    present = list(table.index)
    for name in present:
        cells = []
        for c in COLUMNS[label]:
            value = table.loc[name, c]
            if pd.isna(value):
                cells.append("--")
                continue
            digits = (
                metric_digits
                if c in HIGHER_IS_BETTER
                else 1
                if c == "flagged_pct"
                else TIME_DECIMALS[label]
            )
            text = f"{value:.{digits}f}"
            if c in best and round(value, digits) == round(best[c], digits):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        families = [n for n in present if n in CLASSICAL]
        if name in (families[2], families[-1]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_rows__mutmut_20(label: str, evidence: Path = EVIDENCE) -> str:
    """The body of a table: one line per detector, the best value of each column in bold."""
    base = classical_means(label, evidence)
    neural = neural_means(label, evidence)
    table = pd.concat([base.reindex(CLASSICAL), neural.reindex(columns=base.columns)])
    table = table.dropna(how="all")  # a detector that was not run on this dataset has no row
    metric_digits = TABLES[label][3]
    best = {}
    for c in COLUMNS[label]:
        if c in HIGHER_IS_BETTER:
            best[c] = table[c].max()
        elif c in LOWER_IS_BETTER:
            best[c] = table[c].min()
    lines = []
    present = list(table.index)
    for name in present:
        cells = []
        for c in COLUMNS[label]:
            value = table.loc[name, c]
            if pd.isna(value):
                cells.append("--")
                continue
            digits = (
                metric_digits
                if c in HIGHER_IS_BETTER
                else 1
                if c == "flagged_pct"
                else TIME_DECIMALS[label]
            )
            text = f"{value:.{digits}f}"
            if c in best and round(value, digits) == round(best[c], digits):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        families = [n for n in present if n in CLASSICAL]
        if name in (families[2], families[-1]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_rows__mutmut_21(label: str, evidence: Path = EVIDENCE) -> str:
    """The body of a table: one line per detector, the best value of each column in bold."""
    base = classical_means(label, evidence)
    neural = neural_means(label, evidence)
    table = pd.concat([base.reindex(CLASSICAL), neural.reindex(columns=base.columns)])
    table = table.dropna(how="all")  # a detector that was not run on this dataset has no row
    metric_digits = TABLES[label][2]
    best = None
    for c in COLUMNS[label]:
        if c in HIGHER_IS_BETTER:
            best[c] = table[c].max()
        elif c in LOWER_IS_BETTER:
            best[c] = table[c].min()
    lines = []
    present = list(table.index)
    for name in present:
        cells = []
        for c in COLUMNS[label]:
            value = table.loc[name, c]
            if pd.isna(value):
                cells.append("--")
                continue
            digits = (
                metric_digits
                if c in HIGHER_IS_BETTER
                else 1
                if c == "flagged_pct"
                else TIME_DECIMALS[label]
            )
            text = f"{value:.{digits}f}"
            if c in best and round(value, digits) == round(best[c], digits):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        families = [n for n in present if n in CLASSICAL]
        if name in (families[2], families[-1]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_rows__mutmut_22(label: str, evidence: Path = EVIDENCE) -> str:
    """The body of a table: one line per detector, the best value of each column in bold."""
    base = classical_means(label, evidence)
    neural = neural_means(label, evidence)
    table = pd.concat([base.reindex(CLASSICAL), neural.reindex(columns=base.columns)])
    table = table.dropna(how="all")  # a detector that was not run on this dataset has no row
    metric_digits = TABLES[label][2]
    best = {}
    for c in COLUMNS[label]:
        if c not in HIGHER_IS_BETTER:
            best[c] = table[c].max()
        elif c in LOWER_IS_BETTER:
            best[c] = table[c].min()
    lines = []
    present = list(table.index)
    for name in present:
        cells = []
        for c in COLUMNS[label]:
            value = table.loc[name, c]
            if pd.isna(value):
                cells.append("--")
                continue
            digits = (
                metric_digits
                if c in HIGHER_IS_BETTER
                else 1
                if c == "flagged_pct"
                else TIME_DECIMALS[label]
            )
            text = f"{value:.{digits}f}"
            if c in best and round(value, digits) == round(best[c], digits):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        families = [n for n in present if n in CLASSICAL]
        if name in (families[2], families[-1]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_rows__mutmut_23(label: str, evidence: Path = EVIDENCE) -> str:
    """The body of a table: one line per detector, the best value of each column in bold."""
    base = classical_means(label, evidence)
    neural = neural_means(label, evidence)
    table = pd.concat([base.reindex(CLASSICAL), neural.reindex(columns=base.columns)])
    table = table.dropna(how="all")  # a detector that was not run on this dataset has no row
    metric_digits = TABLES[label][2]
    best = {}
    for c in COLUMNS[label]:
        if c in HIGHER_IS_BETTER:
            best[c] = None
        elif c in LOWER_IS_BETTER:
            best[c] = table[c].min()
    lines = []
    present = list(table.index)
    for name in present:
        cells = []
        for c in COLUMNS[label]:
            value = table.loc[name, c]
            if pd.isna(value):
                cells.append("--")
                continue
            digits = (
                metric_digits
                if c in HIGHER_IS_BETTER
                else 1
                if c == "flagged_pct"
                else TIME_DECIMALS[label]
            )
            text = f"{value:.{digits}f}"
            if c in best and round(value, digits) == round(best[c], digits):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        families = [n for n in present if n in CLASSICAL]
        if name in (families[2], families[-1]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_rows__mutmut_24(label: str, evidence: Path = EVIDENCE) -> str:
    """The body of a table: one line per detector, the best value of each column in bold."""
    base = classical_means(label, evidence)
    neural = neural_means(label, evidence)
    table = pd.concat([base.reindex(CLASSICAL), neural.reindex(columns=base.columns)])
    table = table.dropna(how="all")  # a detector that was not run on this dataset has no row
    metric_digits = TABLES[label][2]
    best = {}
    for c in COLUMNS[label]:
        if c in HIGHER_IS_BETTER:
            best[c] = table[c].max()
        elif c not in LOWER_IS_BETTER:
            best[c] = table[c].min()
    lines = []
    present = list(table.index)
    for name in present:
        cells = []
        for c in COLUMNS[label]:
            value = table.loc[name, c]
            if pd.isna(value):
                cells.append("--")
                continue
            digits = (
                metric_digits
                if c in HIGHER_IS_BETTER
                else 1
                if c == "flagged_pct"
                else TIME_DECIMALS[label]
            )
            text = f"{value:.{digits}f}"
            if c in best and round(value, digits) == round(best[c], digits):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        families = [n for n in present if n in CLASSICAL]
        if name in (families[2], families[-1]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_rows__mutmut_25(label: str, evidence: Path = EVIDENCE) -> str:
    """The body of a table: one line per detector, the best value of each column in bold."""
    base = classical_means(label, evidence)
    neural = neural_means(label, evidence)
    table = pd.concat([base.reindex(CLASSICAL), neural.reindex(columns=base.columns)])
    table = table.dropna(how="all")  # a detector that was not run on this dataset has no row
    metric_digits = TABLES[label][2]
    best = {}
    for c in COLUMNS[label]:
        if c in HIGHER_IS_BETTER:
            best[c] = table[c].max()
        elif c in LOWER_IS_BETTER:
            best[c] = None
    lines = []
    present = list(table.index)
    for name in present:
        cells = []
        for c in COLUMNS[label]:
            value = table.loc[name, c]
            if pd.isna(value):
                cells.append("--")
                continue
            digits = (
                metric_digits
                if c in HIGHER_IS_BETTER
                else 1
                if c == "flagged_pct"
                else TIME_DECIMALS[label]
            )
            text = f"{value:.{digits}f}"
            if c in best and round(value, digits) == round(best[c], digits):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        families = [n for n in present if n in CLASSICAL]
        if name in (families[2], families[-1]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_rows__mutmut_26(label: str, evidence: Path = EVIDENCE) -> str:
    """The body of a table: one line per detector, the best value of each column in bold."""
    base = classical_means(label, evidence)
    neural = neural_means(label, evidence)
    table = pd.concat([base.reindex(CLASSICAL), neural.reindex(columns=base.columns)])
    table = table.dropna(how="all")  # a detector that was not run on this dataset has no row
    metric_digits = TABLES[label][2]
    best = {}
    for c in COLUMNS[label]:
        if c in HIGHER_IS_BETTER:
            best[c] = table[c].max()
        elif c in LOWER_IS_BETTER:
            best[c] = table[c].min()
    lines = None
    present = list(table.index)
    for name in present:
        cells = []
        for c in COLUMNS[label]:
            value = table.loc[name, c]
            if pd.isna(value):
                cells.append("--")
                continue
            digits = (
                metric_digits
                if c in HIGHER_IS_BETTER
                else 1
                if c == "flagged_pct"
                else TIME_DECIMALS[label]
            )
            text = f"{value:.{digits}f}"
            if c in best and round(value, digits) == round(best[c], digits):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        families = [n for n in present if n in CLASSICAL]
        if name in (families[2], families[-1]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_rows__mutmut_27(label: str, evidence: Path = EVIDENCE) -> str:
    """The body of a table: one line per detector, the best value of each column in bold."""
    base = classical_means(label, evidence)
    neural = neural_means(label, evidence)
    table = pd.concat([base.reindex(CLASSICAL), neural.reindex(columns=base.columns)])
    table = table.dropna(how="all")  # a detector that was not run on this dataset has no row
    metric_digits = TABLES[label][2]
    best = {}
    for c in COLUMNS[label]:
        if c in HIGHER_IS_BETTER:
            best[c] = table[c].max()
        elif c in LOWER_IS_BETTER:
            best[c] = table[c].min()
    lines = []
    present = None
    for name in present:
        cells = []
        for c in COLUMNS[label]:
            value = table.loc[name, c]
            if pd.isna(value):
                cells.append("--")
                continue
            digits = (
                metric_digits
                if c in HIGHER_IS_BETTER
                else 1
                if c == "flagged_pct"
                else TIME_DECIMALS[label]
            )
            text = f"{value:.{digits}f}"
            if c in best and round(value, digits) == round(best[c], digits):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        families = [n for n in present if n in CLASSICAL]
        if name in (families[2], families[-1]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_rows__mutmut_28(label: str, evidence: Path = EVIDENCE) -> str:
    """The body of a table: one line per detector, the best value of each column in bold."""
    base = classical_means(label, evidence)
    neural = neural_means(label, evidence)
    table = pd.concat([base.reindex(CLASSICAL), neural.reindex(columns=base.columns)])
    table = table.dropna(how="all")  # a detector that was not run on this dataset has no row
    metric_digits = TABLES[label][2]
    best = {}
    for c in COLUMNS[label]:
        if c in HIGHER_IS_BETTER:
            best[c] = table[c].max()
        elif c in LOWER_IS_BETTER:
            best[c] = table[c].min()
    lines = []
    present = list(None)
    for name in present:
        cells = []
        for c in COLUMNS[label]:
            value = table.loc[name, c]
            if pd.isna(value):
                cells.append("--")
                continue
            digits = (
                metric_digits
                if c in HIGHER_IS_BETTER
                else 1
                if c == "flagged_pct"
                else TIME_DECIMALS[label]
            )
            text = f"{value:.{digits}f}"
            if c in best and round(value, digits) == round(best[c], digits):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        families = [n for n in present if n in CLASSICAL]
        if name in (families[2], families[-1]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_rows__mutmut_29(label: str, evidence: Path = EVIDENCE) -> str:
    """The body of a table: one line per detector, the best value of each column in bold."""
    base = classical_means(label, evidence)
    neural = neural_means(label, evidence)
    table = pd.concat([base.reindex(CLASSICAL), neural.reindex(columns=base.columns)])
    table = table.dropna(how="all")  # a detector that was not run on this dataset has no row
    metric_digits = TABLES[label][2]
    best = {}
    for c in COLUMNS[label]:
        if c in HIGHER_IS_BETTER:
            best[c] = table[c].max()
        elif c in LOWER_IS_BETTER:
            best[c] = table[c].min()
    lines = []
    present = list(table.index)
    for name in present:
        cells = None
        for c in COLUMNS[label]:
            value = table.loc[name, c]
            if pd.isna(value):
                cells.append("--")
                continue
            digits = (
                metric_digits
                if c in HIGHER_IS_BETTER
                else 1
                if c == "flagged_pct"
                else TIME_DECIMALS[label]
            )
            text = f"{value:.{digits}f}"
            if c in best and round(value, digits) == round(best[c], digits):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        families = [n for n in present if n in CLASSICAL]
        if name in (families[2], families[-1]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_rows__mutmut_30(label: str, evidence: Path = EVIDENCE) -> str:
    """The body of a table: one line per detector, the best value of each column in bold."""
    base = classical_means(label, evidence)
    neural = neural_means(label, evidence)
    table = pd.concat([base.reindex(CLASSICAL), neural.reindex(columns=base.columns)])
    table = table.dropna(how="all")  # a detector that was not run on this dataset has no row
    metric_digits = TABLES[label][2]
    best = {}
    for c in COLUMNS[label]:
        if c in HIGHER_IS_BETTER:
            best[c] = table[c].max()
        elif c in LOWER_IS_BETTER:
            best[c] = table[c].min()
    lines = []
    present = list(table.index)
    for name in present:
        cells = []
        for c in COLUMNS[label]:
            value = None
            if pd.isna(value):
                cells.append("--")
                continue
            digits = (
                metric_digits
                if c in HIGHER_IS_BETTER
                else 1
                if c == "flagged_pct"
                else TIME_DECIMALS[label]
            )
            text = f"{value:.{digits}f}"
            if c in best and round(value, digits) == round(best[c], digits):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        families = [n for n in present if n in CLASSICAL]
        if name in (families[2], families[-1]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_rows__mutmut_31(label: str, evidence: Path = EVIDENCE) -> str:
    """The body of a table: one line per detector, the best value of each column in bold."""
    base = classical_means(label, evidence)
    neural = neural_means(label, evidence)
    table = pd.concat([base.reindex(CLASSICAL), neural.reindex(columns=base.columns)])
    table = table.dropna(how="all")  # a detector that was not run on this dataset has no row
    metric_digits = TABLES[label][2]
    best = {}
    for c in COLUMNS[label]:
        if c in HIGHER_IS_BETTER:
            best[c] = table[c].max()
        elif c in LOWER_IS_BETTER:
            best[c] = table[c].min()
    lines = []
    present = list(table.index)
    for name in present:
        cells = []
        for c in COLUMNS[label]:
            value = table.loc[name, c]
            if pd.isna(None):
                cells.append("--")
                continue
            digits = (
                metric_digits
                if c in HIGHER_IS_BETTER
                else 1
                if c == "flagged_pct"
                else TIME_DECIMALS[label]
            )
            text = f"{value:.{digits}f}"
            if c in best and round(value, digits) == round(best[c], digits):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        families = [n for n in present if n in CLASSICAL]
        if name in (families[2], families[-1]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_rows__mutmut_32(label: str, evidence: Path = EVIDENCE) -> str:
    """The body of a table: one line per detector, the best value of each column in bold."""
    base = classical_means(label, evidence)
    neural = neural_means(label, evidence)
    table = pd.concat([base.reindex(CLASSICAL), neural.reindex(columns=base.columns)])
    table = table.dropna(how="all")  # a detector that was not run on this dataset has no row
    metric_digits = TABLES[label][2]
    best = {}
    for c in COLUMNS[label]:
        if c in HIGHER_IS_BETTER:
            best[c] = table[c].max()
        elif c in LOWER_IS_BETTER:
            best[c] = table[c].min()
    lines = []
    present = list(table.index)
    for name in present:
        cells = []
        for c in COLUMNS[label]:
            value = table.loc[name, c]
            if pd.isna(value):
                cells.append(None)
                continue
            digits = (
                metric_digits
                if c in HIGHER_IS_BETTER
                else 1
                if c == "flagged_pct"
                else TIME_DECIMALS[label]
            )
            text = f"{value:.{digits}f}"
            if c in best and round(value, digits) == round(best[c], digits):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        families = [n for n in present if n in CLASSICAL]
        if name in (families[2], families[-1]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_rows__mutmut_33(label: str, evidence: Path = EVIDENCE) -> str:
    """The body of a table: one line per detector, the best value of each column in bold."""
    base = classical_means(label, evidence)
    neural = neural_means(label, evidence)
    table = pd.concat([base.reindex(CLASSICAL), neural.reindex(columns=base.columns)])
    table = table.dropna(how="all")  # a detector that was not run on this dataset has no row
    metric_digits = TABLES[label][2]
    best = {}
    for c in COLUMNS[label]:
        if c in HIGHER_IS_BETTER:
            best[c] = table[c].max()
        elif c in LOWER_IS_BETTER:
            best[c] = table[c].min()
    lines = []
    present = list(table.index)
    for name in present:
        cells = []
        for c in COLUMNS[label]:
            value = table.loc[name, c]
            if pd.isna(value):
                cells.append("XX--XX")
                continue
            digits = (
                metric_digits
                if c in HIGHER_IS_BETTER
                else 1
                if c == "flagged_pct"
                else TIME_DECIMALS[label]
            )
            text = f"{value:.{digits}f}"
            if c in best and round(value, digits) == round(best[c], digits):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        families = [n for n in present if n in CLASSICAL]
        if name in (families[2], families[-1]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_rows__mutmut_34(label: str, evidence: Path = EVIDENCE) -> str:
    """The body of a table: one line per detector, the best value of each column in bold."""
    base = classical_means(label, evidence)
    neural = neural_means(label, evidence)
    table = pd.concat([base.reindex(CLASSICAL), neural.reindex(columns=base.columns)])
    table = table.dropna(how="all")  # a detector that was not run on this dataset has no row
    metric_digits = TABLES[label][2]
    best = {}
    for c in COLUMNS[label]:
        if c in HIGHER_IS_BETTER:
            best[c] = table[c].max()
        elif c in LOWER_IS_BETTER:
            best[c] = table[c].min()
    lines = []
    present = list(table.index)
    for name in present:
        cells = []
        for c in COLUMNS[label]:
            value = table.loc[name, c]
            if pd.isna(value):
                cells.append("--")
                break
            digits = (
                metric_digits
                if c in HIGHER_IS_BETTER
                else 1
                if c == "flagged_pct"
                else TIME_DECIMALS[label]
            )
            text = f"{value:.{digits}f}"
            if c in best and round(value, digits) == round(best[c], digits):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        families = [n for n in present if n in CLASSICAL]
        if name in (families[2], families[-1]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_rows__mutmut_35(label: str, evidence: Path = EVIDENCE) -> str:
    """The body of a table: one line per detector, the best value of each column in bold."""
    base = classical_means(label, evidence)
    neural = neural_means(label, evidence)
    table = pd.concat([base.reindex(CLASSICAL), neural.reindex(columns=base.columns)])
    table = table.dropna(how="all")  # a detector that was not run on this dataset has no row
    metric_digits = TABLES[label][2]
    best = {}
    for c in COLUMNS[label]:
        if c in HIGHER_IS_BETTER:
            best[c] = table[c].max()
        elif c in LOWER_IS_BETTER:
            best[c] = table[c].min()
    lines = []
    present = list(table.index)
    for name in present:
        cells = []
        for c in COLUMNS[label]:
            value = table.loc[name, c]
            if pd.isna(value):
                cells.append("--")
                continue
            digits = None
            text = f"{value:.{digits}f}"
            if c in best and round(value, digits) == round(best[c], digits):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        families = [n for n in present if n in CLASSICAL]
        if name in (families[2], families[-1]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_rows__mutmut_36(label: str, evidence: Path = EVIDENCE) -> str:
    """The body of a table: one line per detector, the best value of each column in bold."""
    base = classical_means(label, evidence)
    neural = neural_means(label, evidence)
    table = pd.concat([base.reindex(CLASSICAL), neural.reindex(columns=base.columns)])
    table = table.dropna(how="all")  # a detector that was not run on this dataset has no row
    metric_digits = TABLES[label][2]
    best = {}
    for c in COLUMNS[label]:
        if c in HIGHER_IS_BETTER:
            best[c] = table[c].max()
        elif c in LOWER_IS_BETTER:
            best[c] = table[c].min()
    lines = []
    present = list(table.index)
    for name in present:
        cells = []
        for c in COLUMNS[label]:
            value = table.loc[name, c]
            if pd.isna(value):
                cells.append("--")
                continue
            digits = (
                metric_digits
                if (c in HIGHER_IS_BETTER) and False
                else 1
                if c == "flagged_pct"
                else TIME_DECIMALS[label]
            )
            text = f"{value:.{digits}f}"
            if c in best and round(value, digits) == round(best[c], digits):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        families = [n for n in present if n in CLASSICAL]
        if name in (families[2], families[-1]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_rows__mutmut_37(label: str, evidence: Path = EVIDENCE) -> str:
    """The body of a table: one line per detector, the best value of each column in bold."""
    base = classical_means(label, evidence)
    neural = neural_means(label, evidence)
    table = pd.concat([base.reindex(CLASSICAL), neural.reindex(columns=base.columns)])
    table = table.dropna(how="all")  # a detector that was not run on this dataset has no row
    metric_digits = TABLES[label][2]
    best = {}
    for c in COLUMNS[label]:
        if c in HIGHER_IS_BETTER:
            best[c] = table[c].max()
        elif c in LOWER_IS_BETTER:
            best[c] = table[c].min()
    lines = []
    present = list(table.index)
    for name in present:
        cells = []
        for c in COLUMNS[label]:
            value = table.loc[name, c]
            if pd.isna(value):
                cells.append("--")
                continue
            digits = (
                metric_digits
                if (c in HIGHER_IS_BETTER) or True
                else 1
                if c == "flagged_pct"
                else TIME_DECIMALS[label]
            )
            text = f"{value:.{digits}f}"
            if c in best and round(value, digits) == round(best[c], digits):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        families = [n for n in present if n in CLASSICAL]
        if name in (families[2], families[-1]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_rows__mutmut_38(label: str, evidence: Path = EVIDENCE) -> str:
    """The body of a table: one line per detector, the best value of each column in bold."""
    base = classical_means(label, evidence)
    neural = neural_means(label, evidence)
    table = pd.concat([base.reindex(CLASSICAL), neural.reindex(columns=base.columns)])
    table = table.dropna(how="all")  # a detector that was not run on this dataset has no row
    metric_digits = TABLES[label][2]
    best = {}
    for c in COLUMNS[label]:
        if c in HIGHER_IS_BETTER:
            best[c] = table[c].max()
        elif c in LOWER_IS_BETTER:
            best[c] = table[c].min()
    lines = []
    present = list(table.index)
    for name in present:
        cells = []
        for c in COLUMNS[label]:
            value = table.loc[name, c]
            if pd.isna(value):
                cells.append("--")
                continue
            digits = (
                metric_digits
                if c not in HIGHER_IS_BETTER
                else 1
                if c == "flagged_pct"
                else TIME_DECIMALS[label]
            )
            text = f"{value:.{digits}f}"
            if c in best and round(value, digits) == round(best[c], digits):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        families = [n for n in present if n in CLASSICAL]
        if name in (families[2], families[-1]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_rows__mutmut_39(label: str, evidence: Path = EVIDENCE) -> str:
    """The body of a table: one line per detector, the best value of each column in bold."""
    base = classical_means(label, evidence)
    neural = neural_means(label, evidence)
    table = pd.concat([base.reindex(CLASSICAL), neural.reindex(columns=base.columns)])
    table = table.dropna(how="all")  # a detector that was not run on this dataset has no row
    metric_digits = TABLES[label][2]
    best = {}
    for c in COLUMNS[label]:
        if c in HIGHER_IS_BETTER:
            best[c] = table[c].max()
        elif c in LOWER_IS_BETTER:
            best[c] = table[c].min()
    lines = []
    present = list(table.index)
    for name in present:
        cells = []
        for c in COLUMNS[label]:
            value = table.loc[name, c]
            if pd.isna(value):
                cells.append("--")
                continue
            digits = (
                metric_digits
                if c in HIGHER_IS_BETTER
                else 1
                if (c == "flagged_pct") and False
                else TIME_DECIMALS[label]
            )
            text = f"{value:.{digits}f}"
            if c in best and round(value, digits) == round(best[c], digits):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        families = [n for n in present if n in CLASSICAL]
        if name in (families[2], families[-1]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_rows__mutmut_40(label: str, evidence: Path = EVIDENCE) -> str:
    """The body of a table: one line per detector, the best value of each column in bold."""
    base = classical_means(label, evidence)
    neural = neural_means(label, evidence)
    table = pd.concat([base.reindex(CLASSICAL), neural.reindex(columns=base.columns)])
    table = table.dropna(how="all")  # a detector that was not run on this dataset has no row
    metric_digits = TABLES[label][2]
    best = {}
    for c in COLUMNS[label]:
        if c in HIGHER_IS_BETTER:
            best[c] = table[c].max()
        elif c in LOWER_IS_BETTER:
            best[c] = table[c].min()
    lines = []
    present = list(table.index)
    for name in present:
        cells = []
        for c in COLUMNS[label]:
            value = table.loc[name, c]
            if pd.isna(value):
                cells.append("--")
                continue
            digits = (
                metric_digits
                if c in HIGHER_IS_BETTER
                else 1
                if (c == "flagged_pct") or True
                else TIME_DECIMALS[label]
            )
            text = f"{value:.{digits}f}"
            if c in best and round(value, digits) == round(best[c], digits):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        families = [n for n in present if n in CLASSICAL]
        if name in (families[2], families[-1]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_rows__mutmut_41(label: str, evidence: Path = EVIDENCE) -> str:
    """The body of a table: one line per detector, the best value of each column in bold."""
    base = classical_means(label, evidence)
    neural = neural_means(label, evidence)
    table = pd.concat([base.reindex(CLASSICAL), neural.reindex(columns=base.columns)])
    table = table.dropna(how="all")  # a detector that was not run on this dataset has no row
    metric_digits = TABLES[label][2]
    best = {}
    for c in COLUMNS[label]:
        if c in HIGHER_IS_BETTER:
            best[c] = table[c].max()
        elif c in LOWER_IS_BETTER:
            best[c] = table[c].min()
    lines = []
    present = list(table.index)
    for name in present:
        cells = []
        for c in COLUMNS[label]:
            value = table.loc[name, c]
            if pd.isna(value):
                cells.append("--")
                continue
            digits = (
                metric_digits
                if c in HIGHER_IS_BETTER
                else 2
                if c == "flagged_pct"
                else TIME_DECIMALS[label]
            )
            text = f"{value:.{digits}f}"
            if c in best and round(value, digits) == round(best[c], digits):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        families = [n for n in present if n in CLASSICAL]
        if name in (families[2], families[-1]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_rows__mutmut_42(label: str, evidence: Path = EVIDENCE) -> str:
    """The body of a table: one line per detector, the best value of each column in bold."""
    base = classical_means(label, evidence)
    neural = neural_means(label, evidence)
    table = pd.concat([base.reindex(CLASSICAL), neural.reindex(columns=base.columns)])
    table = table.dropna(how="all")  # a detector that was not run on this dataset has no row
    metric_digits = TABLES[label][2]
    best = {}
    for c in COLUMNS[label]:
        if c in HIGHER_IS_BETTER:
            best[c] = table[c].max()
        elif c in LOWER_IS_BETTER:
            best[c] = table[c].min()
    lines = []
    present = list(table.index)
    for name in present:
        cells = []
        for c in COLUMNS[label]:
            value = table.loc[name, c]
            if pd.isna(value):
                cells.append("--")
                continue
            digits = (
                metric_digits
                if c in HIGHER_IS_BETTER
                else 1
                if c != "flagged_pct"
                else TIME_DECIMALS[label]
            )
            text = f"{value:.{digits}f}"
            if c in best and round(value, digits) == round(best[c], digits):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        families = [n for n in present if n in CLASSICAL]
        if name in (families[2], families[-1]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_rows__mutmut_43(label: str, evidence: Path = EVIDENCE) -> str:
    """The body of a table: one line per detector, the best value of each column in bold."""
    base = classical_means(label, evidence)
    neural = neural_means(label, evidence)
    table = pd.concat([base.reindex(CLASSICAL), neural.reindex(columns=base.columns)])
    table = table.dropna(how="all")  # a detector that was not run on this dataset has no row
    metric_digits = TABLES[label][2]
    best = {}
    for c in COLUMNS[label]:
        if c in HIGHER_IS_BETTER:
            best[c] = table[c].max()
        elif c in LOWER_IS_BETTER:
            best[c] = table[c].min()
    lines = []
    present = list(table.index)
    for name in present:
        cells = []
        for c in COLUMNS[label]:
            value = table.loc[name, c]
            if pd.isna(value):
                cells.append("--")
                continue
            digits = (
                metric_digits
                if c in HIGHER_IS_BETTER
                else 1
                if c == "XXflagged_pctXX"
                else TIME_DECIMALS[label]
            )
            text = f"{value:.{digits}f}"
            if c in best and round(value, digits) == round(best[c], digits):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        families = [n for n in present if n in CLASSICAL]
        if name in (families[2], families[-1]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_rows__mutmut_44(label: str, evidence: Path = EVIDENCE) -> str:
    """The body of a table: one line per detector, the best value of each column in bold."""
    base = classical_means(label, evidence)
    neural = neural_means(label, evidence)
    table = pd.concat([base.reindex(CLASSICAL), neural.reindex(columns=base.columns)])
    table = table.dropna(how="all")  # a detector that was not run on this dataset has no row
    metric_digits = TABLES[label][2]
    best = {}
    for c in COLUMNS[label]:
        if c in HIGHER_IS_BETTER:
            best[c] = table[c].max()
        elif c in LOWER_IS_BETTER:
            best[c] = table[c].min()
    lines = []
    present = list(table.index)
    for name in present:
        cells = []
        for c in COLUMNS[label]:
            value = table.loc[name, c]
            if pd.isna(value):
                cells.append("--")
                continue
            digits = (
                metric_digits
                if c in HIGHER_IS_BETTER
                else 1
                if c == "FLAGGED_PCT"
                else TIME_DECIMALS[label]
            )
            text = f"{value:.{digits}f}"
            if c in best and round(value, digits) == round(best[c], digits):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        families = [n for n in present if n in CLASSICAL]
        if name in (families[2], families[-1]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_rows__mutmut_45(label: str, evidence: Path = EVIDENCE) -> str:
    """The body of a table: one line per detector, the best value of each column in bold."""
    base = classical_means(label, evidence)
    neural = neural_means(label, evidence)
    table = pd.concat([base.reindex(CLASSICAL), neural.reindex(columns=base.columns)])
    table = table.dropna(how="all")  # a detector that was not run on this dataset has no row
    metric_digits = TABLES[label][2]
    best = {}
    for c in COLUMNS[label]:
        if c in HIGHER_IS_BETTER:
            best[c] = table[c].max()
        elif c in LOWER_IS_BETTER:
            best[c] = table[c].min()
    lines = []
    present = list(table.index)
    for name in present:
        cells = []
        for c in COLUMNS[label]:
            value = table.loc[name, c]
            if pd.isna(value):
                cells.append("--")
                continue
            digits = (
                metric_digits
                if c in HIGHER_IS_BETTER
                else 1
                if c == "flagged_pct"
                else TIME_DECIMALS[label]
            )
            text = None
            if c in best and round(value, digits) == round(best[c], digits):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        families = [n for n in present if n in CLASSICAL]
        if name in (families[2], families[-1]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_rows__mutmut_46(label: str, evidence: Path = EVIDENCE) -> str:
    """The body of a table: one line per detector, the best value of each column in bold."""
    base = classical_means(label, evidence)
    neural = neural_means(label, evidence)
    table = pd.concat([base.reindex(CLASSICAL), neural.reindex(columns=base.columns)])
    table = table.dropna(how="all")  # a detector that was not run on this dataset has no row
    metric_digits = TABLES[label][2]
    best = {}
    for c in COLUMNS[label]:
        if c in HIGHER_IS_BETTER:
            best[c] = table[c].max()
        elif c in LOWER_IS_BETTER:
            best[c] = table[c].min()
    lines = []
    present = list(table.index)
    for name in present:
        cells = []
        for c in COLUMNS[label]:
            value = table.loc[name, c]
            if pd.isna(value):
                cells.append("--")
                continue
            digits = (
                metric_digits
                if c in HIGHER_IS_BETTER
                else 1
                if c == "flagged_pct"
                else TIME_DECIMALS[label]
            )
            text = f"{value:.{digits}f}"
            if c in best or round(value, digits) == round(best[c], digits):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        families = [n for n in present if n in CLASSICAL]
        if name in (families[2], families[-1]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_rows__mutmut_47(label: str, evidence: Path = EVIDENCE) -> str:
    """The body of a table: one line per detector, the best value of each column in bold."""
    base = classical_means(label, evidence)
    neural = neural_means(label, evidence)
    table = pd.concat([base.reindex(CLASSICAL), neural.reindex(columns=base.columns)])
    table = table.dropna(how="all")  # a detector that was not run on this dataset has no row
    metric_digits = TABLES[label][2]
    best = {}
    for c in COLUMNS[label]:
        if c in HIGHER_IS_BETTER:
            best[c] = table[c].max()
        elif c in LOWER_IS_BETTER:
            best[c] = table[c].min()
    lines = []
    present = list(table.index)
    for name in present:
        cells = []
        for c in COLUMNS[label]:
            value = table.loc[name, c]
            if pd.isna(value):
                cells.append("--")
                continue
            digits = (
                metric_digits
                if c in HIGHER_IS_BETTER
                else 1
                if c == "flagged_pct"
                else TIME_DECIMALS[label]
            )
            text = f"{value:.{digits}f}"
            if c not in best and round(value, digits) == round(best[c], digits):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        families = [n for n in present if n in CLASSICAL]
        if name in (families[2], families[-1]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_rows__mutmut_48(label: str, evidence: Path = EVIDENCE) -> str:
    """The body of a table: one line per detector, the best value of each column in bold."""
    base = classical_means(label, evidence)
    neural = neural_means(label, evidence)
    table = pd.concat([base.reindex(CLASSICAL), neural.reindex(columns=base.columns)])
    table = table.dropna(how="all")  # a detector that was not run on this dataset has no row
    metric_digits = TABLES[label][2]
    best = {}
    for c in COLUMNS[label]:
        if c in HIGHER_IS_BETTER:
            best[c] = table[c].max()
        elif c in LOWER_IS_BETTER:
            best[c] = table[c].min()
    lines = []
    present = list(table.index)
    for name in present:
        cells = []
        for c in COLUMNS[label]:
            value = table.loc[name, c]
            if pd.isna(value):
                cells.append("--")
                continue
            digits = (
                metric_digits
                if c in HIGHER_IS_BETTER
                else 1
                if c == "flagged_pct"
                else TIME_DECIMALS[label]
            )
            text = f"{value:.{digits}f}"
            if c in best and round(None, digits) == round(best[c], digits):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        families = [n for n in present if n in CLASSICAL]
        if name in (families[2], families[-1]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_rows__mutmut_49(label: str, evidence: Path = EVIDENCE) -> str:
    """The body of a table: one line per detector, the best value of each column in bold."""
    base = classical_means(label, evidence)
    neural = neural_means(label, evidence)
    table = pd.concat([base.reindex(CLASSICAL), neural.reindex(columns=base.columns)])
    table = table.dropna(how="all")  # a detector that was not run on this dataset has no row
    metric_digits = TABLES[label][2]
    best = {}
    for c in COLUMNS[label]:
        if c in HIGHER_IS_BETTER:
            best[c] = table[c].max()
        elif c in LOWER_IS_BETTER:
            best[c] = table[c].min()
    lines = []
    present = list(table.index)
    for name in present:
        cells = []
        for c in COLUMNS[label]:
            value = table.loc[name, c]
            if pd.isna(value):
                cells.append("--")
                continue
            digits = (
                metric_digits
                if c in HIGHER_IS_BETTER
                else 1
                if c == "flagged_pct"
                else TIME_DECIMALS[label]
            )
            text = f"{value:.{digits}f}"
            if c in best and round(value, None) == round(best[c], digits):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        families = [n for n in present if n in CLASSICAL]
        if name in (families[2], families[-1]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_rows__mutmut_50(label: str, evidence: Path = EVIDENCE) -> str:
    """The body of a table: one line per detector, the best value of each column in bold."""
    base = classical_means(label, evidence)
    neural = neural_means(label, evidence)
    table = pd.concat([base.reindex(CLASSICAL), neural.reindex(columns=base.columns)])
    table = table.dropna(how="all")  # a detector that was not run on this dataset has no row
    metric_digits = TABLES[label][2]
    best = {}
    for c in COLUMNS[label]:
        if c in HIGHER_IS_BETTER:
            best[c] = table[c].max()
        elif c in LOWER_IS_BETTER:
            best[c] = table[c].min()
    lines = []
    present = list(table.index)
    for name in present:
        cells = []
        for c in COLUMNS[label]:
            value = table.loc[name, c]
            if pd.isna(value):
                cells.append("--")
                continue
            digits = (
                metric_digits
                if c in HIGHER_IS_BETTER
                else 1
                if c == "flagged_pct"
                else TIME_DECIMALS[label]
            )
            text = f"{value:.{digits}f}"
            if c in best and round(digits) == round(best[c], digits):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        families = [n for n in present if n in CLASSICAL]
        if name in (families[2], families[-1]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_rows__mutmut_51(label: str, evidence: Path = EVIDENCE) -> str:
    """The body of a table: one line per detector, the best value of each column in bold."""
    base = classical_means(label, evidence)
    neural = neural_means(label, evidence)
    table = pd.concat([base.reindex(CLASSICAL), neural.reindex(columns=base.columns)])
    table = table.dropna(how="all")  # a detector that was not run on this dataset has no row
    metric_digits = TABLES[label][2]
    best = {}
    for c in COLUMNS[label]:
        if c in HIGHER_IS_BETTER:
            best[c] = table[c].max()
        elif c in LOWER_IS_BETTER:
            best[c] = table[c].min()
    lines = []
    present = list(table.index)
    for name in present:
        cells = []
        for c in COLUMNS[label]:
            value = table.loc[name, c]
            if pd.isna(value):
                cells.append("--")
                continue
            digits = (
                metric_digits
                if c in HIGHER_IS_BETTER
                else 1
                if c == "flagged_pct"
                else TIME_DECIMALS[label]
            )
            text = f"{value:.{digits}f}"
            if c in best and round(value, ) == round(best[c], digits):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        families = [n for n in present if n in CLASSICAL]
        if name in (families[2], families[-1]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_rows__mutmut_52(label: str, evidence: Path = EVIDENCE) -> str:
    """The body of a table: one line per detector, the best value of each column in bold."""
    base = classical_means(label, evidence)
    neural = neural_means(label, evidence)
    table = pd.concat([base.reindex(CLASSICAL), neural.reindex(columns=base.columns)])
    table = table.dropna(how="all")  # a detector that was not run on this dataset has no row
    metric_digits = TABLES[label][2]
    best = {}
    for c in COLUMNS[label]:
        if c in HIGHER_IS_BETTER:
            best[c] = table[c].max()
        elif c in LOWER_IS_BETTER:
            best[c] = table[c].min()
    lines = []
    present = list(table.index)
    for name in present:
        cells = []
        for c in COLUMNS[label]:
            value = table.loc[name, c]
            if pd.isna(value):
                cells.append("--")
                continue
            digits = (
                metric_digits
                if c in HIGHER_IS_BETTER
                else 1
                if c == "flagged_pct"
                else TIME_DECIMALS[label]
            )
            text = f"{value:.{digits}f}"
            if c in best and round(value, digits) != round(best[c], digits):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        families = [n for n in present if n in CLASSICAL]
        if name in (families[2], families[-1]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_rows__mutmut_53(label: str, evidence: Path = EVIDENCE) -> str:
    """The body of a table: one line per detector, the best value of each column in bold."""
    base = classical_means(label, evidence)
    neural = neural_means(label, evidence)
    table = pd.concat([base.reindex(CLASSICAL), neural.reindex(columns=base.columns)])
    table = table.dropna(how="all")  # a detector that was not run on this dataset has no row
    metric_digits = TABLES[label][2]
    best = {}
    for c in COLUMNS[label]:
        if c in HIGHER_IS_BETTER:
            best[c] = table[c].max()
        elif c in LOWER_IS_BETTER:
            best[c] = table[c].min()
    lines = []
    present = list(table.index)
    for name in present:
        cells = []
        for c in COLUMNS[label]:
            value = table.loc[name, c]
            if pd.isna(value):
                cells.append("--")
                continue
            digits = (
                metric_digits
                if c in HIGHER_IS_BETTER
                else 1
                if c == "flagged_pct"
                else TIME_DECIMALS[label]
            )
            text = f"{value:.{digits}f}"
            if c in best and round(value, digits) == round(None, digits):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        families = [n for n in present if n in CLASSICAL]
        if name in (families[2], families[-1]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_rows__mutmut_54(label: str, evidence: Path = EVIDENCE) -> str:
    """The body of a table: one line per detector, the best value of each column in bold."""
    base = classical_means(label, evidence)
    neural = neural_means(label, evidence)
    table = pd.concat([base.reindex(CLASSICAL), neural.reindex(columns=base.columns)])
    table = table.dropna(how="all")  # a detector that was not run on this dataset has no row
    metric_digits = TABLES[label][2]
    best = {}
    for c in COLUMNS[label]:
        if c in HIGHER_IS_BETTER:
            best[c] = table[c].max()
        elif c in LOWER_IS_BETTER:
            best[c] = table[c].min()
    lines = []
    present = list(table.index)
    for name in present:
        cells = []
        for c in COLUMNS[label]:
            value = table.loc[name, c]
            if pd.isna(value):
                cells.append("--")
                continue
            digits = (
                metric_digits
                if c in HIGHER_IS_BETTER
                else 1
                if c == "flagged_pct"
                else TIME_DECIMALS[label]
            )
            text = f"{value:.{digits}f}"
            if c in best and round(value, digits) == round(best[c], None):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        families = [n for n in present if n in CLASSICAL]
        if name in (families[2], families[-1]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_rows__mutmut_55(label: str, evidence: Path = EVIDENCE) -> str:
    """The body of a table: one line per detector, the best value of each column in bold."""
    base = classical_means(label, evidence)
    neural = neural_means(label, evidence)
    table = pd.concat([base.reindex(CLASSICAL), neural.reindex(columns=base.columns)])
    table = table.dropna(how="all")  # a detector that was not run on this dataset has no row
    metric_digits = TABLES[label][2]
    best = {}
    for c in COLUMNS[label]:
        if c in HIGHER_IS_BETTER:
            best[c] = table[c].max()
        elif c in LOWER_IS_BETTER:
            best[c] = table[c].min()
    lines = []
    present = list(table.index)
    for name in present:
        cells = []
        for c in COLUMNS[label]:
            value = table.loc[name, c]
            if pd.isna(value):
                cells.append("--")
                continue
            digits = (
                metric_digits
                if c in HIGHER_IS_BETTER
                else 1
                if c == "flagged_pct"
                else TIME_DECIMALS[label]
            )
            text = f"{value:.{digits}f}"
            if c in best and round(value, digits) == round(digits):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        families = [n for n in present if n in CLASSICAL]
        if name in (families[2], families[-1]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_rows__mutmut_56(label: str, evidence: Path = EVIDENCE) -> str:
    """The body of a table: one line per detector, the best value of each column in bold."""
    base = classical_means(label, evidence)
    neural = neural_means(label, evidence)
    table = pd.concat([base.reindex(CLASSICAL), neural.reindex(columns=base.columns)])
    table = table.dropna(how="all")  # a detector that was not run on this dataset has no row
    metric_digits = TABLES[label][2]
    best = {}
    for c in COLUMNS[label]:
        if c in HIGHER_IS_BETTER:
            best[c] = table[c].max()
        elif c in LOWER_IS_BETTER:
            best[c] = table[c].min()
    lines = []
    present = list(table.index)
    for name in present:
        cells = []
        for c in COLUMNS[label]:
            value = table.loc[name, c]
            if pd.isna(value):
                cells.append("--")
                continue
            digits = (
                metric_digits
                if c in HIGHER_IS_BETTER
                else 1
                if c == "flagged_pct"
                else TIME_DECIMALS[label]
            )
            text = f"{value:.{digits}f}"
            if c in best and round(value, digits) == round(best[c], ):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        families = [n for n in present if n in CLASSICAL]
        if name in (families[2], families[-1]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_rows__mutmut_57(label: str, evidence: Path = EVIDENCE) -> str:
    """The body of a table: one line per detector, the best value of each column in bold."""
    base = classical_means(label, evidence)
    neural = neural_means(label, evidence)
    table = pd.concat([base.reindex(CLASSICAL), neural.reindex(columns=base.columns)])
    table = table.dropna(how="all")  # a detector that was not run on this dataset has no row
    metric_digits = TABLES[label][2]
    best = {}
    for c in COLUMNS[label]:
        if c in HIGHER_IS_BETTER:
            best[c] = table[c].max()
        elif c in LOWER_IS_BETTER:
            best[c] = table[c].min()
    lines = []
    present = list(table.index)
    for name in present:
        cells = []
        for c in COLUMNS[label]:
            value = table.loc[name, c]
            if pd.isna(value):
                cells.append("--")
                continue
            digits = (
                metric_digits
                if c in HIGHER_IS_BETTER
                else 1
                if c == "flagged_pct"
                else TIME_DECIMALS[label]
            )
            text = f"{value:.{digits}f}"
            if c in best and round(value, digits) == round(best[c], digits):
                text = None
            cells.append(text)
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        families = [n for n in present if n in CLASSICAL]
        if name in (families[2], families[-1]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_rows__mutmut_58(label: str, evidence: Path = EVIDENCE) -> str:
    """The body of a table: one line per detector, the best value of each column in bold."""
    base = classical_means(label, evidence)
    neural = neural_means(label, evidence)
    table = pd.concat([base.reindex(CLASSICAL), neural.reindex(columns=base.columns)])
    table = table.dropna(how="all")  # a detector that was not run on this dataset has no row
    metric_digits = TABLES[label][2]
    best = {}
    for c in COLUMNS[label]:
        if c in HIGHER_IS_BETTER:
            best[c] = table[c].max()
        elif c in LOWER_IS_BETTER:
            best[c] = table[c].min()
    lines = []
    present = list(table.index)
    for name in present:
        cells = []
        for c in COLUMNS[label]:
            value = table.loc[name, c]
            if pd.isna(value):
                cells.append("--")
                continue
            digits = (
                metric_digits
                if c in HIGHER_IS_BETTER
                else 1
                if c == "flagged_pct"
                else TIME_DECIMALS[label]
            )
            text = f"{value:.{digits}f}"
            if c in best and round(value, digits) == round(best[c], digits):
                text = f"\\textbf{{{text}}}"
            cells.append(None)
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        families = [n for n in present if n in CLASSICAL]
        if name in (families[2], families[-1]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_rows__mutmut_59(label: str, evidence: Path = EVIDENCE) -> str:
    """The body of a table: one line per detector, the best value of each column in bold."""
    base = classical_means(label, evidence)
    neural = neural_means(label, evidence)
    table = pd.concat([base.reindex(CLASSICAL), neural.reindex(columns=base.columns)])
    table = table.dropna(how="all")  # a detector that was not run on this dataset has no row
    metric_digits = TABLES[label][2]
    best = {}
    for c in COLUMNS[label]:
        if c in HIGHER_IS_BETTER:
            best[c] = table[c].max()
        elif c in LOWER_IS_BETTER:
            best[c] = table[c].min()
    lines = []
    present = list(table.index)
    for name in present:
        cells = []
        for c in COLUMNS[label]:
            value = table.loc[name, c]
            if pd.isna(value):
                cells.append("--")
                continue
            digits = (
                metric_digits
                if c in HIGHER_IS_BETTER
                else 1
                if c == "flagged_pct"
                else TIME_DECIMALS[label]
            )
            text = f"{value:.{digits}f}"
            if c in best and round(value, digits) == round(best[c], digits):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(None)
        families = [n for n in present if n in CLASSICAL]
        if name in (families[2], families[-1]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_rows__mutmut_60(label: str, evidence: Path = EVIDENCE) -> str:
    """The body of a table: one line per detector, the best value of each column in bold."""
    base = classical_means(label, evidence)
    neural = neural_means(label, evidence)
    table = pd.concat([base.reindex(CLASSICAL), neural.reindex(columns=base.columns)])
    table = table.dropna(how="all")  # a detector that was not run on this dataset has no row
    metric_digits = TABLES[label][2]
    best = {}
    for c in COLUMNS[label]:
        if c in HIGHER_IS_BETTER:
            best[c] = table[c].max()
        elif c in LOWER_IS_BETTER:
            best[c] = table[c].min()
    lines = []
    present = list(table.index)
    for name in present:
        cells = []
        for c in COLUMNS[label]:
            value = table.loc[name, c]
            if pd.isna(value):
                cells.append("--")
                continue
            digits = (
                metric_digits
                if c in HIGHER_IS_BETTER
                else 1
                if c == "flagged_pct"
                else TIME_DECIMALS[label]
            )
            text = f"{value:.{digits}f}"
            if c in best and round(value, digits) == round(best[c], digits):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) - r" \\")
        families = [n for n in present if n in CLASSICAL]
        if name in (families[2], families[-1]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_rows__mutmut_61(label: str, evidence: Path = EVIDENCE) -> str:
    """The body of a table: one line per detector, the best value of each column in bold."""
    base = classical_means(label, evidence)
    neural = neural_means(label, evidence)
    table = pd.concat([base.reindex(CLASSICAL), neural.reindex(columns=base.columns)])
    table = table.dropna(how="all")  # a detector that was not run on this dataset has no row
    metric_digits = TABLES[label][2]
    best = {}
    for c in COLUMNS[label]:
        if c in HIGHER_IS_BETTER:
            best[c] = table[c].max()
        elif c in LOWER_IS_BETTER:
            best[c] = table[c].min()
    lines = []
    present = list(table.index)
    for name in present:
        cells = []
        for c in COLUMNS[label]:
            value = table.loc[name, c]
            if pd.isna(value):
                cells.append("--")
                continue
            digits = (
                metric_digits
                if c in HIGHER_IS_BETTER
                else 1
                if c == "flagged_pct"
                else TIME_DECIMALS[label]
            )
            text = f"{value:.{digits}f}"
            if c in best and round(value, digits) == round(best[c], digits):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{NAMES[name]:<18} & " - " & ".join(cells) + r" \\")
        families = [n for n in present if n in CLASSICAL]
        if name in (families[2], families[-1]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_rows__mutmut_62(label: str, evidence: Path = EVIDENCE) -> str:
    """The body of a table: one line per detector, the best value of each column in bold."""
    base = classical_means(label, evidence)
    neural = neural_means(label, evidence)
    table = pd.concat([base.reindex(CLASSICAL), neural.reindex(columns=base.columns)])
    table = table.dropna(how="all")  # a detector that was not run on this dataset has no row
    metric_digits = TABLES[label][2]
    best = {}
    for c in COLUMNS[label]:
        if c in HIGHER_IS_BETTER:
            best[c] = table[c].max()
        elif c in LOWER_IS_BETTER:
            best[c] = table[c].min()
    lines = []
    present = list(table.index)
    for name in present:
        cells = []
        for c in COLUMNS[label]:
            value = table.loc[name, c]
            if pd.isna(value):
                cells.append("--")
                continue
            digits = (
                metric_digits
                if c in HIGHER_IS_BETTER
                else 1
                if c == "flagged_pct"
                else TIME_DECIMALS[label]
            )
            text = f"{value:.{digits}f}"
            if c in best and round(value, digits) == round(best[c], digits):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(None) + r" \\")
        families = [n for n in present if n in CLASSICAL]
        if name in (families[2], families[-1]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_rows__mutmut_63(label: str, evidence: Path = EVIDENCE) -> str:
    """The body of a table: one line per detector, the best value of each column in bold."""
    base = classical_means(label, evidence)
    neural = neural_means(label, evidence)
    table = pd.concat([base.reindex(CLASSICAL), neural.reindex(columns=base.columns)])
    table = table.dropna(how="all")  # a detector that was not run on this dataset has no row
    metric_digits = TABLES[label][2]
    best = {}
    for c in COLUMNS[label]:
        if c in HIGHER_IS_BETTER:
            best[c] = table[c].max()
        elif c in LOWER_IS_BETTER:
            best[c] = table[c].min()
    lines = []
    present = list(table.index)
    for name in present:
        cells = []
        for c in COLUMNS[label]:
            value = table.loc[name, c]
            if pd.isna(value):
                cells.append("--")
                continue
            digits = (
                metric_digits
                if c in HIGHER_IS_BETTER
                else 1
                if c == "flagged_pct"
                else TIME_DECIMALS[label]
            )
            text = f"{value:.{digits}f}"
            if c in best and round(value, digits) == round(best[c], digits):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{NAMES[name]:<18} & " + "XX & XX".join(cells) + r" \\")
        families = [n for n in present if n in CLASSICAL]
        if name in (families[2], families[-1]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_rows__mutmut_64(label: str, evidence: Path = EVIDENCE) -> str:
    """The body of a table: one line per detector, the best value of each column in bold."""
    base = classical_means(label, evidence)
    neural = neural_means(label, evidence)
    table = pd.concat([base.reindex(CLASSICAL), neural.reindex(columns=base.columns)])
    table = table.dropna(how="all")  # a detector that was not run on this dataset has no row
    metric_digits = TABLES[label][2]
    best = {}
    for c in COLUMNS[label]:
        if c in HIGHER_IS_BETTER:
            best[c] = table[c].max()
        elif c in LOWER_IS_BETTER:
            best[c] = table[c].min()
    lines = []
    present = list(table.index)
    for name in present:
        cells = []
        for c in COLUMNS[label]:
            value = table.loc[name, c]
            if pd.isna(value):
                cells.append("--")
                continue
            digits = (
                metric_digits
                if c in HIGHER_IS_BETTER
                else 1
                if c == "flagged_pct"
                else TIME_DECIMALS[label]
            )
            text = f"{value:.{digits}f}"
            if c in best and round(value, digits) == round(best[c], digits):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r"XX \\XX")
        families = [n for n in present if n in CLASSICAL]
        if name in (families[2], families[-1]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_rows__mutmut_65(label: str, evidence: Path = EVIDENCE) -> str:
    """The body of a table: one line per detector, the best value of each column in bold."""
    base = classical_means(label, evidence)
    neural = neural_means(label, evidence)
    table = pd.concat([base.reindex(CLASSICAL), neural.reindex(columns=base.columns)])
    table = table.dropna(how="all")  # a detector that was not run on this dataset has no row
    metric_digits = TABLES[label][2]
    best = {}
    for c in COLUMNS[label]:
        if c in HIGHER_IS_BETTER:
            best[c] = table[c].max()
        elif c in LOWER_IS_BETTER:
            best[c] = table[c].min()
    lines = []
    present = list(table.index)
    for name in present:
        cells = []
        for c in COLUMNS[label]:
            value = table.loc[name, c]
            if pd.isna(value):
                cells.append("--")
                continue
            digits = (
                metric_digits
                if c in HIGHER_IS_BETTER
                else 1
                if c == "flagged_pct"
                else TIME_DECIMALS[label]
            )
            text = f"{value:.{digits}f}"
            if c in best and round(value, digits) == round(best[c], digits):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        families = None
        if name in (families[2], families[-1]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_rows__mutmut_66(label: str, evidence: Path = EVIDENCE) -> str:
    """The body of a table: one line per detector, the best value of each column in bold."""
    base = classical_means(label, evidence)
    neural = neural_means(label, evidence)
    table = pd.concat([base.reindex(CLASSICAL), neural.reindex(columns=base.columns)])
    table = table.dropna(how="all")  # a detector that was not run on this dataset has no row
    metric_digits = TABLES[label][2]
    best = {}
    for c in COLUMNS[label]:
        if c in HIGHER_IS_BETTER:
            best[c] = table[c].max()
        elif c in LOWER_IS_BETTER:
            best[c] = table[c].min()
    lines = []
    present = list(table.index)
    for name in present:
        cells = []
        for c in COLUMNS[label]:
            value = table.loc[name, c]
            if pd.isna(value):
                cells.append("--")
                continue
            digits = (
                metric_digits
                if c in HIGHER_IS_BETTER
                else 1
                if c == "flagged_pct"
                else TIME_DECIMALS[label]
            )
            text = f"{value:.{digits}f}"
            if c in best and round(value, digits) == round(best[c], digits):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        families = [n for n in present if n not in CLASSICAL]
        if name in (families[2], families[-1]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_rows__mutmut_67(label: str, evidence: Path = EVIDENCE) -> str:
    """The body of a table: one line per detector, the best value of each column in bold."""
    base = classical_means(label, evidence)
    neural = neural_means(label, evidence)
    table = pd.concat([base.reindex(CLASSICAL), neural.reindex(columns=base.columns)])
    table = table.dropna(how="all")  # a detector that was not run on this dataset has no row
    metric_digits = TABLES[label][2]
    best = {}
    for c in COLUMNS[label]:
        if c in HIGHER_IS_BETTER:
            best[c] = table[c].max()
        elif c in LOWER_IS_BETTER:
            best[c] = table[c].min()
    lines = []
    present = list(table.index)
    for name in present:
        cells = []
        for c in COLUMNS[label]:
            value = table.loc[name, c]
            if pd.isna(value):
                cells.append("--")
                continue
            digits = (
                metric_digits
                if c in HIGHER_IS_BETTER
                else 1
                if c == "flagged_pct"
                else TIME_DECIMALS[label]
            )
            text = f"{value:.{digits}f}"
            if c in best and round(value, digits) == round(best[c], digits):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        families = [n for n in present if n in CLASSICAL]
        if name not in (families[2], families[-1]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_rows__mutmut_68(label: str, evidence: Path = EVIDENCE) -> str:
    """The body of a table: one line per detector, the best value of each column in bold."""
    base = classical_means(label, evidence)
    neural = neural_means(label, evidence)
    table = pd.concat([base.reindex(CLASSICAL), neural.reindex(columns=base.columns)])
    table = table.dropna(how="all")  # a detector that was not run on this dataset has no row
    metric_digits = TABLES[label][2]
    best = {}
    for c in COLUMNS[label]:
        if c in HIGHER_IS_BETTER:
            best[c] = table[c].max()
        elif c in LOWER_IS_BETTER:
            best[c] = table[c].min()
    lines = []
    present = list(table.index)
    for name in present:
        cells = []
        for c in COLUMNS[label]:
            value = table.loc[name, c]
            if pd.isna(value):
                cells.append("--")
                continue
            digits = (
                metric_digits
                if c in HIGHER_IS_BETTER
                else 1
                if c == "flagged_pct"
                else TIME_DECIMALS[label]
            )
            text = f"{value:.{digits}f}"
            if c in best and round(value, digits) == round(best[c], digits):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        families = [n for n in present if n in CLASSICAL]
        if name in (families[3], families[-1]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_rows__mutmut_69(label: str, evidence: Path = EVIDENCE) -> str:
    """The body of a table: one line per detector, the best value of each column in bold."""
    base = classical_means(label, evidence)
    neural = neural_means(label, evidence)
    table = pd.concat([base.reindex(CLASSICAL), neural.reindex(columns=base.columns)])
    table = table.dropna(how="all")  # a detector that was not run on this dataset has no row
    metric_digits = TABLES[label][2]
    best = {}
    for c in COLUMNS[label]:
        if c in HIGHER_IS_BETTER:
            best[c] = table[c].max()
        elif c in LOWER_IS_BETTER:
            best[c] = table[c].min()
    lines = []
    present = list(table.index)
    for name in present:
        cells = []
        for c in COLUMNS[label]:
            value = table.loc[name, c]
            if pd.isna(value):
                cells.append("--")
                continue
            digits = (
                metric_digits
                if c in HIGHER_IS_BETTER
                else 1
                if c == "flagged_pct"
                else TIME_DECIMALS[label]
            )
            text = f"{value:.{digits}f}"
            if c in best and round(value, digits) == round(best[c], digits):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        families = [n for n in present if n in CLASSICAL]
        if name in (families[2], families[+1]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_rows__mutmut_70(label: str, evidence: Path = EVIDENCE) -> str:
    """The body of a table: one line per detector, the best value of each column in bold."""
    base = classical_means(label, evidence)
    neural = neural_means(label, evidence)
    table = pd.concat([base.reindex(CLASSICAL), neural.reindex(columns=base.columns)])
    table = table.dropna(how="all")  # a detector that was not run on this dataset has no row
    metric_digits = TABLES[label][2]
    best = {}
    for c in COLUMNS[label]:
        if c in HIGHER_IS_BETTER:
            best[c] = table[c].max()
        elif c in LOWER_IS_BETTER:
            best[c] = table[c].min()
    lines = []
    present = list(table.index)
    for name in present:
        cells = []
        for c in COLUMNS[label]:
            value = table.loc[name, c]
            if pd.isna(value):
                cells.append("--")
                continue
            digits = (
                metric_digits
                if c in HIGHER_IS_BETTER
                else 1
                if c == "flagged_pct"
                else TIME_DECIMALS[label]
            )
            text = f"{value:.{digits}f}"
            if c in best and round(value, digits) == round(best[c], digits):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        families = [n for n in present if n in CLASSICAL]
        if name in (families[2], families[-2]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_rows__mutmut_71(label: str, evidence: Path = EVIDENCE) -> str:
    """The body of a table: one line per detector, the best value of each column in bold."""
    base = classical_means(label, evidence)
    neural = neural_means(label, evidence)
    table = pd.concat([base.reindex(CLASSICAL), neural.reindex(columns=base.columns)])
    table = table.dropna(how="all")  # a detector that was not run on this dataset has no row
    metric_digits = TABLES[label][2]
    best = {}
    for c in COLUMNS[label]:
        if c in HIGHER_IS_BETTER:
            best[c] = table[c].max()
        elif c in LOWER_IS_BETTER:
            best[c] = table[c].min()
    lines = []
    present = list(table.index)
    for name in present:
        cells = []
        for c in COLUMNS[label]:
            value = table.loc[name, c]
            if pd.isna(value):
                cells.append("--")
                continue
            digits = (
                metric_digits
                if c in HIGHER_IS_BETTER
                else 1
                if c == "flagged_pct"
                else TIME_DECIMALS[label]
            )
            text = f"{value:.{digits}f}"
            if c in best and round(value, digits) == round(best[c], digits):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        families = [n for n in present if n in CLASSICAL]
        if name in (families[2], families[-1]):
            lines.append(None)
    return "\n".join(lines)


def x_rows__mutmut_72(label: str, evidence: Path = EVIDENCE) -> str:
    """The body of a table: one line per detector, the best value of each column in bold."""
    base = classical_means(label, evidence)
    neural = neural_means(label, evidence)
    table = pd.concat([base.reindex(CLASSICAL), neural.reindex(columns=base.columns)])
    table = table.dropna(how="all")  # a detector that was not run on this dataset has no row
    metric_digits = TABLES[label][2]
    best = {}
    for c in COLUMNS[label]:
        if c in HIGHER_IS_BETTER:
            best[c] = table[c].max()
        elif c in LOWER_IS_BETTER:
            best[c] = table[c].min()
    lines = []
    present = list(table.index)
    for name in present:
        cells = []
        for c in COLUMNS[label]:
            value = table.loc[name, c]
            if pd.isna(value):
                cells.append("--")
                continue
            digits = (
                metric_digits
                if c in HIGHER_IS_BETTER
                else 1
                if c == "flagged_pct"
                else TIME_DECIMALS[label]
            )
            text = f"{value:.{digits}f}"
            if c in best and round(value, digits) == round(best[c], digits):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        families = [n for n in present if n in CLASSICAL]
        if name in (families[2], families[-1]):
            lines.append(r"XX\midruleXX")
    return "\n".join(lines)


def x_rows__mutmut_73(label: str, evidence: Path = EVIDENCE) -> str:
    """The body of a table: one line per detector, the best value of each column in bold."""
    base = classical_means(label, evidence)
    neural = neural_means(label, evidence)
    table = pd.concat([base.reindex(CLASSICAL), neural.reindex(columns=base.columns)])
    table = table.dropna(how="all")  # a detector that was not run on this dataset has no row
    metric_digits = TABLES[label][2]
    best = {}
    for c in COLUMNS[label]:
        if c in HIGHER_IS_BETTER:
            best[c] = table[c].max()
        elif c in LOWER_IS_BETTER:
            best[c] = table[c].min()
    lines = []
    present = list(table.index)
    for name in present:
        cells = []
        for c in COLUMNS[label]:
            value = table.loc[name, c]
            if pd.isna(value):
                cells.append("--")
                continue
            digits = (
                metric_digits
                if c in HIGHER_IS_BETTER
                else 1
                if c == "flagged_pct"
                else TIME_DECIMALS[label]
            )
            text = f"{value:.{digits}f}"
            if c in best and round(value, digits) == round(best[c], digits):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        families = [n for n in present if n in CLASSICAL]
        if name in (families[2], families[-1]):
            lines.append(r"\mIDRULE")
    return "\n".join(lines)


def x_rows__mutmut_74(label: str, evidence: Path = EVIDENCE) -> str:
    """The body of a table: one line per detector, the best value of each column in bold."""
    base = classical_means(label, evidence)
    neural = neural_means(label, evidence)
    table = pd.concat([base.reindex(CLASSICAL), neural.reindex(columns=base.columns)])
    table = table.dropna(how="all")  # a detector that was not run on this dataset has no row
    metric_digits = TABLES[label][2]
    best = {}
    for c in COLUMNS[label]:
        if c in HIGHER_IS_BETTER:
            best[c] = table[c].max()
        elif c in LOWER_IS_BETTER:
            best[c] = table[c].min()
    lines = []
    present = list(table.index)
    for name in present:
        cells = []
        for c in COLUMNS[label]:
            value = table.loc[name, c]
            if pd.isna(value):
                cells.append("--")
                continue
            digits = (
                metric_digits
                if c in HIGHER_IS_BETTER
                else 1
                if c == "flagged_pct"
                else TIME_DECIMALS[label]
            )
            text = f"{value:.{digits}f}"
            if c in best and round(value, digits) == round(best[c], digits):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        families = [n for n in present if n in CLASSICAL]
        if name in (families[2], families[-1]):
            lines.append(r"\midrule")
    return "\n".join(None)


def x_rows__mutmut_75(label: str, evidence: Path = EVIDENCE) -> str:
    """The body of a table: one line per detector, the best value of each column in bold."""
    base = classical_means(label, evidence)
    neural = neural_means(label, evidence)
    table = pd.concat([base.reindex(CLASSICAL), neural.reindex(columns=base.columns)])
    table = table.dropna(how="all")  # a detector that was not run on this dataset has no row
    metric_digits = TABLES[label][2]
    best = {}
    for c in COLUMNS[label]:
        if c in HIGHER_IS_BETTER:
            best[c] = table[c].max()
        elif c in LOWER_IS_BETTER:
            best[c] = table[c].min()
    lines = []
    present = list(table.index)
    for name in present:
        cells = []
        for c in COLUMNS[label]:
            value = table.loc[name, c]
            if pd.isna(value):
                cells.append("--")
                continue
            digits = (
                metric_digits
                if c in HIGHER_IS_BETTER
                else 1
                if c == "flagged_pct"
                else TIME_DECIMALS[label]
            )
            text = f"{value:.{digits}f}"
            if c in best and round(value, digits) == round(best[c], digits):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        families = [n for n in present if n in CLASSICAL]
        if name in (families[2], families[-1]):
            lines.append(r"\midrule")
    return "XX\nXX".join(lines)

mutants_x_rows__mutmut['_mutmut_orig'] = x_rows__mutmut_orig # type: ignore # mutmut generated
mutants_x_rows__mutmut['x_rows__mutmut_1'] = x_rows__mutmut_1 # type: ignore # mutmut generated
mutants_x_rows__mutmut['x_rows__mutmut_2'] = x_rows__mutmut_2 # type: ignore # mutmut generated
mutants_x_rows__mutmut['x_rows__mutmut_3'] = x_rows__mutmut_3 # type: ignore # mutmut generated
mutants_x_rows__mutmut['x_rows__mutmut_4'] = x_rows__mutmut_4 # type: ignore # mutmut generated
mutants_x_rows__mutmut['x_rows__mutmut_5'] = x_rows__mutmut_5 # type: ignore # mutmut generated
mutants_x_rows__mutmut['x_rows__mutmut_6'] = x_rows__mutmut_6 # type: ignore # mutmut generated
mutants_x_rows__mutmut['x_rows__mutmut_7'] = x_rows__mutmut_7 # type: ignore # mutmut generated
mutants_x_rows__mutmut['x_rows__mutmut_8'] = x_rows__mutmut_8 # type: ignore # mutmut generated
mutants_x_rows__mutmut['x_rows__mutmut_9'] = x_rows__mutmut_9 # type: ignore # mutmut generated
mutants_x_rows__mutmut['x_rows__mutmut_10'] = x_rows__mutmut_10 # type: ignore # mutmut generated
mutants_x_rows__mutmut['x_rows__mutmut_11'] = x_rows__mutmut_11 # type: ignore # mutmut generated
mutants_x_rows__mutmut['x_rows__mutmut_12'] = x_rows__mutmut_12 # type: ignore # mutmut generated
mutants_x_rows__mutmut['x_rows__mutmut_13'] = x_rows__mutmut_13 # type: ignore # mutmut generated
mutants_x_rows__mutmut['x_rows__mutmut_14'] = x_rows__mutmut_14 # type: ignore # mutmut generated
mutants_x_rows__mutmut['x_rows__mutmut_15'] = x_rows__mutmut_15 # type: ignore # mutmut generated
mutants_x_rows__mutmut['x_rows__mutmut_16'] = x_rows__mutmut_16 # type: ignore # mutmut generated
mutants_x_rows__mutmut['x_rows__mutmut_17'] = x_rows__mutmut_17 # type: ignore # mutmut generated
mutants_x_rows__mutmut['x_rows__mutmut_18'] = x_rows__mutmut_18 # type: ignore # mutmut generated
mutants_x_rows__mutmut['x_rows__mutmut_19'] = x_rows__mutmut_19 # type: ignore # mutmut generated
mutants_x_rows__mutmut['x_rows__mutmut_20'] = x_rows__mutmut_20 # type: ignore # mutmut generated
mutants_x_rows__mutmut['x_rows__mutmut_21'] = x_rows__mutmut_21 # type: ignore # mutmut generated
mutants_x_rows__mutmut['x_rows__mutmut_22'] = x_rows__mutmut_22 # type: ignore # mutmut generated
mutants_x_rows__mutmut['x_rows__mutmut_23'] = x_rows__mutmut_23 # type: ignore # mutmut generated
mutants_x_rows__mutmut['x_rows__mutmut_24'] = x_rows__mutmut_24 # type: ignore # mutmut generated
mutants_x_rows__mutmut['x_rows__mutmut_25'] = x_rows__mutmut_25 # type: ignore # mutmut generated
mutants_x_rows__mutmut['x_rows__mutmut_26'] = x_rows__mutmut_26 # type: ignore # mutmut generated
mutants_x_rows__mutmut['x_rows__mutmut_27'] = x_rows__mutmut_27 # type: ignore # mutmut generated
mutants_x_rows__mutmut['x_rows__mutmut_28'] = x_rows__mutmut_28 # type: ignore # mutmut generated
mutants_x_rows__mutmut['x_rows__mutmut_29'] = x_rows__mutmut_29 # type: ignore # mutmut generated
mutants_x_rows__mutmut['x_rows__mutmut_30'] = x_rows__mutmut_30 # type: ignore # mutmut generated
mutants_x_rows__mutmut['x_rows__mutmut_31'] = x_rows__mutmut_31 # type: ignore # mutmut generated
mutants_x_rows__mutmut['x_rows__mutmut_32'] = x_rows__mutmut_32 # type: ignore # mutmut generated
mutants_x_rows__mutmut['x_rows__mutmut_33'] = x_rows__mutmut_33 # type: ignore # mutmut generated
mutants_x_rows__mutmut['x_rows__mutmut_34'] = x_rows__mutmut_34 # type: ignore # mutmut generated
mutants_x_rows__mutmut['x_rows__mutmut_35'] = x_rows__mutmut_35 # type: ignore # mutmut generated
mutants_x_rows__mutmut['x_rows__mutmut_36'] = x_rows__mutmut_36 # type: ignore # mutmut generated
mutants_x_rows__mutmut['x_rows__mutmut_37'] = x_rows__mutmut_37 # type: ignore # mutmut generated
mutants_x_rows__mutmut['x_rows__mutmut_38'] = x_rows__mutmut_38 # type: ignore # mutmut generated
mutants_x_rows__mutmut['x_rows__mutmut_39'] = x_rows__mutmut_39 # type: ignore # mutmut generated
mutants_x_rows__mutmut['x_rows__mutmut_40'] = x_rows__mutmut_40 # type: ignore # mutmut generated
mutants_x_rows__mutmut['x_rows__mutmut_41'] = x_rows__mutmut_41 # type: ignore # mutmut generated
mutants_x_rows__mutmut['x_rows__mutmut_42'] = x_rows__mutmut_42 # type: ignore # mutmut generated
mutants_x_rows__mutmut['x_rows__mutmut_43'] = x_rows__mutmut_43 # type: ignore # mutmut generated
mutants_x_rows__mutmut['x_rows__mutmut_44'] = x_rows__mutmut_44 # type: ignore # mutmut generated
mutants_x_rows__mutmut['x_rows__mutmut_45'] = x_rows__mutmut_45 # type: ignore # mutmut generated
mutants_x_rows__mutmut['x_rows__mutmut_46'] = x_rows__mutmut_46 # type: ignore # mutmut generated
mutants_x_rows__mutmut['x_rows__mutmut_47'] = x_rows__mutmut_47 # type: ignore # mutmut generated
mutants_x_rows__mutmut['x_rows__mutmut_48'] = x_rows__mutmut_48 # type: ignore # mutmut generated
mutants_x_rows__mutmut['x_rows__mutmut_49'] = x_rows__mutmut_49 # type: ignore # mutmut generated
mutants_x_rows__mutmut['x_rows__mutmut_50'] = x_rows__mutmut_50 # type: ignore # mutmut generated
mutants_x_rows__mutmut['x_rows__mutmut_51'] = x_rows__mutmut_51 # type: ignore # mutmut generated
mutants_x_rows__mutmut['x_rows__mutmut_52'] = x_rows__mutmut_52 # type: ignore # mutmut generated
mutants_x_rows__mutmut['x_rows__mutmut_53'] = x_rows__mutmut_53 # type: ignore # mutmut generated
mutants_x_rows__mutmut['x_rows__mutmut_54'] = x_rows__mutmut_54 # type: ignore # mutmut generated
mutants_x_rows__mutmut['x_rows__mutmut_55'] = x_rows__mutmut_55 # type: ignore # mutmut generated
mutants_x_rows__mutmut['x_rows__mutmut_56'] = x_rows__mutmut_56 # type: ignore # mutmut generated
mutants_x_rows__mutmut['x_rows__mutmut_57'] = x_rows__mutmut_57 # type: ignore # mutmut generated
mutants_x_rows__mutmut['x_rows__mutmut_58'] = x_rows__mutmut_58 # type: ignore # mutmut generated
mutants_x_rows__mutmut['x_rows__mutmut_59'] = x_rows__mutmut_59 # type: ignore # mutmut generated
mutants_x_rows__mutmut['x_rows__mutmut_60'] = x_rows__mutmut_60 # type: ignore # mutmut generated
mutants_x_rows__mutmut['x_rows__mutmut_61'] = x_rows__mutmut_61 # type: ignore # mutmut generated
mutants_x_rows__mutmut['x_rows__mutmut_62'] = x_rows__mutmut_62 # type: ignore # mutmut generated
mutants_x_rows__mutmut['x_rows__mutmut_63'] = x_rows__mutmut_63 # type: ignore # mutmut generated
mutants_x_rows__mutmut['x_rows__mutmut_64'] = x_rows__mutmut_64 # type: ignore # mutmut generated
mutants_x_rows__mutmut['x_rows__mutmut_65'] = x_rows__mutmut_65 # type: ignore # mutmut generated
mutants_x_rows__mutmut['x_rows__mutmut_66'] = x_rows__mutmut_66 # type: ignore # mutmut generated
mutants_x_rows__mutmut['x_rows__mutmut_67'] = x_rows__mutmut_67 # type: ignore # mutmut generated
mutants_x_rows__mutmut['x_rows__mutmut_68'] = x_rows__mutmut_68 # type: ignore # mutmut generated
mutants_x_rows__mutmut['x_rows__mutmut_69'] = x_rows__mutmut_69 # type: ignore # mutmut generated
mutants_x_rows__mutmut['x_rows__mutmut_70'] = x_rows__mutmut_70 # type: ignore # mutmut generated
mutants_x_rows__mutmut['x_rows__mutmut_71'] = x_rows__mutmut_71 # type: ignore # mutmut generated
mutants_x_rows__mutmut['x_rows__mutmut_72'] = x_rows__mutmut_72 # type: ignore # mutmut generated
mutants_x_rows__mutmut['x_rows__mutmut_73'] = x_rows__mutmut_73 # type: ignore # mutmut generated
mutants_x_rows__mutmut['x_rows__mutmut_74'] = x_rows__mutmut_74 # type: ignore # mutmut generated
mutants_x_rows__mutmut['x_rows__mutmut_75'] = x_rows__mutmut_75 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_pool_rows__mutmut)
def pool_rows(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_orig(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_1(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = None

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_2(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads(None)

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_3(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" * "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_4(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence * "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_5(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "XXlabelled_poolXX" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_6(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "LABELLED_POOL" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_7(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "XXlabelled_results.jsonXX").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_8(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "LABELLED_RESULTS.JSON").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_9(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(None, payload["index"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_10(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], None, payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_11(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], None)

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_12(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["index"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_13(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_14(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], )

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_15(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["XXdataXX"], payload["index"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_16(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["DATA"], payload["index"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_17(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["XXindexXX"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_18(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["INDEX"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_19(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["XXcolumnsXX"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_20(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["COLUMNS"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_21(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["columns"])

    pr = None
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_22(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["columns"])

    pr = pd.concat(None)
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_23(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["columns"])

    pr = pd.concat([frame(None), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_24(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["columns"])

    pr = pd.concat([frame(results["XXpr_aucXX"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_25(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["columns"])

    pr = pd.concat([frame(results["PR_AUC"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_26(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(None)])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_27(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["XXdeepXX"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_28(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["DEEP"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_29(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["XXpr_aucXX"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_30(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["PR_AUC"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_31(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = None
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_32(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat(None)
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_33(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(None), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_34(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["XXroc_aucXX"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_35(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["ROC_AUC"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_36(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(None)])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_37(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["XXdeepXX"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_38(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["DEEP"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_39(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["XXroc_aucXX"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_40(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["ROC_AUC"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_41(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = None
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_42(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["XXmedian_rank_allXX"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_43(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["MEDIAN_RANK_ALL"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_44(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = None
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_45(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" * "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_46(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence * "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_47(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "XXlabelled_poolXX" / "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_48(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "LABELLED_POOL" / "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_49(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "XXrunsXX",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_50(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "RUNS",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_51(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" * "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_52(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" * "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_53(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence * "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_54(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "XXfull_registryXX" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_55(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "FULL_REGISTRY" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_56(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "XXpool_deepXX" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_57(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "POOL_DEEP" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_58(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" / "XXrunsXX",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_59(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" / "RUNS",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_60(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob(None):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_61(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("XX*.jsonXX"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_62(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.JSON"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_63(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get(None, {}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_64(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", None):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_65(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get({}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_66(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", ):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_67(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(None).get("metrics", {}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_68(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("XXmetricsXX", {}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_69(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("METRICS", {}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_70(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = None
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_71(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, 0) - 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_72(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(None, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_73(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, None) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_74(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_75(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, ) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_76(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, 1) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_77(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, 0) + 2
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_78(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, 0) + 1
    lines = None
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_79(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = None
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_80(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            None
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_81(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['XXmedianXX']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_82(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['MEDIAN']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_83(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['XXloXX']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_84(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['LO']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_85(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['XXhiXX']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_86(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['HI']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_87(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'XXmedianXX']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_88(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'MEDIAN']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_89(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name not in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_90(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(None)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_91(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[3], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_92(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(None)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_93(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[11]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_pool_rows__mutmut_94(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(None)
    return "\n".join(lines)


def x_pool_rows__mutmut_95(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"XX\midruleXX")
    return "\n".join(lines)


def x_pool_rows__mutmut_96(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\mIDRULE")
    return "\n".join(lines)


def x_pool_rows__mutmut_97(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(None)


def x_pool_rows__mutmut_98(evidence: Path = EVIDENCE) -> str:
    """Rows of the labelled-pool table: problems run, median PR-AUC with its interval, ROC, rank."""
    results = json.loads((evidence / "labelled_pool" / "labelled_results.json").read_text())

    def frame(payload: dict) -> pd.DataFrame:
        return pd.DataFrame(payload["data"], payload["index"], payload["columns"])

    pr = pd.concat([frame(results["pr_auc"]), frame(results["deep"]["pr_auc"])])
    roc = pd.concat([frame(results["roc_auc"]), frame(results["deep"]["roc_auc"])])
    ranks = results["median_rank_all"]
    counts: dict[str, int] = {}
    for folder in (
        evidence / "labelled_pool" / "runs",
        evidence / "full_registry" / "pool_deep" / "runs",
    ):
        for path in folder.glob("*.json"):
            for method in json.loads(path.read_text()).get("metrics", {}):
                counts[method] = counts.get(method, 0) + 1
    lines = []
    for name in NAMES:
        a = pr.loc[name]
        lines.append(
            f"{NAMES[name]:<18} & {counts[name]} & {a['median']:.3f} "
            f"[{a['lo']:.3f}, {a['hi']:.3f}] & {roc.loc[name, 'median']:.3f} "
            f"& {ranks[name]:.1f} \\\\"
        )
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "XX\nXX".join(lines)

mutants_x_pool_rows__mutmut['_mutmut_orig'] = x_pool_rows__mutmut_orig # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_1'] = x_pool_rows__mutmut_1 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_2'] = x_pool_rows__mutmut_2 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_3'] = x_pool_rows__mutmut_3 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_4'] = x_pool_rows__mutmut_4 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_5'] = x_pool_rows__mutmut_5 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_6'] = x_pool_rows__mutmut_6 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_7'] = x_pool_rows__mutmut_7 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_8'] = x_pool_rows__mutmut_8 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_9'] = x_pool_rows__mutmut_9 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_10'] = x_pool_rows__mutmut_10 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_11'] = x_pool_rows__mutmut_11 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_12'] = x_pool_rows__mutmut_12 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_13'] = x_pool_rows__mutmut_13 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_14'] = x_pool_rows__mutmut_14 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_15'] = x_pool_rows__mutmut_15 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_16'] = x_pool_rows__mutmut_16 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_17'] = x_pool_rows__mutmut_17 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_18'] = x_pool_rows__mutmut_18 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_19'] = x_pool_rows__mutmut_19 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_20'] = x_pool_rows__mutmut_20 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_21'] = x_pool_rows__mutmut_21 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_22'] = x_pool_rows__mutmut_22 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_23'] = x_pool_rows__mutmut_23 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_24'] = x_pool_rows__mutmut_24 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_25'] = x_pool_rows__mutmut_25 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_26'] = x_pool_rows__mutmut_26 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_27'] = x_pool_rows__mutmut_27 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_28'] = x_pool_rows__mutmut_28 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_29'] = x_pool_rows__mutmut_29 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_30'] = x_pool_rows__mutmut_30 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_31'] = x_pool_rows__mutmut_31 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_32'] = x_pool_rows__mutmut_32 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_33'] = x_pool_rows__mutmut_33 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_34'] = x_pool_rows__mutmut_34 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_35'] = x_pool_rows__mutmut_35 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_36'] = x_pool_rows__mutmut_36 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_37'] = x_pool_rows__mutmut_37 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_38'] = x_pool_rows__mutmut_38 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_39'] = x_pool_rows__mutmut_39 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_40'] = x_pool_rows__mutmut_40 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_41'] = x_pool_rows__mutmut_41 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_42'] = x_pool_rows__mutmut_42 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_43'] = x_pool_rows__mutmut_43 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_44'] = x_pool_rows__mutmut_44 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_45'] = x_pool_rows__mutmut_45 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_46'] = x_pool_rows__mutmut_46 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_47'] = x_pool_rows__mutmut_47 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_48'] = x_pool_rows__mutmut_48 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_49'] = x_pool_rows__mutmut_49 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_50'] = x_pool_rows__mutmut_50 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_51'] = x_pool_rows__mutmut_51 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_52'] = x_pool_rows__mutmut_52 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_53'] = x_pool_rows__mutmut_53 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_54'] = x_pool_rows__mutmut_54 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_55'] = x_pool_rows__mutmut_55 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_56'] = x_pool_rows__mutmut_56 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_57'] = x_pool_rows__mutmut_57 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_58'] = x_pool_rows__mutmut_58 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_59'] = x_pool_rows__mutmut_59 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_60'] = x_pool_rows__mutmut_60 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_61'] = x_pool_rows__mutmut_61 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_62'] = x_pool_rows__mutmut_62 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_63'] = x_pool_rows__mutmut_63 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_64'] = x_pool_rows__mutmut_64 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_65'] = x_pool_rows__mutmut_65 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_66'] = x_pool_rows__mutmut_66 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_67'] = x_pool_rows__mutmut_67 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_68'] = x_pool_rows__mutmut_68 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_69'] = x_pool_rows__mutmut_69 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_70'] = x_pool_rows__mutmut_70 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_71'] = x_pool_rows__mutmut_71 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_72'] = x_pool_rows__mutmut_72 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_73'] = x_pool_rows__mutmut_73 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_74'] = x_pool_rows__mutmut_74 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_75'] = x_pool_rows__mutmut_75 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_76'] = x_pool_rows__mutmut_76 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_77'] = x_pool_rows__mutmut_77 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_78'] = x_pool_rows__mutmut_78 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_79'] = x_pool_rows__mutmut_79 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_80'] = x_pool_rows__mutmut_80 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_81'] = x_pool_rows__mutmut_81 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_82'] = x_pool_rows__mutmut_82 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_83'] = x_pool_rows__mutmut_83 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_84'] = x_pool_rows__mutmut_84 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_85'] = x_pool_rows__mutmut_85 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_86'] = x_pool_rows__mutmut_86 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_87'] = x_pool_rows__mutmut_87 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_88'] = x_pool_rows__mutmut_88 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_89'] = x_pool_rows__mutmut_89 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_90'] = x_pool_rows__mutmut_90 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_91'] = x_pool_rows__mutmut_91 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_92'] = x_pool_rows__mutmut_92 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_93'] = x_pool_rows__mutmut_93 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_94'] = x_pool_rows__mutmut_94 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_95'] = x_pool_rows__mutmut_95 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_96'] = x_pool_rows__mutmut_96 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_97'] = x_pool_rows__mutmut_97 # type: ignore # mutmut generated
mutants_x_pool_rows__mutmut['x_pool_rows__mutmut_98'] = x_pool_rows__mutmut_98 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_chrono_rows__mutmut)
def chrono_rows(evidence: Path = EVIDENCE) -> str:
    """Rows of the chronological-pilot table, in registry order."""
    pilot = json.loads((evidence / "temporal_pilot" / "temporal_pilot.json").read_text())
    lines = []
    for name in NAMES:
        if name not in pilot["chronological"]:
            continue
        chron, strat = pilot["chronological"][name], pilot["stratified"][name]
        ci = chron["pr_auc_ci"]
        lines.append(
            f"{NAMES[name]:<18} & ${strat['pr_auc']['mean']:.3f} "
            f"\\pm {strat['pr_auc']['std']:.3f}$ "
            f"& ${chron['pr_auc']:.3f}$ [{ci['ci_low']:.3f}, {ci['ci_high']:.3f}] "
            f"& {chron['roc_auc']:.3f} & {chron['flagged_pct']:.2f} \\\\"
        )
        if name == list(NAMES)[2]:
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_chrono_rows__mutmut_orig(evidence: Path = EVIDENCE) -> str:
    """Rows of the chronological-pilot table, in registry order."""
    pilot = json.loads((evidence / "temporal_pilot" / "temporal_pilot.json").read_text())
    lines = []
    for name in NAMES:
        if name not in pilot["chronological"]:
            continue
        chron, strat = pilot["chronological"][name], pilot["stratified"][name]
        ci = chron["pr_auc_ci"]
        lines.append(
            f"{NAMES[name]:<18} & ${strat['pr_auc']['mean']:.3f} "
            f"\\pm {strat['pr_auc']['std']:.3f}$ "
            f"& ${chron['pr_auc']:.3f}$ [{ci['ci_low']:.3f}, {ci['ci_high']:.3f}] "
            f"& {chron['roc_auc']:.3f} & {chron['flagged_pct']:.2f} \\\\"
        )
        if name == list(NAMES)[2]:
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_chrono_rows__mutmut_1(evidence: Path = EVIDENCE) -> str:
    """Rows of the chronological-pilot table, in registry order."""
    pilot = None
    lines = []
    for name in NAMES:
        if name not in pilot["chronological"]:
            continue
        chron, strat = pilot["chronological"][name], pilot["stratified"][name]
        ci = chron["pr_auc_ci"]
        lines.append(
            f"{NAMES[name]:<18} & ${strat['pr_auc']['mean']:.3f} "
            f"\\pm {strat['pr_auc']['std']:.3f}$ "
            f"& ${chron['pr_auc']:.3f}$ [{ci['ci_low']:.3f}, {ci['ci_high']:.3f}] "
            f"& {chron['roc_auc']:.3f} & {chron['flagged_pct']:.2f} \\\\"
        )
        if name == list(NAMES)[2]:
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_chrono_rows__mutmut_2(evidence: Path = EVIDENCE) -> str:
    """Rows of the chronological-pilot table, in registry order."""
    pilot = json.loads(None)
    lines = []
    for name in NAMES:
        if name not in pilot["chronological"]:
            continue
        chron, strat = pilot["chronological"][name], pilot["stratified"][name]
        ci = chron["pr_auc_ci"]
        lines.append(
            f"{NAMES[name]:<18} & ${strat['pr_auc']['mean']:.3f} "
            f"\\pm {strat['pr_auc']['std']:.3f}$ "
            f"& ${chron['pr_auc']:.3f}$ [{ci['ci_low']:.3f}, {ci['ci_high']:.3f}] "
            f"& {chron['roc_auc']:.3f} & {chron['flagged_pct']:.2f} \\\\"
        )
        if name == list(NAMES)[2]:
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_chrono_rows__mutmut_3(evidence: Path = EVIDENCE) -> str:
    """Rows of the chronological-pilot table, in registry order."""
    pilot = json.loads((evidence / "temporal_pilot" * "temporal_pilot.json").read_text())
    lines = []
    for name in NAMES:
        if name not in pilot["chronological"]:
            continue
        chron, strat = pilot["chronological"][name], pilot["stratified"][name]
        ci = chron["pr_auc_ci"]
        lines.append(
            f"{NAMES[name]:<18} & ${strat['pr_auc']['mean']:.3f} "
            f"\\pm {strat['pr_auc']['std']:.3f}$ "
            f"& ${chron['pr_auc']:.3f}$ [{ci['ci_low']:.3f}, {ci['ci_high']:.3f}] "
            f"& {chron['roc_auc']:.3f} & {chron['flagged_pct']:.2f} \\\\"
        )
        if name == list(NAMES)[2]:
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_chrono_rows__mutmut_4(evidence: Path = EVIDENCE) -> str:
    """Rows of the chronological-pilot table, in registry order."""
    pilot = json.loads((evidence * "temporal_pilot" / "temporal_pilot.json").read_text())
    lines = []
    for name in NAMES:
        if name not in pilot["chronological"]:
            continue
        chron, strat = pilot["chronological"][name], pilot["stratified"][name]
        ci = chron["pr_auc_ci"]
        lines.append(
            f"{NAMES[name]:<18} & ${strat['pr_auc']['mean']:.3f} "
            f"\\pm {strat['pr_auc']['std']:.3f}$ "
            f"& ${chron['pr_auc']:.3f}$ [{ci['ci_low']:.3f}, {ci['ci_high']:.3f}] "
            f"& {chron['roc_auc']:.3f} & {chron['flagged_pct']:.2f} \\\\"
        )
        if name == list(NAMES)[2]:
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_chrono_rows__mutmut_5(evidence: Path = EVIDENCE) -> str:
    """Rows of the chronological-pilot table, in registry order."""
    pilot = json.loads((evidence / "XXtemporal_pilotXX" / "temporal_pilot.json").read_text())
    lines = []
    for name in NAMES:
        if name not in pilot["chronological"]:
            continue
        chron, strat = pilot["chronological"][name], pilot["stratified"][name]
        ci = chron["pr_auc_ci"]
        lines.append(
            f"{NAMES[name]:<18} & ${strat['pr_auc']['mean']:.3f} "
            f"\\pm {strat['pr_auc']['std']:.3f}$ "
            f"& ${chron['pr_auc']:.3f}$ [{ci['ci_low']:.3f}, {ci['ci_high']:.3f}] "
            f"& {chron['roc_auc']:.3f} & {chron['flagged_pct']:.2f} \\\\"
        )
        if name == list(NAMES)[2]:
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_chrono_rows__mutmut_6(evidence: Path = EVIDENCE) -> str:
    """Rows of the chronological-pilot table, in registry order."""
    pilot = json.loads((evidence / "TEMPORAL_PILOT" / "temporal_pilot.json").read_text())
    lines = []
    for name in NAMES:
        if name not in pilot["chronological"]:
            continue
        chron, strat = pilot["chronological"][name], pilot["stratified"][name]
        ci = chron["pr_auc_ci"]
        lines.append(
            f"{NAMES[name]:<18} & ${strat['pr_auc']['mean']:.3f} "
            f"\\pm {strat['pr_auc']['std']:.3f}$ "
            f"& ${chron['pr_auc']:.3f}$ [{ci['ci_low']:.3f}, {ci['ci_high']:.3f}] "
            f"& {chron['roc_auc']:.3f} & {chron['flagged_pct']:.2f} \\\\"
        )
        if name == list(NAMES)[2]:
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_chrono_rows__mutmut_7(evidence: Path = EVIDENCE) -> str:
    """Rows of the chronological-pilot table, in registry order."""
    pilot = json.loads((evidence / "temporal_pilot" / "XXtemporal_pilot.jsonXX").read_text())
    lines = []
    for name in NAMES:
        if name not in pilot["chronological"]:
            continue
        chron, strat = pilot["chronological"][name], pilot["stratified"][name]
        ci = chron["pr_auc_ci"]
        lines.append(
            f"{NAMES[name]:<18} & ${strat['pr_auc']['mean']:.3f} "
            f"\\pm {strat['pr_auc']['std']:.3f}$ "
            f"& ${chron['pr_auc']:.3f}$ [{ci['ci_low']:.3f}, {ci['ci_high']:.3f}] "
            f"& {chron['roc_auc']:.3f} & {chron['flagged_pct']:.2f} \\\\"
        )
        if name == list(NAMES)[2]:
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_chrono_rows__mutmut_8(evidence: Path = EVIDENCE) -> str:
    """Rows of the chronological-pilot table, in registry order."""
    pilot = json.loads((evidence / "temporal_pilot" / "TEMPORAL_PILOT.JSON").read_text())
    lines = []
    for name in NAMES:
        if name not in pilot["chronological"]:
            continue
        chron, strat = pilot["chronological"][name], pilot["stratified"][name]
        ci = chron["pr_auc_ci"]
        lines.append(
            f"{NAMES[name]:<18} & ${strat['pr_auc']['mean']:.3f} "
            f"\\pm {strat['pr_auc']['std']:.3f}$ "
            f"& ${chron['pr_auc']:.3f}$ [{ci['ci_low']:.3f}, {ci['ci_high']:.3f}] "
            f"& {chron['roc_auc']:.3f} & {chron['flagged_pct']:.2f} \\\\"
        )
        if name == list(NAMES)[2]:
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_chrono_rows__mutmut_9(evidence: Path = EVIDENCE) -> str:
    """Rows of the chronological-pilot table, in registry order."""
    pilot = json.loads((evidence / "temporal_pilot" / "temporal_pilot.json").read_text())
    lines = None
    for name in NAMES:
        if name not in pilot["chronological"]:
            continue
        chron, strat = pilot["chronological"][name], pilot["stratified"][name]
        ci = chron["pr_auc_ci"]
        lines.append(
            f"{NAMES[name]:<18} & ${strat['pr_auc']['mean']:.3f} "
            f"\\pm {strat['pr_auc']['std']:.3f}$ "
            f"& ${chron['pr_auc']:.3f}$ [{ci['ci_low']:.3f}, {ci['ci_high']:.3f}] "
            f"& {chron['roc_auc']:.3f} & {chron['flagged_pct']:.2f} \\\\"
        )
        if name == list(NAMES)[2]:
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_chrono_rows__mutmut_10(evidence: Path = EVIDENCE) -> str:
    """Rows of the chronological-pilot table, in registry order."""
    pilot = json.loads((evidence / "temporal_pilot" / "temporal_pilot.json").read_text())
    lines = []
    for name in NAMES:
        if name in pilot["chronological"]:
            continue
        chron, strat = pilot["chronological"][name], pilot["stratified"][name]
        ci = chron["pr_auc_ci"]
        lines.append(
            f"{NAMES[name]:<18} & ${strat['pr_auc']['mean']:.3f} "
            f"\\pm {strat['pr_auc']['std']:.3f}$ "
            f"& ${chron['pr_auc']:.3f}$ [{ci['ci_low']:.3f}, {ci['ci_high']:.3f}] "
            f"& {chron['roc_auc']:.3f} & {chron['flagged_pct']:.2f} \\\\"
        )
        if name == list(NAMES)[2]:
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_chrono_rows__mutmut_11(evidence: Path = EVIDENCE) -> str:
    """Rows of the chronological-pilot table, in registry order."""
    pilot = json.loads((evidence / "temporal_pilot" / "temporal_pilot.json").read_text())
    lines = []
    for name in NAMES:
        if name not in pilot["XXchronologicalXX"]:
            continue
        chron, strat = pilot["chronological"][name], pilot["stratified"][name]
        ci = chron["pr_auc_ci"]
        lines.append(
            f"{NAMES[name]:<18} & ${strat['pr_auc']['mean']:.3f} "
            f"\\pm {strat['pr_auc']['std']:.3f}$ "
            f"& ${chron['pr_auc']:.3f}$ [{ci['ci_low']:.3f}, {ci['ci_high']:.3f}] "
            f"& {chron['roc_auc']:.3f} & {chron['flagged_pct']:.2f} \\\\"
        )
        if name == list(NAMES)[2]:
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_chrono_rows__mutmut_12(evidence: Path = EVIDENCE) -> str:
    """Rows of the chronological-pilot table, in registry order."""
    pilot = json.loads((evidence / "temporal_pilot" / "temporal_pilot.json").read_text())
    lines = []
    for name in NAMES:
        if name not in pilot["CHRONOLOGICAL"]:
            continue
        chron, strat = pilot["chronological"][name], pilot["stratified"][name]
        ci = chron["pr_auc_ci"]
        lines.append(
            f"{NAMES[name]:<18} & ${strat['pr_auc']['mean']:.3f} "
            f"\\pm {strat['pr_auc']['std']:.3f}$ "
            f"& ${chron['pr_auc']:.3f}$ [{ci['ci_low']:.3f}, {ci['ci_high']:.3f}] "
            f"& {chron['roc_auc']:.3f} & {chron['flagged_pct']:.2f} \\\\"
        )
        if name == list(NAMES)[2]:
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_chrono_rows__mutmut_13(evidence: Path = EVIDENCE) -> str:
    """Rows of the chronological-pilot table, in registry order."""
    pilot = json.loads((evidence / "temporal_pilot" / "temporal_pilot.json").read_text())
    lines = []
    for name in NAMES:
        if name not in pilot["chronological"]:
            break
        chron, strat = pilot["chronological"][name], pilot["stratified"][name]
        ci = chron["pr_auc_ci"]
        lines.append(
            f"{NAMES[name]:<18} & ${strat['pr_auc']['mean']:.3f} "
            f"\\pm {strat['pr_auc']['std']:.3f}$ "
            f"& ${chron['pr_auc']:.3f}$ [{ci['ci_low']:.3f}, {ci['ci_high']:.3f}] "
            f"& {chron['roc_auc']:.3f} & {chron['flagged_pct']:.2f} \\\\"
        )
        if name == list(NAMES)[2]:
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_chrono_rows__mutmut_14(evidence: Path = EVIDENCE) -> str:
    """Rows of the chronological-pilot table, in registry order."""
    pilot = json.loads((evidence / "temporal_pilot" / "temporal_pilot.json").read_text())
    lines = []
    for name in NAMES:
        if name not in pilot["chronological"]:
            continue
        chron, strat = None
        ci = chron["pr_auc_ci"]
        lines.append(
            f"{NAMES[name]:<18} & ${strat['pr_auc']['mean']:.3f} "
            f"\\pm {strat['pr_auc']['std']:.3f}$ "
            f"& ${chron['pr_auc']:.3f}$ [{ci['ci_low']:.3f}, {ci['ci_high']:.3f}] "
            f"& {chron['roc_auc']:.3f} & {chron['flagged_pct']:.2f} \\\\"
        )
        if name == list(NAMES)[2]:
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_chrono_rows__mutmut_15(evidence: Path = EVIDENCE) -> str:
    """Rows of the chronological-pilot table, in registry order."""
    pilot = json.loads((evidence / "temporal_pilot" / "temporal_pilot.json").read_text())
    lines = []
    for name in NAMES:
        if name not in pilot["chronological"]:
            continue
        chron, strat = pilot["XXchronologicalXX"][name], pilot["stratified"][name]
        ci = chron["pr_auc_ci"]
        lines.append(
            f"{NAMES[name]:<18} & ${strat['pr_auc']['mean']:.3f} "
            f"\\pm {strat['pr_auc']['std']:.3f}$ "
            f"& ${chron['pr_auc']:.3f}$ [{ci['ci_low']:.3f}, {ci['ci_high']:.3f}] "
            f"& {chron['roc_auc']:.3f} & {chron['flagged_pct']:.2f} \\\\"
        )
        if name == list(NAMES)[2]:
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_chrono_rows__mutmut_16(evidence: Path = EVIDENCE) -> str:
    """Rows of the chronological-pilot table, in registry order."""
    pilot = json.loads((evidence / "temporal_pilot" / "temporal_pilot.json").read_text())
    lines = []
    for name in NAMES:
        if name not in pilot["chronological"]:
            continue
        chron, strat = pilot["CHRONOLOGICAL"][name], pilot["stratified"][name]
        ci = chron["pr_auc_ci"]
        lines.append(
            f"{NAMES[name]:<18} & ${strat['pr_auc']['mean']:.3f} "
            f"\\pm {strat['pr_auc']['std']:.3f}$ "
            f"& ${chron['pr_auc']:.3f}$ [{ci['ci_low']:.3f}, {ci['ci_high']:.3f}] "
            f"& {chron['roc_auc']:.3f} & {chron['flagged_pct']:.2f} \\\\"
        )
        if name == list(NAMES)[2]:
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_chrono_rows__mutmut_17(evidence: Path = EVIDENCE) -> str:
    """Rows of the chronological-pilot table, in registry order."""
    pilot = json.loads((evidence / "temporal_pilot" / "temporal_pilot.json").read_text())
    lines = []
    for name in NAMES:
        if name not in pilot["chronological"]:
            continue
        chron, strat = pilot["chronological"][name], pilot["XXstratifiedXX"][name]
        ci = chron["pr_auc_ci"]
        lines.append(
            f"{NAMES[name]:<18} & ${strat['pr_auc']['mean']:.3f} "
            f"\\pm {strat['pr_auc']['std']:.3f}$ "
            f"& ${chron['pr_auc']:.3f}$ [{ci['ci_low']:.3f}, {ci['ci_high']:.3f}] "
            f"& {chron['roc_auc']:.3f} & {chron['flagged_pct']:.2f} \\\\"
        )
        if name == list(NAMES)[2]:
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_chrono_rows__mutmut_18(evidence: Path = EVIDENCE) -> str:
    """Rows of the chronological-pilot table, in registry order."""
    pilot = json.loads((evidence / "temporal_pilot" / "temporal_pilot.json").read_text())
    lines = []
    for name in NAMES:
        if name not in pilot["chronological"]:
            continue
        chron, strat = pilot["chronological"][name], pilot["STRATIFIED"][name]
        ci = chron["pr_auc_ci"]
        lines.append(
            f"{NAMES[name]:<18} & ${strat['pr_auc']['mean']:.3f} "
            f"\\pm {strat['pr_auc']['std']:.3f}$ "
            f"& ${chron['pr_auc']:.3f}$ [{ci['ci_low']:.3f}, {ci['ci_high']:.3f}] "
            f"& {chron['roc_auc']:.3f} & {chron['flagged_pct']:.2f} \\\\"
        )
        if name == list(NAMES)[2]:
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_chrono_rows__mutmut_19(evidence: Path = EVIDENCE) -> str:
    """Rows of the chronological-pilot table, in registry order."""
    pilot = json.loads((evidence / "temporal_pilot" / "temporal_pilot.json").read_text())
    lines = []
    for name in NAMES:
        if name not in pilot["chronological"]:
            continue
        chron, strat = pilot["chronological"][name], pilot["stratified"][name]
        ci = None
        lines.append(
            f"{NAMES[name]:<18} & ${strat['pr_auc']['mean']:.3f} "
            f"\\pm {strat['pr_auc']['std']:.3f}$ "
            f"& ${chron['pr_auc']:.3f}$ [{ci['ci_low']:.3f}, {ci['ci_high']:.3f}] "
            f"& {chron['roc_auc']:.3f} & {chron['flagged_pct']:.2f} \\\\"
        )
        if name == list(NAMES)[2]:
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_chrono_rows__mutmut_20(evidence: Path = EVIDENCE) -> str:
    """Rows of the chronological-pilot table, in registry order."""
    pilot = json.loads((evidence / "temporal_pilot" / "temporal_pilot.json").read_text())
    lines = []
    for name in NAMES:
        if name not in pilot["chronological"]:
            continue
        chron, strat = pilot["chronological"][name], pilot["stratified"][name]
        ci = chron["XXpr_auc_ciXX"]
        lines.append(
            f"{NAMES[name]:<18} & ${strat['pr_auc']['mean']:.3f} "
            f"\\pm {strat['pr_auc']['std']:.3f}$ "
            f"& ${chron['pr_auc']:.3f}$ [{ci['ci_low']:.3f}, {ci['ci_high']:.3f}] "
            f"& {chron['roc_auc']:.3f} & {chron['flagged_pct']:.2f} \\\\"
        )
        if name == list(NAMES)[2]:
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_chrono_rows__mutmut_21(evidence: Path = EVIDENCE) -> str:
    """Rows of the chronological-pilot table, in registry order."""
    pilot = json.loads((evidence / "temporal_pilot" / "temporal_pilot.json").read_text())
    lines = []
    for name in NAMES:
        if name not in pilot["chronological"]:
            continue
        chron, strat = pilot["chronological"][name], pilot["stratified"][name]
        ci = chron["PR_AUC_CI"]
        lines.append(
            f"{NAMES[name]:<18} & ${strat['pr_auc']['mean']:.3f} "
            f"\\pm {strat['pr_auc']['std']:.3f}$ "
            f"& ${chron['pr_auc']:.3f}$ [{ci['ci_low']:.3f}, {ci['ci_high']:.3f}] "
            f"& {chron['roc_auc']:.3f} & {chron['flagged_pct']:.2f} \\\\"
        )
        if name == list(NAMES)[2]:
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_chrono_rows__mutmut_22(evidence: Path = EVIDENCE) -> str:
    """Rows of the chronological-pilot table, in registry order."""
    pilot = json.loads((evidence / "temporal_pilot" / "temporal_pilot.json").read_text())
    lines = []
    for name in NAMES:
        if name not in pilot["chronological"]:
            continue
        chron, strat = pilot["chronological"][name], pilot["stratified"][name]
        ci = chron["pr_auc_ci"]
        lines.append(
            None
        )
        if name == list(NAMES)[2]:
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_chrono_rows__mutmut_23(evidence: Path = EVIDENCE) -> str:
    """Rows of the chronological-pilot table, in registry order."""
    pilot = json.loads((evidence / "temporal_pilot" / "temporal_pilot.json").read_text())
    lines = []
    for name in NAMES:
        if name not in pilot["chronological"]:
            continue
        chron, strat = pilot["chronological"][name], pilot["stratified"][name]
        ci = chron["pr_auc_ci"]
        lines.append(
            f"{NAMES[name]:<18} & ${strat['XXpr_aucXX']['mean']:.3f} "
            f"\\pm {strat['pr_auc']['std']:.3f}$ "
            f"& ${chron['pr_auc']:.3f}$ [{ci['ci_low']:.3f}, {ci['ci_high']:.3f}] "
            f"& {chron['roc_auc']:.3f} & {chron['flagged_pct']:.2f} \\\\"
        )
        if name == list(NAMES)[2]:
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_chrono_rows__mutmut_24(evidence: Path = EVIDENCE) -> str:
    """Rows of the chronological-pilot table, in registry order."""
    pilot = json.loads((evidence / "temporal_pilot" / "temporal_pilot.json").read_text())
    lines = []
    for name in NAMES:
        if name not in pilot["chronological"]:
            continue
        chron, strat = pilot["chronological"][name], pilot["stratified"][name]
        ci = chron["pr_auc_ci"]
        lines.append(
            f"{NAMES[name]:<18} & ${strat['PR_AUC']['mean']:.3f} "
            f"\\pm {strat['pr_auc']['std']:.3f}$ "
            f"& ${chron['pr_auc']:.3f}$ [{ci['ci_low']:.3f}, {ci['ci_high']:.3f}] "
            f"& {chron['roc_auc']:.3f} & {chron['flagged_pct']:.2f} \\\\"
        )
        if name == list(NAMES)[2]:
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_chrono_rows__mutmut_25(evidence: Path = EVIDENCE) -> str:
    """Rows of the chronological-pilot table, in registry order."""
    pilot = json.loads((evidence / "temporal_pilot" / "temporal_pilot.json").read_text())
    lines = []
    for name in NAMES:
        if name not in pilot["chronological"]:
            continue
        chron, strat = pilot["chronological"][name], pilot["stratified"][name]
        ci = chron["pr_auc_ci"]
        lines.append(
            f"{NAMES[name]:<18} & ${strat['pr_auc']['XXmeanXX']:.3f} "
            f"\\pm {strat['pr_auc']['std']:.3f}$ "
            f"& ${chron['pr_auc']:.3f}$ [{ci['ci_low']:.3f}, {ci['ci_high']:.3f}] "
            f"& {chron['roc_auc']:.3f} & {chron['flagged_pct']:.2f} \\\\"
        )
        if name == list(NAMES)[2]:
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_chrono_rows__mutmut_26(evidence: Path = EVIDENCE) -> str:
    """Rows of the chronological-pilot table, in registry order."""
    pilot = json.loads((evidence / "temporal_pilot" / "temporal_pilot.json").read_text())
    lines = []
    for name in NAMES:
        if name not in pilot["chronological"]:
            continue
        chron, strat = pilot["chronological"][name], pilot["stratified"][name]
        ci = chron["pr_auc_ci"]
        lines.append(
            f"{NAMES[name]:<18} & ${strat['pr_auc']['MEAN']:.3f} "
            f"\\pm {strat['pr_auc']['std']:.3f}$ "
            f"& ${chron['pr_auc']:.3f}$ [{ci['ci_low']:.3f}, {ci['ci_high']:.3f}] "
            f"& {chron['roc_auc']:.3f} & {chron['flagged_pct']:.2f} \\\\"
        )
        if name == list(NAMES)[2]:
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_chrono_rows__mutmut_27(evidence: Path = EVIDENCE) -> str:
    """Rows of the chronological-pilot table, in registry order."""
    pilot = json.loads((evidence / "temporal_pilot" / "temporal_pilot.json").read_text())
    lines = []
    for name in NAMES:
        if name not in pilot["chronological"]:
            continue
        chron, strat = pilot["chronological"][name], pilot["stratified"][name]
        ci = chron["pr_auc_ci"]
        lines.append(
            f"{NAMES[name]:<18} & ${strat['pr_auc']['mean']:.3f} "
            f"\\pm {strat['XXpr_aucXX']['std']:.3f}$ "
            f"& ${chron['pr_auc']:.3f}$ [{ci['ci_low']:.3f}, {ci['ci_high']:.3f}] "
            f"& {chron['roc_auc']:.3f} & {chron['flagged_pct']:.2f} \\\\"
        )
        if name == list(NAMES)[2]:
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_chrono_rows__mutmut_28(evidence: Path = EVIDENCE) -> str:
    """Rows of the chronological-pilot table, in registry order."""
    pilot = json.loads((evidence / "temporal_pilot" / "temporal_pilot.json").read_text())
    lines = []
    for name in NAMES:
        if name not in pilot["chronological"]:
            continue
        chron, strat = pilot["chronological"][name], pilot["stratified"][name]
        ci = chron["pr_auc_ci"]
        lines.append(
            f"{NAMES[name]:<18} & ${strat['pr_auc']['mean']:.3f} "
            f"\\pm {strat['PR_AUC']['std']:.3f}$ "
            f"& ${chron['pr_auc']:.3f}$ [{ci['ci_low']:.3f}, {ci['ci_high']:.3f}] "
            f"& {chron['roc_auc']:.3f} & {chron['flagged_pct']:.2f} \\\\"
        )
        if name == list(NAMES)[2]:
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_chrono_rows__mutmut_29(evidence: Path = EVIDENCE) -> str:
    """Rows of the chronological-pilot table, in registry order."""
    pilot = json.loads((evidence / "temporal_pilot" / "temporal_pilot.json").read_text())
    lines = []
    for name in NAMES:
        if name not in pilot["chronological"]:
            continue
        chron, strat = pilot["chronological"][name], pilot["stratified"][name]
        ci = chron["pr_auc_ci"]
        lines.append(
            f"{NAMES[name]:<18} & ${strat['pr_auc']['mean']:.3f} "
            f"\\pm {strat['pr_auc']['XXstdXX']:.3f}$ "
            f"& ${chron['pr_auc']:.3f}$ [{ci['ci_low']:.3f}, {ci['ci_high']:.3f}] "
            f"& {chron['roc_auc']:.3f} & {chron['flagged_pct']:.2f} \\\\"
        )
        if name == list(NAMES)[2]:
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_chrono_rows__mutmut_30(evidence: Path = EVIDENCE) -> str:
    """Rows of the chronological-pilot table, in registry order."""
    pilot = json.loads((evidence / "temporal_pilot" / "temporal_pilot.json").read_text())
    lines = []
    for name in NAMES:
        if name not in pilot["chronological"]:
            continue
        chron, strat = pilot["chronological"][name], pilot["stratified"][name]
        ci = chron["pr_auc_ci"]
        lines.append(
            f"{NAMES[name]:<18} & ${strat['pr_auc']['mean']:.3f} "
            f"\\pm {strat['pr_auc']['STD']:.3f}$ "
            f"& ${chron['pr_auc']:.3f}$ [{ci['ci_low']:.3f}, {ci['ci_high']:.3f}] "
            f"& {chron['roc_auc']:.3f} & {chron['flagged_pct']:.2f} \\\\"
        )
        if name == list(NAMES)[2]:
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_chrono_rows__mutmut_31(evidence: Path = EVIDENCE) -> str:
    """Rows of the chronological-pilot table, in registry order."""
    pilot = json.loads((evidence / "temporal_pilot" / "temporal_pilot.json").read_text())
    lines = []
    for name in NAMES:
        if name not in pilot["chronological"]:
            continue
        chron, strat = pilot["chronological"][name], pilot["stratified"][name]
        ci = chron["pr_auc_ci"]
        lines.append(
            f"{NAMES[name]:<18} & ${strat['pr_auc']['mean']:.3f} "
            f"\\pm {strat['pr_auc']['std']:.3f}$ "
            f"& ${chron['XXpr_aucXX']:.3f}$ [{ci['ci_low']:.3f}, {ci['ci_high']:.3f}] "
            f"& {chron['roc_auc']:.3f} & {chron['flagged_pct']:.2f} \\\\"
        )
        if name == list(NAMES)[2]:
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_chrono_rows__mutmut_32(evidence: Path = EVIDENCE) -> str:
    """Rows of the chronological-pilot table, in registry order."""
    pilot = json.loads((evidence / "temporal_pilot" / "temporal_pilot.json").read_text())
    lines = []
    for name in NAMES:
        if name not in pilot["chronological"]:
            continue
        chron, strat = pilot["chronological"][name], pilot["stratified"][name]
        ci = chron["pr_auc_ci"]
        lines.append(
            f"{NAMES[name]:<18} & ${strat['pr_auc']['mean']:.3f} "
            f"\\pm {strat['pr_auc']['std']:.3f}$ "
            f"& ${chron['PR_AUC']:.3f}$ [{ci['ci_low']:.3f}, {ci['ci_high']:.3f}] "
            f"& {chron['roc_auc']:.3f} & {chron['flagged_pct']:.2f} \\\\"
        )
        if name == list(NAMES)[2]:
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_chrono_rows__mutmut_33(evidence: Path = EVIDENCE) -> str:
    """Rows of the chronological-pilot table, in registry order."""
    pilot = json.loads((evidence / "temporal_pilot" / "temporal_pilot.json").read_text())
    lines = []
    for name in NAMES:
        if name not in pilot["chronological"]:
            continue
        chron, strat = pilot["chronological"][name], pilot["stratified"][name]
        ci = chron["pr_auc_ci"]
        lines.append(
            f"{NAMES[name]:<18} & ${strat['pr_auc']['mean']:.3f} "
            f"\\pm {strat['pr_auc']['std']:.3f}$ "
            f"& ${chron['pr_auc']:.3f}$ [{ci['XXci_lowXX']:.3f}, {ci['ci_high']:.3f}] "
            f"& {chron['roc_auc']:.3f} & {chron['flagged_pct']:.2f} \\\\"
        )
        if name == list(NAMES)[2]:
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_chrono_rows__mutmut_34(evidence: Path = EVIDENCE) -> str:
    """Rows of the chronological-pilot table, in registry order."""
    pilot = json.loads((evidence / "temporal_pilot" / "temporal_pilot.json").read_text())
    lines = []
    for name in NAMES:
        if name not in pilot["chronological"]:
            continue
        chron, strat = pilot["chronological"][name], pilot["stratified"][name]
        ci = chron["pr_auc_ci"]
        lines.append(
            f"{NAMES[name]:<18} & ${strat['pr_auc']['mean']:.3f} "
            f"\\pm {strat['pr_auc']['std']:.3f}$ "
            f"& ${chron['pr_auc']:.3f}$ [{ci['CI_LOW']:.3f}, {ci['ci_high']:.3f}] "
            f"& {chron['roc_auc']:.3f} & {chron['flagged_pct']:.2f} \\\\"
        )
        if name == list(NAMES)[2]:
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_chrono_rows__mutmut_35(evidence: Path = EVIDENCE) -> str:
    """Rows of the chronological-pilot table, in registry order."""
    pilot = json.loads((evidence / "temporal_pilot" / "temporal_pilot.json").read_text())
    lines = []
    for name in NAMES:
        if name not in pilot["chronological"]:
            continue
        chron, strat = pilot["chronological"][name], pilot["stratified"][name]
        ci = chron["pr_auc_ci"]
        lines.append(
            f"{NAMES[name]:<18} & ${strat['pr_auc']['mean']:.3f} "
            f"\\pm {strat['pr_auc']['std']:.3f}$ "
            f"& ${chron['pr_auc']:.3f}$ [{ci['ci_low']:.3f}, {ci['XXci_highXX']:.3f}] "
            f"& {chron['roc_auc']:.3f} & {chron['flagged_pct']:.2f} \\\\"
        )
        if name == list(NAMES)[2]:
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_chrono_rows__mutmut_36(evidence: Path = EVIDENCE) -> str:
    """Rows of the chronological-pilot table, in registry order."""
    pilot = json.loads((evidence / "temporal_pilot" / "temporal_pilot.json").read_text())
    lines = []
    for name in NAMES:
        if name not in pilot["chronological"]:
            continue
        chron, strat = pilot["chronological"][name], pilot["stratified"][name]
        ci = chron["pr_auc_ci"]
        lines.append(
            f"{NAMES[name]:<18} & ${strat['pr_auc']['mean']:.3f} "
            f"\\pm {strat['pr_auc']['std']:.3f}$ "
            f"& ${chron['pr_auc']:.3f}$ [{ci['ci_low']:.3f}, {ci['CI_HIGH']:.3f}] "
            f"& {chron['roc_auc']:.3f} & {chron['flagged_pct']:.2f} \\\\"
        )
        if name == list(NAMES)[2]:
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_chrono_rows__mutmut_37(evidence: Path = EVIDENCE) -> str:
    """Rows of the chronological-pilot table, in registry order."""
    pilot = json.loads((evidence / "temporal_pilot" / "temporal_pilot.json").read_text())
    lines = []
    for name in NAMES:
        if name not in pilot["chronological"]:
            continue
        chron, strat = pilot["chronological"][name], pilot["stratified"][name]
        ci = chron["pr_auc_ci"]
        lines.append(
            f"{NAMES[name]:<18} & ${strat['pr_auc']['mean']:.3f} "
            f"\\pm {strat['pr_auc']['std']:.3f}$ "
            f"& ${chron['pr_auc']:.3f}$ [{ci['ci_low']:.3f}, {ci['ci_high']:.3f}] "
            f"& {chron['XXroc_aucXX']:.3f} & {chron['flagged_pct']:.2f} \\\\"
        )
        if name == list(NAMES)[2]:
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_chrono_rows__mutmut_38(evidence: Path = EVIDENCE) -> str:
    """Rows of the chronological-pilot table, in registry order."""
    pilot = json.loads((evidence / "temporal_pilot" / "temporal_pilot.json").read_text())
    lines = []
    for name in NAMES:
        if name not in pilot["chronological"]:
            continue
        chron, strat = pilot["chronological"][name], pilot["stratified"][name]
        ci = chron["pr_auc_ci"]
        lines.append(
            f"{NAMES[name]:<18} & ${strat['pr_auc']['mean']:.3f} "
            f"\\pm {strat['pr_auc']['std']:.3f}$ "
            f"& ${chron['pr_auc']:.3f}$ [{ci['ci_low']:.3f}, {ci['ci_high']:.3f}] "
            f"& {chron['ROC_AUC']:.3f} & {chron['flagged_pct']:.2f} \\\\"
        )
        if name == list(NAMES)[2]:
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_chrono_rows__mutmut_39(evidence: Path = EVIDENCE) -> str:
    """Rows of the chronological-pilot table, in registry order."""
    pilot = json.loads((evidence / "temporal_pilot" / "temporal_pilot.json").read_text())
    lines = []
    for name in NAMES:
        if name not in pilot["chronological"]:
            continue
        chron, strat = pilot["chronological"][name], pilot["stratified"][name]
        ci = chron["pr_auc_ci"]
        lines.append(
            f"{NAMES[name]:<18} & ${strat['pr_auc']['mean']:.3f} "
            f"\\pm {strat['pr_auc']['std']:.3f}$ "
            f"& ${chron['pr_auc']:.3f}$ [{ci['ci_low']:.3f}, {ci['ci_high']:.3f}] "
            f"& {chron['roc_auc']:.3f} & {chron['XXflagged_pctXX']:.2f} \\\\"
        )
        if name == list(NAMES)[2]:
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_chrono_rows__mutmut_40(evidence: Path = EVIDENCE) -> str:
    """Rows of the chronological-pilot table, in registry order."""
    pilot = json.loads((evidence / "temporal_pilot" / "temporal_pilot.json").read_text())
    lines = []
    for name in NAMES:
        if name not in pilot["chronological"]:
            continue
        chron, strat = pilot["chronological"][name], pilot["stratified"][name]
        ci = chron["pr_auc_ci"]
        lines.append(
            f"{NAMES[name]:<18} & ${strat['pr_auc']['mean']:.3f} "
            f"\\pm {strat['pr_auc']['std']:.3f}$ "
            f"& ${chron['pr_auc']:.3f}$ [{ci['ci_low']:.3f}, {ci['ci_high']:.3f}] "
            f"& {chron['roc_auc']:.3f} & {chron['FLAGGED_PCT']:.2f} \\\\"
        )
        if name == list(NAMES)[2]:
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_chrono_rows__mutmut_41(evidence: Path = EVIDENCE) -> str:
    """Rows of the chronological-pilot table, in registry order."""
    pilot = json.loads((evidence / "temporal_pilot" / "temporal_pilot.json").read_text())
    lines = []
    for name in NAMES:
        if name not in pilot["chronological"]:
            continue
        chron, strat = pilot["chronological"][name], pilot["stratified"][name]
        ci = chron["pr_auc_ci"]
        lines.append(
            f"{NAMES[name]:<18} & ${strat['pr_auc']['mean']:.3f} "
            f"\\pm {strat['pr_auc']['std']:.3f}$ "
            f"& ${chron['pr_auc']:.3f}$ [{ci['ci_low']:.3f}, {ci['ci_high']:.3f}] "
            f"& {chron['roc_auc']:.3f} & {chron['flagged_pct']:.2f} \\\\"
        )
        if name != list(NAMES)[2]:
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_chrono_rows__mutmut_42(evidence: Path = EVIDENCE) -> str:
    """Rows of the chronological-pilot table, in registry order."""
    pilot = json.loads((evidence / "temporal_pilot" / "temporal_pilot.json").read_text())
    lines = []
    for name in NAMES:
        if name not in pilot["chronological"]:
            continue
        chron, strat = pilot["chronological"][name], pilot["stratified"][name]
        ci = chron["pr_auc_ci"]
        lines.append(
            f"{NAMES[name]:<18} & ${strat['pr_auc']['mean']:.3f} "
            f"\\pm {strat['pr_auc']['std']:.3f}$ "
            f"& ${chron['pr_auc']:.3f}$ [{ci['ci_low']:.3f}, {ci['ci_high']:.3f}] "
            f"& {chron['roc_auc']:.3f} & {chron['flagged_pct']:.2f} \\\\"
        )
        if name == list(None)[2]:
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_chrono_rows__mutmut_43(evidence: Path = EVIDENCE) -> str:
    """Rows of the chronological-pilot table, in registry order."""
    pilot = json.loads((evidence / "temporal_pilot" / "temporal_pilot.json").read_text())
    lines = []
    for name in NAMES:
        if name not in pilot["chronological"]:
            continue
        chron, strat = pilot["chronological"][name], pilot["stratified"][name]
        ci = chron["pr_auc_ci"]
        lines.append(
            f"{NAMES[name]:<18} & ${strat['pr_auc']['mean']:.3f} "
            f"\\pm {strat['pr_auc']['std']:.3f}$ "
            f"& ${chron['pr_auc']:.3f}$ [{ci['ci_low']:.3f}, {ci['ci_high']:.3f}] "
            f"& {chron['roc_auc']:.3f} & {chron['flagged_pct']:.2f} \\\\"
        )
        if name == list(NAMES)[3]:
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_chrono_rows__mutmut_44(evidence: Path = EVIDENCE) -> str:
    """Rows of the chronological-pilot table, in registry order."""
    pilot = json.loads((evidence / "temporal_pilot" / "temporal_pilot.json").read_text())
    lines = []
    for name in NAMES:
        if name not in pilot["chronological"]:
            continue
        chron, strat = pilot["chronological"][name], pilot["stratified"][name]
        ci = chron["pr_auc_ci"]
        lines.append(
            f"{NAMES[name]:<18} & ${strat['pr_auc']['mean']:.3f} "
            f"\\pm {strat['pr_auc']['std']:.3f}$ "
            f"& ${chron['pr_auc']:.3f}$ [{ci['ci_low']:.3f}, {ci['ci_high']:.3f}] "
            f"& {chron['roc_auc']:.3f} & {chron['flagged_pct']:.2f} \\\\"
        )
        if name == list(NAMES)[2]:
            lines.append(None)
    return "\n".join(lines)


def x_chrono_rows__mutmut_45(evidence: Path = EVIDENCE) -> str:
    """Rows of the chronological-pilot table, in registry order."""
    pilot = json.loads((evidence / "temporal_pilot" / "temporal_pilot.json").read_text())
    lines = []
    for name in NAMES:
        if name not in pilot["chronological"]:
            continue
        chron, strat = pilot["chronological"][name], pilot["stratified"][name]
        ci = chron["pr_auc_ci"]
        lines.append(
            f"{NAMES[name]:<18} & ${strat['pr_auc']['mean']:.3f} "
            f"\\pm {strat['pr_auc']['std']:.3f}$ "
            f"& ${chron['pr_auc']:.3f}$ [{ci['ci_low']:.3f}, {ci['ci_high']:.3f}] "
            f"& {chron['roc_auc']:.3f} & {chron['flagged_pct']:.2f} \\\\"
        )
        if name == list(NAMES)[2]:
            lines.append(r"XX\midruleXX")
    return "\n".join(lines)


def x_chrono_rows__mutmut_46(evidence: Path = EVIDENCE) -> str:
    """Rows of the chronological-pilot table, in registry order."""
    pilot = json.loads((evidence / "temporal_pilot" / "temporal_pilot.json").read_text())
    lines = []
    for name in NAMES:
        if name not in pilot["chronological"]:
            continue
        chron, strat = pilot["chronological"][name], pilot["stratified"][name]
        ci = chron["pr_auc_ci"]
        lines.append(
            f"{NAMES[name]:<18} & ${strat['pr_auc']['mean']:.3f} "
            f"\\pm {strat['pr_auc']['std']:.3f}$ "
            f"& ${chron['pr_auc']:.3f}$ [{ci['ci_low']:.3f}, {ci['ci_high']:.3f}] "
            f"& {chron['roc_auc']:.3f} & {chron['flagged_pct']:.2f} \\\\"
        )
        if name == list(NAMES)[2]:
            lines.append(r"\mIDRULE")
    return "\n".join(lines)


def x_chrono_rows__mutmut_47(evidence: Path = EVIDENCE) -> str:
    """Rows of the chronological-pilot table, in registry order."""
    pilot = json.loads((evidence / "temporal_pilot" / "temporal_pilot.json").read_text())
    lines = []
    for name in NAMES:
        if name not in pilot["chronological"]:
            continue
        chron, strat = pilot["chronological"][name], pilot["stratified"][name]
        ci = chron["pr_auc_ci"]
        lines.append(
            f"{NAMES[name]:<18} & ${strat['pr_auc']['mean']:.3f} "
            f"\\pm {strat['pr_auc']['std']:.3f}$ "
            f"& ${chron['pr_auc']:.3f}$ [{ci['ci_low']:.3f}, {ci['ci_high']:.3f}] "
            f"& {chron['roc_auc']:.3f} & {chron['flagged_pct']:.2f} \\\\"
        )
        if name == list(NAMES)[2]:
            lines.append(r"\midrule")
    return "\n".join(None)


def x_chrono_rows__mutmut_48(evidence: Path = EVIDENCE) -> str:
    """Rows of the chronological-pilot table, in registry order."""
    pilot = json.loads((evidence / "temporal_pilot" / "temporal_pilot.json").read_text())
    lines = []
    for name in NAMES:
        if name not in pilot["chronological"]:
            continue
        chron, strat = pilot["chronological"][name], pilot["stratified"][name]
        ci = chron["pr_auc_ci"]
        lines.append(
            f"{NAMES[name]:<18} & ${strat['pr_auc']['mean']:.3f} "
            f"\\pm {strat['pr_auc']['std']:.3f}$ "
            f"& ${chron['pr_auc']:.3f}$ [{ci['ci_low']:.3f}, {ci['ci_high']:.3f}] "
            f"& {chron['roc_auc']:.3f} & {chron['flagged_pct']:.2f} \\\\"
        )
        if name == list(NAMES)[2]:
            lines.append(r"\midrule")
    return "XX\nXX".join(lines)

mutants_x_chrono_rows__mutmut['_mutmut_orig'] = x_chrono_rows__mutmut_orig # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_1'] = x_chrono_rows__mutmut_1 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_2'] = x_chrono_rows__mutmut_2 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_3'] = x_chrono_rows__mutmut_3 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_4'] = x_chrono_rows__mutmut_4 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_5'] = x_chrono_rows__mutmut_5 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_6'] = x_chrono_rows__mutmut_6 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_7'] = x_chrono_rows__mutmut_7 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_8'] = x_chrono_rows__mutmut_8 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_9'] = x_chrono_rows__mutmut_9 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_10'] = x_chrono_rows__mutmut_10 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_11'] = x_chrono_rows__mutmut_11 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_12'] = x_chrono_rows__mutmut_12 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_13'] = x_chrono_rows__mutmut_13 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_14'] = x_chrono_rows__mutmut_14 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_15'] = x_chrono_rows__mutmut_15 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_16'] = x_chrono_rows__mutmut_16 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_17'] = x_chrono_rows__mutmut_17 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_18'] = x_chrono_rows__mutmut_18 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_19'] = x_chrono_rows__mutmut_19 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_20'] = x_chrono_rows__mutmut_20 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_21'] = x_chrono_rows__mutmut_21 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_22'] = x_chrono_rows__mutmut_22 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_23'] = x_chrono_rows__mutmut_23 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_24'] = x_chrono_rows__mutmut_24 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_25'] = x_chrono_rows__mutmut_25 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_26'] = x_chrono_rows__mutmut_26 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_27'] = x_chrono_rows__mutmut_27 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_28'] = x_chrono_rows__mutmut_28 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_29'] = x_chrono_rows__mutmut_29 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_30'] = x_chrono_rows__mutmut_30 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_31'] = x_chrono_rows__mutmut_31 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_32'] = x_chrono_rows__mutmut_32 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_33'] = x_chrono_rows__mutmut_33 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_34'] = x_chrono_rows__mutmut_34 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_35'] = x_chrono_rows__mutmut_35 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_36'] = x_chrono_rows__mutmut_36 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_37'] = x_chrono_rows__mutmut_37 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_38'] = x_chrono_rows__mutmut_38 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_39'] = x_chrono_rows__mutmut_39 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_40'] = x_chrono_rows__mutmut_40 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_41'] = x_chrono_rows__mutmut_41 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_42'] = x_chrono_rows__mutmut_42 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_43'] = x_chrono_rows__mutmut_43 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_44'] = x_chrono_rows__mutmut_44 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_45'] = x_chrono_rows__mutmut_45 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_46'] = x_chrono_rows__mutmut_46 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_47'] = x_chrono_rows__mutmut_47 # type: ignore # mutmut generated
mutants_x_chrono_rows__mutmut['x_chrono_rows__mutmut_48'] = x_chrono_rows__mutmut_48 # type: ignore # mutmut generated


LABELS = {
    "missing_value": "Miss.",
    "duplicate": "Dup.",
    "univariate_outlier": "Uni.",
    "multivariate_outlier": "Multi.",
    "temporal_drift": "Drift",
    "invalid_format": "Inv.",
}
EXTRA_NAMES = {
    "lstm_autoencoder": "LSTM autoencoder",
    "drift": "Drift detector",
    "transform_dedup": "Dedup rule",
}
mutants_x_matrix_table__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_matrix_table__mutmut)
def matrix_table(frame: pd.DataFrame, caption: str, label: str) -> str:
    """A LaTeX table of mean recall by method and type, the best value of each column in bold."""
    best = frame.max()
    lines = [
        r"\begin{table}[t]",
        rf"\caption{{{caption}}}",
        rf"\label{{{label}}}",
        r"\centering",
        r"\footnotesize",
        r"\setlength{\tabcolsep}{3pt}",
        r"\begin{tabular}{l" + "c" * len(frame.columns) + "}",
        r"\toprule",
        "Method & " + " & ".join(LABELS[c] for c in frame.columns) + r" \\",
        r"\midrule",
    ]
    names = {**NAMES, **EXTRA_NAMES}
    for method in frame.index:
        cells = []
        for column in frame.columns:
            text = f"{frame.loc[method, column]:.2f}"
            if method in NAMES and round(frame.loc[method, column], 2) == round(best[column], 2):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{names[method]:<18} & " + " & ".join(cells) + r" \\")
        if method in ("great_expectations", "pca", "lunar"):
            lines.append(r"\midrule")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    return "\n".join(lines)


def x_matrix_table__mutmut_orig(frame: pd.DataFrame, caption: str, label: str) -> str:
    """A LaTeX table of mean recall by method and type, the best value of each column in bold."""
    best = frame.max()
    lines = [
        r"\begin{table}[t]",
        rf"\caption{{{caption}}}",
        rf"\label{{{label}}}",
        r"\centering",
        r"\footnotesize",
        r"\setlength{\tabcolsep}{3pt}",
        r"\begin{tabular}{l" + "c" * len(frame.columns) + "}",
        r"\toprule",
        "Method & " + " & ".join(LABELS[c] for c in frame.columns) + r" \\",
        r"\midrule",
    ]
    names = {**NAMES, **EXTRA_NAMES}
    for method in frame.index:
        cells = []
        for column in frame.columns:
            text = f"{frame.loc[method, column]:.2f}"
            if method in NAMES and round(frame.loc[method, column], 2) == round(best[column], 2):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{names[method]:<18} & " + " & ".join(cells) + r" \\")
        if method in ("great_expectations", "pca", "lunar"):
            lines.append(r"\midrule")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    return "\n".join(lines)


def x_matrix_table__mutmut_1(frame: pd.DataFrame, caption: str, label: str) -> str:
    """A LaTeX table of mean recall by method and type, the best value of each column in bold."""
    best = None
    lines = [
        r"\begin{table}[t]",
        rf"\caption{{{caption}}}",
        rf"\label{{{label}}}",
        r"\centering",
        r"\footnotesize",
        r"\setlength{\tabcolsep}{3pt}",
        r"\begin{tabular}{l" + "c" * len(frame.columns) + "}",
        r"\toprule",
        "Method & " + " & ".join(LABELS[c] for c in frame.columns) + r" \\",
        r"\midrule",
    ]
    names = {**NAMES, **EXTRA_NAMES}
    for method in frame.index:
        cells = []
        for column in frame.columns:
            text = f"{frame.loc[method, column]:.2f}"
            if method in NAMES and round(frame.loc[method, column], 2) == round(best[column], 2):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{names[method]:<18} & " + " & ".join(cells) + r" \\")
        if method in ("great_expectations", "pca", "lunar"):
            lines.append(r"\midrule")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    return "\n".join(lines)


def x_matrix_table__mutmut_2(frame: pd.DataFrame, caption: str, label: str) -> str:
    """A LaTeX table of mean recall by method and type, the best value of each column in bold."""
    best = frame.max()
    lines = None
    names = {**NAMES, **EXTRA_NAMES}
    for method in frame.index:
        cells = []
        for column in frame.columns:
            text = f"{frame.loc[method, column]:.2f}"
            if method in NAMES and round(frame.loc[method, column], 2) == round(best[column], 2):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{names[method]:<18} & " + " & ".join(cells) + r" \\")
        if method in ("great_expectations", "pca", "lunar"):
            lines.append(r"\midrule")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    return "\n".join(lines)


def x_matrix_table__mutmut_3(frame: pd.DataFrame, caption: str, label: str) -> str:
    """A LaTeX table of mean recall by method and type, the best value of each column in bold."""
    best = frame.max()
    lines = [
        r"XX\begin{table}[t]XX",
        rf"\caption{{{caption}}}",
        rf"\label{{{label}}}",
        r"\centering",
        r"\footnotesize",
        r"\setlength{\tabcolsep}{3pt}",
        r"\begin{tabular}{l" + "c" * len(frame.columns) + "}",
        r"\toprule",
        "Method & " + " & ".join(LABELS[c] for c in frame.columns) + r" \\",
        r"\midrule",
    ]
    names = {**NAMES, **EXTRA_NAMES}
    for method in frame.index:
        cells = []
        for column in frame.columns:
            text = f"{frame.loc[method, column]:.2f}"
            if method in NAMES and round(frame.loc[method, column], 2) == round(best[column], 2):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{names[method]:<18} & " + " & ".join(cells) + r" \\")
        if method in ("great_expectations", "pca", "lunar"):
            lines.append(r"\midrule")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    return "\n".join(lines)


def x_matrix_table__mutmut_4(frame: pd.DataFrame, caption: str, label: str) -> str:
    """A LaTeX table of mean recall by method and type, the best value of each column in bold."""
    best = frame.max()
    lines = [
        r"\bEGIN{TABLE}[T]",
        rf"\caption{{{caption}}}",
        rf"\label{{{label}}}",
        r"\centering",
        r"\footnotesize",
        r"\setlength{\tabcolsep}{3pt}",
        r"\begin{tabular}{l" + "c" * len(frame.columns) + "}",
        r"\toprule",
        "Method & " + " & ".join(LABELS[c] for c in frame.columns) + r" \\",
        r"\midrule",
    ]
    names = {**NAMES, **EXTRA_NAMES}
    for method in frame.index:
        cells = []
        for column in frame.columns:
            text = f"{frame.loc[method, column]:.2f}"
            if method in NAMES and round(frame.loc[method, column], 2) == round(best[column], 2):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{names[method]:<18} & " + " & ".join(cells) + r" \\")
        if method in ("great_expectations", "pca", "lunar"):
            lines.append(r"\midrule")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    return "\n".join(lines)


def x_matrix_table__mutmut_5(frame: pd.DataFrame, caption: str, label: str) -> str:
    """A LaTeX table of mean recall by method and type, the best value of each column in bold."""
    best = frame.max()
    lines = [
        r"\begin{table}[t]",
        rf"\caption{{{caption}}}",
        rf"\label{{{label}}}",
        r"XX\centeringXX",
        r"\footnotesize",
        r"\setlength{\tabcolsep}{3pt}",
        r"\begin{tabular}{l" + "c" * len(frame.columns) + "}",
        r"\toprule",
        "Method & " + " & ".join(LABELS[c] for c in frame.columns) + r" \\",
        r"\midrule",
    ]
    names = {**NAMES, **EXTRA_NAMES}
    for method in frame.index:
        cells = []
        for column in frame.columns:
            text = f"{frame.loc[method, column]:.2f}"
            if method in NAMES and round(frame.loc[method, column], 2) == round(best[column], 2):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{names[method]:<18} & " + " & ".join(cells) + r" \\")
        if method in ("great_expectations", "pca", "lunar"):
            lines.append(r"\midrule")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    return "\n".join(lines)


def x_matrix_table__mutmut_6(frame: pd.DataFrame, caption: str, label: str) -> str:
    """A LaTeX table of mean recall by method and type, the best value of each column in bold."""
    best = frame.max()
    lines = [
        r"\begin{table}[t]",
        rf"\caption{{{caption}}}",
        rf"\label{{{label}}}",
        r"\cENTERING",
        r"\footnotesize",
        r"\setlength{\tabcolsep}{3pt}",
        r"\begin{tabular}{l" + "c" * len(frame.columns) + "}",
        r"\toprule",
        "Method & " + " & ".join(LABELS[c] for c in frame.columns) + r" \\",
        r"\midrule",
    ]
    names = {**NAMES, **EXTRA_NAMES}
    for method in frame.index:
        cells = []
        for column in frame.columns:
            text = f"{frame.loc[method, column]:.2f}"
            if method in NAMES and round(frame.loc[method, column], 2) == round(best[column], 2):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{names[method]:<18} & " + " & ".join(cells) + r" \\")
        if method in ("great_expectations", "pca", "lunar"):
            lines.append(r"\midrule")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    return "\n".join(lines)


def x_matrix_table__mutmut_7(frame: pd.DataFrame, caption: str, label: str) -> str:
    """A LaTeX table of mean recall by method and type, the best value of each column in bold."""
    best = frame.max()
    lines = [
        r"\begin{table}[t]",
        rf"\caption{{{caption}}}",
        rf"\label{{{label}}}",
        r"\centering",
        r"XX\footnotesizeXX",
        r"\setlength{\tabcolsep}{3pt}",
        r"\begin{tabular}{l" + "c" * len(frame.columns) + "}",
        r"\toprule",
        "Method & " + " & ".join(LABELS[c] for c in frame.columns) + r" \\",
        r"\midrule",
    ]
    names = {**NAMES, **EXTRA_NAMES}
    for method in frame.index:
        cells = []
        for column in frame.columns:
            text = f"{frame.loc[method, column]:.2f}"
            if method in NAMES and round(frame.loc[method, column], 2) == round(best[column], 2):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{names[method]:<18} & " + " & ".join(cells) + r" \\")
        if method in ("great_expectations", "pca", "lunar"):
            lines.append(r"\midrule")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    return "\n".join(lines)


def x_matrix_table__mutmut_8(frame: pd.DataFrame, caption: str, label: str) -> str:
    """A LaTeX table of mean recall by method and type, the best value of each column in bold."""
    best = frame.max()
    lines = [
        r"\begin{table}[t]",
        rf"\caption{{{caption}}}",
        rf"\label{{{label}}}",
        r"\centering",
        r"\fOOTNOTESIZE",
        r"\setlength{\tabcolsep}{3pt}",
        r"\begin{tabular}{l" + "c" * len(frame.columns) + "}",
        r"\toprule",
        "Method & " + " & ".join(LABELS[c] for c in frame.columns) + r" \\",
        r"\midrule",
    ]
    names = {**NAMES, **EXTRA_NAMES}
    for method in frame.index:
        cells = []
        for column in frame.columns:
            text = f"{frame.loc[method, column]:.2f}"
            if method in NAMES and round(frame.loc[method, column], 2) == round(best[column], 2):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{names[method]:<18} & " + " & ".join(cells) + r" \\")
        if method in ("great_expectations", "pca", "lunar"):
            lines.append(r"\midrule")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    return "\n".join(lines)


def x_matrix_table__mutmut_9(frame: pd.DataFrame, caption: str, label: str) -> str:
    """A LaTeX table of mean recall by method and type, the best value of each column in bold."""
    best = frame.max()
    lines = [
        r"\begin{table}[t]",
        rf"\caption{{{caption}}}",
        rf"\label{{{label}}}",
        r"\centering",
        r"\footnotesize",
        r"XX\setlength{\tabcolsep}{3pt}XX",
        r"\begin{tabular}{l" + "c" * len(frame.columns) + "}",
        r"\toprule",
        "Method & " + " & ".join(LABELS[c] for c in frame.columns) + r" \\",
        r"\midrule",
    ]
    names = {**NAMES, **EXTRA_NAMES}
    for method in frame.index:
        cells = []
        for column in frame.columns:
            text = f"{frame.loc[method, column]:.2f}"
            if method in NAMES and round(frame.loc[method, column], 2) == round(best[column], 2):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{names[method]:<18} & " + " & ".join(cells) + r" \\")
        if method in ("great_expectations", "pca", "lunar"):
            lines.append(r"\midrule")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    return "\n".join(lines)


def x_matrix_table__mutmut_10(frame: pd.DataFrame, caption: str, label: str) -> str:
    """A LaTeX table of mean recall by method and type, the best value of each column in bold."""
    best = frame.max()
    lines = [
        r"\begin{table}[t]",
        rf"\caption{{{caption}}}",
        rf"\label{{{label}}}",
        r"\centering",
        r"\footnotesize",
        r"\sETLENGTH{\tABCOLSEP}{3PT}",
        r"\begin{tabular}{l" + "c" * len(frame.columns) + "}",
        r"\toprule",
        "Method & " + " & ".join(LABELS[c] for c in frame.columns) + r" \\",
        r"\midrule",
    ]
    names = {**NAMES, **EXTRA_NAMES}
    for method in frame.index:
        cells = []
        for column in frame.columns:
            text = f"{frame.loc[method, column]:.2f}"
            if method in NAMES and round(frame.loc[method, column], 2) == round(best[column], 2):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{names[method]:<18} & " + " & ".join(cells) + r" \\")
        if method in ("great_expectations", "pca", "lunar"):
            lines.append(r"\midrule")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    return "\n".join(lines)


def x_matrix_table__mutmut_11(frame: pd.DataFrame, caption: str, label: str) -> str:
    """A LaTeX table of mean recall by method and type, the best value of each column in bold."""
    best = frame.max()
    lines = [
        r"\begin{table}[t]",
        rf"\caption{{{caption}}}",
        rf"\label{{{label}}}",
        r"\centering",
        r"\footnotesize",
        r"\setlength{\tabcolsep}{3pt}",
        r"\begin{tabular}{l" + "c" * len(frame.columns) - "}",
        r"\toprule",
        "Method & " + " & ".join(LABELS[c] for c in frame.columns) + r" \\",
        r"\midrule",
    ]
    names = {**NAMES, **EXTRA_NAMES}
    for method in frame.index:
        cells = []
        for column in frame.columns:
            text = f"{frame.loc[method, column]:.2f}"
            if method in NAMES and round(frame.loc[method, column], 2) == round(best[column], 2):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{names[method]:<18} & " + " & ".join(cells) + r" \\")
        if method in ("great_expectations", "pca", "lunar"):
            lines.append(r"\midrule")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    return "\n".join(lines)


def x_matrix_table__mutmut_12(frame: pd.DataFrame, caption: str, label: str) -> str:
    """A LaTeX table of mean recall by method and type, the best value of each column in bold."""
    best = frame.max()
    lines = [
        r"\begin{table}[t]",
        rf"\caption{{{caption}}}",
        rf"\label{{{label}}}",
        r"\centering",
        r"\footnotesize",
        r"\setlength{\tabcolsep}{3pt}",
        r"\begin{tabular}{l" - "c" * len(frame.columns) + "}",
        r"\toprule",
        "Method & " + " & ".join(LABELS[c] for c in frame.columns) + r" \\",
        r"\midrule",
    ]
    names = {**NAMES, **EXTRA_NAMES}
    for method in frame.index:
        cells = []
        for column in frame.columns:
            text = f"{frame.loc[method, column]:.2f}"
            if method in NAMES and round(frame.loc[method, column], 2) == round(best[column], 2):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{names[method]:<18} & " + " & ".join(cells) + r" \\")
        if method in ("great_expectations", "pca", "lunar"):
            lines.append(r"\midrule")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    return "\n".join(lines)


def x_matrix_table__mutmut_13(frame: pd.DataFrame, caption: str, label: str) -> str:
    """A LaTeX table of mean recall by method and type, the best value of each column in bold."""
    best = frame.max()
    lines = [
        r"\begin{table}[t]",
        rf"\caption{{{caption}}}",
        rf"\label{{{label}}}",
        r"\centering",
        r"\footnotesize",
        r"\setlength{\tabcolsep}{3pt}",
        r"XX\begin{tabular}{lXX" + "c" * len(frame.columns) + "}",
        r"\toprule",
        "Method & " + " & ".join(LABELS[c] for c in frame.columns) + r" \\",
        r"\midrule",
    ]
    names = {**NAMES, **EXTRA_NAMES}
    for method in frame.index:
        cells = []
        for column in frame.columns:
            text = f"{frame.loc[method, column]:.2f}"
            if method in NAMES and round(frame.loc[method, column], 2) == round(best[column], 2):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{names[method]:<18} & " + " & ".join(cells) + r" \\")
        if method in ("great_expectations", "pca", "lunar"):
            lines.append(r"\midrule")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    return "\n".join(lines)


def x_matrix_table__mutmut_14(frame: pd.DataFrame, caption: str, label: str) -> str:
    """A LaTeX table of mean recall by method and type, the best value of each column in bold."""
    best = frame.max()
    lines = [
        r"\begin{table}[t]",
        rf"\caption{{{caption}}}",
        rf"\label{{{label}}}",
        r"\centering",
        r"\footnotesize",
        r"\setlength{\tabcolsep}{3pt}",
        r"\bEGIN{TABULAR}{L" + "c" * len(frame.columns) + "}",
        r"\toprule",
        "Method & " + " & ".join(LABELS[c] for c in frame.columns) + r" \\",
        r"\midrule",
    ]
    names = {**NAMES, **EXTRA_NAMES}
    for method in frame.index:
        cells = []
        for column in frame.columns:
            text = f"{frame.loc[method, column]:.2f}"
            if method in NAMES and round(frame.loc[method, column], 2) == round(best[column], 2):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{names[method]:<18} & " + " & ".join(cells) + r" \\")
        if method in ("great_expectations", "pca", "lunar"):
            lines.append(r"\midrule")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    return "\n".join(lines)


def x_matrix_table__mutmut_15(frame: pd.DataFrame, caption: str, label: str) -> str:
    """A LaTeX table of mean recall by method and type, the best value of each column in bold."""
    best = frame.max()
    lines = [
        r"\begin{table}[t]",
        rf"\caption{{{caption}}}",
        rf"\label{{{label}}}",
        r"\centering",
        r"\footnotesize",
        r"\setlength{\tabcolsep}{3pt}",
        r"\begin{tabular}{l" + "c" / len(frame.columns) + "}",
        r"\toprule",
        "Method & " + " & ".join(LABELS[c] for c in frame.columns) + r" \\",
        r"\midrule",
    ]
    names = {**NAMES, **EXTRA_NAMES}
    for method in frame.index:
        cells = []
        for column in frame.columns:
            text = f"{frame.loc[method, column]:.2f}"
            if method in NAMES and round(frame.loc[method, column], 2) == round(best[column], 2):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{names[method]:<18} & " + " & ".join(cells) + r" \\")
        if method in ("great_expectations", "pca", "lunar"):
            lines.append(r"\midrule")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    return "\n".join(lines)


def x_matrix_table__mutmut_16(frame: pd.DataFrame, caption: str, label: str) -> str:
    """A LaTeX table of mean recall by method and type, the best value of each column in bold."""
    best = frame.max()
    lines = [
        r"\begin{table}[t]",
        rf"\caption{{{caption}}}",
        rf"\label{{{label}}}",
        r"\centering",
        r"\footnotesize",
        r"\setlength{\tabcolsep}{3pt}",
        r"\begin{tabular}{l" + "XXcXX" * len(frame.columns) + "}",
        r"\toprule",
        "Method & " + " & ".join(LABELS[c] for c in frame.columns) + r" \\",
        r"\midrule",
    ]
    names = {**NAMES, **EXTRA_NAMES}
    for method in frame.index:
        cells = []
        for column in frame.columns:
            text = f"{frame.loc[method, column]:.2f}"
            if method in NAMES and round(frame.loc[method, column], 2) == round(best[column], 2):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{names[method]:<18} & " + " & ".join(cells) + r" \\")
        if method in ("great_expectations", "pca", "lunar"):
            lines.append(r"\midrule")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    return "\n".join(lines)


def x_matrix_table__mutmut_17(frame: pd.DataFrame, caption: str, label: str) -> str:
    """A LaTeX table of mean recall by method and type, the best value of each column in bold."""
    best = frame.max()
    lines = [
        r"\begin{table}[t]",
        rf"\caption{{{caption}}}",
        rf"\label{{{label}}}",
        r"\centering",
        r"\footnotesize",
        r"\setlength{\tabcolsep}{3pt}",
        r"\begin{tabular}{l" + "C" * len(frame.columns) + "}",
        r"\toprule",
        "Method & " + " & ".join(LABELS[c] for c in frame.columns) + r" \\",
        r"\midrule",
    ]
    names = {**NAMES, **EXTRA_NAMES}
    for method in frame.index:
        cells = []
        for column in frame.columns:
            text = f"{frame.loc[method, column]:.2f}"
            if method in NAMES and round(frame.loc[method, column], 2) == round(best[column], 2):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{names[method]:<18} & " + " & ".join(cells) + r" \\")
        if method in ("great_expectations", "pca", "lunar"):
            lines.append(r"\midrule")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    return "\n".join(lines)


def x_matrix_table__mutmut_18(frame: pd.DataFrame, caption: str, label: str) -> str:
    """A LaTeX table of mean recall by method and type, the best value of each column in bold."""
    best = frame.max()
    lines = [
        r"\begin{table}[t]",
        rf"\caption{{{caption}}}",
        rf"\label{{{label}}}",
        r"\centering",
        r"\footnotesize",
        r"\setlength{\tabcolsep}{3pt}",
        r"\begin{tabular}{l" + "c" * len(frame.columns) + "XX}XX",
        r"\toprule",
        "Method & " + " & ".join(LABELS[c] for c in frame.columns) + r" \\",
        r"\midrule",
    ]
    names = {**NAMES, **EXTRA_NAMES}
    for method in frame.index:
        cells = []
        for column in frame.columns:
            text = f"{frame.loc[method, column]:.2f}"
            if method in NAMES and round(frame.loc[method, column], 2) == round(best[column], 2):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{names[method]:<18} & " + " & ".join(cells) + r" \\")
        if method in ("great_expectations", "pca", "lunar"):
            lines.append(r"\midrule")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    return "\n".join(lines)


def x_matrix_table__mutmut_19(frame: pd.DataFrame, caption: str, label: str) -> str:
    """A LaTeX table of mean recall by method and type, the best value of each column in bold."""
    best = frame.max()
    lines = [
        r"\begin{table}[t]",
        rf"\caption{{{caption}}}",
        rf"\label{{{label}}}",
        r"\centering",
        r"\footnotesize",
        r"\setlength{\tabcolsep}{3pt}",
        r"\begin{tabular}{l" + "c" * len(frame.columns) + "}",
        r"XX\topruleXX",
        "Method & " + " & ".join(LABELS[c] for c in frame.columns) + r" \\",
        r"\midrule",
    ]
    names = {**NAMES, **EXTRA_NAMES}
    for method in frame.index:
        cells = []
        for column in frame.columns:
            text = f"{frame.loc[method, column]:.2f}"
            if method in NAMES and round(frame.loc[method, column], 2) == round(best[column], 2):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{names[method]:<18} & " + " & ".join(cells) + r" \\")
        if method in ("great_expectations", "pca", "lunar"):
            lines.append(r"\midrule")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    return "\n".join(lines)


def x_matrix_table__mutmut_20(frame: pd.DataFrame, caption: str, label: str) -> str:
    """A LaTeX table of mean recall by method and type, the best value of each column in bold."""
    best = frame.max()
    lines = [
        r"\begin{table}[t]",
        rf"\caption{{{caption}}}",
        rf"\label{{{label}}}",
        r"\centering",
        r"\footnotesize",
        r"\setlength{\tabcolsep}{3pt}",
        r"\begin{tabular}{l" + "c" * len(frame.columns) + "}",
        r"\tOPRULE",
        "Method & " + " & ".join(LABELS[c] for c in frame.columns) + r" \\",
        r"\midrule",
    ]
    names = {**NAMES, **EXTRA_NAMES}
    for method in frame.index:
        cells = []
        for column in frame.columns:
            text = f"{frame.loc[method, column]:.2f}"
            if method in NAMES and round(frame.loc[method, column], 2) == round(best[column], 2):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{names[method]:<18} & " + " & ".join(cells) + r" \\")
        if method in ("great_expectations", "pca", "lunar"):
            lines.append(r"\midrule")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    return "\n".join(lines)


def x_matrix_table__mutmut_21(frame: pd.DataFrame, caption: str, label: str) -> str:
    """A LaTeX table of mean recall by method and type, the best value of each column in bold."""
    best = frame.max()
    lines = [
        r"\begin{table}[t]",
        rf"\caption{{{caption}}}",
        rf"\label{{{label}}}",
        r"\centering",
        r"\footnotesize",
        r"\setlength{\tabcolsep}{3pt}",
        r"\begin{tabular}{l" + "c" * len(frame.columns) + "}",
        r"\toprule",
        "Method & " + " & ".join(LABELS[c] for c in frame.columns) - r" \\",
        r"\midrule",
    ]
    names = {**NAMES, **EXTRA_NAMES}
    for method in frame.index:
        cells = []
        for column in frame.columns:
            text = f"{frame.loc[method, column]:.2f}"
            if method in NAMES and round(frame.loc[method, column], 2) == round(best[column], 2):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{names[method]:<18} & " + " & ".join(cells) + r" \\")
        if method in ("great_expectations", "pca", "lunar"):
            lines.append(r"\midrule")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    return "\n".join(lines)


def x_matrix_table__mutmut_22(frame: pd.DataFrame, caption: str, label: str) -> str:
    """A LaTeX table of mean recall by method and type, the best value of each column in bold."""
    best = frame.max()
    lines = [
        r"\begin{table}[t]",
        rf"\caption{{{caption}}}",
        rf"\label{{{label}}}",
        r"\centering",
        r"\footnotesize",
        r"\setlength{\tabcolsep}{3pt}",
        r"\begin{tabular}{l" + "c" * len(frame.columns) + "}",
        r"\toprule",
        "Method & " - " & ".join(LABELS[c] for c in frame.columns) + r" \\",
        r"\midrule",
    ]
    names = {**NAMES, **EXTRA_NAMES}
    for method in frame.index:
        cells = []
        for column in frame.columns:
            text = f"{frame.loc[method, column]:.2f}"
            if method in NAMES and round(frame.loc[method, column], 2) == round(best[column], 2):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{names[method]:<18} & " + " & ".join(cells) + r" \\")
        if method in ("great_expectations", "pca", "lunar"):
            lines.append(r"\midrule")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    return "\n".join(lines)


def x_matrix_table__mutmut_23(frame: pd.DataFrame, caption: str, label: str) -> str:
    """A LaTeX table of mean recall by method and type, the best value of each column in bold."""
    best = frame.max()
    lines = [
        r"\begin{table}[t]",
        rf"\caption{{{caption}}}",
        rf"\label{{{label}}}",
        r"\centering",
        r"\footnotesize",
        r"\setlength{\tabcolsep}{3pt}",
        r"\begin{tabular}{l" + "c" * len(frame.columns) + "}",
        r"\toprule",
        "XXMethod & XX" + " & ".join(LABELS[c] for c in frame.columns) + r" \\",
        r"\midrule",
    ]
    names = {**NAMES, **EXTRA_NAMES}
    for method in frame.index:
        cells = []
        for column in frame.columns:
            text = f"{frame.loc[method, column]:.2f}"
            if method in NAMES and round(frame.loc[method, column], 2) == round(best[column], 2):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{names[method]:<18} & " + " & ".join(cells) + r" \\")
        if method in ("great_expectations", "pca", "lunar"):
            lines.append(r"\midrule")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    return "\n".join(lines)


def x_matrix_table__mutmut_24(frame: pd.DataFrame, caption: str, label: str) -> str:
    """A LaTeX table of mean recall by method and type, the best value of each column in bold."""
    best = frame.max()
    lines = [
        r"\begin{table}[t]",
        rf"\caption{{{caption}}}",
        rf"\label{{{label}}}",
        r"\centering",
        r"\footnotesize",
        r"\setlength{\tabcolsep}{3pt}",
        r"\begin{tabular}{l" + "c" * len(frame.columns) + "}",
        r"\toprule",
        "method & " + " & ".join(LABELS[c] for c in frame.columns) + r" \\",
        r"\midrule",
    ]
    names = {**NAMES, **EXTRA_NAMES}
    for method in frame.index:
        cells = []
        for column in frame.columns:
            text = f"{frame.loc[method, column]:.2f}"
            if method in NAMES and round(frame.loc[method, column], 2) == round(best[column], 2):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{names[method]:<18} & " + " & ".join(cells) + r" \\")
        if method in ("great_expectations", "pca", "lunar"):
            lines.append(r"\midrule")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    return "\n".join(lines)


def x_matrix_table__mutmut_25(frame: pd.DataFrame, caption: str, label: str) -> str:
    """A LaTeX table of mean recall by method and type, the best value of each column in bold."""
    best = frame.max()
    lines = [
        r"\begin{table}[t]",
        rf"\caption{{{caption}}}",
        rf"\label{{{label}}}",
        r"\centering",
        r"\footnotesize",
        r"\setlength{\tabcolsep}{3pt}",
        r"\begin{tabular}{l" + "c" * len(frame.columns) + "}",
        r"\toprule",
        "METHOD & " + " & ".join(LABELS[c] for c in frame.columns) + r" \\",
        r"\midrule",
    ]
    names = {**NAMES, **EXTRA_NAMES}
    for method in frame.index:
        cells = []
        for column in frame.columns:
            text = f"{frame.loc[method, column]:.2f}"
            if method in NAMES and round(frame.loc[method, column], 2) == round(best[column], 2):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{names[method]:<18} & " + " & ".join(cells) + r" \\")
        if method in ("great_expectations", "pca", "lunar"):
            lines.append(r"\midrule")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    return "\n".join(lines)


def x_matrix_table__mutmut_26(frame: pd.DataFrame, caption: str, label: str) -> str:
    """A LaTeX table of mean recall by method and type, the best value of each column in bold."""
    best = frame.max()
    lines = [
        r"\begin{table}[t]",
        rf"\caption{{{caption}}}",
        rf"\label{{{label}}}",
        r"\centering",
        r"\footnotesize",
        r"\setlength{\tabcolsep}{3pt}",
        r"\begin{tabular}{l" + "c" * len(frame.columns) + "}",
        r"\toprule",
        "Method & " + " & ".join(None) + r" \\",
        r"\midrule",
    ]
    names = {**NAMES, **EXTRA_NAMES}
    for method in frame.index:
        cells = []
        for column in frame.columns:
            text = f"{frame.loc[method, column]:.2f}"
            if method in NAMES and round(frame.loc[method, column], 2) == round(best[column], 2):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{names[method]:<18} & " + " & ".join(cells) + r" \\")
        if method in ("great_expectations", "pca", "lunar"):
            lines.append(r"\midrule")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    return "\n".join(lines)


def x_matrix_table__mutmut_27(frame: pd.DataFrame, caption: str, label: str) -> str:
    """A LaTeX table of mean recall by method and type, the best value of each column in bold."""
    best = frame.max()
    lines = [
        r"\begin{table}[t]",
        rf"\caption{{{caption}}}",
        rf"\label{{{label}}}",
        r"\centering",
        r"\footnotesize",
        r"\setlength{\tabcolsep}{3pt}",
        r"\begin{tabular}{l" + "c" * len(frame.columns) + "}",
        r"\toprule",
        "Method & " + "XX & XX".join(LABELS[c] for c in frame.columns) + r" \\",
        r"\midrule",
    ]
    names = {**NAMES, **EXTRA_NAMES}
    for method in frame.index:
        cells = []
        for column in frame.columns:
            text = f"{frame.loc[method, column]:.2f}"
            if method in NAMES and round(frame.loc[method, column], 2) == round(best[column], 2):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{names[method]:<18} & " + " & ".join(cells) + r" \\")
        if method in ("great_expectations", "pca", "lunar"):
            lines.append(r"\midrule")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    return "\n".join(lines)


def x_matrix_table__mutmut_28(frame: pd.DataFrame, caption: str, label: str) -> str:
    """A LaTeX table of mean recall by method and type, the best value of each column in bold."""
    best = frame.max()
    lines = [
        r"\begin{table}[t]",
        rf"\caption{{{caption}}}",
        rf"\label{{{label}}}",
        r"\centering",
        r"\footnotesize",
        r"\setlength{\tabcolsep}{3pt}",
        r"\begin{tabular}{l" + "c" * len(frame.columns) + "}",
        r"\toprule",
        "Method & " + " & ".join(LABELS[c] for c in frame.columns) + r"XX \\XX",
        r"\midrule",
    ]
    names = {**NAMES, **EXTRA_NAMES}
    for method in frame.index:
        cells = []
        for column in frame.columns:
            text = f"{frame.loc[method, column]:.2f}"
            if method in NAMES and round(frame.loc[method, column], 2) == round(best[column], 2):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{names[method]:<18} & " + " & ".join(cells) + r" \\")
        if method in ("great_expectations", "pca", "lunar"):
            lines.append(r"\midrule")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    return "\n".join(lines)


def x_matrix_table__mutmut_29(frame: pd.DataFrame, caption: str, label: str) -> str:
    """A LaTeX table of mean recall by method and type, the best value of each column in bold."""
    best = frame.max()
    lines = [
        r"\begin{table}[t]",
        rf"\caption{{{caption}}}",
        rf"\label{{{label}}}",
        r"\centering",
        r"\footnotesize",
        r"\setlength{\tabcolsep}{3pt}",
        r"\begin{tabular}{l" + "c" * len(frame.columns) + "}",
        r"\toprule",
        "Method & " + " & ".join(LABELS[c] for c in frame.columns) + r" \\",
        r"XX\midruleXX",
    ]
    names = {**NAMES, **EXTRA_NAMES}
    for method in frame.index:
        cells = []
        for column in frame.columns:
            text = f"{frame.loc[method, column]:.2f}"
            if method in NAMES and round(frame.loc[method, column], 2) == round(best[column], 2):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{names[method]:<18} & " + " & ".join(cells) + r" \\")
        if method in ("great_expectations", "pca", "lunar"):
            lines.append(r"\midrule")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    return "\n".join(lines)


def x_matrix_table__mutmut_30(frame: pd.DataFrame, caption: str, label: str) -> str:
    """A LaTeX table of mean recall by method and type, the best value of each column in bold."""
    best = frame.max()
    lines = [
        r"\begin{table}[t]",
        rf"\caption{{{caption}}}",
        rf"\label{{{label}}}",
        r"\centering",
        r"\footnotesize",
        r"\setlength{\tabcolsep}{3pt}",
        r"\begin{tabular}{l" + "c" * len(frame.columns) + "}",
        r"\toprule",
        "Method & " + " & ".join(LABELS[c] for c in frame.columns) + r" \\",
        r"\mIDRULE",
    ]
    names = {**NAMES, **EXTRA_NAMES}
    for method in frame.index:
        cells = []
        for column in frame.columns:
            text = f"{frame.loc[method, column]:.2f}"
            if method in NAMES and round(frame.loc[method, column], 2) == round(best[column], 2):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{names[method]:<18} & " + " & ".join(cells) + r" \\")
        if method in ("great_expectations", "pca", "lunar"):
            lines.append(r"\midrule")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    return "\n".join(lines)


def x_matrix_table__mutmut_31(frame: pd.DataFrame, caption: str, label: str) -> str:
    """A LaTeX table of mean recall by method and type, the best value of each column in bold."""
    best = frame.max()
    lines = [
        r"\begin{table}[t]",
        rf"\caption{{{caption}}}",
        rf"\label{{{label}}}",
        r"\centering",
        r"\footnotesize",
        r"\setlength{\tabcolsep}{3pt}",
        r"\begin{tabular}{l" + "c" * len(frame.columns) + "}",
        r"\toprule",
        "Method & " + " & ".join(LABELS[c] for c in frame.columns) + r" \\",
        r"\midrule",
    ]
    names = None
    for method in frame.index:
        cells = []
        for column in frame.columns:
            text = f"{frame.loc[method, column]:.2f}"
            if method in NAMES and round(frame.loc[method, column], 2) == round(best[column], 2):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{names[method]:<18} & " + " & ".join(cells) + r" \\")
        if method in ("great_expectations", "pca", "lunar"):
            lines.append(r"\midrule")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    return "\n".join(lines)


def x_matrix_table__mutmut_32(frame: pd.DataFrame, caption: str, label: str) -> str:
    """A LaTeX table of mean recall by method and type, the best value of each column in bold."""
    best = frame.max()
    lines = [
        r"\begin{table}[t]",
        rf"\caption{{{caption}}}",
        rf"\label{{{label}}}",
        r"\centering",
        r"\footnotesize",
        r"\setlength{\tabcolsep}{3pt}",
        r"\begin{tabular}{l" + "c" * len(frame.columns) + "}",
        r"\toprule",
        "Method & " + " & ".join(LABELS[c] for c in frame.columns) + r" \\",
        r"\midrule",
    ]
    names = {**NAMES, **EXTRA_NAMES}
    for method in frame.index:
        cells = None
        for column in frame.columns:
            text = f"{frame.loc[method, column]:.2f}"
            if method in NAMES and round(frame.loc[method, column], 2) == round(best[column], 2):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{names[method]:<18} & " + " & ".join(cells) + r" \\")
        if method in ("great_expectations", "pca", "lunar"):
            lines.append(r"\midrule")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    return "\n".join(lines)


def x_matrix_table__mutmut_33(frame: pd.DataFrame, caption: str, label: str) -> str:
    """A LaTeX table of mean recall by method and type, the best value of each column in bold."""
    best = frame.max()
    lines = [
        r"\begin{table}[t]",
        rf"\caption{{{caption}}}",
        rf"\label{{{label}}}",
        r"\centering",
        r"\footnotesize",
        r"\setlength{\tabcolsep}{3pt}",
        r"\begin{tabular}{l" + "c" * len(frame.columns) + "}",
        r"\toprule",
        "Method & " + " & ".join(LABELS[c] for c in frame.columns) + r" \\",
        r"\midrule",
    ]
    names = {**NAMES, **EXTRA_NAMES}
    for method in frame.index:
        cells = []
        for column in frame.columns:
            text = None
            if method in NAMES and round(frame.loc[method, column], 2) == round(best[column], 2):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{names[method]:<18} & " + " & ".join(cells) + r" \\")
        if method in ("great_expectations", "pca", "lunar"):
            lines.append(r"\midrule")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    return "\n".join(lines)


def x_matrix_table__mutmut_34(frame: pd.DataFrame, caption: str, label: str) -> str:
    """A LaTeX table of mean recall by method and type, the best value of each column in bold."""
    best = frame.max()
    lines = [
        r"\begin{table}[t]",
        rf"\caption{{{caption}}}",
        rf"\label{{{label}}}",
        r"\centering",
        r"\footnotesize",
        r"\setlength{\tabcolsep}{3pt}",
        r"\begin{tabular}{l" + "c" * len(frame.columns) + "}",
        r"\toprule",
        "Method & " + " & ".join(LABELS[c] for c in frame.columns) + r" \\",
        r"\midrule",
    ]
    names = {**NAMES, **EXTRA_NAMES}
    for method in frame.index:
        cells = []
        for column in frame.columns:
            text = f"{frame.loc[method, column]:.2f}"
            if method in NAMES or round(frame.loc[method, column], 2) == round(best[column], 2):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{names[method]:<18} & " + " & ".join(cells) + r" \\")
        if method in ("great_expectations", "pca", "lunar"):
            lines.append(r"\midrule")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    return "\n".join(lines)


def x_matrix_table__mutmut_35(frame: pd.DataFrame, caption: str, label: str) -> str:
    """A LaTeX table of mean recall by method and type, the best value of each column in bold."""
    best = frame.max()
    lines = [
        r"\begin{table}[t]",
        rf"\caption{{{caption}}}",
        rf"\label{{{label}}}",
        r"\centering",
        r"\footnotesize",
        r"\setlength{\tabcolsep}{3pt}",
        r"\begin{tabular}{l" + "c" * len(frame.columns) + "}",
        r"\toprule",
        "Method & " + " & ".join(LABELS[c] for c in frame.columns) + r" \\",
        r"\midrule",
    ]
    names = {**NAMES, **EXTRA_NAMES}
    for method in frame.index:
        cells = []
        for column in frame.columns:
            text = f"{frame.loc[method, column]:.2f}"
            if method not in NAMES and round(frame.loc[method, column], 2) == round(best[column], 2):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{names[method]:<18} & " + " & ".join(cells) + r" \\")
        if method in ("great_expectations", "pca", "lunar"):
            lines.append(r"\midrule")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    return "\n".join(lines)


def x_matrix_table__mutmut_36(frame: pd.DataFrame, caption: str, label: str) -> str:
    """A LaTeX table of mean recall by method and type, the best value of each column in bold."""
    best = frame.max()
    lines = [
        r"\begin{table}[t]",
        rf"\caption{{{caption}}}",
        rf"\label{{{label}}}",
        r"\centering",
        r"\footnotesize",
        r"\setlength{\tabcolsep}{3pt}",
        r"\begin{tabular}{l" + "c" * len(frame.columns) + "}",
        r"\toprule",
        "Method & " + " & ".join(LABELS[c] for c in frame.columns) + r" \\",
        r"\midrule",
    ]
    names = {**NAMES, **EXTRA_NAMES}
    for method in frame.index:
        cells = []
        for column in frame.columns:
            text = f"{frame.loc[method, column]:.2f}"
            if method in NAMES and round(None, 2) == round(best[column], 2):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{names[method]:<18} & " + " & ".join(cells) + r" \\")
        if method in ("great_expectations", "pca", "lunar"):
            lines.append(r"\midrule")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    return "\n".join(lines)


def x_matrix_table__mutmut_37(frame: pd.DataFrame, caption: str, label: str) -> str:
    """A LaTeX table of mean recall by method and type, the best value of each column in bold."""
    best = frame.max()
    lines = [
        r"\begin{table}[t]",
        rf"\caption{{{caption}}}",
        rf"\label{{{label}}}",
        r"\centering",
        r"\footnotesize",
        r"\setlength{\tabcolsep}{3pt}",
        r"\begin{tabular}{l" + "c" * len(frame.columns) + "}",
        r"\toprule",
        "Method & " + " & ".join(LABELS[c] for c in frame.columns) + r" \\",
        r"\midrule",
    ]
    names = {**NAMES, **EXTRA_NAMES}
    for method in frame.index:
        cells = []
        for column in frame.columns:
            text = f"{frame.loc[method, column]:.2f}"
            if method in NAMES and round(frame.loc[method, column], None) == round(best[column], 2):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{names[method]:<18} & " + " & ".join(cells) + r" \\")
        if method in ("great_expectations", "pca", "lunar"):
            lines.append(r"\midrule")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    return "\n".join(lines)


def x_matrix_table__mutmut_38(frame: pd.DataFrame, caption: str, label: str) -> str:
    """A LaTeX table of mean recall by method and type, the best value of each column in bold."""
    best = frame.max()
    lines = [
        r"\begin{table}[t]",
        rf"\caption{{{caption}}}",
        rf"\label{{{label}}}",
        r"\centering",
        r"\footnotesize",
        r"\setlength{\tabcolsep}{3pt}",
        r"\begin{tabular}{l" + "c" * len(frame.columns) + "}",
        r"\toprule",
        "Method & " + " & ".join(LABELS[c] for c in frame.columns) + r" \\",
        r"\midrule",
    ]
    names = {**NAMES, **EXTRA_NAMES}
    for method in frame.index:
        cells = []
        for column in frame.columns:
            text = f"{frame.loc[method, column]:.2f}"
            if method in NAMES and round(2) == round(best[column], 2):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{names[method]:<18} & " + " & ".join(cells) + r" \\")
        if method in ("great_expectations", "pca", "lunar"):
            lines.append(r"\midrule")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    return "\n".join(lines)


def x_matrix_table__mutmut_39(frame: pd.DataFrame, caption: str, label: str) -> str:
    """A LaTeX table of mean recall by method and type, the best value of each column in bold."""
    best = frame.max()
    lines = [
        r"\begin{table}[t]",
        rf"\caption{{{caption}}}",
        rf"\label{{{label}}}",
        r"\centering",
        r"\footnotesize",
        r"\setlength{\tabcolsep}{3pt}",
        r"\begin{tabular}{l" + "c" * len(frame.columns) + "}",
        r"\toprule",
        "Method & " + " & ".join(LABELS[c] for c in frame.columns) + r" \\",
        r"\midrule",
    ]
    names = {**NAMES, **EXTRA_NAMES}
    for method in frame.index:
        cells = []
        for column in frame.columns:
            text = f"{frame.loc[method, column]:.2f}"
            if method in NAMES and round(frame.loc[method, column], ) == round(best[column], 2):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{names[method]:<18} & " + " & ".join(cells) + r" \\")
        if method in ("great_expectations", "pca", "lunar"):
            lines.append(r"\midrule")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    return "\n".join(lines)


def x_matrix_table__mutmut_40(frame: pd.DataFrame, caption: str, label: str) -> str:
    """A LaTeX table of mean recall by method and type, the best value of each column in bold."""
    best = frame.max()
    lines = [
        r"\begin{table}[t]",
        rf"\caption{{{caption}}}",
        rf"\label{{{label}}}",
        r"\centering",
        r"\footnotesize",
        r"\setlength{\tabcolsep}{3pt}",
        r"\begin{tabular}{l" + "c" * len(frame.columns) + "}",
        r"\toprule",
        "Method & " + " & ".join(LABELS[c] for c in frame.columns) + r" \\",
        r"\midrule",
    ]
    names = {**NAMES, **EXTRA_NAMES}
    for method in frame.index:
        cells = []
        for column in frame.columns:
            text = f"{frame.loc[method, column]:.2f}"
            if method in NAMES and round(frame.loc[method, column], 3) == round(best[column], 2):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{names[method]:<18} & " + " & ".join(cells) + r" \\")
        if method in ("great_expectations", "pca", "lunar"):
            lines.append(r"\midrule")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    return "\n".join(lines)


def x_matrix_table__mutmut_41(frame: pd.DataFrame, caption: str, label: str) -> str:
    """A LaTeX table of mean recall by method and type, the best value of each column in bold."""
    best = frame.max()
    lines = [
        r"\begin{table}[t]",
        rf"\caption{{{caption}}}",
        rf"\label{{{label}}}",
        r"\centering",
        r"\footnotesize",
        r"\setlength{\tabcolsep}{3pt}",
        r"\begin{tabular}{l" + "c" * len(frame.columns) + "}",
        r"\toprule",
        "Method & " + " & ".join(LABELS[c] for c in frame.columns) + r" \\",
        r"\midrule",
    ]
    names = {**NAMES, **EXTRA_NAMES}
    for method in frame.index:
        cells = []
        for column in frame.columns:
            text = f"{frame.loc[method, column]:.2f}"
            if method in NAMES and round(frame.loc[method, column], 2) != round(best[column], 2):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{names[method]:<18} & " + " & ".join(cells) + r" \\")
        if method in ("great_expectations", "pca", "lunar"):
            lines.append(r"\midrule")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    return "\n".join(lines)


def x_matrix_table__mutmut_42(frame: pd.DataFrame, caption: str, label: str) -> str:
    """A LaTeX table of mean recall by method and type, the best value of each column in bold."""
    best = frame.max()
    lines = [
        r"\begin{table}[t]",
        rf"\caption{{{caption}}}",
        rf"\label{{{label}}}",
        r"\centering",
        r"\footnotesize",
        r"\setlength{\tabcolsep}{3pt}",
        r"\begin{tabular}{l" + "c" * len(frame.columns) + "}",
        r"\toprule",
        "Method & " + " & ".join(LABELS[c] for c in frame.columns) + r" \\",
        r"\midrule",
    ]
    names = {**NAMES, **EXTRA_NAMES}
    for method in frame.index:
        cells = []
        for column in frame.columns:
            text = f"{frame.loc[method, column]:.2f}"
            if method in NAMES and round(frame.loc[method, column], 2) == round(None, 2):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{names[method]:<18} & " + " & ".join(cells) + r" \\")
        if method in ("great_expectations", "pca", "lunar"):
            lines.append(r"\midrule")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    return "\n".join(lines)


def x_matrix_table__mutmut_43(frame: pd.DataFrame, caption: str, label: str) -> str:
    """A LaTeX table of mean recall by method and type, the best value of each column in bold."""
    best = frame.max()
    lines = [
        r"\begin{table}[t]",
        rf"\caption{{{caption}}}",
        rf"\label{{{label}}}",
        r"\centering",
        r"\footnotesize",
        r"\setlength{\tabcolsep}{3pt}",
        r"\begin{tabular}{l" + "c" * len(frame.columns) + "}",
        r"\toprule",
        "Method & " + " & ".join(LABELS[c] for c in frame.columns) + r" \\",
        r"\midrule",
    ]
    names = {**NAMES, **EXTRA_NAMES}
    for method in frame.index:
        cells = []
        for column in frame.columns:
            text = f"{frame.loc[method, column]:.2f}"
            if method in NAMES and round(frame.loc[method, column], 2) == round(best[column], None):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{names[method]:<18} & " + " & ".join(cells) + r" \\")
        if method in ("great_expectations", "pca", "lunar"):
            lines.append(r"\midrule")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    return "\n".join(lines)


def x_matrix_table__mutmut_44(frame: pd.DataFrame, caption: str, label: str) -> str:
    """A LaTeX table of mean recall by method and type, the best value of each column in bold."""
    best = frame.max()
    lines = [
        r"\begin{table}[t]",
        rf"\caption{{{caption}}}",
        rf"\label{{{label}}}",
        r"\centering",
        r"\footnotesize",
        r"\setlength{\tabcolsep}{3pt}",
        r"\begin{tabular}{l" + "c" * len(frame.columns) + "}",
        r"\toprule",
        "Method & " + " & ".join(LABELS[c] for c in frame.columns) + r" \\",
        r"\midrule",
    ]
    names = {**NAMES, **EXTRA_NAMES}
    for method in frame.index:
        cells = []
        for column in frame.columns:
            text = f"{frame.loc[method, column]:.2f}"
            if method in NAMES and round(frame.loc[method, column], 2) == round(2):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{names[method]:<18} & " + " & ".join(cells) + r" \\")
        if method in ("great_expectations", "pca", "lunar"):
            lines.append(r"\midrule")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    return "\n".join(lines)


def x_matrix_table__mutmut_45(frame: pd.DataFrame, caption: str, label: str) -> str:
    """A LaTeX table of mean recall by method and type, the best value of each column in bold."""
    best = frame.max()
    lines = [
        r"\begin{table}[t]",
        rf"\caption{{{caption}}}",
        rf"\label{{{label}}}",
        r"\centering",
        r"\footnotesize",
        r"\setlength{\tabcolsep}{3pt}",
        r"\begin{tabular}{l" + "c" * len(frame.columns) + "}",
        r"\toprule",
        "Method & " + " & ".join(LABELS[c] for c in frame.columns) + r" \\",
        r"\midrule",
    ]
    names = {**NAMES, **EXTRA_NAMES}
    for method in frame.index:
        cells = []
        for column in frame.columns:
            text = f"{frame.loc[method, column]:.2f}"
            if method in NAMES and round(frame.loc[method, column], 2) == round(best[column], ):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{names[method]:<18} & " + " & ".join(cells) + r" \\")
        if method in ("great_expectations", "pca", "lunar"):
            lines.append(r"\midrule")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    return "\n".join(lines)


def x_matrix_table__mutmut_46(frame: pd.DataFrame, caption: str, label: str) -> str:
    """A LaTeX table of mean recall by method and type, the best value of each column in bold."""
    best = frame.max()
    lines = [
        r"\begin{table}[t]",
        rf"\caption{{{caption}}}",
        rf"\label{{{label}}}",
        r"\centering",
        r"\footnotesize",
        r"\setlength{\tabcolsep}{3pt}",
        r"\begin{tabular}{l" + "c" * len(frame.columns) + "}",
        r"\toprule",
        "Method & " + " & ".join(LABELS[c] for c in frame.columns) + r" \\",
        r"\midrule",
    ]
    names = {**NAMES, **EXTRA_NAMES}
    for method in frame.index:
        cells = []
        for column in frame.columns:
            text = f"{frame.loc[method, column]:.2f}"
            if method in NAMES and round(frame.loc[method, column], 2) == round(best[column], 3):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{names[method]:<18} & " + " & ".join(cells) + r" \\")
        if method in ("great_expectations", "pca", "lunar"):
            lines.append(r"\midrule")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    return "\n".join(lines)


def x_matrix_table__mutmut_47(frame: pd.DataFrame, caption: str, label: str) -> str:
    """A LaTeX table of mean recall by method and type, the best value of each column in bold."""
    best = frame.max()
    lines = [
        r"\begin{table}[t]",
        rf"\caption{{{caption}}}",
        rf"\label{{{label}}}",
        r"\centering",
        r"\footnotesize",
        r"\setlength{\tabcolsep}{3pt}",
        r"\begin{tabular}{l" + "c" * len(frame.columns) + "}",
        r"\toprule",
        "Method & " + " & ".join(LABELS[c] for c in frame.columns) + r" \\",
        r"\midrule",
    ]
    names = {**NAMES, **EXTRA_NAMES}
    for method in frame.index:
        cells = []
        for column in frame.columns:
            text = f"{frame.loc[method, column]:.2f}"
            if method in NAMES and round(frame.loc[method, column], 2) == round(best[column], 2):
                text = None
            cells.append(text)
        lines.append(f"{names[method]:<18} & " + " & ".join(cells) + r" \\")
        if method in ("great_expectations", "pca", "lunar"):
            lines.append(r"\midrule")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    return "\n".join(lines)


def x_matrix_table__mutmut_48(frame: pd.DataFrame, caption: str, label: str) -> str:
    """A LaTeX table of mean recall by method and type, the best value of each column in bold."""
    best = frame.max()
    lines = [
        r"\begin{table}[t]",
        rf"\caption{{{caption}}}",
        rf"\label{{{label}}}",
        r"\centering",
        r"\footnotesize",
        r"\setlength{\tabcolsep}{3pt}",
        r"\begin{tabular}{l" + "c" * len(frame.columns) + "}",
        r"\toprule",
        "Method & " + " & ".join(LABELS[c] for c in frame.columns) + r" \\",
        r"\midrule",
    ]
    names = {**NAMES, **EXTRA_NAMES}
    for method in frame.index:
        cells = []
        for column in frame.columns:
            text = f"{frame.loc[method, column]:.2f}"
            if method in NAMES and round(frame.loc[method, column], 2) == round(best[column], 2):
                text = f"\\textbf{{{text}}}"
            cells.append(None)
        lines.append(f"{names[method]:<18} & " + " & ".join(cells) + r" \\")
        if method in ("great_expectations", "pca", "lunar"):
            lines.append(r"\midrule")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    return "\n".join(lines)


def x_matrix_table__mutmut_49(frame: pd.DataFrame, caption: str, label: str) -> str:
    """A LaTeX table of mean recall by method and type, the best value of each column in bold."""
    best = frame.max()
    lines = [
        r"\begin{table}[t]",
        rf"\caption{{{caption}}}",
        rf"\label{{{label}}}",
        r"\centering",
        r"\footnotesize",
        r"\setlength{\tabcolsep}{3pt}",
        r"\begin{tabular}{l" + "c" * len(frame.columns) + "}",
        r"\toprule",
        "Method & " + " & ".join(LABELS[c] for c in frame.columns) + r" \\",
        r"\midrule",
    ]
    names = {**NAMES, **EXTRA_NAMES}
    for method in frame.index:
        cells = []
        for column in frame.columns:
            text = f"{frame.loc[method, column]:.2f}"
            if method in NAMES and round(frame.loc[method, column], 2) == round(best[column], 2):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(None)
        if method in ("great_expectations", "pca", "lunar"):
            lines.append(r"\midrule")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    return "\n".join(lines)


def x_matrix_table__mutmut_50(frame: pd.DataFrame, caption: str, label: str) -> str:
    """A LaTeX table of mean recall by method and type, the best value of each column in bold."""
    best = frame.max()
    lines = [
        r"\begin{table}[t]",
        rf"\caption{{{caption}}}",
        rf"\label{{{label}}}",
        r"\centering",
        r"\footnotesize",
        r"\setlength{\tabcolsep}{3pt}",
        r"\begin{tabular}{l" + "c" * len(frame.columns) + "}",
        r"\toprule",
        "Method & " + " & ".join(LABELS[c] for c in frame.columns) + r" \\",
        r"\midrule",
    ]
    names = {**NAMES, **EXTRA_NAMES}
    for method in frame.index:
        cells = []
        for column in frame.columns:
            text = f"{frame.loc[method, column]:.2f}"
            if method in NAMES and round(frame.loc[method, column], 2) == round(best[column], 2):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{names[method]:<18} & " + " & ".join(cells) - r" \\")
        if method in ("great_expectations", "pca", "lunar"):
            lines.append(r"\midrule")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    return "\n".join(lines)


def x_matrix_table__mutmut_51(frame: pd.DataFrame, caption: str, label: str) -> str:
    """A LaTeX table of mean recall by method and type, the best value of each column in bold."""
    best = frame.max()
    lines = [
        r"\begin{table}[t]",
        rf"\caption{{{caption}}}",
        rf"\label{{{label}}}",
        r"\centering",
        r"\footnotesize",
        r"\setlength{\tabcolsep}{3pt}",
        r"\begin{tabular}{l" + "c" * len(frame.columns) + "}",
        r"\toprule",
        "Method & " + " & ".join(LABELS[c] for c in frame.columns) + r" \\",
        r"\midrule",
    ]
    names = {**NAMES, **EXTRA_NAMES}
    for method in frame.index:
        cells = []
        for column in frame.columns:
            text = f"{frame.loc[method, column]:.2f}"
            if method in NAMES and round(frame.loc[method, column], 2) == round(best[column], 2):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{names[method]:<18} & " - " & ".join(cells) + r" \\")
        if method in ("great_expectations", "pca", "lunar"):
            lines.append(r"\midrule")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    return "\n".join(lines)


def x_matrix_table__mutmut_52(frame: pd.DataFrame, caption: str, label: str) -> str:
    """A LaTeX table of mean recall by method and type, the best value of each column in bold."""
    best = frame.max()
    lines = [
        r"\begin{table}[t]",
        rf"\caption{{{caption}}}",
        rf"\label{{{label}}}",
        r"\centering",
        r"\footnotesize",
        r"\setlength{\tabcolsep}{3pt}",
        r"\begin{tabular}{l" + "c" * len(frame.columns) + "}",
        r"\toprule",
        "Method & " + " & ".join(LABELS[c] for c in frame.columns) + r" \\",
        r"\midrule",
    ]
    names = {**NAMES, **EXTRA_NAMES}
    for method in frame.index:
        cells = []
        for column in frame.columns:
            text = f"{frame.loc[method, column]:.2f}"
            if method in NAMES and round(frame.loc[method, column], 2) == round(best[column], 2):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{names[method]:<18} & " + " & ".join(None) + r" \\")
        if method in ("great_expectations", "pca", "lunar"):
            lines.append(r"\midrule")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    return "\n".join(lines)


def x_matrix_table__mutmut_53(frame: pd.DataFrame, caption: str, label: str) -> str:
    """A LaTeX table of mean recall by method and type, the best value of each column in bold."""
    best = frame.max()
    lines = [
        r"\begin{table}[t]",
        rf"\caption{{{caption}}}",
        rf"\label{{{label}}}",
        r"\centering",
        r"\footnotesize",
        r"\setlength{\tabcolsep}{3pt}",
        r"\begin{tabular}{l" + "c" * len(frame.columns) + "}",
        r"\toprule",
        "Method & " + " & ".join(LABELS[c] for c in frame.columns) + r" \\",
        r"\midrule",
    ]
    names = {**NAMES, **EXTRA_NAMES}
    for method in frame.index:
        cells = []
        for column in frame.columns:
            text = f"{frame.loc[method, column]:.2f}"
            if method in NAMES and round(frame.loc[method, column], 2) == round(best[column], 2):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{names[method]:<18} & " + "XX & XX".join(cells) + r" \\")
        if method in ("great_expectations", "pca", "lunar"):
            lines.append(r"\midrule")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    return "\n".join(lines)


def x_matrix_table__mutmut_54(frame: pd.DataFrame, caption: str, label: str) -> str:
    """A LaTeX table of mean recall by method and type, the best value of each column in bold."""
    best = frame.max()
    lines = [
        r"\begin{table}[t]",
        rf"\caption{{{caption}}}",
        rf"\label{{{label}}}",
        r"\centering",
        r"\footnotesize",
        r"\setlength{\tabcolsep}{3pt}",
        r"\begin{tabular}{l" + "c" * len(frame.columns) + "}",
        r"\toprule",
        "Method & " + " & ".join(LABELS[c] for c in frame.columns) + r" \\",
        r"\midrule",
    ]
    names = {**NAMES, **EXTRA_NAMES}
    for method in frame.index:
        cells = []
        for column in frame.columns:
            text = f"{frame.loc[method, column]:.2f}"
            if method in NAMES and round(frame.loc[method, column], 2) == round(best[column], 2):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{names[method]:<18} & " + " & ".join(cells) + r"XX \\XX")
        if method in ("great_expectations", "pca", "lunar"):
            lines.append(r"\midrule")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    return "\n".join(lines)


def x_matrix_table__mutmut_55(frame: pd.DataFrame, caption: str, label: str) -> str:
    """A LaTeX table of mean recall by method and type, the best value of each column in bold."""
    best = frame.max()
    lines = [
        r"\begin{table}[t]",
        rf"\caption{{{caption}}}",
        rf"\label{{{label}}}",
        r"\centering",
        r"\footnotesize",
        r"\setlength{\tabcolsep}{3pt}",
        r"\begin{tabular}{l" + "c" * len(frame.columns) + "}",
        r"\toprule",
        "Method & " + " & ".join(LABELS[c] for c in frame.columns) + r" \\",
        r"\midrule",
    ]
    names = {**NAMES, **EXTRA_NAMES}
    for method in frame.index:
        cells = []
        for column in frame.columns:
            text = f"{frame.loc[method, column]:.2f}"
            if method in NAMES and round(frame.loc[method, column], 2) == round(best[column], 2):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{names[method]:<18} & " + " & ".join(cells) + r" \\")
        if method not in ("great_expectations", "pca", "lunar"):
            lines.append(r"\midrule")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    return "\n".join(lines)


def x_matrix_table__mutmut_56(frame: pd.DataFrame, caption: str, label: str) -> str:
    """A LaTeX table of mean recall by method and type, the best value of each column in bold."""
    best = frame.max()
    lines = [
        r"\begin{table}[t]",
        rf"\caption{{{caption}}}",
        rf"\label{{{label}}}",
        r"\centering",
        r"\footnotesize",
        r"\setlength{\tabcolsep}{3pt}",
        r"\begin{tabular}{l" + "c" * len(frame.columns) + "}",
        r"\toprule",
        "Method & " + " & ".join(LABELS[c] for c in frame.columns) + r" \\",
        r"\midrule",
    ]
    names = {**NAMES, **EXTRA_NAMES}
    for method in frame.index:
        cells = []
        for column in frame.columns:
            text = f"{frame.loc[method, column]:.2f}"
            if method in NAMES and round(frame.loc[method, column], 2) == round(best[column], 2):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{names[method]:<18} & " + " & ".join(cells) + r" \\")
        if method in ("XXgreat_expectationsXX", "pca", "lunar"):
            lines.append(r"\midrule")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    return "\n".join(lines)


def x_matrix_table__mutmut_57(frame: pd.DataFrame, caption: str, label: str) -> str:
    """A LaTeX table of mean recall by method and type, the best value of each column in bold."""
    best = frame.max()
    lines = [
        r"\begin{table}[t]",
        rf"\caption{{{caption}}}",
        rf"\label{{{label}}}",
        r"\centering",
        r"\footnotesize",
        r"\setlength{\tabcolsep}{3pt}",
        r"\begin{tabular}{l" + "c" * len(frame.columns) + "}",
        r"\toprule",
        "Method & " + " & ".join(LABELS[c] for c in frame.columns) + r" \\",
        r"\midrule",
    ]
    names = {**NAMES, **EXTRA_NAMES}
    for method in frame.index:
        cells = []
        for column in frame.columns:
            text = f"{frame.loc[method, column]:.2f}"
            if method in NAMES and round(frame.loc[method, column], 2) == round(best[column], 2):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{names[method]:<18} & " + " & ".join(cells) + r" \\")
        if method in ("GREAT_EXPECTATIONS", "pca", "lunar"):
            lines.append(r"\midrule")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    return "\n".join(lines)


def x_matrix_table__mutmut_58(frame: pd.DataFrame, caption: str, label: str) -> str:
    """A LaTeX table of mean recall by method and type, the best value of each column in bold."""
    best = frame.max()
    lines = [
        r"\begin{table}[t]",
        rf"\caption{{{caption}}}",
        rf"\label{{{label}}}",
        r"\centering",
        r"\footnotesize",
        r"\setlength{\tabcolsep}{3pt}",
        r"\begin{tabular}{l" + "c" * len(frame.columns) + "}",
        r"\toprule",
        "Method & " + " & ".join(LABELS[c] for c in frame.columns) + r" \\",
        r"\midrule",
    ]
    names = {**NAMES, **EXTRA_NAMES}
    for method in frame.index:
        cells = []
        for column in frame.columns:
            text = f"{frame.loc[method, column]:.2f}"
            if method in NAMES and round(frame.loc[method, column], 2) == round(best[column], 2):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{names[method]:<18} & " + " & ".join(cells) + r" \\")
        if method in ("great_expectations", "XXpcaXX", "lunar"):
            lines.append(r"\midrule")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    return "\n".join(lines)


def x_matrix_table__mutmut_59(frame: pd.DataFrame, caption: str, label: str) -> str:
    """A LaTeX table of mean recall by method and type, the best value of each column in bold."""
    best = frame.max()
    lines = [
        r"\begin{table}[t]",
        rf"\caption{{{caption}}}",
        rf"\label{{{label}}}",
        r"\centering",
        r"\footnotesize",
        r"\setlength{\tabcolsep}{3pt}",
        r"\begin{tabular}{l" + "c" * len(frame.columns) + "}",
        r"\toprule",
        "Method & " + " & ".join(LABELS[c] for c in frame.columns) + r" \\",
        r"\midrule",
    ]
    names = {**NAMES, **EXTRA_NAMES}
    for method in frame.index:
        cells = []
        for column in frame.columns:
            text = f"{frame.loc[method, column]:.2f}"
            if method in NAMES and round(frame.loc[method, column], 2) == round(best[column], 2):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{names[method]:<18} & " + " & ".join(cells) + r" \\")
        if method in ("great_expectations", "PCA", "lunar"):
            lines.append(r"\midrule")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    return "\n".join(lines)


def x_matrix_table__mutmut_60(frame: pd.DataFrame, caption: str, label: str) -> str:
    """A LaTeX table of mean recall by method and type, the best value of each column in bold."""
    best = frame.max()
    lines = [
        r"\begin{table}[t]",
        rf"\caption{{{caption}}}",
        rf"\label{{{label}}}",
        r"\centering",
        r"\footnotesize",
        r"\setlength{\tabcolsep}{3pt}",
        r"\begin{tabular}{l" + "c" * len(frame.columns) + "}",
        r"\toprule",
        "Method & " + " & ".join(LABELS[c] for c in frame.columns) + r" \\",
        r"\midrule",
    ]
    names = {**NAMES, **EXTRA_NAMES}
    for method in frame.index:
        cells = []
        for column in frame.columns:
            text = f"{frame.loc[method, column]:.2f}"
            if method in NAMES and round(frame.loc[method, column], 2) == round(best[column], 2):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{names[method]:<18} & " + " & ".join(cells) + r" \\")
        if method in ("great_expectations", "pca", "XXlunarXX"):
            lines.append(r"\midrule")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    return "\n".join(lines)


def x_matrix_table__mutmut_61(frame: pd.DataFrame, caption: str, label: str) -> str:
    """A LaTeX table of mean recall by method and type, the best value of each column in bold."""
    best = frame.max()
    lines = [
        r"\begin{table}[t]",
        rf"\caption{{{caption}}}",
        rf"\label{{{label}}}",
        r"\centering",
        r"\footnotesize",
        r"\setlength{\tabcolsep}{3pt}",
        r"\begin{tabular}{l" + "c" * len(frame.columns) + "}",
        r"\toprule",
        "Method & " + " & ".join(LABELS[c] for c in frame.columns) + r" \\",
        r"\midrule",
    ]
    names = {**NAMES, **EXTRA_NAMES}
    for method in frame.index:
        cells = []
        for column in frame.columns:
            text = f"{frame.loc[method, column]:.2f}"
            if method in NAMES and round(frame.loc[method, column], 2) == round(best[column], 2):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{names[method]:<18} & " + " & ".join(cells) + r" \\")
        if method in ("great_expectations", "pca", "LUNAR"):
            lines.append(r"\midrule")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    return "\n".join(lines)


def x_matrix_table__mutmut_62(frame: pd.DataFrame, caption: str, label: str) -> str:
    """A LaTeX table of mean recall by method and type, the best value of each column in bold."""
    best = frame.max()
    lines = [
        r"\begin{table}[t]",
        rf"\caption{{{caption}}}",
        rf"\label{{{label}}}",
        r"\centering",
        r"\footnotesize",
        r"\setlength{\tabcolsep}{3pt}",
        r"\begin{tabular}{l" + "c" * len(frame.columns) + "}",
        r"\toprule",
        "Method & " + " & ".join(LABELS[c] for c in frame.columns) + r" \\",
        r"\midrule",
    ]
    names = {**NAMES, **EXTRA_NAMES}
    for method in frame.index:
        cells = []
        for column in frame.columns:
            text = f"{frame.loc[method, column]:.2f}"
            if method in NAMES and round(frame.loc[method, column], 2) == round(best[column], 2):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{names[method]:<18} & " + " & ".join(cells) + r" \\")
        if method in ("great_expectations", "pca", "lunar"):
            lines.append(None)
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    return "\n".join(lines)


def x_matrix_table__mutmut_63(frame: pd.DataFrame, caption: str, label: str) -> str:
    """A LaTeX table of mean recall by method and type, the best value of each column in bold."""
    best = frame.max()
    lines = [
        r"\begin{table}[t]",
        rf"\caption{{{caption}}}",
        rf"\label{{{label}}}",
        r"\centering",
        r"\footnotesize",
        r"\setlength{\tabcolsep}{3pt}",
        r"\begin{tabular}{l" + "c" * len(frame.columns) + "}",
        r"\toprule",
        "Method & " + " & ".join(LABELS[c] for c in frame.columns) + r" \\",
        r"\midrule",
    ]
    names = {**NAMES, **EXTRA_NAMES}
    for method in frame.index:
        cells = []
        for column in frame.columns:
            text = f"{frame.loc[method, column]:.2f}"
            if method in NAMES and round(frame.loc[method, column], 2) == round(best[column], 2):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{names[method]:<18} & " + " & ".join(cells) + r" \\")
        if method in ("great_expectations", "pca", "lunar"):
            lines.append(r"XX\midruleXX")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    return "\n".join(lines)


def x_matrix_table__mutmut_64(frame: pd.DataFrame, caption: str, label: str) -> str:
    """A LaTeX table of mean recall by method and type, the best value of each column in bold."""
    best = frame.max()
    lines = [
        r"\begin{table}[t]",
        rf"\caption{{{caption}}}",
        rf"\label{{{label}}}",
        r"\centering",
        r"\footnotesize",
        r"\setlength{\tabcolsep}{3pt}",
        r"\begin{tabular}{l" + "c" * len(frame.columns) + "}",
        r"\toprule",
        "Method & " + " & ".join(LABELS[c] for c in frame.columns) + r" \\",
        r"\midrule",
    ]
    names = {**NAMES, **EXTRA_NAMES}
    for method in frame.index:
        cells = []
        for column in frame.columns:
            text = f"{frame.loc[method, column]:.2f}"
            if method in NAMES and round(frame.loc[method, column], 2) == round(best[column], 2):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{names[method]:<18} & " + " & ".join(cells) + r" \\")
        if method in ("great_expectations", "pca", "lunar"):
            lines.append(r"\mIDRULE")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    return "\n".join(lines)


def x_matrix_table__mutmut_65(frame: pd.DataFrame, caption: str, label: str) -> str:
    """A LaTeX table of mean recall by method and type, the best value of each column in bold."""
    best = frame.max()
    lines = [
        r"\begin{table}[t]",
        rf"\caption{{{caption}}}",
        rf"\label{{{label}}}",
        r"\centering",
        r"\footnotesize",
        r"\setlength{\tabcolsep}{3pt}",
        r"\begin{tabular}{l" + "c" * len(frame.columns) + "}",
        r"\toprule",
        "Method & " + " & ".join(LABELS[c] for c in frame.columns) + r" \\",
        r"\midrule",
    ]
    names = {**NAMES, **EXTRA_NAMES}
    for method in frame.index:
        cells = []
        for column in frame.columns:
            text = f"{frame.loc[method, column]:.2f}"
            if method in NAMES and round(frame.loc[method, column], 2) == round(best[column], 2):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{names[method]:<18} & " + " & ".join(cells) + r" \\")
        if method in ("great_expectations", "pca", "lunar"):
            lines.append(r"\midrule")
    lines = [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    return "\n".join(lines)


def x_matrix_table__mutmut_66(frame: pd.DataFrame, caption: str, label: str) -> str:
    """A LaTeX table of mean recall by method and type, the best value of each column in bold."""
    best = frame.max()
    lines = [
        r"\begin{table}[t]",
        rf"\caption{{{caption}}}",
        rf"\label{{{label}}}",
        r"\centering",
        r"\footnotesize",
        r"\setlength{\tabcolsep}{3pt}",
        r"\begin{tabular}{l" + "c" * len(frame.columns) + "}",
        r"\toprule",
        "Method & " + " & ".join(LABELS[c] for c in frame.columns) + r" \\",
        r"\midrule",
    ]
    names = {**NAMES, **EXTRA_NAMES}
    for method in frame.index:
        cells = []
        for column in frame.columns:
            text = f"{frame.loc[method, column]:.2f}"
            if method in NAMES and round(frame.loc[method, column], 2) == round(best[column], 2):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{names[method]:<18} & " + " & ".join(cells) + r" \\")
        if method in ("great_expectations", "pca", "lunar"):
            lines.append(r"\midrule")
    lines -= [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    return "\n".join(lines)


def x_matrix_table__mutmut_67(frame: pd.DataFrame, caption: str, label: str) -> str:
    """A LaTeX table of mean recall by method and type, the best value of each column in bold."""
    best = frame.max()
    lines = [
        r"\begin{table}[t]",
        rf"\caption{{{caption}}}",
        rf"\label{{{label}}}",
        r"\centering",
        r"\footnotesize",
        r"\setlength{\tabcolsep}{3pt}",
        r"\begin{tabular}{l" + "c" * len(frame.columns) + "}",
        r"\toprule",
        "Method & " + " & ".join(LABELS[c] for c in frame.columns) + r" \\",
        r"\midrule",
    ]
    names = {**NAMES, **EXTRA_NAMES}
    for method in frame.index:
        cells = []
        for column in frame.columns:
            text = f"{frame.loc[method, column]:.2f}"
            if method in NAMES and round(frame.loc[method, column], 2) == round(best[column], 2):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{names[method]:<18} & " + " & ".join(cells) + r" \\")
        if method in ("great_expectations", "pca", "lunar"):
            lines.append(r"\midrule")
    lines += [r"XX\bottomruleXX", r"\end{tabular}", r"\end{table}"]
    return "\n".join(lines)


def x_matrix_table__mutmut_68(frame: pd.DataFrame, caption: str, label: str) -> str:
    """A LaTeX table of mean recall by method and type, the best value of each column in bold."""
    best = frame.max()
    lines = [
        r"\begin{table}[t]",
        rf"\caption{{{caption}}}",
        rf"\label{{{label}}}",
        r"\centering",
        r"\footnotesize",
        r"\setlength{\tabcolsep}{3pt}",
        r"\begin{tabular}{l" + "c" * len(frame.columns) + "}",
        r"\toprule",
        "Method & " + " & ".join(LABELS[c] for c in frame.columns) + r" \\",
        r"\midrule",
    ]
    names = {**NAMES, **EXTRA_NAMES}
    for method in frame.index:
        cells = []
        for column in frame.columns:
            text = f"{frame.loc[method, column]:.2f}"
            if method in NAMES and round(frame.loc[method, column], 2) == round(best[column], 2):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{names[method]:<18} & " + " & ".join(cells) + r" \\")
        if method in ("great_expectations", "pca", "lunar"):
            lines.append(r"\midrule")
    lines += [r"\bOTTOMRULE", r"\end{tabular}", r"\end{table}"]
    return "\n".join(lines)


def x_matrix_table__mutmut_69(frame: pd.DataFrame, caption: str, label: str) -> str:
    """A LaTeX table of mean recall by method and type, the best value of each column in bold."""
    best = frame.max()
    lines = [
        r"\begin{table}[t]",
        rf"\caption{{{caption}}}",
        rf"\label{{{label}}}",
        r"\centering",
        r"\footnotesize",
        r"\setlength{\tabcolsep}{3pt}",
        r"\begin{tabular}{l" + "c" * len(frame.columns) + "}",
        r"\toprule",
        "Method & " + " & ".join(LABELS[c] for c in frame.columns) + r" \\",
        r"\midrule",
    ]
    names = {**NAMES, **EXTRA_NAMES}
    for method in frame.index:
        cells = []
        for column in frame.columns:
            text = f"{frame.loc[method, column]:.2f}"
            if method in NAMES and round(frame.loc[method, column], 2) == round(best[column], 2):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{names[method]:<18} & " + " & ".join(cells) + r" \\")
        if method in ("great_expectations", "pca", "lunar"):
            lines.append(r"\midrule")
    lines += [r"\bottomrule", r"XX\end{tabular}XX", r"\end{table}"]
    return "\n".join(lines)


def x_matrix_table__mutmut_70(frame: pd.DataFrame, caption: str, label: str) -> str:
    """A LaTeX table of mean recall by method and type, the best value of each column in bold."""
    best = frame.max()
    lines = [
        r"\begin{table}[t]",
        rf"\caption{{{caption}}}",
        rf"\label{{{label}}}",
        r"\centering",
        r"\footnotesize",
        r"\setlength{\tabcolsep}{3pt}",
        r"\begin{tabular}{l" + "c" * len(frame.columns) + "}",
        r"\toprule",
        "Method & " + " & ".join(LABELS[c] for c in frame.columns) + r" \\",
        r"\midrule",
    ]
    names = {**NAMES, **EXTRA_NAMES}
    for method in frame.index:
        cells = []
        for column in frame.columns:
            text = f"{frame.loc[method, column]:.2f}"
            if method in NAMES and round(frame.loc[method, column], 2) == round(best[column], 2):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{names[method]:<18} & " + " & ".join(cells) + r" \\")
        if method in ("great_expectations", "pca", "lunar"):
            lines.append(r"\midrule")
    lines += [r"\bottomrule", r"\eND{TABULAR}", r"\end{table}"]
    return "\n".join(lines)


def x_matrix_table__mutmut_71(frame: pd.DataFrame, caption: str, label: str) -> str:
    """A LaTeX table of mean recall by method and type, the best value of each column in bold."""
    best = frame.max()
    lines = [
        r"\begin{table}[t]",
        rf"\caption{{{caption}}}",
        rf"\label{{{label}}}",
        r"\centering",
        r"\footnotesize",
        r"\setlength{\tabcolsep}{3pt}",
        r"\begin{tabular}{l" + "c" * len(frame.columns) + "}",
        r"\toprule",
        "Method & " + " & ".join(LABELS[c] for c in frame.columns) + r" \\",
        r"\midrule",
    ]
    names = {**NAMES, **EXTRA_NAMES}
    for method in frame.index:
        cells = []
        for column in frame.columns:
            text = f"{frame.loc[method, column]:.2f}"
            if method in NAMES and round(frame.loc[method, column], 2) == round(best[column], 2):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{names[method]:<18} & " + " & ".join(cells) + r" \\")
        if method in ("great_expectations", "pca", "lunar"):
            lines.append(r"\midrule")
    lines += [r"\bottomrule", r"\end{tabular}", r"XX\end{table}XX"]
    return "\n".join(lines)


def x_matrix_table__mutmut_72(frame: pd.DataFrame, caption: str, label: str) -> str:
    """A LaTeX table of mean recall by method and type, the best value of each column in bold."""
    best = frame.max()
    lines = [
        r"\begin{table}[t]",
        rf"\caption{{{caption}}}",
        rf"\label{{{label}}}",
        r"\centering",
        r"\footnotesize",
        r"\setlength{\tabcolsep}{3pt}",
        r"\begin{tabular}{l" + "c" * len(frame.columns) + "}",
        r"\toprule",
        "Method & " + " & ".join(LABELS[c] for c in frame.columns) + r" \\",
        r"\midrule",
    ]
    names = {**NAMES, **EXTRA_NAMES}
    for method in frame.index:
        cells = []
        for column in frame.columns:
            text = f"{frame.loc[method, column]:.2f}"
            if method in NAMES and round(frame.loc[method, column], 2) == round(best[column], 2):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{names[method]:<18} & " + " & ".join(cells) + r" \\")
        if method in ("great_expectations", "pca", "lunar"):
            lines.append(r"\midrule")
    lines += [r"\bottomrule", r"\end{tabular}", r"\eND{TABLE}"]
    return "\n".join(lines)


def x_matrix_table__mutmut_73(frame: pd.DataFrame, caption: str, label: str) -> str:
    """A LaTeX table of mean recall by method and type, the best value of each column in bold."""
    best = frame.max()
    lines = [
        r"\begin{table}[t]",
        rf"\caption{{{caption}}}",
        rf"\label{{{label}}}",
        r"\centering",
        r"\footnotesize",
        r"\setlength{\tabcolsep}{3pt}",
        r"\begin{tabular}{l" + "c" * len(frame.columns) + "}",
        r"\toprule",
        "Method & " + " & ".join(LABELS[c] for c in frame.columns) + r" \\",
        r"\midrule",
    ]
    names = {**NAMES, **EXTRA_NAMES}
    for method in frame.index:
        cells = []
        for column in frame.columns:
            text = f"{frame.loc[method, column]:.2f}"
            if method in NAMES and round(frame.loc[method, column], 2) == round(best[column], 2):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{names[method]:<18} & " + " & ".join(cells) + r" \\")
        if method in ("great_expectations", "pca", "lunar"):
            lines.append(r"\midrule")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    return "\n".join(None)


def x_matrix_table__mutmut_74(frame: pd.DataFrame, caption: str, label: str) -> str:
    """A LaTeX table of mean recall by method and type, the best value of each column in bold."""
    best = frame.max()
    lines = [
        r"\begin{table}[t]",
        rf"\caption{{{caption}}}",
        rf"\label{{{label}}}",
        r"\centering",
        r"\footnotesize",
        r"\setlength{\tabcolsep}{3pt}",
        r"\begin{tabular}{l" + "c" * len(frame.columns) + "}",
        r"\toprule",
        "Method & " + " & ".join(LABELS[c] for c in frame.columns) + r" \\",
        r"\midrule",
    ]
    names = {**NAMES, **EXTRA_NAMES}
    for method in frame.index:
        cells = []
        for column in frame.columns:
            text = f"{frame.loc[method, column]:.2f}"
            if method in NAMES and round(frame.loc[method, column], 2) == round(best[column], 2):
                text = f"\\textbf{{{text}}}"
            cells.append(text)
        lines.append(f"{names[method]:<18} & " + " & ".join(cells) + r" \\")
        if method in ("great_expectations", "pca", "lunar"):
            lines.append(r"\midrule")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    return "XX\nXX".join(lines)

mutants_x_matrix_table__mutmut['_mutmut_orig'] = x_matrix_table__mutmut_orig # type: ignore # mutmut generated
mutants_x_matrix_table__mutmut['x_matrix_table__mutmut_1'] = x_matrix_table__mutmut_1 # type: ignore # mutmut generated
mutants_x_matrix_table__mutmut['x_matrix_table__mutmut_2'] = x_matrix_table__mutmut_2 # type: ignore # mutmut generated
mutants_x_matrix_table__mutmut['x_matrix_table__mutmut_3'] = x_matrix_table__mutmut_3 # type: ignore # mutmut generated
mutants_x_matrix_table__mutmut['x_matrix_table__mutmut_4'] = x_matrix_table__mutmut_4 # type: ignore # mutmut generated
mutants_x_matrix_table__mutmut['x_matrix_table__mutmut_5'] = x_matrix_table__mutmut_5 # type: ignore # mutmut generated
mutants_x_matrix_table__mutmut['x_matrix_table__mutmut_6'] = x_matrix_table__mutmut_6 # type: ignore # mutmut generated
mutants_x_matrix_table__mutmut['x_matrix_table__mutmut_7'] = x_matrix_table__mutmut_7 # type: ignore # mutmut generated
mutants_x_matrix_table__mutmut['x_matrix_table__mutmut_8'] = x_matrix_table__mutmut_8 # type: ignore # mutmut generated
mutants_x_matrix_table__mutmut['x_matrix_table__mutmut_9'] = x_matrix_table__mutmut_9 # type: ignore # mutmut generated
mutants_x_matrix_table__mutmut['x_matrix_table__mutmut_10'] = x_matrix_table__mutmut_10 # type: ignore # mutmut generated
mutants_x_matrix_table__mutmut['x_matrix_table__mutmut_11'] = x_matrix_table__mutmut_11 # type: ignore # mutmut generated
mutants_x_matrix_table__mutmut['x_matrix_table__mutmut_12'] = x_matrix_table__mutmut_12 # type: ignore # mutmut generated
mutants_x_matrix_table__mutmut['x_matrix_table__mutmut_13'] = x_matrix_table__mutmut_13 # type: ignore # mutmut generated
mutants_x_matrix_table__mutmut['x_matrix_table__mutmut_14'] = x_matrix_table__mutmut_14 # type: ignore # mutmut generated
mutants_x_matrix_table__mutmut['x_matrix_table__mutmut_15'] = x_matrix_table__mutmut_15 # type: ignore # mutmut generated
mutants_x_matrix_table__mutmut['x_matrix_table__mutmut_16'] = x_matrix_table__mutmut_16 # type: ignore # mutmut generated
mutants_x_matrix_table__mutmut['x_matrix_table__mutmut_17'] = x_matrix_table__mutmut_17 # type: ignore # mutmut generated
mutants_x_matrix_table__mutmut['x_matrix_table__mutmut_18'] = x_matrix_table__mutmut_18 # type: ignore # mutmut generated
mutants_x_matrix_table__mutmut['x_matrix_table__mutmut_19'] = x_matrix_table__mutmut_19 # type: ignore # mutmut generated
mutants_x_matrix_table__mutmut['x_matrix_table__mutmut_20'] = x_matrix_table__mutmut_20 # type: ignore # mutmut generated
mutants_x_matrix_table__mutmut['x_matrix_table__mutmut_21'] = x_matrix_table__mutmut_21 # type: ignore # mutmut generated
mutants_x_matrix_table__mutmut['x_matrix_table__mutmut_22'] = x_matrix_table__mutmut_22 # type: ignore # mutmut generated
mutants_x_matrix_table__mutmut['x_matrix_table__mutmut_23'] = x_matrix_table__mutmut_23 # type: ignore # mutmut generated
mutants_x_matrix_table__mutmut['x_matrix_table__mutmut_24'] = x_matrix_table__mutmut_24 # type: ignore # mutmut generated
mutants_x_matrix_table__mutmut['x_matrix_table__mutmut_25'] = x_matrix_table__mutmut_25 # type: ignore # mutmut generated
mutants_x_matrix_table__mutmut['x_matrix_table__mutmut_26'] = x_matrix_table__mutmut_26 # type: ignore # mutmut generated
mutants_x_matrix_table__mutmut['x_matrix_table__mutmut_27'] = x_matrix_table__mutmut_27 # type: ignore # mutmut generated
mutants_x_matrix_table__mutmut['x_matrix_table__mutmut_28'] = x_matrix_table__mutmut_28 # type: ignore # mutmut generated
mutants_x_matrix_table__mutmut['x_matrix_table__mutmut_29'] = x_matrix_table__mutmut_29 # type: ignore # mutmut generated
mutants_x_matrix_table__mutmut['x_matrix_table__mutmut_30'] = x_matrix_table__mutmut_30 # type: ignore # mutmut generated
mutants_x_matrix_table__mutmut['x_matrix_table__mutmut_31'] = x_matrix_table__mutmut_31 # type: ignore # mutmut generated
mutants_x_matrix_table__mutmut['x_matrix_table__mutmut_32'] = x_matrix_table__mutmut_32 # type: ignore # mutmut generated
mutants_x_matrix_table__mutmut['x_matrix_table__mutmut_33'] = x_matrix_table__mutmut_33 # type: ignore # mutmut generated
mutants_x_matrix_table__mutmut['x_matrix_table__mutmut_34'] = x_matrix_table__mutmut_34 # type: ignore # mutmut generated
mutants_x_matrix_table__mutmut['x_matrix_table__mutmut_35'] = x_matrix_table__mutmut_35 # type: ignore # mutmut generated
mutants_x_matrix_table__mutmut['x_matrix_table__mutmut_36'] = x_matrix_table__mutmut_36 # type: ignore # mutmut generated
mutants_x_matrix_table__mutmut['x_matrix_table__mutmut_37'] = x_matrix_table__mutmut_37 # type: ignore # mutmut generated
mutants_x_matrix_table__mutmut['x_matrix_table__mutmut_38'] = x_matrix_table__mutmut_38 # type: ignore # mutmut generated
mutants_x_matrix_table__mutmut['x_matrix_table__mutmut_39'] = x_matrix_table__mutmut_39 # type: ignore # mutmut generated
mutants_x_matrix_table__mutmut['x_matrix_table__mutmut_40'] = x_matrix_table__mutmut_40 # type: ignore # mutmut generated
mutants_x_matrix_table__mutmut['x_matrix_table__mutmut_41'] = x_matrix_table__mutmut_41 # type: ignore # mutmut generated
mutants_x_matrix_table__mutmut['x_matrix_table__mutmut_42'] = x_matrix_table__mutmut_42 # type: ignore # mutmut generated
mutants_x_matrix_table__mutmut['x_matrix_table__mutmut_43'] = x_matrix_table__mutmut_43 # type: ignore # mutmut generated
mutants_x_matrix_table__mutmut['x_matrix_table__mutmut_44'] = x_matrix_table__mutmut_44 # type: ignore # mutmut generated
mutants_x_matrix_table__mutmut['x_matrix_table__mutmut_45'] = x_matrix_table__mutmut_45 # type: ignore # mutmut generated
mutants_x_matrix_table__mutmut['x_matrix_table__mutmut_46'] = x_matrix_table__mutmut_46 # type: ignore # mutmut generated
mutants_x_matrix_table__mutmut['x_matrix_table__mutmut_47'] = x_matrix_table__mutmut_47 # type: ignore # mutmut generated
mutants_x_matrix_table__mutmut['x_matrix_table__mutmut_48'] = x_matrix_table__mutmut_48 # type: ignore # mutmut generated
mutants_x_matrix_table__mutmut['x_matrix_table__mutmut_49'] = x_matrix_table__mutmut_49 # type: ignore # mutmut generated
mutants_x_matrix_table__mutmut['x_matrix_table__mutmut_50'] = x_matrix_table__mutmut_50 # type: ignore # mutmut generated
mutants_x_matrix_table__mutmut['x_matrix_table__mutmut_51'] = x_matrix_table__mutmut_51 # type: ignore # mutmut generated
mutants_x_matrix_table__mutmut['x_matrix_table__mutmut_52'] = x_matrix_table__mutmut_52 # type: ignore # mutmut generated
mutants_x_matrix_table__mutmut['x_matrix_table__mutmut_53'] = x_matrix_table__mutmut_53 # type: ignore # mutmut generated
mutants_x_matrix_table__mutmut['x_matrix_table__mutmut_54'] = x_matrix_table__mutmut_54 # type: ignore # mutmut generated
mutants_x_matrix_table__mutmut['x_matrix_table__mutmut_55'] = x_matrix_table__mutmut_55 # type: ignore # mutmut generated
mutants_x_matrix_table__mutmut['x_matrix_table__mutmut_56'] = x_matrix_table__mutmut_56 # type: ignore # mutmut generated
mutants_x_matrix_table__mutmut['x_matrix_table__mutmut_57'] = x_matrix_table__mutmut_57 # type: ignore # mutmut generated
mutants_x_matrix_table__mutmut['x_matrix_table__mutmut_58'] = x_matrix_table__mutmut_58 # type: ignore # mutmut generated
mutants_x_matrix_table__mutmut['x_matrix_table__mutmut_59'] = x_matrix_table__mutmut_59 # type: ignore # mutmut generated
mutants_x_matrix_table__mutmut['x_matrix_table__mutmut_60'] = x_matrix_table__mutmut_60 # type: ignore # mutmut generated
mutants_x_matrix_table__mutmut['x_matrix_table__mutmut_61'] = x_matrix_table__mutmut_61 # type: ignore # mutmut generated
mutants_x_matrix_table__mutmut['x_matrix_table__mutmut_62'] = x_matrix_table__mutmut_62 # type: ignore # mutmut generated
mutants_x_matrix_table__mutmut['x_matrix_table__mutmut_63'] = x_matrix_table__mutmut_63 # type: ignore # mutmut generated
mutants_x_matrix_table__mutmut['x_matrix_table__mutmut_64'] = x_matrix_table__mutmut_64 # type: ignore # mutmut generated
mutants_x_matrix_table__mutmut['x_matrix_table__mutmut_65'] = x_matrix_table__mutmut_65 # type: ignore # mutmut generated
mutants_x_matrix_table__mutmut['x_matrix_table__mutmut_66'] = x_matrix_table__mutmut_66 # type: ignore # mutmut generated
mutants_x_matrix_table__mutmut['x_matrix_table__mutmut_67'] = x_matrix_table__mutmut_67 # type: ignore # mutmut generated
mutants_x_matrix_table__mutmut['x_matrix_table__mutmut_68'] = x_matrix_table__mutmut_68 # type: ignore # mutmut generated
mutants_x_matrix_table__mutmut['x_matrix_table__mutmut_69'] = x_matrix_table__mutmut_69 # type: ignore # mutmut generated
mutants_x_matrix_table__mutmut['x_matrix_table__mutmut_70'] = x_matrix_table__mutmut_70 # type: ignore # mutmut generated
mutants_x_matrix_table__mutmut['x_matrix_table__mutmut_71'] = x_matrix_table__mutmut_71 # type: ignore # mutmut generated
mutants_x_matrix_table__mutmut['x_matrix_table__mutmut_72'] = x_matrix_table__mutmut_72 # type: ignore # mutmut generated
mutants_x_matrix_table__mutmut['x_matrix_table__mutmut_73'] = x_matrix_table__mutmut_73 # type: ignore # mutmut generated
mutants_x_matrix_table__mutmut['x_matrix_table__mutmut_74'] = x_matrix_table__mutmut_74 # type: ignore # mutmut generated


EXAMPLES = (
    ("adbench:fraud", "Fraud"),
    ("adbench:cardio", "Cardio"),
    ("adbench:annthyroid", "Annthyroid"),
    ("uci:73", "Mushroom"),
)
mutants_x_example_rows__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_example_rows__mutmut)
def example_rows(evidence: Path = EVIDENCE) -> str:
    """PR-AUC of every detector on four problems of the pool, the best of each column in bold."""
    import sys

    sys.path.insert(0, str(ROOT / "research"))
    import labelled_summary as ls

    runs = ls.load(evidence / "labelled_pool" / "runs") + ls.load(
        evidence / "full_registry" / "pool_deep" / "runs"
    )
    wide = ls.table(runs).pivot(index="problem", columns="method", values="pr_auc")
    best = {problem: wide.loc[problem].max() for problem, _ in EXAMPLES}
    lines = []
    for name in NAMES:
        cells = []
        for problem, _ in EXAMPLES:
            value = wide.loc[problem, name]
            if pd.isna(value):
                cells.append("--")
            elif round(value, 2) == round(best[problem], 2):
                cells.append(f"\\textbf{{{value:.2f}}}")
            else:
                cells.append(f"{value:.2f}")
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_example_rows__mutmut_orig(evidence: Path = EVIDENCE) -> str:
    """PR-AUC of every detector on four problems of the pool, the best of each column in bold."""
    import sys

    sys.path.insert(0, str(ROOT / "research"))
    import labelled_summary as ls

    runs = ls.load(evidence / "labelled_pool" / "runs") + ls.load(
        evidence / "full_registry" / "pool_deep" / "runs"
    )
    wide = ls.table(runs).pivot(index="problem", columns="method", values="pr_auc")
    best = {problem: wide.loc[problem].max() for problem, _ in EXAMPLES}
    lines = []
    for name in NAMES:
        cells = []
        for problem, _ in EXAMPLES:
            value = wide.loc[problem, name]
            if pd.isna(value):
                cells.append("--")
            elif round(value, 2) == round(best[problem], 2):
                cells.append(f"\\textbf{{{value:.2f}}}")
            else:
                cells.append(f"{value:.2f}")
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_example_rows__mutmut_1(evidence: Path = EVIDENCE) -> str:
    """PR-AUC of every detector on four problems of the pool, the best of each column in bold."""
    import sys

    sys.path.insert(None, str(ROOT / "research"))
    import labelled_summary as ls

    runs = ls.load(evidence / "labelled_pool" / "runs") + ls.load(
        evidence / "full_registry" / "pool_deep" / "runs"
    )
    wide = ls.table(runs).pivot(index="problem", columns="method", values="pr_auc")
    best = {problem: wide.loc[problem].max() for problem, _ in EXAMPLES}
    lines = []
    for name in NAMES:
        cells = []
        for problem, _ in EXAMPLES:
            value = wide.loc[problem, name]
            if pd.isna(value):
                cells.append("--")
            elif round(value, 2) == round(best[problem], 2):
                cells.append(f"\\textbf{{{value:.2f}}}")
            else:
                cells.append(f"{value:.2f}")
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_example_rows__mutmut_2(evidence: Path = EVIDENCE) -> str:
    """PR-AUC of every detector on four problems of the pool, the best of each column in bold."""
    import sys

    sys.path.insert(0, None)
    import labelled_summary as ls

    runs = ls.load(evidence / "labelled_pool" / "runs") + ls.load(
        evidence / "full_registry" / "pool_deep" / "runs"
    )
    wide = ls.table(runs).pivot(index="problem", columns="method", values="pr_auc")
    best = {problem: wide.loc[problem].max() for problem, _ in EXAMPLES}
    lines = []
    for name in NAMES:
        cells = []
        for problem, _ in EXAMPLES:
            value = wide.loc[problem, name]
            if pd.isna(value):
                cells.append("--")
            elif round(value, 2) == round(best[problem], 2):
                cells.append(f"\\textbf{{{value:.2f}}}")
            else:
                cells.append(f"{value:.2f}")
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_example_rows__mutmut_3(evidence: Path = EVIDENCE) -> str:
    """PR-AUC of every detector on four problems of the pool, the best of each column in bold."""
    import sys

    sys.path.insert(str(ROOT / "research"))
    import labelled_summary as ls

    runs = ls.load(evidence / "labelled_pool" / "runs") + ls.load(
        evidence / "full_registry" / "pool_deep" / "runs"
    )
    wide = ls.table(runs).pivot(index="problem", columns="method", values="pr_auc")
    best = {problem: wide.loc[problem].max() for problem, _ in EXAMPLES}
    lines = []
    for name in NAMES:
        cells = []
        for problem, _ in EXAMPLES:
            value = wide.loc[problem, name]
            if pd.isna(value):
                cells.append("--")
            elif round(value, 2) == round(best[problem], 2):
                cells.append(f"\\textbf{{{value:.2f}}}")
            else:
                cells.append(f"{value:.2f}")
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_example_rows__mutmut_4(evidence: Path = EVIDENCE) -> str:
    """PR-AUC of every detector on four problems of the pool, the best of each column in bold."""
    import sys

    sys.path.insert(0, )
    import labelled_summary as ls

    runs = ls.load(evidence / "labelled_pool" / "runs") + ls.load(
        evidence / "full_registry" / "pool_deep" / "runs"
    )
    wide = ls.table(runs).pivot(index="problem", columns="method", values="pr_auc")
    best = {problem: wide.loc[problem].max() for problem, _ in EXAMPLES}
    lines = []
    for name in NAMES:
        cells = []
        for problem, _ in EXAMPLES:
            value = wide.loc[problem, name]
            if pd.isna(value):
                cells.append("--")
            elif round(value, 2) == round(best[problem], 2):
                cells.append(f"\\textbf{{{value:.2f}}}")
            else:
                cells.append(f"{value:.2f}")
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_example_rows__mutmut_5(evidence: Path = EVIDENCE) -> str:
    """PR-AUC of every detector on four problems of the pool, the best of each column in bold."""
    import sys

    sys.path.insert(1, str(ROOT / "research"))
    import labelled_summary as ls

    runs = ls.load(evidence / "labelled_pool" / "runs") + ls.load(
        evidence / "full_registry" / "pool_deep" / "runs"
    )
    wide = ls.table(runs).pivot(index="problem", columns="method", values="pr_auc")
    best = {problem: wide.loc[problem].max() for problem, _ in EXAMPLES}
    lines = []
    for name in NAMES:
        cells = []
        for problem, _ in EXAMPLES:
            value = wide.loc[problem, name]
            if pd.isna(value):
                cells.append("--")
            elif round(value, 2) == round(best[problem], 2):
                cells.append(f"\\textbf{{{value:.2f}}}")
            else:
                cells.append(f"{value:.2f}")
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_example_rows__mutmut_6(evidence: Path = EVIDENCE) -> str:
    """PR-AUC of every detector on four problems of the pool, the best of each column in bold."""
    import sys

    sys.path.insert(0, str(None))
    import labelled_summary as ls

    runs = ls.load(evidence / "labelled_pool" / "runs") + ls.load(
        evidence / "full_registry" / "pool_deep" / "runs"
    )
    wide = ls.table(runs).pivot(index="problem", columns="method", values="pr_auc")
    best = {problem: wide.loc[problem].max() for problem, _ in EXAMPLES}
    lines = []
    for name in NAMES:
        cells = []
        for problem, _ in EXAMPLES:
            value = wide.loc[problem, name]
            if pd.isna(value):
                cells.append("--")
            elif round(value, 2) == round(best[problem], 2):
                cells.append(f"\\textbf{{{value:.2f}}}")
            else:
                cells.append(f"{value:.2f}")
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_example_rows__mutmut_7(evidence: Path = EVIDENCE) -> str:
    """PR-AUC of every detector on four problems of the pool, the best of each column in bold."""
    import sys

    sys.path.insert(0, str(ROOT * "research"))
    import labelled_summary as ls

    runs = ls.load(evidence / "labelled_pool" / "runs") + ls.load(
        evidence / "full_registry" / "pool_deep" / "runs"
    )
    wide = ls.table(runs).pivot(index="problem", columns="method", values="pr_auc")
    best = {problem: wide.loc[problem].max() for problem, _ in EXAMPLES}
    lines = []
    for name in NAMES:
        cells = []
        for problem, _ in EXAMPLES:
            value = wide.loc[problem, name]
            if pd.isna(value):
                cells.append("--")
            elif round(value, 2) == round(best[problem], 2):
                cells.append(f"\\textbf{{{value:.2f}}}")
            else:
                cells.append(f"{value:.2f}")
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_example_rows__mutmut_8(evidence: Path = EVIDENCE) -> str:
    """PR-AUC of every detector on four problems of the pool, the best of each column in bold."""
    import sys

    sys.path.insert(0, str(ROOT / "XXresearchXX"))
    import labelled_summary as ls

    runs = ls.load(evidence / "labelled_pool" / "runs") + ls.load(
        evidence / "full_registry" / "pool_deep" / "runs"
    )
    wide = ls.table(runs).pivot(index="problem", columns="method", values="pr_auc")
    best = {problem: wide.loc[problem].max() for problem, _ in EXAMPLES}
    lines = []
    for name in NAMES:
        cells = []
        for problem, _ in EXAMPLES:
            value = wide.loc[problem, name]
            if pd.isna(value):
                cells.append("--")
            elif round(value, 2) == round(best[problem], 2):
                cells.append(f"\\textbf{{{value:.2f}}}")
            else:
                cells.append(f"{value:.2f}")
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_example_rows__mutmut_9(evidence: Path = EVIDENCE) -> str:
    """PR-AUC of every detector on four problems of the pool, the best of each column in bold."""
    import sys

    sys.path.insert(0, str(ROOT / "RESEARCH"))
    import labelled_summary as ls

    runs = ls.load(evidence / "labelled_pool" / "runs") + ls.load(
        evidence / "full_registry" / "pool_deep" / "runs"
    )
    wide = ls.table(runs).pivot(index="problem", columns="method", values="pr_auc")
    best = {problem: wide.loc[problem].max() for problem, _ in EXAMPLES}
    lines = []
    for name in NAMES:
        cells = []
        for problem, _ in EXAMPLES:
            value = wide.loc[problem, name]
            if pd.isna(value):
                cells.append("--")
            elif round(value, 2) == round(best[problem], 2):
                cells.append(f"\\textbf{{{value:.2f}}}")
            else:
                cells.append(f"{value:.2f}")
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_example_rows__mutmut_10(evidence: Path = EVIDENCE) -> str:
    """PR-AUC of every detector on four problems of the pool, the best of each column in bold."""
    import sys

    sys.path.insert(0, str(ROOT / "research"))
    import labelled_summary as ls

    runs = None
    wide = ls.table(runs).pivot(index="problem", columns="method", values="pr_auc")
    best = {problem: wide.loc[problem].max() for problem, _ in EXAMPLES}
    lines = []
    for name in NAMES:
        cells = []
        for problem, _ in EXAMPLES:
            value = wide.loc[problem, name]
            if pd.isna(value):
                cells.append("--")
            elif round(value, 2) == round(best[problem], 2):
                cells.append(f"\\textbf{{{value:.2f}}}")
            else:
                cells.append(f"{value:.2f}")
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_example_rows__mutmut_11(evidence: Path = EVIDENCE) -> str:
    """PR-AUC of every detector on four problems of the pool, the best of each column in bold."""
    import sys

    sys.path.insert(0, str(ROOT / "research"))
    import labelled_summary as ls

    runs = ls.load(evidence / "labelled_pool" / "runs") - ls.load(
        evidence / "full_registry" / "pool_deep" / "runs"
    )
    wide = ls.table(runs).pivot(index="problem", columns="method", values="pr_auc")
    best = {problem: wide.loc[problem].max() for problem, _ in EXAMPLES}
    lines = []
    for name in NAMES:
        cells = []
        for problem, _ in EXAMPLES:
            value = wide.loc[problem, name]
            if pd.isna(value):
                cells.append("--")
            elif round(value, 2) == round(best[problem], 2):
                cells.append(f"\\textbf{{{value:.2f}}}")
            else:
                cells.append(f"{value:.2f}")
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_example_rows__mutmut_12(evidence: Path = EVIDENCE) -> str:
    """PR-AUC of every detector on four problems of the pool, the best of each column in bold."""
    import sys

    sys.path.insert(0, str(ROOT / "research"))
    import labelled_summary as ls

    runs = ls.load(None) + ls.load(
        evidence / "full_registry" / "pool_deep" / "runs"
    )
    wide = ls.table(runs).pivot(index="problem", columns="method", values="pr_auc")
    best = {problem: wide.loc[problem].max() for problem, _ in EXAMPLES}
    lines = []
    for name in NAMES:
        cells = []
        for problem, _ in EXAMPLES:
            value = wide.loc[problem, name]
            if pd.isna(value):
                cells.append("--")
            elif round(value, 2) == round(best[problem], 2):
                cells.append(f"\\textbf{{{value:.2f}}}")
            else:
                cells.append(f"{value:.2f}")
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_example_rows__mutmut_13(evidence: Path = EVIDENCE) -> str:
    """PR-AUC of every detector on four problems of the pool, the best of each column in bold."""
    import sys

    sys.path.insert(0, str(ROOT / "research"))
    import labelled_summary as ls

    runs = ls.load(evidence / "labelled_pool" * "runs") + ls.load(
        evidence / "full_registry" / "pool_deep" / "runs"
    )
    wide = ls.table(runs).pivot(index="problem", columns="method", values="pr_auc")
    best = {problem: wide.loc[problem].max() for problem, _ in EXAMPLES}
    lines = []
    for name in NAMES:
        cells = []
        for problem, _ in EXAMPLES:
            value = wide.loc[problem, name]
            if pd.isna(value):
                cells.append("--")
            elif round(value, 2) == round(best[problem], 2):
                cells.append(f"\\textbf{{{value:.2f}}}")
            else:
                cells.append(f"{value:.2f}")
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_example_rows__mutmut_14(evidence: Path = EVIDENCE) -> str:
    """PR-AUC of every detector on four problems of the pool, the best of each column in bold."""
    import sys

    sys.path.insert(0, str(ROOT / "research"))
    import labelled_summary as ls

    runs = ls.load(evidence * "labelled_pool" / "runs") + ls.load(
        evidence / "full_registry" / "pool_deep" / "runs"
    )
    wide = ls.table(runs).pivot(index="problem", columns="method", values="pr_auc")
    best = {problem: wide.loc[problem].max() for problem, _ in EXAMPLES}
    lines = []
    for name in NAMES:
        cells = []
        for problem, _ in EXAMPLES:
            value = wide.loc[problem, name]
            if pd.isna(value):
                cells.append("--")
            elif round(value, 2) == round(best[problem], 2):
                cells.append(f"\\textbf{{{value:.2f}}}")
            else:
                cells.append(f"{value:.2f}")
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_example_rows__mutmut_15(evidence: Path = EVIDENCE) -> str:
    """PR-AUC of every detector on four problems of the pool, the best of each column in bold."""
    import sys

    sys.path.insert(0, str(ROOT / "research"))
    import labelled_summary as ls

    runs = ls.load(evidence / "XXlabelled_poolXX" / "runs") + ls.load(
        evidence / "full_registry" / "pool_deep" / "runs"
    )
    wide = ls.table(runs).pivot(index="problem", columns="method", values="pr_auc")
    best = {problem: wide.loc[problem].max() for problem, _ in EXAMPLES}
    lines = []
    for name in NAMES:
        cells = []
        for problem, _ in EXAMPLES:
            value = wide.loc[problem, name]
            if pd.isna(value):
                cells.append("--")
            elif round(value, 2) == round(best[problem], 2):
                cells.append(f"\\textbf{{{value:.2f}}}")
            else:
                cells.append(f"{value:.2f}")
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_example_rows__mutmut_16(evidence: Path = EVIDENCE) -> str:
    """PR-AUC of every detector on four problems of the pool, the best of each column in bold."""
    import sys

    sys.path.insert(0, str(ROOT / "research"))
    import labelled_summary as ls

    runs = ls.load(evidence / "LABELLED_POOL" / "runs") + ls.load(
        evidence / "full_registry" / "pool_deep" / "runs"
    )
    wide = ls.table(runs).pivot(index="problem", columns="method", values="pr_auc")
    best = {problem: wide.loc[problem].max() for problem, _ in EXAMPLES}
    lines = []
    for name in NAMES:
        cells = []
        for problem, _ in EXAMPLES:
            value = wide.loc[problem, name]
            if pd.isna(value):
                cells.append("--")
            elif round(value, 2) == round(best[problem], 2):
                cells.append(f"\\textbf{{{value:.2f}}}")
            else:
                cells.append(f"{value:.2f}")
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_example_rows__mutmut_17(evidence: Path = EVIDENCE) -> str:
    """PR-AUC of every detector on four problems of the pool, the best of each column in bold."""
    import sys

    sys.path.insert(0, str(ROOT / "research"))
    import labelled_summary as ls

    runs = ls.load(evidence / "labelled_pool" / "XXrunsXX") + ls.load(
        evidence / "full_registry" / "pool_deep" / "runs"
    )
    wide = ls.table(runs).pivot(index="problem", columns="method", values="pr_auc")
    best = {problem: wide.loc[problem].max() for problem, _ in EXAMPLES}
    lines = []
    for name in NAMES:
        cells = []
        for problem, _ in EXAMPLES:
            value = wide.loc[problem, name]
            if pd.isna(value):
                cells.append("--")
            elif round(value, 2) == round(best[problem], 2):
                cells.append(f"\\textbf{{{value:.2f}}}")
            else:
                cells.append(f"{value:.2f}")
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_example_rows__mutmut_18(evidence: Path = EVIDENCE) -> str:
    """PR-AUC of every detector on four problems of the pool, the best of each column in bold."""
    import sys

    sys.path.insert(0, str(ROOT / "research"))
    import labelled_summary as ls

    runs = ls.load(evidence / "labelled_pool" / "RUNS") + ls.load(
        evidence / "full_registry" / "pool_deep" / "runs"
    )
    wide = ls.table(runs).pivot(index="problem", columns="method", values="pr_auc")
    best = {problem: wide.loc[problem].max() for problem, _ in EXAMPLES}
    lines = []
    for name in NAMES:
        cells = []
        for problem, _ in EXAMPLES:
            value = wide.loc[problem, name]
            if pd.isna(value):
                cells.append("--")
            elif round(value, 2) == round(best[problem], 2):
                cells.append(f"\\textbf{{{value:.2f}}}")
            else:
                cells.append(f"{value:.2f}")
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_example_rows__mutmut_19(evidence: Path = EVIDENCE) -> str:
    """PR-AUC of every detector on four problems of the pool, the best of each column in bold."""
    import sys

    sys.path.insert(0, str(ROOT / "research"))
    import labelled_summary as ls

    runs = ls.load(evidence / "labelled_pool" / "runs") + ls.load(
        None
    )
    wide = ls.table(runs).pivot(index="problem", columns="method", values="pr_auc")
    best = {problem: wide.loc[problem].max() for problem, _ in EXAMPLES}
    lines = []
    for name in NAMES:
        cells = []
        for problem, _ in EXAMPLES:
            value = wide.loc[problem, name]
            if pd.isna(value):
                cells.append("--")
            elif round(value, 2) == round(best[problem], 2):
                cells.append(f"\\textbf{{{value:.2f}}}")
            else:
                cells.append(f"{value:.2f}")
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_example_rows__mutmut_20(evidence: Path = EVIDENCE) -> str:
    """PR-AUC of every detector on four problems of the pool, the best of each column in bold."""
    import sys

    sys.path.insert(0, str(ROOT / "research"))
    import labelled_summary as ls

    runs = ls.load(evidence / "labelled_pool" / "runs") + ls.load(
        evidence / "full_registry" / "pool_deep" * "runs"
    )
    wide = ls.table(runs).pivot(index="problem", columns="method", values="pr_auc")
    best = {problem: wide.loc[problem].max() for problem, _ in EXAMPLES}
    lines = []
    for name in NAMES:
        cells = []
        for problem, _ in EXAMPLES:
            value = wide.loc[problem, name]
            if pd.isna(value):
                cells.append("--")
            elif round(value, 2) == round(best[problem], 2):
                cells.append(f"\\textbf{{{value:.2f}}}")
            else:
                cells.append(f"{value:.2f}")
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_example_rows__mutmut_21(evidence: Path = EVIDENCE) -> str:
    """PR-AUC of every detector on four problems of the pool, the best of each column in bold."""
    import sys

    sys.path.insert(0, str(ROOT / "research"))
    import labelled_summary as ls

    runs = ls.load(evidence / "labelled_pool" / "runs") + ls.load(
        evidence / "full_registry" * "pool_deep" / "runs"
    )
    wide = ls.table(runs).pivot(index="problem", columns="method", values="pr_auc")
    best = {problem: wide.loc[problem].max() for problem, _ in EXAMPLES}
    lines = []
    for name in NAMES:
        cells = []
        for problem, _ in EXAMPLES:
            value = wide.loc[problem, name]
            if pd.isna(value):
                cells.append("--")
            elif round(value, 2) == round(best[problem], 2):
                cells.append(f"\\textbf{{{value:.2f}}}")
            else:
                cells.append(f"{value:.2f}")
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_example_rows__mutmut_22(evidence: Path = EVIDENCE) -> str:
    """PR-AUC of every detector on four problems of the pool, the best of each column in bold."""
    import sys

    sys.path.insert(0, str(ROOT / "research"))
    import labelled_summary as ls

    runs = ls.load(evidence / "labelled_pool" / "runs") + ls.load(
        evidence * "full_registry" / "pool_deep" / "runs"
    )
    wide = ls.table(runs).pivot(index="problem", columns="method", values="pr_auc")
    best = {problem: wide.loc[problem].max() for problem, _ in EXAMPLES}
    lines = []
    for name in NAMES:
        cells = []
        for problem, _ in EXAMPLES:
            value = wide.loc[problem, name]
            if pd.isna(value):
                cells.append("--")
            elif round(value, 2) == round(best[problem], 2):
                cells.append(f"\\textbf{{{value:.2f}}}")
            else:
                cells.append(f"{value:.2f}")
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_example_rows__mutmut_23(evidence: Path = EVIDENCE) -> str:
    """PR-AUC of every detector on four problems of the pool, the best of each column in bold."""
    import sys

    sys.path.insert(0, str(ROOT / "research"))
    import labelled_summary as ls

    runs = ls.load(evidence / "labelled_pool" / "runs") + ls.load(
        evidence / "XXfull_registryXX" / "pool_deep" / "runs"
    )
    wide = ls.table(runs).pivot(index="problem", columns="method", values="pr_auc")
    best = {problem: wide.loc[problem].max() for problem, _ in EXAMPLES}
    lines = []
    for name in NAMES:
        cells = []
        for problem, _ in EXAMPLES:
            value = wide.loc[problem, name]
            if pd.isna(value):
                cells.append("--")
            elif round(value, 2) == round(best[problem], 2):
                cells.append(f"\\textbf{{{value:.2f}}}")
            else:
                cells.append(f"{value:.2f}")
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_example_rows__mutmut_24(evidence: Path = EVIDENCE) -> str:
    """PR-AUC of every detector on four problems of the pool, the best of each column in bold."""
    import sys

    sys.path.insert(0, str(ROOT / "research"))
    import labelled_summary as ls

    runs = ls.load(evidence / "labelled_pool" / "runs") + ls.load(
        evidence / "FULL_REGISTRY" / "pool_deep" / "runs"
    )
    wide = ls.table(runs).pivot(index="problem", columns="method", values="pr_auc")
    best = {problem: wide.loc[problem].max() for problem, _ in EXAMPLES}
    lines = []
    for name in NAMES:
        cells = []
        for problem, _ in EXAMPLES:
            value = wide.loc[problem, name]
            if pd.isna(value):
                cells.append("--")
            elif round(value, 2) == round(best[problem], 2):
                cells.append(f"\\textbf{{{value:.2f}}}")
            else:
                cells.append(f"{value:.2f}")
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_example_rows__mutmut_25(evidence: Path = EVIDENCE) -> str:
    """PR-AUC of every detector on four problems of the pool, the best of each column in bold."""
    import sys

    sys.path.insert(0, str(ROOT / "research"))
    import labelled_summary as ls

    runs = ls.load(evidence / "labelled_pool" / "runs") + ls.load(
        evidence / "full_registry" / "XXpool_deepXX" / "runs"
    )
    wide = ls.table(runs).pivot(index="problem", columns="method", values="pr_auc")
    best = {problem: wide.loc[problem].max() for problem, _ in EXAMPLES}
    lines = []
    for name in NAMES:
        cells = []
        for problem, _ in EXAMPLES:
            value = wide.loc[problem, name]
            if pd.isna(value):
                cells.append("--")
            elif round(value, 2) == round(best[problem], 2):
                cells.append(f"\\textbf{{{value:.2f}}}")
            else:
                cells.append(f"{value:.2f}")
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_example_rows__mutmut_26(evidence: Path = EVIDENCE) -> str:
    """PR-AUC of every detector on four problems of the pool, the best of each column in bold."""
    import sys

    sys.path.insert(0, str(ROOT / "research"))
    import labelled_summary as ls

    runs = ls.load(evidence / "labelled_pool" / "runs") + ls.load(
        evidence / "full_registry" / "POOL_DEEP" / "runs"
    )
    wide = ls.table(runs).pivot(index="problem", columns="method", values="pr_auc")
    best = {problem: wide.loc[problem].max() for problem, _ in EXAMPLES}
    lines = []
    for name in NAMES:
        cells = []
        for problem, _ in EXAMPLES:
            value = wide.loc[problem, name]
            if pd.isna(value):
                cells.append("--")
            elif round(value, 2) == round(best[problem], 2):
                cells.append(f"\\textbf{{{value:.2f}}}")
            else:
                cells.append(f"{value:.2f}")
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_example_rows__mutmut_27(evidence: Path = EVIDENCE) -> str:
    """PR-AUC of every detector on four problems of the pool, the best of each column in bold."""
    import sys

    sys.path.insert(0, str(ROOT / "research"))
    import labelled_summary as ls

    runs = ls.load(evidence / "labelled_pool" / "runs") + ls.load(
        evidence / "full_registry" / "pool_deep" / "XXrunsXX"
    )
    wide = ls.table(runs).pivot(index="problem", columns="method", values="pr_auc")
    best = {problem: wide.loc[problem].max() for problem, _ in EXAMPLES}
    lines = []
    for name in NAMES:
        cells = []
        for problem, _ in EXAMPLES:
            value = wide.loc[problem, name]
            if pd.isna(value):
                cells.append("--")
            elif round(value, 2) == round(best[problem], 2):
                cells.append(f"\\textbf{{{value:.2f}}}")
            else:
                cells.append(f"{value:.2f}")
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_example_rows__mutmut_28(evidence: Path = EVIDENCE) -> str:
    """PR-AUC of every detector on four problems of the pool, the best of each column in bold."""
    import sys

    sys.path.insert(0, str(ROOT / "research"))
    import labelled_summary as ls

    runs = ls.load(evidence / "labelled_pool" / "runs") + ls.load(
        evidence / "full_registry" / "pool_deep" / "RUNS"
    )
    wide = ls.table(runs).pivot(index="problem", columns="method", values="pr_auc")
    best = {problem: wide.loc[problem].max() for problem, _ in EXAMPLES}
    lines = []
    for name in NAMES:
        cells = []
        for problem, _ in EXAMPLES:
            value = wide.loc[problem, name]
            if pd.isna(value):
                cells.append("--")
            elif round(value, 2) == round(best[problem], 2):
                cells.append(f"\\textbf{{{value:.2f}}}")
            else:
                cells.append(f"{value:.2f}")
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_example_rows__mutmut_29(evidence: Path = EVIDENCE) -> str:
    """PR-AUC of every detector on four problems of the pool, the best of each column in bold."""
    import sys

    sys.path.insert(0, str(ROOT / "research"))
    import labelled_summary as ls

    runs = ls.load(evidence / "labelled_pool" / "runs") + ls.load(
        evidence / "full_registry" / "pool_deep" / "runs"
    )
    wide = None
    best = {problem: wide.loc[problem].max() for problem, _ in EXAMPLES}
    lines = []
    for name in NAMES:
        cells = []
        for problem, _ in EXAMPLES:
            value = wide.loc[problem, name]
            if pd.isna(value):
                cells.append("--")
            elif round(value, 2) == round(best[problem], 2):
                cells.append(f"\\textbf{{{value:.2f}}}")
            else:
                cells.append(f"{value:.2f}")
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_example_rows__mutmut_30(evidence: Path = EVIDENCE) -> str:
    """PR-AUC of every detector on four problems of the pool, the best of each column in bold."""
    import sys

    sys.path.insert(0, str(ROOT / "research"))
    import labelled_summary as ls

    runs = ls.load(evidence / "labelled_pool" / "runs") + ls.load(
        evidence / "full_registry" / "pool_deep" / "runs"
    )
    wide = ls.table(runs).pivot(index=None, columns="method", values="pr_auc")
    best = {problem: wide.loc[problem].max() for problem, _ in EXAMPLES}
    lines = []
    for name in NAMES:
        cells = []
        for problem, _ in EXAMPLES:
            value = wide.loc[problem, name]
            if pd.isna(value):
                cells.append("--")
            elif round(value, 2) == round(best[problem], 2):
                cells.append(f"\\textbf{{{value:.2f}}}")
            else:
                cells.append(f"{value:.2f}")
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_example_rows__mutmut_31(evidence: Path = EVIDENCE) -> str:
    """PR-AUC of every detector on four problems of the pool, the best of each column in bold."""
    import sys

    sys.path.insert(0, str(ROOT / "research"))
    import labelled_summary as ls

    runs = ls.load(evidence / "labelled_pool" / "runs") + ls.load(
        evidence / "full_registry" / "pool_deep" / "runs"
    )
    wide = ls.table(runs).pivot(index="problem", columns=None, values="pr_auc")
    best = {problem: wide.loc[problem].max() for problem, _ in EXAMPLES}
    lines = []
    for name in NAMES:
        cells = []
        for problem, _ in EXAMPLES:
            value = wide.loc[problem, name]
            if pd.isna(value):
                cells.append("--")
            elif round(value, 2) == round(best[problem], 2):
                cells.append(f"\\textbf{{{value:.2f}}}")
            else:
                cells.append(f"{value:.2f}")
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_example_rows__mutmut_32(evidence: Path = EVIDENCE) -> str:
    """PR-AUC of every detector on four problems of the pool, the best of each column in bold."""
    import sys

    sys.path.insert(0, str(ROOT / "research"))
    import labelled_summary as ls

    runs = ls.load(evidence / "labelled_pool" / "runs") + ls.load(
        evidence / "full_registry" / "pool_deep" / "runs"
    )
    wide = ls.table(runs).pivot(index="problem", columns="method", values=None)
    best = {problem: wide.loc[problem].max() for problem, _ in EXAMPLES}
    lines = []
    for name in NAMES:
        cells = []
        for problem, _ in EXAMPLES:
            value = wide.loc[problem, name]
            if pd.isna(value):
                cells.append("--")
            elif round(value, 2) == round(best[problem], 2):
                cells.append(f"\\textbf{{{value:.2f}}}")
            else:
                cells.append(f"{value:.2f}")
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_example_rows__mutmut_33(evidence: Path = EVIDENCE) -> str:
    """PR-AUC of every detector on four problems of the pool, the best of each column in bold."""
    import sys

    sys.path.insert(0, str(ROOT / "research"))
    import labelled_summary as ls

    runs = ls.load(evidence / "labelled_pool" / "runs") + ls.load(
        evidence / "full_registry" / "pool_deep" / "runs"
    )
    wide = ls.table(runs).pivot(columns="method", values="pr_auc")
    best = {problem: wide.loc[problem].max() for problem, _ in EXAMPLES}
    lines = []
    for name in NAMES:
        cells = []
        for problem, _ in EXAMPLES:
            value = wide.loc[problem, name]
            if pd.isna(value):
                cells.append("--")
            elif round(value, 2) == round(best[problem], 2):
                cells.append(f"\\textbf{{{value:.2f}}}")
            else:
                cells.append(f"{value:.2f}")
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_example_rows__mutmut_34(evidence: Path = EVIDENCE) -> str:
    """PR-AUC of every detector on four problems of the pool, the best of each column in bold."""
    import sys

    sys.path.insert(0, str(ROOT / "research"))
    import labelled_summary as ls

    runs = ls.load(evidence / "labelled_pool" / "runs") + ls.load(
        evidence / "full_registry" / "pool_deep" / "runs"
    )
    wide = ls.table(runs).pivot(index="problem", values="pr_auc")
    best = {problem: wide.loc[problem].max() for problem, _ in EXAMPLES}
    lines = []
    for name in NAMES:
        cells = []
        for problem, _ in EXAMPLES:
            value = wide.loc[problem, name]
            if pd.isna(value):
                cells.append("--")
            elif round(value, 2) == round(best[problem], 2):
                cells.append(f"\\textbf{{{value:.2f}}}")
            else:
                cells.append(f"{value:.2f}")
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_example_rows__mutmut_35(evidence: Path = EVIDENCE) -> str:
    """PR-AUC of every detector on four problems of the pool, the best of each column in bold."""
    import sys

    sys.path.insert(0, str(ROOT / "research"))
    import labelled_summary as ls

    runs = ls.load(evidence / "labelled_pool" / "runs") + ls.load(
        evidence / "full_registry" / "pool_deep" / "runs"
    )
    wide = ls.table(runs).pivot(index="problem", columns="method", )
    best = {problem: wide.loc[problem].max() for problem, _ in EXAMPLES}
    lines = []
    for name in NAMES:
        cells = []
        for problem, _ in EXAMPLES:
            value = wide.loc[problem, name]
            if pd.isna(value):
                cells.append("--")
            elif round(value, 2) == round(best[problem], 2):
                cells.append(f"\\textbf{{{value:.2f}}}")
            else:
                cells.append(f"{value:.2f}")
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_example_rows__mutmut_36(evidence: Path = EVIDENCE) -> str:
    """PR-AUC of every detector on four problems of the pool, the best of each column in bold."""
    import sys

    sys.path.insert(0, str(ROOT / "research"))
    import labelled_summary as ls

    runs = ls.load(evidence / "labelled_pool" / "runs") + ls.load(
        evidence / "full_registry" / "pool_deep" / "runs"
    )
    wide = ls.table(None).pivot(index="problem", columns="method", values="pr_auc")
    best = {problem: wide.loc[problem].max() for problem, _ in EXAMPLES}
    lines = []
    for name in NAMES:
        cells = []
        for problem, _ in EXAMPLES:
            value = wide.loc[problem, name]
            if pd.isna(value):
                cells.append("--")
            elif round(value, 2) == round(best[problem], 2):
                cells.append(f"\\textbf{{{value:.2f}}}")
            else:
                cells.append(f"{value:.2f}")
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_example_rows__mutmut_37(evidence: Path = EVIDENCE) -> str:
    """PR-AUC of every detector on four problems of the pool, the best of each column in bold."""
    import sys

    sys.path.insert(0, str(ROOT / "research"))
    import labelled_summary as ls

    runs = ls.load(evidence / "labelled_pool" / "runs") + ls.load(
        evidence / "full_registry" / "pool_deep" / "runs"
    )
    wide = ls.table(runs).pivot(index="XXproblemXX", columns="method", values="pr_auc")
    best = {problem: wide.loc[problem].max() for problem, _ in EXAMPLES}
    lines = []
    for name in NAMES:
        cells = []
        for problem, _ in EXAMPLES:
            value = wide.loc[problem, name]
            if pd.isna(value):
                cells.append("--")
            elif round(value, 2) == round(best[problem], 2):
                cells.append(f"\\textbf{{{value:.2f}}}")
            else:
                cells.append(f"{value:.2f}")
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_example_rows__mutmut_38(evidence: Path = EVIDENCE) -> str:
    """PR-AUC of every detector on four problems of the pool, the best of each column in bold."""
    import sys

    sys.path.insert(0, str(ROOT / "research"))
    import labelled_summary as ls

    runs = ls.load(evidence / "labelled_pool" / "runs") + ls.load(
        evidence / "full_registry" / "pool_deep" / "runs"
    )
    wide = ls.table(runs).pivot(index="PROBLEM", columns="method", values="pr_auc")
    best = {problem: wide.loc[problem].max() for problem, _ in EXAMPLES}
    lines = []
    for name in NAMES:
        cells = []
        for problem, _ in EXAMPLES:
            value = wide.loc[problem, name]
            if pd.isna(value):
                cells.append("--")
            elif round(value, 2) == round(best[problem], 2):
                cells.append(f"\\textbf{{{value:.2f}}}")
            else:
                cells.append(f"{value:.2f}")
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_example_rows__mutmut_39(evidence: Path = EVIDENCE) -> str:
    """PR-AUC of every detector on four problems of the pool, the best of each column in bold."""
    import sys

    sys.path.insert(0, str(ROOT / "research"))
    import labelled_summary as ls

    runs = ls.load(evidence / "labelled_pool" / "runs") + ls.load(
        evidence / "full_registry" / "pool_deep" / "runs"
    )
    wide = ls.table(runs).pivot(index="problem", columns="XXmethodXX", values="pr_auc")
    best = {problem: wide.loc[problem].max() for problem, _ in EXAMPLES}
    lines = []
    for name in NAMES:
        cells = []
        for problem, _ in EXAMPLES:
            value = wide.loc[problem, name]
            if pd.isna(value):
                cells.append("--")
            elif round(value, 2) == round(best[problem], 2):
                cells.append(f"\\textbf{{{value:.2f}}}")
            else:
                cells.append(f"{value:.2f}")
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_example_rows__mutmut_40(evidence: Path = EVIDENCE) -> str:
    """PR-AUC of every detector on four problems of the pool, the best of each column in bold."""
    import sys

    sys.path.insert(0, str(ROOT / "research"))
    import labelled_summary as ls

    runs = ls.load(evidence / "labelled_pool" / "runs") + ls.load(
        evidence / "full_registry" / "pool_deep" / "runs"
    )
    wide = ls.table(runs).pivot(index="problem", columns="METHOD", values="pr_auc")
    best = {problem: wide.loc[problem].max() for problem, _ in EXAMPLES}
    lines = []
    for name in NAMES:
        cells = []
        for problem, _ in EXAMPLES:
            value = wide.loc[problem, name]
            if pd.isna(value):
                cells.append("--")
            elif round(value, 2) == round(best[problem], 2):
                cells.append(f"\\textbf{{{value:.2f}}}")
            else:
                cells.append(f"{value:.2f}")
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_example_rows__mutmut_41(evidence: Path = EVIDENCE) -> str:
    """PR-AUC of every detector on four problems of the pool, the best of each column in bold."""
    import sys

    sys.path.insert(0, str(ROOT / "research"))
    import labelled_summary as ls

    runs = ls.load(evidence / "labelled_pool" / "runs") + ls.load(
        evidence / "full_registry" / "pool_deep" / "runs"
    )
    wide = ls.table(runs).pivot(index="problem", columns="method", values="XXpr_aucXX")
    best = {problem: wide.loc[problem].max() for problem, _ in EXAMPLES}
    lines = []
    for name in NAMES:
        cells = []
        for problem, _ in EXAMPLES:
            value = wide.loc[problem, name]
            if pd.isna(value):
                cells.append("--")
            elif round(value, 2) == round(best[problem], 2):
                cells.append(f"\\textbf{{{value:.2f}}}")
            else:
                cells.append(f"{value:.2f}")
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_example_rows__mutmut_42(evidence: Path = EVIDENCE) -> str:
    """PR-AUC of every detector on four problems of the pool, the best of each column in bold."""
    import sys

    sys.path.insert(0, str(ROOT / "research"))
    import labelled_summary as ls

    runs = ls.load(evidence / "labelled_pool" / "runs") + ls.load(
        evidence / "full_registry" / "pool_deep" / "runs"
    )
    wide = ls.table(runs).pivot(index="problem", columns="method", values="PR_AUC")
    best = {problem: wide.loc[problem].max() for problem, _ in EXAMPLES}
    lines = []
    for name in NAMES:
        cells = []
        for problem, _ in EXAMPLES:
            value = wide.loc[problem, name]
            if pd.isna(value):
                cells.append("--")
            elif round(value, 2) == round(best[problem], 2):
                cells.append(f"\\textbf{{{value:.2f}}}")
            else:
                cells.append(f"{value:.2f}")
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_example_rows__mutmut_43(evidence: Path = EVIDENCE) -> str:
    """PR-AUC of every detector on four problems of the pool, the best of each column in bold."""
    import sys

    sys.path.insert(0, str(ROOT / "research"))
    import labelled_summary as ls

    runs = ls.load(evidence / "labelled_pool" / "runs") + ls.load(
        evidence / "full_registry" / "pool_deep" / "runs"
    )
    wide = ls.table(runs).pivot(index="problem", columns="method", values="pr_auc")
    best = None
    lines = []
    for name in NAMES:
        cells = []
        for problem, _ in EXAMPLES:
            value = wide.loc[problem, name]
            if pd.isna(value):
                cells.append("--")
            elif round(value, 2) == round(best[problem], 2):
                cells.append(f"\\textbf{{{value:.2f}}}")
            else:
                cells.append(f"{value:.2f}")
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_example_rows__mutmut_44(evidence: Path = EVIDENCE) -> str:
    """PR-AUC of every detector on four problems of the pool, the best of each column in bold."""
    import sys

    sys.path.insert(0, str(ROOT / "research"))
    import labelled_summary as ls

    runs = ls.load(evidence / "labelled_pool" / "runs") + ls.load(
        evidence / "full_registry" / "pool_deep" / "runs"
    )
    wide = ls.table(runs).pivot(index="problem", columns="method", values="pr_auc")
    best = {problem: wide.loc[problem].max() for problem, _ in EXAMPLES}
    lines = None
    for name in NAMES:
        cells = []
        for problem, _ in EXAMPLES:
            value = wide.loc[problem, name]
            if pd.isna(value):
                cells.append("--")
            elif round(value, 2) == round(best[problem], 2):
                cells.append(f"\\textbf{{{value:.2f}}}")
            else:
                cells.append(f"{value:.2f}")
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_example_rows__mutmut_45(evidence: Path = EVIDENCE) -> str:
    """PR-AUC of every detector on four problems of the pool, the best of each column in bold."""
    import sys

    sys.path.insert(0, str(ROOT / "research"))
    import labelled_summary as ls

    runs = ls.load(evidence / "labelled_pool" / "runs") + ls.load(
        evidence / "full_registry" / "pool_deep" / "runs"
    )
    wide = ls.table(runs).pivot(index="problem", columns="method", values="pr_auc")
    best = {problem: wide.loc[problem].max() for problem, _ in EXAMPLES}
    lines = []
    for name in NAMES:
        cells = None
        for problem, _ in EXAMPLES:
            value = wide.loc[problem, name]
            if pd.isna(value):
                cells.append("--")
            elif round(value, 2) == round(best[problem], 2):
                cells.append(f"\\textbf{{{value:.2f}}}")
            else:
                cells.append(f"{value:.2f}")
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_example_rows__mutmut_46(evidence: Path = EVIDENCE) -> str:
    """PR-AUC of every detector on four problems of the pool, the best of each column in bold."""
    import sys

    sys.path.insert(0, str(ROOT / "research"))
    import labelled_summary as ls

    runs = ls.load(evidence / "labelled_pool" / "runs") + ls.load(
        evidence / "full_registry" / "pool_deep" / "runs"
    )
    wide = ls.table(runs).pivot(index="problem", columns="method", values="pr_auc")
    best = {problem: wide.loc[problem].max() for problem, _ in EXAMPLES}
    lines = []
    for name in NAMES:
        cells = []
        for problem, _ in EXAMPLES:
            value = None
            if pd.isna(value):
                cells.append("--")
            elif round(value, 2) == round(best[problem], 2):
                cells.append(f"\\textbf{{{value:.2f}}}")
            else:
                cells.append(f"{value:.2f}")
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_example_rows__mutmut_47(evidence: Path = EVIDENCE) -> str:
    """PR-AUC of every detector on four problems of the pool, the best of each column in bold."""
    import sys

    sys.path.insert(0, str(ROOT / "research"))
    import labelled_summary as ls

    runs = ls.load(evidence / "labelled_pool" / "runs") + ls.load(
        evidence / "full_registry" / "pool_deep" / "runs"
    )
    wide = ls.table(runs).pivot(index="problem", columns="method", values="pr_auc")
    best = {problem: wide.loc[problem].max() for problem, _ in EXAMPLES}
    lines = []
    for name in NAMES:
        cells = []
        for problem, _ in EXAMPLES:
            value = wide.loc[problem, name]
            if pd.isna(None):
                cells.append("--")
            elif round(value, 2) == round(best[problem], 2):
                cells.append(f"\\textbf{{{value:.2f}}}")
            else:
                cells.append(f"{value:.2f}")
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_example_rows__mutmut_48(evidence: Path = EVIDENCE) -> str:
    """PR-AUC of every detector on four problems of the pool, the best of each column in bold."""
    import sys

    sys.path.insert(0, str(ROOT / "research"))
    import labelled_summary as ls

    runs = ls.load(evidence / "labelled_pool" / "runs") + ls.load(
        evidence / "full_registry" / "pool_deep" / "runs"
    )
    wide = ls.table(runs).pivot(index="problem", columns="method", values="pr_auc")
    best = {problem: wide.loc[problem].max() for problem, _ in EXAMPLES}
    lines = []
    for name in NAMES:
        cells = []
        for problem, _ in EXAMPLES:
            value = wide.loc[problem, name]
            if pd.isna(value):
                cells.append(None)
            elif round(value, 2) == round(best[problem], 2):
                cells.append(f"\\textbf{{{value:.2f}}}")
            else:
                cells.append(f"{value:.2f}")
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_example_rows__mutmut_49(evidence: Path = EVIDENCE) -> str:
    """PR-AUC of every detector on four problems of the pool, the best of each column in bold."""
    import sys

    sys.path.insert(0, str(ROOT / "research"))
    import labelled_summary as ls

    runs = ls.load(evidence / "labelled_pool" / "runs") + ls.load(
        evidence / "full_registry" / "pool_deep" / "runs"
    )
    wide = ls.table(runs).pivot(index="problem", columns="method", values="pr_auc")
    best = {problem: wide.loc[problem].max() for problem, _ in EXAMPLES}
    lines = []
    for name in NAMES:
        cells = []
        for problem, _ in EXAMPLES:
            value = wide.loc[problem, name]
            if pd.isna(value):
                cells.append("XX--XX")
            elif round(value, 2) == round(best[problem], 2):
                cells.append(f"\\textbf{{{value:.2f}}}")
            else:
                cells.append(f"{value:.2f}")
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_example_rows__mutmut_50(evidence: Path = EVIDENCE) -> str:
    """PR-AUC of every detector on four problems of the pool, the best of each column in bold."""
    import sys

    sys.path.insert(0, str(ROOT / "research"))
    import labelled_summary as ls

    runs = ls.load(evidence / "labelled_pool" / "runs") + ls.load(
        evidence / "full_registry" / "pool_deep" / "runs"
    )
    wide = ls.table(runs).pivot(index="problem", columns="method", values="pr_auc")
    best = {problem: wide.loc[problem].max() for problem, _ in EXAMPLES}
    lines = []
    for name in NAMES:
        cells = []
        for problem, _ in EXAMPLES:
            value = wide.loc[problem, name]
            if pd.isna(value):
                cells.append("--")
            elif round(None, 2) == round(best[problem], 2):
                cells.append(f"\\textbf{{{value:.2f}}}")
            else:
                cells.append(f"{value:.2f}")
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_example_rows__mutmut_51(evidence: Path = EVIDENCE) -> str:
    """PR-AUC of every detector on four problems of the pool, the best of each column in bold."""
    import sys

    sys.path.insert(0, str(ROOT / "research"))
    import labelled_summary as ls

    runs = ls.load(evidence / "labelled_pool" / "runs") + ls.load(
        evidence / "full_registry" / "pool_deep" / "runs"
    )
    wide = ls.table(runs).pivot(index="problem", columns="method", values="pr_auc")
    best = {problem: wide.loc[problem].max() for problem, _ in EXAMPLES}
    lines = []
    for name in NAMES:
        cells = []
        for problem, _ in EXAMPLES:
            value = wide.loc[problem, name]
            if pd.isna(value):
                cells.append("--")
            elif round(value, None) == round(best[problem], 2):
                cells.append(f"\\textbf{{{value:.2f}}}")
            else:
                cells.append(f"{value:.2f}")
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_example_rows__mutmut_52(evidence: Path = EVIDENCE) -> str:
    """PR-AUC of every detector on four problems of the pool, the best of each column in bold."""
    import sys

    sys.path.insert(0, str(ROOT / "research"))
    import labelled_summary as ls

    runs = ls.load(evidence / "labelled_pool" / "runs") + ls.load(
        evidence / "full_registry" / "pool_deep" / "runs"
    )
    wide = ls.table(runs).pivot(index="problem", columns="method", values="pr_auc")
    best = {problem: wide.loc[problem].max() for problem, _ in EXAMPLES}
    lines = []
    for name in NAMES:
        cells = []
        for problem, _ in EXAMPLES:
            value = wide.loc[problem, name]
            if pd.isna(value):
                cells.append("--")
            elif round(2) == round(best[problem], 2):
                cells.append(f"\\textbf{{{value:.2f}}}")
            else:
                cells.append(f"{value:.2f}")
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_example_rows__mutmut_53(evidence: Path = EVIDENCE) -> str:
    """PR-AUC of every detector on four problems of the pool, the best of each column in bold."""
    import sys

    sys.path.insert(0, str(ROOT / "research"))
    import labelled_summary as ls

    runs = ls.load(evidence / "labelled_pool" / "runs") + ls.load(
        evidence / "full_registry" / "pool_deep" / "runs"
    )
    wide = ls.table(runs).pivot(index="problem", columns="method", values="pr_auc")
    best = {problem: wide.loc[problem].max() for problem, _ in EXAMPLES}
    lines = []
    for name in NAMES:
        cells = []
        for problem, _ in EXAMPLES:
            value = wide.loc[problem, name]
            if pd.isna(value):
                cells.append("--")
            elif round(value, ) == round(best[problem], 2):
                cells.append(f"\\textbf{{{value:.2f}}}")
            else:
                cells.append(f"{value:.2f}")
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_example_rows__mutmut_54(evidence: Path = EVIDENCE) -> str:
    """PR-AUC of every detector on four problems of the pool, the best of each column in bold."""
    import sys

    sys.path.insert(0, str(ROOT / "research"))
    import labelled_summary as ls

    runs = ls.load(evidence / "labelled_pool" / "runs") + ls.load(
        evidence / "full_registry" / "pool_deep" / "runs"
    )
    wide = ls.table(runs).pivot(index="problem", columns="method", values="pr_auc")
    best = {problem: wide.loc[problem].max() for problem, _ in EXAMPLES}
    lines = []
    for name in NAMES:
        cells = []
        for problem, _ in EXAMPLES:
            value = wide.loc[problem, name]
            if pd.isna(value):
                cells.append("--")
            elif round(value, 3) == round(best[problem], 2):
                cells.append(f"\\textbf{{{value:.2f}}}")
            else:
                cells.append(f"{value:.2f}")
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_example_rows__mutmut_55(evidence: Path = EVIDENCE) -> str:
    """PR-AUC of every detector on four problems of the pool, the best of each column in bold."""
    import sys

    sys.path.insert(0, str(ROOT / "research"))
    import labelled_summary as ls

    runs = ls.load(evidence / "labelled_pool" / "runs") + ls.load(
        evidence / "full_registry" / "pool_deep" / "runs"
    )
    wide = ls.table(runs).pivot(index="problem", columns="method", values="pr_auc")
    best = {problem: wide.loc[problem].max() for problem, _ in EXAMPLES}
    lines = []
    for name in NAMES:
        cells = []
        for problem, _ in EXAMPLES:
            value = wide.loc[problem, name]
            if pd.isna(value):
                cells.append("--")
            elif round(value, 2) != round(best[problem], 2):
                cells.append(f"\\textbf{{{value:.2f}}}")
            else:
                cells.append(f"{value:.2f}")
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_example_rows__mutmut_56(evidence: Path = EVIDENCE) -> str:
    """PR-AUC of every detector on four problems of the pool, the best of each column in bold."""
    import sys

    sys.path.insert(0, str(ROOT / "research"))
    import labelled_summary as ls

    runs = ls.load(evidence / "labelled_pool" / "runs") + ls.load(
        evidence / "full_registry" / "pool_deep" / "runs"
    )
    wide = ls.table(runs).pivot(index="problem", columns="method", values="pr_auc")
    best = {problem: wide.loc[problem].max() for problem, _ in EXAMPLES}
    lines = []
    for name in NAMES:
        cells = []
        for problem, _ in EXAMPLES:
            value = wide.loc[problem, name]
            if pd.isna(value):
                cells.append("--")
            elif round(value, 2) == round(None, 2):
                cells.append(f"\\textbf{{{value:.2f}}}")
            else:
                cells.append(f"{value:.2f}")
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_example_rows__mutmut_57(evidence: Path = EVIDENCE) -> str:
    """PR-AUC of every detector on four problems of the pool, the best of each column in bold."""
    import sys

    sys.path.insert(0, str(ROOT / "research"))
    import labelled_summary as ls

    runs = ls.load(evidence / "labelled_pool" / "runs") + ls.load(
        evidence / "full_registry" / "pool_deep" / "runs"
    )
    wide = ls.table(runs).pivot(index="problem", columns="method", values="pr_auc")
    best = {problem: wide.loc[problem].max() for problem, _ in EXAMPLES}
    lines = []
    for name in NAMES:
        cells = []
        for problem, _ in EXAMPLES:
            value = wide.loc[problem, name]
            if pd.isna(value):
                cells.append("--")
            elif round(value, 2) == round(best[problem], None):
                cells.append(f"\\textbf{{{value:.2f}}}")
            else:
                cells.append(f"{value:.2f}")
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_example_rows__mutmut_58(evidence: Path = EVIDENCE) -> str:
    """PR-AUC of every detector on four problems of the pool, the best of each column in bold."""
    import sys

    sys.path.insert(0, str(ROOT / "research"))
    import labelled_summary as ls

    runs = ls.load(evidence / "labelled_pool" / "runs") + ls.load(
        evidence / "full_registry" / "pool_deep" / "runs"
    )
    wide = ls.table(runs).pivot(index="problem", columns="method", values="pr_auc")
    best = {problem: wide.loc[problem].max() for problem, _ in EXAMPLES}
    lines = []
    for name in NAMES:
        cells = []
        for problem, _ in EXAMPLES:
            value = wide.loc[problem, name]
            if pd.isna(value):
                cells.append("--")
            elif round(value, 2) == round(2):
                cells.append(f"\\textbf{{{value:.2f}}}")
            else:
                cells.append(f"{value:.2f}")
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_example_rows__mutmut_59(evidence: Path = EVIDENCE) -> str:
    """PR-AUC of every detector on four problems of the pool, the best of each column in bold."""
    import sys

    sys.path.insert(0, str(ROOT / "research"))
    import labelled_summary as ls

    runs = ls.load(evidence / "labelled_pool" / "runs") + ls.load(
        evidence / "full_registry" / "pool_deep" / "runs"
    )
    wide = ls.table(runs).pivot(index="problem", columns="method", values="pr_auc")
    best = {problem: wide.loc[problem].max() for problem, _ in EXAMPLES}
    lines = []
    for name in NAMES:
        cells = []
        for problem, _ in EXAMPLES:
            value = wide.loc[problem, name]
            if pd.isna(value):
                cells.append("--")
            elif round(value, 2) == round(best[problem], ):
                cells.append(f"\\textbf{{{value:.2f}}}")
            else:
                cells.append(f"{value:.2f}")
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_example_rows__mutmut_60(evidence: Path = EVIDENCE) -> str:
    """PR-AUC of every detector on four problems of the pool, the best of each column in bold."""
    import sys

    sys.path.insert(0, str(ROOT / "research"))
    import labelled_summary as ls

    runs = ls.load(evidence / "labelled_pool" / "runs") + ls.load(
        evidence / "full_registry" / "pool_deep" / "runs"
    )
    wide = ls.table(runs).pivot(index="problem", columns="method", values="pr_auc")
    best = {problem: wide.loc[problem].max() for problem, _ in EXAMPLES}
    lines = []
    for name in NAMES:
        cells = []
        for problem, _ in EXAMPLES:
            value = wide.loc[problem, name]
            if pd.isna(value):
                cells.append("--")
            elif round(value, 2) == round(best[problem], 3):
                cells.append(f"\\textbf{{{value:.2f}}}")
            else:
                cells.append(f"{value:.2f}")
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_example_rows__mutmut_61(evidence: Path = EVIDENCE) -> str:
    """PR-AUC of every detector on four problems of the pool, the best of each column in bold."""
    import sys

    sys.path.insert(0, str(ROOT / "research"))
    import labelled_summary as ls

    runs = ls.load(evidence / "labelled_pool" / "runs") + ls.load(
        evidence / "full_registry" / "pool_deep" / "runs"
    )
    wide = ls.table(runs).pivot(index="problem", columns="method", values="pr_auc")
    best = {problem: wide.loc[problem].max() for problem, _ in EXAMPLES}
    lines = []
    for name in NAMES:
        cells = []
        for problem, _ in EXAMPLES:
            value = wide.loc[problem, name]
            if pd.isna(value):
                cells.append("--")
            elif round(value, 2) == round(best[problem], 2):
                cells.append(None)
            else:
                cells.append(f"{value:.2f}")
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_example_rows__mutmut_62(evidence: Path = EVIDENCE) -> str:
    """PR-AUC of every detector on four problems of the pool, the best of each column in bold."""
    import sys

    sys.path.insert(0, str(ROOT / "research"))
    import labelled_summary as ls

    runs = ls.load(evidence / "labelled_pool" / "runs") + ls.load(
        evidence / "full_registry" / "pool_deep" / "runs"
    )
    wide = ls.table(runs).pivot(index="problem", columns="method", values="pr_auc")
    best = {problem: wide.loc[problem].max() for problem, _ in EXAMPLES}
    lines = []
    for name in NAMES:
        cells = []
        for problem, _ in EXAMPLES:
            value = wide.loc[problem, name]
            if pd.isna(value):
                cells.append("--")
            elif round(value, 2) == round(best[problem], 2):
                cells.append(f"\\textbf{{{value:.2f}}}")
            else:
                cells.append(None)
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_example_rows__mutmut_63(evidence: Path = EVIDENCE) -> str:
    """PR-AUC of every detector on four problems of the pool, the best of each column in bold."""
    import sys

    sys.path.insert(0, str(ROOT / "research"))
    import labelled_summary as ls

    runs = ls.load(evidence / "labelled_pool" / "runs") + ls.load(
        evidence / "full_registry" / "pool_deep" / "runs"
    )
    wide = ls.table(runs).pivot(index="problem", columns="method", values="pr_auc")
    best = {problem: wide.loc[problem].max() for problem, _ in EXAMPLES}
    lines = []
    for name in NAMES:
        cells = []
        for problem, _ in EXAMPLES:
            value = wide.loc[problem, name]
            if pd.isna(value):
                cells.append("--")
            elif round(value, 2) == round(best[problem], 2):
                cells.append(f"\\textbf{{{value:.2f}}}")
            else:
                cells.append(f"{value:.2f}")
        lines.append(None)
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_example_rows__mutmut_64(evidence: Path = EVIDENCE) -> str:
    """PR-AUC of every detector on four problems of the pool, the best of each column in bold."""
    import sys

    sys.path.insert(0, str(ROOT / "research"))
    import labelled_summary as ls

    runs = ls.load(evidence / "labelled_pool" / "runs") + ls.load(
        evidence / "full_registry" / "pool_deep" / "runs"
    )
    wide = ls.table(runs).pivot(index="problem", columns="method", values="pr_auc")
    best = {problem: wide.loc[problem].max() for problem, _ in EXAMPLES}
    lines = []
    for name in NAMES:
        cells = []
        for problem, _ in EXAMPLES:
            value = wide.loc[problem, name]
            if pd.isna(value):
                cells.append("--")
            elif round(value, 2) == round(best[problem], 2):
                cells.append(f"\\textbf{{{value:.2f}}}")
            else:
                cells.append(f"{value:.2f}")
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) - r" \\")
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_example_rows__mutmut_65(evidence: Path = EVIDENCE) -> str:
    """PR-AUC of every detector on four problems of the pool, the best of each column in bold."""
    import sys

    sys.path.insert(0, str(ROOT / "research"))
    import labelled_summary as ls

    runs = ls.load(evidence / "labelled_pool" / "runs") + ls.load(
        evidence / "full_registry" / "pool_deep" / "runs"
    )
    wide = ls.table(runs).pivot(index="problem", columns="method", values="pr_auc")
    best = {problem: wide.loc[problem].max() for problem, _ in EXAMPLES}
    lines = []
    for name in NAMES:
        cells = []
        for problem, _ in EXAMPLES:
            value = wide.loc[problem, name]
            if pd.isna(value):
                cells.append("--")
            elif round(value, 2) == round(best[problem], 2):
                cells.append(f"\\textbf{{{value:.2f}}}")
            else:
                cells.append(f"{value:.2f}")
        lines.append(f"{NAMES[name]:<18} & " - " & ".join(cells) + r" \\")
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_example_rows__mutmut_66(evidence: Path = EVIDENCE) -> str:
    """PR-AUC of every detector on four problems of the pool, the best of each column in bold."""
    import sys

    sys.path.insert(0, str(ROOT / "research"))
    import labelled_summary as ls

    runs = ls.load(evidence / "labelled_pool" / "runs") + ls.load(
        evidence / "full_registry" / "pool_deep" / "runs"
    )
    wide = ls.table(runs).pivot(index="problem", columns="method", values="pr_auc")
    best = {problem: wide.loc[problem].max() for problem, _ in EXAMPLES}
    lines = []
    for name in NAMES:
        cells = []
        for problem, _ in EXAMPLES:
            value = wide.loc[problem, name]
            if pd.isna(value):
                cells.append("--")
            elif round(value, 2) == round(best[problem], 2):
                cells.append(f"\\textbf{{{value:.2f}}}")
            else:
                cells.append(f"{value:.2f}")
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(None) + r" \\")
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_example_rows__mutmut_67(evidence: Path = EVIDENCE) -> str:
    """PR-AUC of every detector on four problems of the pool, the best of each column in bold."""
    import sys

    sys.path.insert(0, str(ROOT / "research"))
    import labelled_summary as ls

    runs = ls.load(evidence / "labelled_pool" / "runs") + ls.load(
        evidence / "full_registry" / "pool_deep" / "runs"
    )
    wide = ls.table(runs).pivot(index="problem", columns="method", values="pr_auc")
    best = {problem: wide.loc[problem].max() for problem, _ in EXAMPLES}
    lines = []
    for name in NAMES:
        cells = []
        for problem, _ in EXAMPLES:
            value = wide.loc[problem, name]
            if pd.isna(value):
                cells.append("--")
            elif round(value, 2) == round(best[problem], 2):
                cells.append(f"\\textbf{{{value:.2f}}}")
            else:
                cells.append(f"{value:.2f}")
        lines.append(f"{NAMES[name]:<18} & " + "XX & XX".join(cells) + r" \\")
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_example_rows__mutmut_68(evidence: Path = EVIDENCE) -> str:
    """PR-AUC of every detector on four problems of the pool, the best of each column in bold."""
    import sys

    sys.path.insert(0, str(ROOT / "research"))
    import labelled_summary as ls

    runs = ls.load(evidence / "labelled_pool" / "runs") + ls.load(
        evidence / "full_registry" / "pool_deep" / "runs"
    )
    wide = ls.table(runs).pivot(index="problem", columns="method", values="pr_auc")
    best = {problem: wide.loc[problem].max() for problem, _ in EXAMPLES}
    lines = []
    for name in NAMES:
        cells = []
        for problem, _ in EXAMPLES:
            value = wide.loc[problem, name]
            if pd.isna(value):
                cells.append("--")
            elif round(value, 2) == round(best[problem], 2):
                cells.append(f"\\textbf{{{value:.2f}}}")
            else:
                cells.append(f"{value:.2f}")
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r"XX \\XX")
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_example_rows__mutmut_69(evidence: Path = EVIDENCE) -> str:
    """PR-AUC of every detector on four problems of the pool, the best of each column in bold."""
    import sys

    sys.path.insert(0, str(ROOT / "research"))
    import labelled_summary as ls

    runs = ls.load(evidence / "labelled_pool" / "runs") + ls.load(
        evidence / "full_registry" / "pool_deep" / "runs"
    )
    wide = ls.table(runs).pivot(index="problem", columns="method", values="pr_auc")
    best = {problem: wide.loc[problem].max() for problem, _ in EXAMPLES}
    lines = []
    for name in NAMES:
        cells = []
        for problem, _ in EXAMPLES:
            value = wide.loc[problem, name]
            if pd.isna(value):
                cells.append("--")
            elif round(value, 2) == round(best[problem], 2):
                cells.append(f"\\textbf{{{value:.2f}}}")
            else:
                cells.append(f"{value:.2f}")
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        if name not in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_example_rows__mutmut_70(evidence: Path = EVIDENCE) -> str:
    """PR-AUC of every detector on four problems of the pool, the best of each column in bold."""
    import sys

    sys.path.insert(0, str(ROOT / "research"))
    import labelled_summary as ls

    runs = ls.load(evidence / "labelled_pool" / "runs") + ls.load(
        evidence / "full_registry" / "pool_deep" / "runs"
    )
    wide = ls.table(runs).pivot(index="problem", columns="method", values="pr_auc")
    best = {problem: wide.loc[problem].max() for problem, _ in EXAMPLES}
    lines = []
    for name in NAMES:
        cells = []
        for problem, _ in EXAMPLES:
            value = wide.loc[problem, name]
            if pd.isna(value):
                cells.append("--")
            elif round(value, 2) == round(best[problem], 2):
                cells.append(f"\\textbf{{{value:.2f}}}")
            else:
                cells.append(f"{value:.2f}")
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        if name in (list(None)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_example_rows__mutmut_71(evidence: Path = EVIDENCE) -> str:
    """PR-AUC of every detector on four problems of the pool, the best of each column in bold."""
    import sys

    sys.path.insert(0, str(ROOT / "research"))
    import labelled_summary as ls

    runs = ls.load(evidence / "labelled_pool" / "runs") + ls.load(
        evidence / "full_registry" / "pool_deep" / "runs"
    )
    wide = ls.table(runs).pivot(index="problem", columns="method", values="pr_auc")
    best = {problem: wide.loc[problem].max() for problem, _ in EXAMPLES}
    lines = []
    for name in NAMES:
        cells = []
        for problem, _ in EXAMPLES:
            value = wide.loc[problem, name]
            if pd.isna(value):
                cells.append("--")
            elif round(value, 2) == round(best[problem], 2):
                cells.append(f"\\textbf{{{value:.2f}}}")
            else:
                cells.append(f"{value:.2f}")
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        if name in (list(NAMES)[3], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_example_rows__mutmut_72(evidence: Path = EVIDENCE) -> str:
    """PR-AUC of every detector on four problems of the pool, the best of each column in bold."""
    import sys

    sys.path.insert(0, str(ROOT / "research"))
    import labelled_summary as ls

    runs = ls.load(evidence / "labelled_pool" / "runs") + ls.load(
        evidence / "full_registry" / "pool_deep" / "runs"
    )
    wide = ls.table(runs).pivot(index="problem", columns="method", values="pr_auc")
    best = {problem: wide.loc[problem].max() for problem, _ in EXAMPLES}
    lines = []
    for name in NAMES:
        cells = []
        for problem, _ in EXAMPLES:
            value = wide.loc[problem, name]
            if pd.isna(value):
                cells.append("--")
            elif round(value, 2) == round(best[problem], 2):
                cells.append(f"\\textbf{{{value:.2f}}}")
            else:
                cells.append(f"{value:.2f}")
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        if name in (list(NAMES)[2], list(None)[10]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_example_rows__mutmut_73(evidence: Path = EVIDENCE) -> str:
    """PR-AUC of every detector on four problems of the pool, the best of each column in bold."""
    import sys

    sys.path.insert(0, str(ROOT / "research"))
    import labelled_summary as ls

    runs = ls.load(evidence / "labelled_pool" / "runs") + ls.load(
        evidence / "full_registry" / "pool_deep" / "runs"
    )
    wide = ls.table(runs).pivot(index="problem", columns="method", values="pr_auc")
    best = {problem: wide.loc[problem].max() for problem, _ in EXAMPLES}
    lines = []
    for name in NAMES:
        cells = []
        for problem, _ in EXAMPLES:
            value = wide.loc[problem, name]
            if pd.isna(value):
                cells.append("--")
            elif round(value, 2) == round(best[problem], 2):
                cells.append(f"\\textbf{{{value:.2f}}}")
            else:
                cells.append(f"{value:.2f}")
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        if name in (list(NAMES)[2], list(NAMES)[11]):
            lines.append(r"\midrule")
    return "\n".join(lines)


def x_example_rows__mutmut_74(evidence: Path = EVIDENCE) -> str:
    """PR-AUC of every detector on four problems of the pool, the best of each column in bold."""
    import sys

    sys.path.insert(0, str(ROOT / "research"))
    import labelled_summary as ls

    runs = ls.load(evidence / "labelled_pool" / "runs") + ls.load(
        evidence / "full_registry" / "pool_deep" / "runs"
    )
    wide = ls.table(runs).pivot(index="problem", columns="method", values="pr_auc")
    best = {problem: wide.loc[problem].max() for problem, _ in EXAMPLES}
    lines = []
    for name in NAMES:
        cells = []
        for problem, _ in EXAMPLES:
            value = wide.loc[problem, name]
            if pd.isna(value):
                cells.append("--")
            elif round(value, 2) == round(best[problem], 2):
                cells.append(f"\\textbf{{{value:.2f}}}")
            else:
                cells.append(f"{value:.2f}")
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(None)
    return "\n".join(lines)


def x_example_rows__mutmut_75(evidence: Path = EVIDENCE) -> str:
    """PR-AUC of every detector on four problems of the pool, the best of each column in bold."""
    import sys

    sys.path.insert(0, str(ROOT / "research"))
    import labelled_summary as ls

    runs = ls.load(evidence / "labelled_pool" / "runs") + ls.load(
        evidence / "full_registry" / "pool_deep" / "runs"
    )
    wide = ls.table(runs).pivot(index="problem", columns="method", values="pr_auc")
    best = {problem: wide.loc[problem].max() for problem, _ in EXAMPLES}
    lines = []
    for name in NAMES:
        cells = []
        for problem, _ in EXAMPLES:
            value = wide.loc[problem, name]
            if pd.isna(value):
                cells.append("--")
            elif round(value, 2) == round(best[problem], 2):
                cells.append(f"\\textbf{{{value:.2f}}}")
            else:
                cells.append(f"{value:.2f}")
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"XX\midruleXX")
    return "\n".join(lines)


def x_example_rows__mutmut_76(evidence: Path = EVIDENCE) -> str:
    """PR-AUC of every detector on four problems of the pool, the best of each column in bold."""
    import sys

    sys.path.insert(0, str(ROOT / "research"))
    import labelled_summary as ls

    runs = ls.load(evidence / "labelled_pool" / "runs") + ls.load(
        evidence / "full_registry" / "pool_deep" / "runs"
    )
    wide = ls.table(runs).pivot(index="problem", columns="method", values="pr_auc")
    best = {problem: wide.loc[problem].max() for problem, _ in EXAMPLES}
    lines = []
    for name in NAMES:
        cells = []
        for problem, _ in EXAMPLES:
            value = wide.loc[problem, name]
            if pd.isna(value):
                cells.append("--")
            elif round(value, 2) == round(best[problem], 2):
                cells.append(f"\\textbf{{{value:.2f}}}")
            else:
                cells.append(f"{value:.2f}")
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\mIDRULE")
    return "\n".join(lines)


def x_example_rows__mutmut_77(evidence: Path = EVIDENCE) -> str:
    """PR-AUC of every detector on four problems of the pool, the best of each column in bold."""
    import sys

    sys.path.insert(0, str(ROOT / "research"))
    import labelled_summary as ls

    runs = ls.load(evidence / "labelled_pool" / "runs") + ls.load(
        evidence / "full_registry" / "pool_deep" / "runs"
    )
    wide = ls.table(runs).pivot(index="problem", columns="method", values="pr_auc")
    best = {problem: wide.loc[problem].max() for problem, _ in EXAMPLES}
    lines = []
    for name in NAMES:
        cells = []
        for problem, _ in EXAMPLES:
            value = wide.loc[problem, name]
            if pd.isna(value):
                cells.append("--")
            elif round(value, 2) == round(best[problem], 2):
                cells.append(f"\\textbf{{{value:.2f}}}")
            else:
                cells.append(f"{value:.2f}")
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "\n".join(None)


def x_example_rows__mutmut_78(evidence: Path = EVIDENCE) -> str:
    """PR-AUC of every detector on four problems of the pool, the best of each column in bold."""
    import sys

    sys.path.insert(0, str(ROOT / "research"))
    import labelled_summary as ls

    runs = ls.load(evidence / "labelled_pool" / "runs") + ls.load(
        evidence / "full_registry" / "pool_deep" / "runs"
    )
    wide = ls.table(runs).pivot(index="problem", columns="method", values="pr_auc")
    best = {problem: wide.loc[problem].max() for problem, _ in EXAMPLES}
    lines = []
    for name in NAMES:
        cells = []
        for problem, _ in EXAMPLES:
            value = wide.loc[problem, name]
            if pd.isna(value):
                cells.append("--")
            elif round(value, 2) == round(best[problem], 2):
                cells.append(f"\\textbf{{{value:.2f}}}")
            else:
                cells.append(f"{value:.2f}")
        lines.append(f"{NAMES[name]:<18} & " + " & ".join(cells) + r" \\")
        if name in (list(NAMES)[2], list(NAMES)[10]):
            lines.append(r"\midrule")
    return "XX\nXX".join(lines)

mutants_x_example_rows__mutmut['_mutmut_orig'] = x_example_rows__mutmut_orig # type: ignore # mutmut generated
mutants_x_example_rows__mutmut['x_example_rows__mutmut_1'] = x_example_rows__mutmut_1 # type: ignore # mutmut generated
mutants_x_example_rows__mutmut['x_example_rows__mutmut_2'] = x_example_rows__mutmut_2 # type: ignore # mutmut generated
mutants_x_example_rows__mutmut['x_example_rows__mutmut_3'] = x_example_rows__mutmut_3 # type: ignore # mutmut generated
mutants_x_example_rows__mutmut['x_example_rows__mutmut_4'] = x_example_rows__mutmut_4 # type: ignore # mutmut generated
mutants_x_example_rows__mutmut['x_example_rows__mutmut_5'] = x_example_rows__mutmut_5 # type: ignore # mutmut generated
mutants_x_example_rows__mutmut['x_example_rows__mutmut_6'] = x_example_rows__mutmut_6 # type: ignore # mutmut generated
mutants_x_example_rows__mutmut['x_example_rows__mutmut_7'] = x_example_rows__mutmut_7 # type: ignore # mutmut generated
mutants_x_example_rows__mutmut['x_example_rows__mutmut_8'] = x_example_rows__mutmut_8 # type: ignore # mutmut generated
mutants_x_example_rows__mutmut['x_example_rows__mutmut_9'] = x_example_rows__mutmut_9 # type: ignore # mutmut generated
mutants_x_example_rows__mutmut['x_example_rows__mutmut_10'] = x_example_rows__mutmut_10 # type: ignore # mutmut generated
mutants_x_example_rows__mutmut['x_example_rows__mutmut_11'] = x_example_rows__mutmut_11 # type: ignore # mutmut generated
mutants_x_example_rows__mutmut['x_example_rows__mutmut_12'] = x_example_rows__mutmut_12 # type: ignore # mutmut generated
mutants_x_example_rows__mutmut['x_example_rows__mutmut_13'] = x_example_rows__mutmut_13 # type: ignore # mutmut generated
mutants_x_example_rows__mutmut['x_example_rows__mutmut_14'] = x_example_rows__mutmut_14 # type: ignore # mutmut generated
mutants_x_example_rows__mutmut['x_example_rows__mutmut_15'] = x_example_rows__mutmut_15 # type: ignore # mutmut generated
mutants_x_example_rows__mutmut['x_example_rows__mutmut_16'] = x_example_rows__mutmut_16 # type: ignore # mutmut generated
mutants_x_example_rows__mutmut['x_example_rows__mutmut_17'] = x_example_rows__mutmut_17 # type: ignore # mutmut generated
mutants_x_example_rows__mutmut['x_example_rows__mutmut_18'] = x_example_rows__mutmut_18 # type: ignore # mutmut generated
mutants_x_example_rows__mutmut['x_example_rows__mutmut_19'] = x_example_rows__mutmut_19 # type: ignore # mutmut generated
mutants_x_example_rows__mutmut['x_example_rows__mutmut_20'] = x_example_rows__mutmut_20 # type: ignore # mutmut generated
mutants_x_example_rows__mutmut['x_example_rows__mutmut_21'] = x_example_rows__mutmut_21 # type: ignore # mutmut generated
mutants_x_example_rows__mutmut['x_example_rows__mutmut_22'] = x_example_rows__mutmut_22 # type: ignore # mutmut generated
mutants_x_example_rows__mutmut['x_example_rows__mutmut_23'] = x_example_rows__mutmut_23 # type: ignore # mutmut generated
mutants_x_example_rows__mutmut['x_example_rows__mutmut_24'] = x_example_rows__mutmut_24 # type: ignore # mutmut generated
mutants_x_example_rows__mutmut['x_example_rows__mutmut_25'] = x_example_rows__mutmut_25 # type: ignore # mutmut generated
mutants_x_example_rows__mutmut['x_example_rows__mutmut_26'] = x_example_rows__mutmut_26 # type: ignore # mutmut generated
mutants_x_example_rows__mutmut['x_example_rows__mutmut_27'] = x_example_rows__mutmut_27 # type: ignore # mutmut generated
mutants_x_example_rows__mutmut['x_example_rows__mutmut_28'] = x_example_rows__mutmut_28 # type: ignore # mutmut generated
mutants_x_example_rows__mutmut['x_example_rows__mutmut_29'] = x_example_rows__mutmut_29 # type: ignore # mutmut generated
mutants_x_example_rows__mutmut['x_example_rows__mutmut_30'] = x_example_rows__mutmut_30 # type: ignore # mutmut generated
mutants_x_example_rows__mutmut['x_example_rows__mutmut_31'] = x_example_rows__mutmut_31 # type: ignore # mutmut generated
mutants_x_example_rows__mutmut['x_example_rows__mutmut_32'] = x_example_rows__mutmut_32 # type: ignore # mutmut generated
mutants_x_example_rows__mutmut['x_example_rows__mutmut_33'] = x_example_rows__mutmut_33 # type: ignore # mutmut generated
mutants_x_example_rows__mutmut['x_example_rows__mutmut_34'] = x_example_rows__mutmut_34 # type: ignore # mutmut generated
mutants_x_example_rows__mutmut['x_example_rows__mutmut_35'] = x_example_rows__mutmut_35 # type: ignore # mutmut generated
mutants_x_example_rows__mutmut['x_example_rows__mutmut_36'] = x_example_rows__mutmut_36 # type: ignore # mutmut generated
mutants_x_example_rows__mutmut['x_example_rows__mutmut_37'] = x_example_rows__mutmut_37 # type: ignore # mutmut generated
mutants_x_example_rows__mutmut['x_example_rows__mutmut_38'] = x_example_rows__mutmut_38 # type: ignore # mutmut generated
mutants_x_example_rows__mutmut['x_example_rows__mutmut_39'] = x_example_rows__mutmut_39 # type: ignore # mutmut generated
mutants_x_example_rows__mutmut['x_example_rows__mutmut_40'] = x_example_rows__mutmut_40 # type: ignore # mutmut generated
mutants_x_example_rows__mutmut['x_example_rows__mutmut_41'] = x_example_rows__mutmut_41 # type: ignore # mutmut generated
mutants_x_example_rows__mutmut['x_example_rows__mutmut_42'] = x_example_rows__mutmut_42 # type: ignore # mutmut generated
mutants_x_example_rows__mutmut['x_example_rows__mutmut_43'] = x_example_rows__mutmut_43 # type: ignore # mutmut generated
mutants_x_example_rows__mutmut['x_example_rows__mutmut_44'] = x_example_rows__mutmut_44 # type: ignore # mutmut generated
mutants_x_example_rows__mutmut['x_example_rows__mutmut_45'] = x_example_rows__mutmut_45 # type: ignore # mutmut generated
mutants_x_example_rows__mutmut['x_example_rows__mutmut_46'] = x_example_rows__mutmut_46 # type: ignore # mutmut generated
mutants_x_example_rows__mutmut['x_example_rows__mutmut_47'] = x_example_rows__mutmut_47 # type: ignore # mutmut generated
mutants_x_example_rows__mutmut['x_example_rows__mutmut_48'] = x_example_rows__mutmut_48 # type: ignore # mutmut generated
mutants_x_example_rows__mutmut['x_example_rows__mutmut_49'] = x_example_rows__mutmut_49 # type: ignore # mutmut generated
mutants_x_example_rows__mutmut['x_example_rows__mutmut_50'] = x_example_rows__mutmut_50 # type: ignore # mutmut generated
mutants_x_example_rows__mutmut['x_example_rows__mutmut_51'] = x_example_rows__mutmut_51 # type: ignore # mutmut generated
mutants_x_example_rows__mutmut['x_example_rows__mutmut_52'] = x_example_rows__mutmut_52 # type: ignore # mutmut generated
mutants_x_example_rows__mutmut['x_example_rows__mutmut_53'] = x_example_rows__mutmut_53 # type: ignore # mutmut generated
mutants_x_example_rows__mutmut['x_example_rows__mutmut_54'] = x_example_rows__mutmut_54 # type: ignore # mutmut generated
mutants_x_example_rows__mutmut['x_example_rows__mutmut_55'] = x_example_rows__mutmut_55 # type: ignore # mutmut generated
mutants_x_example_rows__mutmut['x_example_rows__mutmut_56'] = x_example_rows__mutmut_56 # type: ignore # mutmut generated
mutants_x_example_rows__mutmut['x_example_rows__mutmut_57'] = x_example_rows__mutmut_57 # type: ignore # mutmut generated
mutants_x_example_rows__mutmut['x_example_rows__mutmut_58'] = x_example_rows__mutmut_58 # type: ignore # mutmut generated
mutants_x_example_rows__mutmut['x_example_rows__mutmut_59'] = x_example_rows__mutmut_59 # type: ignore # mutmut generated
mutants_x_example_rows__mutmut['x_example_rows__mutmut_60'] = x_example_rows__mutmut_60 # type: ignore # mutmut generated
mutants_x_example_rows__mutmut['x_example_rows__mutmut_61'] = x_example_rows__mutmut_61 # type: ignore # mutmut generated
mutants_x_example_rows__mutmut['x_example_rows__mutmut_62'] = x_example_rows__mutmut_62 # type: ignore # mutmut generated
mutants_x_example_rows__mutmut['x_example_rows__mutmut_63'] = x_example_rows__mutmut_63 # type: ignore # mutmut generated
mutants_x_example_rows__mutmut['x_example_rows__mutmut_64'] = x_example_rows__mutmut_64 # type: ignore # mutmut generated
mutants_x_example_rows__mutmut['x_example_rows__mutmut_65'] = x_example_rows__mutmut_65 # type: ignore # mutmut generated
mutants_x_example_rows__mutmut['x_example_rows__mutmut_66'] = x_example_rows__mutmut_66 # type: ignore # mutmut generated
mutants_x_example_rows__mutmut['x_example_rows__mutmut_67'] = x_example_rows__mutmut_67 # type: ignore # mutmut generated
mutants_x_example_rows__mutmut['x_example_rows__mutmut_68'] = x_example_rows__mutmut_68 # type: ignore # mutmut generated
mutants_x_example_rows__mutmut['x_example_rows__mutmut_69'] = x_example_rows__mutmut_69 # type: ignore # mutmut generated
mutants_x_example_rows__mutmut['x_example_rows__mutmut_70'] = x_example_rows__mutmut_70 # type: ignore # mutmut generated
mutants_x_example_rows__mutmut['x_example_rows__mutmut_71'] = x_example_rows__mutmut_71 # type: ignore # mutmut generated
mutants_x_example_rows__mutmut['x_example_rows__mutmut_72'] = x_example_rows__mutmut_72 # type: ignore # mutmut generated
mutants_x_example_rows__mutmut['x_example_rows__mutmut_73'] = x_example_rows__mutmut_73 # type: ignore # mutmut generated
mutants_x_example_rows__mutmut['x_example_rows__mutmut_74'] = x_example_rows__mutmut_74 # type: ignore # mutmut generated
mutants_x_example_rows__mutmut['x_example_rows__mutmut_75'] = x_example_rows__mutmut_75 # type: ignore # mutmut generated
mutants_x_example_rows__mutmut['x_example_rows__mutmut_76'] = x_example_rows__mutmut_76 # type: ignore # mutmut generated
mutants_x_example_rows__mutmut['x_example_rows__mutmut_77'] = x_example_rows__mutmut_77 # type: ignore # mutmut generated
mutants_x_example_rows__mutmut['x_example_rows__mutmut_78'] = x_example_rows__mutmut_78 # type: ignore # mutmut generated
mutants_x_replace_body__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_replace_body__mutmut)
def replace_body(tex: str, label: str, body: str) -> str:
    pattern = re.compile(rf"(\\label\{{tab:{label}\}}.*?\\midrule\n).*?(\n\\bottomrule)", re.S)
    if not pattern.search(tex):
        raise ValueError(f"table {label} not found")
    return pattern.sub(lambda m: m.group(1) + body + m.group(2), tex, count=1)


def x_replace_body__mutmut_orig(tex: str, label: str, body: str) -> str:
    pattern = re.compile(rf"(\\label\{{tab:{label}\}}.*?\\midrule\n).*?(\n\\bottomrule)", re.S)
    if not pattern.search(tex):
        raise ValueError(f"table {label} not found")
    return pattern.sub(lambda m: m.group(1) + body + m.group(2), tex, count=1)


def x_replace_body__mutmut_1(tex: str, label: str, body: str) -> str:
    pattern = None
    if not pattern.search(tex):
        raise ValueError(f"table {label} not found")
    return pattern.sub(lambda m: m.group(1) + body + m.group(2), tex, count=1)


def x_replace_body__mutmut_2(tex: str, label: str, body: str) -> str:
    pattern = re.compile(None, re.S)
    if not pattern.search(tex):
        raise ValueError(f"table {label} not found")
    return pattern.sub(lambda m: m.group(1) + body + m.group(2), tex, count=1)


def x_replace_body__mutmut_3(tex: str, label: str, body: str) -> str:
    pattern = re.compile(rf"(\\label\{{tab:{label}\}}.*?\\midrule\n).*?(\n\\bottomrule)", None)
    if not pattern.search(tex):
        raise ValueError(f"table {label} not found")
    return pattern.sub(lambda m: m.group(1) + body + m.group(2), tex, count=1)


def x_replace_body__mutmut_4(tex: str, label: str, body: str) -> str:
    pattern = re.compile(re.S)
    if not pattern.search(tex):
        raise ValueError(f"table {label} not found")
    return pattern.sub(lambda m: m.group(1) + body + m.group(2), tex, count=1)


def x_replace_body__mutmut_5(tex: str, label: str, body: str) -> str:
    pattern = re.compile(rf"(\\label\{{tab:{label}\}}.*?\\midrule\n).*?(\n\\bottomrule)", )
    if not pattern.search(tex):
        raise ValueError(f"table {label} not found")
    return pattern.sub(lambda m: m.group(1) + body + m.group(2), tex, count=1)


def x_replace_body__mutmut_6(tex: str, label: str, body: str) -> str:
    pattern = re.compile(rf"(\\label\{{tab:{label}\}}.*?\\midrule\n).*?(\n\\bottomrule)", re.S)
    if pattern.search(tex):
        raise ValueError(f"table {label} not found")
    return pattern.sub(lambda m: m.group(1) + body + m.group(2), tex, count=1)


def x_replace_body__mutmut_7(tex: str, label: str, body: str) -> str:
    pattern = re.compile(rf"(\\label\{{tab:{label}\}}.*?\\midrule\n).*?(\n\\bottomrule)", re.S)
    if not pattern.search(None):
        raise ValueError(f"table {label} not found")
    return pattern.sub(lambda m: m.group(1) + body + m.group(2), tex, count=1)


def x_replace_body__mutmut_8(tex: str, label: str, body: str) -> str:
    pattern = re.compile(rf"(\\label\{{tab:{label}\}}.*?\\midrule\n).*?(\n\\bottomrule)", re.S)
    if not pattern.search(tex):
        raise ValueError(None)
    return pattern.sub(lambda m: m.group(1) + body + m.group(2), tex, count=1)


def x_replace_body__mutmut_9(tex: str, label: str, body: str) -> str:
    pattern = re.compile(rf"(\\label\{{tab:{label}\}}.*?\\midrule\n).*?(\n\\bottomrule)", re.S)
    if not pattern.search(tex):
        raise ValueError(f"table {label} not found")
    return pattern.sub(None, tex, count=1)


def x_replace_body__mutmut_10(tex: str, label: str, body: str) -> str:
    pattern = re.compile(rf"(\\label\{{tab:{label}\}}.*?\\midrule\n).*?(\n\\bottomrule)", re.S)
    if not pattern.search(tex):
        raise ValueError(f"table {label} not found")
    return pattern.sub(lambda m: m.group(1) + body + m.group(2), None, count=1)


def x_replace_body__mutmut_11(tex: str, label: str, body: str) -> str:
    pattern = re.compile(rf"(\\label\{{tab:{label}\}}.*?\\midrule\n).*?(\n\\bottomrule)", re.S)
    if not pattern.search(tex):
        raise ValueError(f"table {label} not found")
    return pattern.sub(lambda m: m.group(1) + body + m.group(2), tex, count=None)


def x_replace_body__mutmut_12(tex: str, label: str, body: str) -> str:
    pattern = re.compile(rf"(\\label\{{tab:{label}\}}.*?\\midrule\n).*?(\n\\bottomrule)", re.S)
    if not pattern.search(tex):
        raise ValueError(f"table {label} not found")
    return pattern.sub(tex, count=1)


def x_replace_body__mutmut_13(tex: str, label: str, body: str) -> str:
    pattern = re.compile(rf"(\\label\{{tab:{label}\}}.*?\\midrule\n).*?(\n\\bottomrule)", re.S)
    if not pattern.search(tex):
        raise ValueError(f"table {label} not found")
    return pattern.sub(lambda m: m.group(1) + body + m.group(2), count=1)


def x_replace_body__mutmut_14(tex: str, label: str, body: str) -> str:
    pattern = re.compile(rf"(\\label\{{tab:{label}\}}.*?\\midrule\n).*?(\n\\bottomrule)", re.S)
    if not pattern.search(tex):
        raise ValueError(f"table {label} not found")
    return pattern.sub(lambda m: m.group(1) + body + m.group(2), tex, )


def x_replace_body__mutmut_15(tex: str, label: str, body: str) -> str:
    pattern = re.compile(rf"(\\label\{{tab:{label}\}}.*?\\midrule\n).*?(\n\\bottomrule)", re.S)
    if not pattern.search(tex):
        raise ValueError(f"table {label} not found")
    return pattern.sub(lambda m: None, tex, count=1)


def x_replace_body__mutmut_16(tex: str, label: str, body: str) -> str:
    pattern = re.compile(rf"(\\label\{{tab:{label}\}}.*?\\midrule\n).*?(\n\\bottomrule)", re.S)
    if not pattern.search(tex):
        raise ValueError(f"table {label} not found")
    return pattern.sub(lambda m: m.group(1) + body - m.group(2), tex, count=1)


def x_replace_body__mutmut_17(tex: str, label: str, body: str) -> str:
    pattern = re.compile(rf"(\\label\{{tab:{label}\}}.*?\\midrule\n).*?(\n\\bottomrule)", re.S)
    if not pattern.search(tex):
        raise ValueError(f"table {label} not found")
    return pattern.sub(lambda m: m.group(1) - body + m.group(2), tex, count=1)


def x_replace_body__mutmut_18(tex: str, label: str, body: str) -> str:
    pattern = re.compile(rf"(\\label\{{tab:{label}\}}.*?\\midrule\n).*?(\n\\bottomrule)", re.S)
    if not pattern.search(tex):
        raise ValueError(f"table {label} not found")
    return pattern.sub(lambda m: m.group(None) + body + m.group(2), tex, count=1)


def x_replace_body__mutmut_19(tex: str, label: str, body: str) -> str:
    pattern = re.compile(rf"(\\label\{{tab:{label}\}}.*?\\midrule\n).*?(\n\\bottomrule)", re.S)
    if not pattern.search(tex):
        raise ValueError(f"table {label} not found")
    return pattern.sub(lambda m: m.group(2) + body + m.group(2), tex, count=1)


def x_replace_body__mutmut_20(tex: str, label: str, body: str) -> str:
    pattern = re.compile(rf"(\\label\{{tab:{label}\}}.*?\\midrule\n).*?(\n\\bottomrule)", re.S)
    if not pattern.search(tex):
        raise ValueError(f"table {label} not found")
    return pattern.sub(lambda m: m.group(1) + body + m.group(None), tex, count=1)


def x_replace_body__mutmut_21(tex: str, label: str, body: str) -> str:
    pattern = re.compile(rf"(\\label\{{tab:{label}\}}.*?\\midrule\n).*?(\n\\bottomrule)", re.S)
    if not pattern.search(tex):
        raise ValueError(f"table {label} not found")
    return pattern.sub(lambda m: m.group(1) + body + m.group(3), tex, count=1)


def x_replace_body__mutmut_22(tex: str, label: str, body: str) -> str:
    pattern = re.compile(rf"(\\label\{{tab:{label}\}}.*?\\midrule\n).*?(\n\\bottomrule)", re.S)
    if not pattern.search(tex):
        raise ValueError(f"table {label} not found")
    return pattern.sub(lambda m: m.group(1) + body + m.group(2), tex, count=2)

mutants_x_replace_body__mutmut['_mutmut_orig'] = x_replace_body__mutmut_orig # type: ignore # mutmut generated
mutants_x_replace_body__mutmut['x_replace_body__mutmut_1'] = x_replace_body__mutmut_1 # type: ignore # mutmut generated
mutants_x_replace_body__mutmut['x_replace_body__mutmut_2'] = x_replace_body__mutmut_2 # type: ignore # mutmut generated
mutants_x_replace_body__mutmut['x_replace_body__mutmut_3'] = x_replace_body__mutmut_3 # type: ignore # mutmut generated
mutants_x_replace_body__mutmut['x_replace_body__mutmut_4'] = x_replace_body__mutmut_4 # type: ignore # mutmut generated
mutants_x_replace_body__mutmut['x_replace_body__mutmut_5'] = x_replace_body__mutmut_5 # type: ignore # mutmut generated
mutants_x_replace_body__mutmut['x_replace_body__mutmut_6'] = x_replace_body__mutmut_6 # type: ignore # mutmut generated
mutants_x_replace_body__mutmut['x_replace_body__mutmut_7'] = x_replace_body__mutmut_7 # type: ignore # mutmut generated
mutants_x_replace_body__mutmut['x_replace_body__mutmut_8'] = x_replace_body__mutmut_8 # type: ignore # mutmut generated
mutants_x_replace_body__mutmut['x_replace_body__mutmut_9'] = x_replace_body__mutmut_9 # type: ignore # mutmut generated
mutants_x_replace_body__mutmut['x_replace_body__mutmut_10'] = x_replace_body__mutmut_10 # type: ignore # mutmut generated
mutants_x_replace_body__mutmut['x_replace_body__mutmut_11'] = x_replace_body__mutmut_11 # type: ignore # mutmut generated
mutants_x_replace_body__mutmut['x_replace_body__mutmut_12'] = x_replace_body__mutmut_12 # type: ignore # mutmut generated
mutants_x_replace_body__mutmut['x_replace_body__mutmut_13'] = x_replace_body__mutmut_13 # type: ignore # mutmut generated
mutants_x_replace_body__mutmut['x_replace_body__mutmut_14'] = x_replace_body__mutmut_14 # type: ignore # mutmut generated
mutants_x_replace_body__mutmut['x_replace_body__mutmut_15'] = x_replace_body__mutmut_15 # type: ignore # mutmut generated
mutants_x_replace_body__mutmut['x_replace_body__mutmut_16'] = x_replace_body__mutmut_16 # type: ignore # mutmut generated
mutants_x_replace_body__mutmut['x_replace_body__mutmut_17'] = x_replace_body__mutmut_17 # type: ignore # mutmut generated
mutants_x_replace_body__mutmut['x_replace_body__mutmut_18'] = x_replace_body__mutmut_18 # type: ignore # mutmut generated
mutants_x_replace_body__mutmut['x_replace_body__mutmut_19'] = x_replace_body__mutmut_19 # type: ignore # mutmut generated
mutants_x_replace_body__mutmut['x_replace_body__mutmut_20'] = x_replace_body__mutmut_20 # type: ignore # mutmut generated
mutants_x_replace_body__mutmut['x_replace_body__mutmut_21'] = x_replace_body__mutmut_21 # type: ignore # mutmut generated
mutants_x_replace_body__mutmut['x_replace_body__mutmut_22'] = x_replace_body__mutmut_22 # type: ignore # mutmut generated
mutants_x_main__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_main__mutmut)
def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tex", type=Path, default=ROOT / "paper" / "main.tex")
    parser.add_argument("--evidence", type=Path, default=EVIDENCE)
    parser.add_argument("--print", action="store_true", help="print the rows instead of writing")
    args = parser.parse_args(argv)
    tex = args.tex.read_text()
    for label in TABLES:
        body = rows(label, args.evidence)
        if args.print:
            print(f"== {label}\n{body}")
        else:
            tex = replace_body(tex, label, body)
    if not args.print:
        args.tex.write_text(tex)
    return 0


def x_main__mutmut_orig(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tex", type=Path, default=ROOT / "paper" / "main.tex")
    parser.add_argument("--evidence", type=Path, default=EVIDENCE)
    parser.add_argument("--print", action="store_true", help="print the rows instead of writing")
    args = parser.parse_args(argv)
    tex = args.tex.read_text()
    for label in TABLES:
        body = rows(label, args.evidence)
        if args.print:
            print(f"== {label}\n{body}")
        else:
            tex = replace_body(tex, label, body)
    if not args.print:
        args.tex.write_text(tex)
    return 0


def x_main__mutmut_1(argv: list[str] | None = None) -> int:
    parser = None
    parser.add_argument("--tex", type=Path, default=ROOT / "paper" / "main.tex")
    parser.add_argument("--evidence", type=Path, default=EVIDENCE)
    parser.add_argument("--print", action="store_true", help="print the rows instead of writing")
    args = parser.parse_args(argv)
    tex = args.tex.read_text()
    for label in TABLES:
        body = rows(label, args.evidence)
        if args.print:
            print(f"== {label}\n{body}")
        else:
            tex = replace_body(tex, label, body)
    if not args.print:
        args.tex.write_text(tex)
    return 0


def x_main__mutmut_2(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=None)
    parser.add_argument("--tex", type=Path, default=ROOT / "paper" / "main.tex")
    parser.add_argument("--evidence", type=Path, default=EVIDENCE)
    parser.add_argument("--print", action="store_true", help="print the rows instead of writing")
    args = parser.parse_args(argv)
    tex = args.tex.read_text()
    for label in TABLES:
        body = rows(label, args.evidence)
        if args.print:
            print(f"== {label}\n{body}")
        else:
            tex = replace_body(tex, label, body)
    if not args.print:
        args.tex.write_text(tex)
    return 0


def x_main__mutmut_3(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(None, type=Path, default=ROOT / "paper" / "main.tex")
    parser.add_argument("--evidence", type=Path, default=EVIDENCE)
    parser.add_argument("--print", action="store_true", help="print the rows instead of writing")
    args = parser.parse_args(argv)
    tex = args.tex.read_text()
    for label in TABLES:
        body = rows(label, args.evidence)
        if args.print:
            print(f"== {label}\n{body}")
        else:
            tex = replace_body(tex, label, body)
    if not args.print:
        args.tex.write_text(tex)
    return 0


def x_main__mutmut_4(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tex", type=None, default=ROOT / "paper" / "main.tex")
    parser.add_argument("--evidence", type=Path, default=EVIDENCE)
    parser.add_argument("--print", action="store_true", help="print the rows instead of writing")
    args = parser.parse_args(argv)
    tex = args.tex.read_text()
    for label in TABLES:
        body = rows(label, args.evidence)
        if args.print:
            print(f"== {label}\n{body}")
        else:
            tex = replace_body(tex, label, body)
    if not args.print:
        args.tex.write_text(tex)
    return 0


def x_main__mutmut_5(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tex", type=Path, default=None)
    parser.add_argument("--evidence", type=Path, default=EVIDENCE)
    parser.add_argument("--print", action="store_true", help="print the rows instead of writing")
    args = parser.parse_args(argv)
    tex = args.tex.read_text()
    for label in TABLES:
        body = rows(label, args.evidence)
        if args.print:
            print(f"== {label}\n{body}")
        else:
            tex = replace_body(tex, label, body)
    if not args.print:
        args.tex.write_text(tex)
    return 0


def x_main__mutmut_6(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(type=Path, default=ROOT / "paper" / "main.tex")
    parser.add_argument("--evidence", type=Path, default=EVIDENCE)
    parser.add_argument("--print", action="store_true", help="print the rows instead of writing")
    args = parser.parse_args(argv)
    tex = args.tex.read_text()
    for label in TABLES:
        body = rows(label, args.evidence)
        if args.print:
            print(f"== {label}\n{body}")
        else:
            tex = replace_body(tex, label, body)
    if not args.print:
        args.tex.write_text(tex)
    return 0


def x_main__mutmut_7(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tex", default=ROOT / "paper" / "main.tex")
    parser.add_argument("--evidence", type=Path, default=EVIDENCE)
    parser.add_argument("--print", action="store_true", help="print the rows instead of writing")
    args = parser.parse_args(argv)
    tex = args.tex.read_text()
    for label in TABLES:
        body = rows(label, args.evidence)
        if args.print:
            print(f"== {label}\n{body}")
        else:
            tex = replace_body(tex, label, body)
    if not args.print:
        args.tex.write_text(tex)
    return 0


def x_main__mutmut_8(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tex", type=Path, )
    parser.add_argument("--evidence", type=Path, default=EVIDENCE)
    parser.add_argument("--print", action="store_true", help="print the rows instead of writing")
    args = parser.parse_args(argv)
    tex = args.tex.read_text()
    for label in TABLES:
        body = rows(label, args.evidence)
        if args.print:
            print(f"== {label}\n{body}")
        else:
            tex = replace_body(tex, label, body)
    if not args.print:
        args.tex.write_text(tex)
    return 0


def x_main__mutmut_9(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("XX--texXX", type=Path, default=ROOT / "paper" / "main.tex")
    parser.add_argument("--evidence", type=Path, default=EVIDENCE)
    parser.add_argument("--print", action="store_true", help="print the rows instead of writing")
    args = parser.parse_args(argv)
    tex = args.tex.read_text()
    for label in TABLES:
        body = rows(label, args.evidence)
        if args.print:
            print(f"== {label}\n{body}")
        else:
            tex = replace_body(tex, label, body)
    if not args.print:
        args.tex.write_text(tex)
    return 0


def x_main__mutmut_10(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--TEX", type=Path, default=ROOT / "paper" / "main.tex")
    parser.add_argument("--evidence", type=Path, default=EVIDENCE)
    parser.add_argument("--print", action="store_true", help="print the rows instead of writing")
    args = parser.parse_args(argv)
    tex = args.tex.read_text()
    for label in TABLES:
        body = rows(label, args.evidence)
        if args.print:
            print(f"== {label}\n{body}")
        else:
            tex = replace_body(tex, label, body)
    if not args.print:
        args.tex.write_text(tex)
    return 0


def x_main__mutmut_11(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tex", type=Path, default=ROOT / "paper" * "main.tex")
    parser.add_argument("--evidence", type=Path, default=EVIDENCE)
    parser.add_argument("--print", action="store_true", help="print the rows instead of writing")
    args = parser.parse_args(argv)
    tex = args.tex.read_text()
    for label in TABLES:
        body = rows(label, args.evidence)
        if args.print:
            print(f"== {label}\n{body}")
        else:
            tex = replace_body(tex, label, body)
    if not args.print:
        args.tex.write_text(tex)
    return 0


def x_main__mutmut_12(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tex", type=Path, default=ROOT * "paper" / "main.tex")
    parser.add_argument("--evidence", type=Path, default=EVIDENCE)
    parser.add_argument("--print", action="store_true", help="print the rows instead of writing")
    args = parser.parse_args(argv)
    tex = args.tex.read_text()
    for label in TABLES:
        body = rows(label, args.evidence)
        if args.print:
            print(f"== {label}\n{body}")
        else:
            tex = replace_body(tex, label, body)
    if not args.print:
        args.tex.write_text(tex)
    return 0


def x_main__mutmut_13(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tex", type=Path, default=ROOT / "XXpaperXX" / "main.tex")
    parser.add_argument("--evidence", type=Path, default=EVIDENCE)
    parser.add_argument("--print", action="store_true", help="print the rows instead of writing")
    args = parser.parse_args(argv)
    tex = args.tex.read_text()
    for label in TABLES:
        body = rows(label, args.evidence)
        if args.print:
            print(f"== {label}\n{body}")
        else:
            tex = replace_body(tex, label, body)
    if not args.print:
        args.tex.write_text(tex)
    return 0


def x_main__mutmut_14(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tex", type=Path, default=ROOT / "PAPER" / "main.tex")
    parser.add_argument("--evidence", type=Path, default=EVIDENCE)
    parser.add_argument("--print", action="store_true", help="print the rows instead of writing")
    args = parser.parse_args(argv)
    tex = args.tex.read_text()
    for label in TABLES:
        body = rows(label, args.evidence)
        if args.print:
            print(f"== {label}\n{body}")
        else:
            tex = replace_body(tex, label, body)
    if not args.print:
        args.tex.write_text(tex)
    return 0


def x_main__mutmut_15(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tex", type=Path, default=ROOT / "paper" / "XXmain.texXX")
    parser.add_argument("--evidence", type=Path, default=EVIDENCE)
    parser.add_argument("--print", action="store_true", help="print the rows instead of writing")
    args = parser.parse_args(argv)
    tex = args.tex.read_text()
    for label in TABLES:
        body = rows(label, args.evidence)
        if args.print:
            print(f"== {label}\n{body}")
        else:
            tex = replace_body(tex, label, body)
    if not args.print:
        args.tex.write_text(tex)
    return 0


def x_main__mutmut_16(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tex", type=Path, default=ROOT / "paper" / "MAIN.TEX")
    parser.add_argument("--evidence", type=Path, default=EVIDENCE)
    parser.add_argument("--print", action="store_true", help="print the rows instead of writing")
    args = parser.parse_args(argv)
    tex = args.tex.read_text()
    for label in TABLES:
        body = rows(label, args.evidence)
        if args.print:
            print(f"== {label}\n{body}")
        else:
            tex = replace_body(tex, label, body)
    if not args.print:
        args.tex.write_text(tex)
    return 0


def x_main__mutmut_17(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tex", type=Path, default=ROOT / "paper" / "main.tex")
    parser.add_argument(None, type=Path, default=EVIDENCE)
    parser.add_argument("--print", action="store_true", help="print the rows instead of writing")
    args = parser.parse_args(argv)
    tex = args.tex.read_text()
    for label in TABLES:
        body = rows(label, args.evidence)
        if args.print:
            print(f"== {label}\n{body}")
        else:
            tex = replace_body(tex, label, body)
    if not args.print:
        args.tex.write_text(tex)
    return 0


def x_main__mutmut_18(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tex", type=Path, default=ROOT / "paper" / "main.tex")
    parser.add_argument("--evidence", type=None, default=EVIDENCE)
    parser.add_argument("--print", action="store_true", help="print the rows instead of writing")
    args = parser.parse_args(argv)
    tex = args.tex.read_text()
    for label in TABLES:
        body = rows(label, args.evidence)
        if args.print:
            print(f"== {label}\n{body}")
        else:
            tex = replace_body(tex, label, body)
    if not args.print:
        args.tex.write_text(tex)
    return 0


def x_main__mutmut_19(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tex", type=Path, default=ROOT / "paper" / "main.tex")
    parser.add_argument("--evidence", type=Path, default=None)
    parser.add_argument("--print", action="store_true", help="print the rows instead of writing")
    args = parser.parse_args(argv)
    tex = args.tex.read_text()
    for label in TABLES:
        body = rows(label, args.evidence)
        if args.print:
            print(f"== {label}\n{body}")
        else:
            tex = replace_body(tex, label, body)
    if not args.print:
        args.tex.write_text(tex)
    return 0


def x_main__mutmut_20(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tex", type=Path, default=ROOT / "paper" / "main.tex")
    parser.add_argument(type=Path, default=EVIDENCE)
    parser.add_argument("--print", action="store_true", help="print the rows instead of writing")
    args = parser.parse_args(argv)
    tex = args.tex.read_text()
    for label in TABLES:
        body = rows(label, args.evidence)
        if args.print:
            print(f"== {label}\n{body}")
        else:
            tex = replace_body(tex, label, body)
    if not args.print:
        args.tex.write_text(tex)
    return 0


def x_main__mutmut_21(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tex", type=Path, default=ROOT / "paper" / "main.tex")
    parser.add_argument("--evidence", default=EVIDENCE)
    parser.add_argument("--print", action="store_true", help="print the rows instead of writing")
    args = parser.parse_args(argv)
    tex = args.tex.read_text()
    for label in TABLES:
        body = rows(label, args.evidence)
        if args.print:
            print(f"== {label}\n{body}")
        else:
            tex = replace_body(tex, label, body)
    if not args.print:
        args.tex.write_text(tex)
    return 0


def x_main__mutmut_22(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tex", type=Path, default=ROOT / "paper" / "main.tex")
    parser.add_argument("--evidence", type=Path, )
    parser.add_argument("--print", action="store_true", help="print the rows instead of writing")
    args = parser.parse_args(argv)
    tex = args.tex.read_text()
    for label in TABLES:
        body = rows(label, args.evidence)
        if args.print:
            print(f"== {label}\n{body}")
        else:
            tex = replace_body(tex, label, body)
    if not args.print:
        args.tex.write_text(tex)
    return 0


def x_main__mutmut_23(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tex", type=Path, default=ROOT / "paper" / "main.tex")
    parser.add_argument("XX--evidenceXX", type=Path, default=EVIDENCE)
    parser.add_argument("--print", action="store_true", help="print the rows instead of writing")
    args = parser.parse_args(argv)
    tex = args.tex.read_text()
    for label in TABLES:
        body = rows(label, args.evidence)
        if args.print:
            print(f"== {label}\n{body}")
        else:
            tex = replace_body(tex, label, body)
    if not args.print:
        args.tex.write_text(tex)
    return 0


def x_main__mutmut_24(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tex", type=Path, default=ROOT / "paper" / "main.tex")
    parser.add_argument("--EVIDENCE", type=Path, default=EVIDENCE)
    parser.add_argument("--print", action="store_true", help="print the rows instead of writing")
    args = parser.parse_args(argv)
    tex = args.tex.read_text()
    for label in TABLES:
        body = rows(label, args.evidence)
        if args.print:
            print(f"== {label}\n{body}")
        else:
            tex = replace_body(tex, label, body)
    if not args.print:
        args.tex.write_text(tex)
    return 0


def x_main__mutmut_25(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tex", type=Path, default=ROOT / "paper" / "main.tex")
    parser.add_argument("--evidence", type=Path, default=EVIDENCE)
    parser.add_argument(None, action="store_true", help="print the rows instead of writing")
    args = parser.parse_args(argv)
    tex = args.tex.read_text()
    for label in TABLES:
        body = rows(label, args.evidence)
        if args.print:
            print(f"== {label}\n{body}")
        else:
            tex = replace_body(tex, label, body)
    if not args.print:
        args.tex.write_text(tex)
    return 0


def x_main__mutmut_26(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tex", type=Path, default=ROOT / "paper" / "main.tex")
    parser.add_argument("--evidence", type=Path, default=EVIDENCE)
    parser.add_argument("--print", action=None, help="print the rows instead of writing")
    args = parser.parse_args(argv)
    tex = args.tex.read_text()
    for label in TABLES:
        body = rows(label, args.evidence)
        if args.print:
            print(f"== {label}\n{body}")
        else:
            tex = replace_body(tex, label, body)
    if not args.print:
        args.tex.write_text(tex)
    return 0


def x_main__mutmut_27(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tex", type=Path, default=ROOT / "paper" / "main.tex")
    parser.add_argument("--evidence", type=Path, default=EVIDENCE)
    parser.add_argument("--print", action="store_true", help=None)
    args = parser.parse_args(argv)
    tex = args.tex.read_text()
    for label in TABLES:
        body = rows(label, args.evidence)
        if args.print:
            print(f"== {label}\n{body}")
        else:
            tex = replace_body(tex, label, body)
    if not args.print:
        args.tex.write_text(tex)
    return 0


def x_main__mutmut_28(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tex", type=Path, default=ROOT / "paper" / "main.tex")
    parser.add_argument("--evidence", type=Path, default=EVIDENCE)
    parser.add_argument(action="store_true", help="print the rows instead of writing")
    args = parser.parse_args(argv)
    tex = args.tex.read_text()
    for label in TABLES:
        body = rows(label, args.evidence)
        if args.print:
            print(f"== {label}\n{body}")
        else:
            tex = replace_body(tex, label, body)
    if not args.print:
        args.tex.write_text(tex)
    return 0


def x_main__mutmut_29(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tex", type=Path, default=ROOT / "paper" / "main.tex")
    parser.add_argument("--evidence", type=Path, default=EVIDENCE)
    parser.add_argument("--print", help="print the rows instead of writing")
    args = parser.parse_args(argv)
    tex = args.tex.read_text()
    for label in TABLES:
        body = rows(label, args.evidence)
        if args.print:
            print(f"== {label}\n{body}")
        else:
            tex = replace_body(tex, label, body)
    if not args.print:
        args.tex.write_text(tex)
    return 0


def x_main__mutmut_30(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tex", type=Path, default=ROOT / "paper" / "main.tex")
    parser.add_argument("--evidence", type=Path, default=EVIDENCE)
    parser.add_argument("--print", action="store_true", )
    args = parser.parse_args(argv)
    tex = args.tex.read_text()
    for label in TABLES:
        body = rows(label, args.evidence)
        if args.print:
            print(f"== {label}\n{body}")
        else:
            tex = replace_body(tex, label, body)
    if not args.print:
        args.tex.write_text(tex)
    return 0


def x_main__mutmut_31(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tex", type=Path, default=ROOT / "paper" / "main.tex")
    parser.add_argument("--evidence", type=Path, default=EVIDENCE)
    parser.add_argument("XX--printXX", action="store_true", help="print the rows instead of writing")
    args = parser.parse_args(argv)
    tex = args.tex.read_text()
    for label in TABLES:
        body = rows(label, args.evidence)
        if args.print:
            print(f"== {label}\n{body}")
        else:
            tex = replace_body(tex, label, body)
    if not args.print:
        args.tex.write_text(tex)
    return 0


def x_main__mutmut_32(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tex", type=Path, default=ROOT / "paper" / "main.tex")
    parser.add_argument("--evidence", type=Path, default=EVIDENCE)
    parser.add_argument("--PRINT", action="store_true", help="print the rows instead of writing")
    args = parser.parse_args(argv)
    tex = args.tex.read_text()
    for label in TABLES:
        body = rows(label, args.evidence)
        if args.print:
            print(f"== {label}\n{body}")
        else:
            tex = replace_body(tex, label, body)
    if not args.print:
        args.tex.write_text(tex)
    return 0


def x_main__mutmut_33(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tex", type=Path, default=ROOT / "paper" / "main.tex")
    parser.add_argument("--evidence", type=Path, default=EVIDENCE)
    parser.add_argument("--print", action="XXstore_trueXX", help="print the rows instead of writing")
    args = parser.parse_args(argv)
    tex = args.tex.read_text()
    for label in TABLES:
        body = rows(label, args.evidence)
        if args.print:
            print(f"== {label}\n{body}")
        else:
            tex = replace_body(tex, label, body)
    if not args.print:
        args.tex.write_text(tex)
    return 0


def x_main__mutmut_34(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tex", type=Path, default=ROOT / "paper" / "main.tex")
    parser.add_argument("--evidence", type=Path, default=EVIDENCE)
    parser.add_argument("--print", action="STORE_TRUE", help="print the rows instead of writing")
    args = parser.parse_args(argv)
    tex = args.tex.read_text()
    for label in TABLES:
        body = rows(label, args.evidence)
        if args.print:
            print(f"== {label}\n{body}")
        else:
            tex = replace_body(tex, label, body)
    if not args.print:
        args.tex.write_text(tex)
    return 0


def x_main__mutmut_35(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tex", type=Path, default=ROOT / "paper" / "main.tex")
    parser.add_argument("--evidence", type=Path, default=EVIDENCE)
    parser.add_argument("--print", action="store_true", help="XXprint the rows instead of writingXX")
    args = parser.parse_args(argv)
    tex = args.tex.read_text()
    for label in TABLES:
        body = rows(label, args.evidence)
        if args.print:
            print(f"== {label}\n{body}")
        else:
            tex = replace_body(tex, label, body)
    if not args.print:
        args.tex.write_text(tex)
    return 0


def x_main__mutmut_36(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tex", type=Path, default=ROOT / "paper" / "main.tex")
    parser.add_argument("--evidence", type=Path, default=EVIDENCE)
    parser.add_argument("--print", action="store_true", help="PRINT THE ROWS INSTEAD OF WRITING")
    args = parser.parse_args(argv)
    tex = args.tex.read_text()
    for label in TABLES:
        body = rows(label, args.evidence)
        if args.print:
            print(f"== {label}\n{body}")
        else:
            tex = replace_body(tex, label, body)
    if not args.print:
        args.tex.write_text(tex)
    return 0


def x_main__mutmut_37(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tex", type=Path, default=ROOT / "paper" / "main.tex")
    parser.add_argument("--evidence", type=Path, default=EVIDENCE)
    parser.add_argument("--print", action="store_true", help="print the rows instead of writing")
    args = None
    tex = args.tex.read_text()
    for label in TABLES:
        body = rows(label, args.evidence)
        if args.print:
            print(f"== {label}\n{body}")
        else:
            tex = replace_body(tex, label, body)
    if not args.print:
        args.tex.write_text(tex)
    return 0


def x_main__mutmut_38(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tex", type=Path, default=ROOT / "paper" / "main.tex")
    parser.add_argument("--evidence", type=Path, default=EVIDENCE)
    parser.add_argument("--print", action="store_true", help="print the rows instead of writing")
    args = parser.parse_args(None)
    tex = args.tex.read_text()
    for label in TABLES:
        body = rows(label, args.evidence)
        if args.print:
            print(f"== {label}\n{body}")
        else:
            tex = replace_body(tex, label, body)
    if not args.print:
        args.tex.write_text(tex)
    return 0


def x_main__mutmut_39(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tex", type=Path, default=ROOT / "paper" / "main.tex")
    parser.add_argument("--evidence", type=Path, default=EVIDENCE)
    parser.add_argument("--print", action="store_true", help="print the rows instead of writing")
    args = parser.parse_args(argv)
    tex = None
    for label in TABLES:
        body = rows(label, args.evidence)
        if args.print:
            print(f"== {label}\n{body}")
        else:
            tex = replace_body(tex, label, body)
    if not args.print:
        args.tex.write_text(tex)
    return 0


def x_main__mutmut_40(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tex", type=Path, default=ROOT / "paper" / "main.tex")
    parser.add_argument("--evidence", type=Path, default=EVIDENCE)
    parser.add_argument("--print", action="store_true", help="print the rows instead of writing")
    args = parser.parse_args(argv)
    tex = args.tex.read_text()
    for label in TABLES:
        body = None
        if args.print:
            print(f"== {label}\n{body}")
        else:
            tex = replace_body(tex, label, body)
    if not args.print:
        args.tex.write_text(tex)
    return 0


def x_main__mutmut_41(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tex", type=Path, default=ROOT / "paper" / "main.tex")
    parser.add_argument("--evidence", type=Path, default=EVIDENCE)
    parser.add_argument("--print", action="store_true", help="print the rows instead of writing")
    args = parser.parse_args(argv)
    tex = args.tex.read_text()
    for label in TABLES:
        body = rows(None, args.evidence)
        if args.print:
            print(f"== {label}\n{body}")
        else:
            tex = replace_body(tex, label, body)
    if not args.print:
        args.tex.write_text(tex)
    return 0


def x_main__mutmut_42(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tex", type=Path, default=ROOT / "paper" / "main.tex")
    parser.add_argument("--evidence", type=Path, default=EVIDENCE)
    parser.add_argument("--print", action="store_true", help="print the rows instead of writing")
    args = parser.parse_args(argv)
    tex = args.tex.read_text()
    for label in TABLES:
        body = rows(label, None)
        if args.print:
            print(f"== {label}\n{body}")
        else:
            tex = replace_body(tex, label, body)
    if not args.print:
        args.tex.write_text(tex)
    return 0


def x_main__mutmut_43(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tex", type=Path, default=ROOT / "paper" / "main.tex")
    parser.add_argument("--evidence", type=Path, default=EVIDENCE)
    parser.add_argument("--print", action="store_true", help="print the rows instead of writing")
    args = parser.parse_args(argv)
    tex = args.tex.read_text()
    for label in TABLES:
        body = rows(args.evidence)
        if args.print:
            print(f"== {label}\n{body}")
        else:
            tex = replace_body(tex, label, body)
    if not args.print:
        args.tex.write_text(tex)
    return 0


def x_main__mutmut_44(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tex", type=Path, default=ROOT / "paper" / "main.tex")
    parser.add_argument("--evidence", type=Path, default=EVIDENCE)
    parser.add_argument("--print", action="store_true", help="print the rows instead of writing")
    args = parser.parse_args(argv)
    tex = args.tex.read_text()
    for label in TABLES:
        body = rows(label, )
        if args.print:
            print(f"== {label}\n{body}")
        else:
            tex = replace_body(tex, label, body)
    if not args.print:
        args.tex.write_text(tex)
    return 0


def x_main__mutmut_45(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tex", type=Path, default=ROOT / "paper" / "main.tex")
    parser.add_argument("--evidence", type=Path, default=EVIDENCE)
    parser.add_argument("--print", action="store_true", help="print the rows instead of writing")
    args = parser.parse_args(argv)
    tex = args.tex.read_text()
    for label in TABLES:
        body = rows(label, args.evidence)
        if args.print:
            print(None)
        else:
            tex = replace_body(tex, label, body)
    if not args.print:
        args.tex.write_text(tex)
    return 0


def x_main__mutmut_46(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tex", type=Path, default=ROOT / "paper" / "main.tex")
    parser.add_argument("--evidence", type=Path, default=EVIDENCE)
    parser.add_argument("--print", action="store_true", help="print the rows instead of writing")
    args = parser.parse_args(argv)
    tex = args.tex.read_text()
    for label in TABLES:
        body = rows(label, args.evidence)
        if args.print:
            print(f"== {label}\n{body}")
        else:
            tex = None
    if not args.print:
        args.tex.write_text(tex)
    return 0


def x_main__mutmut_47(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tex", type=Path, default=ROOT / "paper" / "main.tex")
    parser.add_argument("--evidence", type=Path, default=EVIDENCE)
    parser.add_argument("--print", action="store_true", help="print the rows instead of writing")
    args = parser.parse_args(argv)
    tex = args.tex.read_text()
    for label in TABLES:
        body = rows(label, args.evidence)
        if args.print:
            print(f"== {label}\n{body}")
        else:
            tex = replace_body(None, label, body)
    if not args.print:
        args.tex.write_text(tex)
    return 0


def x_main__mutmut_48(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tex", type=Path, default=ROOT / "paper" / "main.tex")
    parser.add_argument("--evidence", type=Path, default=EVIDENCE)
    parser.add_argument("--print", action="store_true", help="print the rows instead of writing")
    args = parser.parse_args(argv)
    tex = args.tex.read_text()
    for label in TABLES:
        body = rows(label, args.evidence)
        if args.print:
            print(f"== {label}\n{body}")
        else:
            tex = replace_body(tex, None, body)
    if not args.print:
        args.tex.write_text(tex)
    return 0


def x_main__mutmut_49(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tex", type=Path, default=ROOT / "paper" / "main.tex")
    parser.add_argument("--evidence", type=Path, default=EVIDENCE)
    parser.add_argument("--print", action="store_true", help="print the rows instead of writing")
    args = parser.parse_args(argv)
    tex = args.tex.read_text()
    for label in TABLES:
        body = rows(label, args.evidence)
        if args.print:
            print(f"== {label}\n{body}")
        else:
            tex = replace_body(tex, label, None)
    if not args.print:
        args.tex.write_text(tex)
    return 0


def x_main__mutmut_50(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tex", type=Path, default=ROOT / "paper" / "main.tex")
    parser.add_argument("--evidence", type=Path, default=EVIDENCE)
    parser.add_argument("--print", action="store_true", help="print the rows instead of writing")
    args = parser.parse_args(argv)
    tex = args.tex.read_text()
    for label in TABLES:
        body = rows(label, args.evidence)
        if args.print:
            print(f"== {label}\n{body}")
        else:
            tex = replace_body(label, body)
    if not args.print:
        args.tex.write_text(tex)
    return 0


def x_main__mutmut_51(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tex", type=Path, default=ROOT / "paper" / "main.tex")
    parser.add_argument("--evidence", type=Path, default=EVIDENCE)
    parser.add_argument("--print", action="store_true", help="print the rows instead of writing")
    args = parser.parse_args(argv)
    tex = args.tex.read_text()
    for label in TABLES:
        body = rows(label, args.evidence)
        if args.print:
            print(f"== {label}\n{body}")
        else:
            tex = replace_body(tex, body)
    if not args.print:
        args.tex.write_text(tex)
    return 0


def x_main__mutmut_52(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tex", type=Path, default=ROOT / "paper" / "main.tex")
    parser.add_argument("--evidence", type=Path, default=EVIDENCE)
    parser.add_argument("--print", action="store_true", help="print the rows instead of writing")
    args = parser.parse_args(argv)
    tex = args.tex.read_text()
    for label in TABLES:
        body = rows(label, args.evidence)
        if args.print:
            print(f"== {label}\n{body}")
        else:
            tex = replace_body(tex, label, )
    if not args.print:
        args.tex.write_text(tex)
    return 0


def x_main__mutmut_53(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tex", type=Path, default=ROOT / "paper" / "main.tex")
    parser.add_argument("--evidence", type=Path, default=EVIDENCE)
    parser.add_argument("--print", action="store_true", help="print the rows instead of writing")
    args = parser.parse_args(argv)
    tex = args.tex.read_text()
    for label in TABLES:
        body = rows(label, args.evidence)
        if args.print:
            print(f"== {label}\n{body}")
        else:
            tex = replace_body(tex, label, body)
    if args.print:
        args.tex.write_text(tex)
    return 0


def x_main__mutmut_54(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tex", type=Path, default=ROOT / "paper" / "main.tex")
    parser.add_argument("--evidence", type=Path, default=EVIDENCE)
    parser.add_argument("--print", action="store_true", help="print the rows instead of writing")
    args = parser.parse_args(argv)
    tex = args.tex.read_text()
    for label in TABLES:
        body = rows(label, args.evidence)
        if args.print:
            print(f"== {label}\n{body}")
        else:
            tex = replace_body(tex, label, body)
    if not args.print:
        args.tex.write_text(None)
    return 0


def x_main__mutmut_55(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tex", type=Path, default=ROOT / "paper" / "main.tex")
    parser.add_argument("--evidence", type=Path, default=EVIDENCE)
    parser.add_argument("--print", action="store_true", help="print the rows instead of writing")
    args = parser.parse_args(argv)
    tex = args.tex.read_text()
    for label in TABLES:
        body = rows(label, args.evidence)
        if args.print:
            print(f"== {label}\n{body}")
        else:
            tex = replace_body(tex, label, body)
    if not args.print:
        args.tex.write_text(tex)
    return 1

mutants_x_main__mutmut['_mutmut_orig'] = x_main__mutmut_orig # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_1'] = x_main__mutmut_1 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_2'] = x_main__mutmut_2 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_3'] = x_main__mutmut_3 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_4'] = x_main__mutmut_4 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_5'] = x_main__mutmut_5 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_6'] = x_main__mutmut_6 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_7'] = x_main__mutmut_7 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_8'] = x_main__mutmut_8 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_9'] = x_main__mutmut_9 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_10'] = x_main__mutmut_10 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_11'] = x_main__mutmut_11 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_12'] = x_main__mutmut_12 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_13'] = x_main__mutmut_13 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_14'] = x_main__mutmut_14 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_15'] = x_main__mutmut_15 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_16'] = x_main__mutmut_16 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_17'] = x_main__mutmut_17 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_18'] = x_main__mutmut_18 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_19'] = x_main__mutmut_19 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_20'] = x_main__mutmut_20 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_21'] = x_main__mutmut_21 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_22'] = x_main__mutmut_22 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_23'] = x_main__mutmut_23 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_24'] = x_main__mutmut_24 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_25'] = x_main__mutmut_25 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_26'] = x_main__mutmut_26 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_27'] = x_main__mutmut_27 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_28'] = x_main__mutmut_28 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_29'] = x_main__mutmut_29 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_30'] = x_main__mutmut_30 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_31'] = x_main__mutmut_31 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_32'] = x_main__mutmut_32 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_33'] = x_main__mutmut_33 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_34'] = x_main__mutmut_34 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_35'] = x_main__mutmut_35 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_36'] = x_main__mutmut_36 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_37'] = x_main__mutmut_37 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_38'] = x_main__mutmut_38 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_39'] = x_main__mutmut_39 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_40'] = x_main__mutmut_40 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_41'] = x_main__mutmut_41 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_42'] = x_main__mutmut_42 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_43'] = x_main__mutmut_43 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_44'] = x_main__mutmut_44 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_45'] = x_main__mutmut_45 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_46'] = x_main__mutmut_46 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_47'] = x_main__mutmut_47 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_48'] = x_main__mutmut_48 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_49'] = x_main__mutmut_49 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_50'] = x_main__mutmut_50 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_51'] = x_main__mutmut_51 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_52'] = x_main__mutmut_52 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_53'] = x_main__mutmut_53 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_54'] = x_main__mutmut_54 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_55'] = x_main__mutmut_55 # type: ignore # mutmut generated


if __name__ == "__main__":
    raise SystemExit(main())
