"""Paired bootstrap, by blocks of time, of the average-precision difference of two scorers."""

from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score

ORIGIN = pd.Timestamp("1970-01-01", tz="UTC")


from mutmut.mutation.trampoline import wrap_in_trampoline as _mutmut_mutated, MutantDict
mutants_x_paired_block_bootstrap__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_paired_block_bootstrap__mutmut)
def paired_block_bootstrap(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_orig(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_1(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = None
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_2(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(None)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_3(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = None
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_4(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(None, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_5(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=None), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_6(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_7(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, ), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_8(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(None, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_9(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=None)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_10(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_11(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, )
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_12(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_13(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) != len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_14(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) != len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_15(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) != len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_16(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError(None)
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_17(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("XXlabels, scores and times must have equal lengthXX")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_18(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("LABELS, SCORES AND TIMES MUST HAVE EQUAL LENGTH")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_19(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() != y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_20(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError(None)
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_21(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("XXboth classes are requiredXX")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_22(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("BOTH CLASSES ARE REQUIRED")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_23(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = None
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_24(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) + ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_25(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(None, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_26(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=None) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_27(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_28(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, ) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_29(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=False) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_30(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = None
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_31(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(None).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_32(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds / block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_33(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = None
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_34(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(None) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_35(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks != k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_36(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(None)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_37(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = None
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_38(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(None)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_39(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = None
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_40(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(None)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_41(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = None
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_42(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(None):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_43(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = None
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_44(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate(None)
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_45(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(None, len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_46(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), None)])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_47(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_48(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), )])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_49(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() == y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_50(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                None
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_51(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index]) + average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_52(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(None, a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_53(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], None)
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_54(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_55(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], )
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_56(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(None, b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_57(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], None)
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_58(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_59(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], )
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_60(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = None
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_61(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(None, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_62(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, None)
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_63(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile([2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_64(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, )
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_65(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [3.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_66(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 98.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_67(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "XXap_aXX": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_68(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "AP_A": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_69(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(None),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_70(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(None, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_71(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, None)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_72(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_73(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, )),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_74(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "XXap_bXX": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_75(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "AP_B": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_76(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(None),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_77(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(None, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_78(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, None)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_79(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_80(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, )),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_81(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "XXdifferenceXX": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_82(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "DIFFERENCE": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_83(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(None),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_84(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) + average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_85(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(None, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_86(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, None) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_87(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_88(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, ) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_89(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(None, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_90(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, None)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_91(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_92(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, )),
        "ci_low": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_93(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "XXci_lowXX": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_94(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "CI_LOW": float(low),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_95(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(None),
        "ci_high": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_96(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "XXci_highXX": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_97(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "CI_HIGH": float(high),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_98(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(None),
        "resamples_used": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_99(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "XXresamples_usedXX": len(gaps),
    }


def x_paired_block_bootstrap__mutmut_100(y, scores_a, scores_b, times, block_seconds, resamples, seed):
    """Difference ``AP(a) - AP(b)`` with a 95 % percentile interval; blocks shared by a and b."""
    y = np.asarray(y)
    a, b = np.asarray(scores_a, dtype=float), np.asarray(scores_b, dtype=float)
    if not len(y) == len(a) == len(b) == len(times):
        raise ValueError("labels, scores and times must have equal length")
    if y.min() == y.max():
        raise ValueError("both classes are required")
    seconds = (pd.to_datetime(times, utc=True) - ORIGIN).dt.total_seconds()
    blocks = (seconds // block_seconds).astype(int).to_numpy()
    members = {k: np.flatnonzero(blocks == k) for k in np.unique(blocks)}
    keys = list(members)
    rng = np.random.default_rng(seed)
    gaps = []
    for _ in range(resamples):
        index = np.concatenate([members[keys[k]] for k in rng.choice(len(keys), len(keys))])
        if y[index].min() != y[index].max():
            gaps.append(
                average_precision_score(y[index], a[index])
                - average_precision_score(y[index], b[index])
            )
    low, high = np.percentile(gaps, [2.5, 97.5])
    return {
        "ap_a": float(average_precision_score(y, a)),
        "ap_b": float(average_precision_score(y, b)),
        "difference": float(average_precision_score(y, a) - average_precision_score(y, b)),
        "ci_low": float(low),
        "ci_high": float(high),
        "RESAMPLES_USED": len(gaps),
    }

mutants_x_paired_block_bootstrap__mutmut['_mutmut_orig'] = x_paired_block_bootstrap__mutmut_orig # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_1'] = x_paired_block_bootstrap__mutmut_1 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_2'] = x_paired_block_bootstrap__mutmut_2 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_3'] = x_paired_block_bootstrap__mutmut_3 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_4'] = x_paired_block_bootstrap__mutmut_4 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_5'] = x_paired_block_bootstrap__mutmut_5 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_6'] = x_paired_block_bootstrap__mutmut_6 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_7'] = x_paired_block_bootstrap__mutmut_7 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_8'] = x_paired_block_bootstrap__mutmut_8 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_9'] = x_paired_block_bootstrap__mutmut_9 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_10'] = x_paired_block_bootstrap__mutmut_10 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_11'] = x_paired_block_bootstrap__mutmut_11 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_12'] = x_paired_block_bootstrap__mutmut_12 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_13'] = x_paired_block_bootstrap__mutmut_13 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_14'] = x_paired_block_bootstrap__mutmut_14 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_15'] = x_paired_block_bootstrap__mutmut_15 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_16'] = x_paired_block_bootstrap__mutmut_16 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_17'] = x_paired_block_bootstrap__mutmut_17 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_18'] = x_paired_block_bootstrap__mutmut_18 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_19'] = x_paired_block_bootstrap__mutmut_19 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_20'] = x_paired_block_bootstrap__mutmut_20 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_21'] = x_paired_block_bootstrap__mutmut_21 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_22'] = x_paired_block_bootstrap__mutmut_22 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_23'] = x_paired_block_bootstrap__mutmut_23 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_24'] = x_paired_block_bootstrap__mutmut_24 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_25'] = x_paired_block_bootstrap__mutmut_25 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_26'] = x_paired_block_bootstrap__mutmut_26 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_27'] = x_paired_block_bootstrap__mutmut_27 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_28'] = x_paired_block_bootstrap__mutmut_28 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_29'] = x_paired_block_bootstrap__mutmut_29 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_30'] = x_paired_block_bootstrap__mutmut_30 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_31'] = x_paired_block_bootstrap__mutmut_31 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_32'] = x_paired_block_bootstrap__mutmut_32 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_33'] = x_paired_block_bootstrap__mutmut_33 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_34'] = x_paired_block_bootstrap__mutmut_34 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_35'] = x_paired_block_bootstrap__mutmut_35 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_36'] = x_paired_block_bootstrap__mutmut_36 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_37'] = x_paired_block_bootstrap__mutmut_37 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_38'] = x_paired_block_bootstrap__mutmut_38 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_39'] = x_paired_block_bootstrap__mutmut_39 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_40'] = x_paired_block_bootstrap__mutmut_40 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_41'] = x_paired_block_bootstrap__mutmut_41 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_42'] = x_paired_block_bootstrap__mutmut_42 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_43'] = x_paired_block_bootstrap__mutmut_43 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_44'] = x_paired_block_bootstrap__mutmut_44 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_45'] = x_paired_block_bootstrap__mutmut_45 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_46'] = x_paired_block_bootstrap__mutmut_46 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_47'] = x_paired_block_bootstrap__mutmut_47 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_48'] = x_paired_block_bootstrap__mutmut_48 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_49'] = x_paired_block_bootstrap__mutmut_49 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_50'] = x_paired_block_bootstrap__mutmut_50 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_51'] = x_paired_block_bootstrap__mutmut_51 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_52'] = x_paired_block_bootstrap__mutmut_52 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_53'] = x_paired_block_bootstrap__mutmut_53 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_54'] = x_paired_block_bootstrap__mutmut_54 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_55'] = x_paired_block_bootstrap__mutmut_55 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_56'] = x_paired_block_bootstrap__mutmut_56 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_57'] = x_paired_block_bootstrap__mutmut_57 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_58'] = x_paired_block_bootstrap__mutmut_58 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_59'] = x_paired_block_bootstrap__mutmut_59 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_60'] = x_paired_block_bootstrap__mutmut_60 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_61'] = x_paired_block_bootstrap__mutmut_61 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_62'] = x_paired_block_bootstrap__mutmut_62 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_63'] = x_paired_block_bootstrap__mutmut_63 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_64'] = x_paired_block_bootstrap__mutmut_64 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_65'] = x_paired_block_bootstrap__mutmut_65 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_66'] = x_paired_block_bootstrap__mutmut_66 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_67'] = x_paired_block_bootstrap__mutmut_67 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_68'] = x_paired_block_bootstrap__mutmut_68 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_69'] = x_paired_block_bootstrap__mutmut_69 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_70'] = x_paired_block_bootstrap__mutmut_70 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_71'] = x_paired_block_bootstrap__mutmut_71 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_72'] = x_paired_block_bootstrap__mutmut_72 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_73'] = x_paired_block_bootstrap__mutmut_73 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_74'] = x_paired_block_bootstrap__mutmut_74 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_75'] = x_paired_block_bootstrap__mutmut_75 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_76'] = x_paired_block_bootstrap__mutmut_76 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_77'] = x_paired_block_bootstrap__mutmut_77 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_78'] = x_paired_block_bootstrap__mutmut_78 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_79'] = x_paired_block_bootstrap__mutmut_79 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_80'] = x_paired_block_bootstrap__mutmut_80 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_81'] = x_paired_block_bootstrap__mutmut_81 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_82'] = x_paired_block_bootstrap__mutmut_82 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_83'] = x_paired_block_bootstrap__mutmut_83 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_84'] = x_paired_block_bootstrap__mutmut_84 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_85'] = x_paired_block_bootstrap__mutmut_85 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_86'] = x_paired_block_bootstrap__mutmut_86 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_87'] = x_paired_block_bootstrap__mutmut_87 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_88'] = x_paired_block_bootstrap__mutmut_88 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_89'] = x_paired_block_bootstrap__mutmut_89 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_90'] = x_paired_block_bootstrap__mutmut_90 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_91'] = x_paired_block_bootstrap__mutmut_91 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_92'] = x_paired_block_bootstrap__mutmut_92 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_93'] = x_paired_block_bootstrap__mutmut_93 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_94'] = x_paired_block_bootstrap__mutmut_94 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_95'] = x_paired_block_bootstrap__mutmut_95 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_96'] = x_paired_block_bootstrap__mutmut_96 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_97'] = x_paired_block_bootstrap__mutmut_97 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_98'] = x_paired_block_bootstrap__mutmut_98 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_99'] = x_paired_block_bootstrap__mutmut_99 # type: ignore # mutmut generated
mutants_x_paired_block_bootstrap__mutmut['x_paired_block_bootstrap__mutmut_100'] = x_paired_block_bootstrap__mutmut_100 # type: ignore # mutmut generated
