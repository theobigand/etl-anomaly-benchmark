"""Summary of the alert-budget runs: JSON with exact denominators and a Markdown table."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import alert_budget as ab  # noqa: E402


from mutmut.mutation.trampoline import wrap_in_trampoline as _mutmut_mutated, MutantDict
mutants_x_load__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_load__mutmut)
def load(folder: Path) -> tuple[list[dict], list[str]]:
    runs, failed = [], []
    for path in sorted(folder.glob("*.json")):
        run = json.loads(path.read_text())
        (failed if "failed" in run else runs).append(run["problem"])
        if "failed" not in run:
            runs[-1] = run
    return [r for r in runs if isinstance(r, dict)], [p for p in failed if isinstance(p, str)]


def x_load__mutmut_orig(folder: Path) -> tuple[list[dict], list[str]]:
    runs, failed = [], []
    for path in sorted(folder.glob("*.json")):
        run = json.loads(path.read_text())
        (failed if "failed" in run else runs).append(run["problem"])
        if "failed" not in run:
            runs[-1] = run
    return [r for r in runs if isinstance(r, dict)], [p for p in failed if isinstance(p, str)]


def x_load__mutmut_1(folder: Path) -> tuple[list[dict], list[str]]:
    runs, failed = None
    for path in sorted(folder.glob("*.json")):
        run = json.loads(path.read_text())
        (failed if "failed" in run else runs).append(run["problem"])
        if "failed" not in run:
            runs[-1] = run
    return [r for r in runs if isinstance(r, dict)], [p for p in failed if isinstance(p, str)]


def x_load__mutmut_2(folder: Path) -> tuple[list[dict], list[str]]:
    runs, failed = [], []
    for path in sorted(None):
        run = json.loads(path.read_text())
        (failed if "failed" in run else runs).append(run["problem"])
        if "failed" not in run:
            runs[-1] = run
    return [r for r in runs if isinstance(r, dict)], [p for p in failed if isinstance(p, str)]


def x_load__mutmut_3(folder: Path) -> tuple[list[dict], list[str]]:
    runs, failed = [], []
    for path in sorted(folder.glob(None)):
        run = json.loads(path.read_text())
        (failed if "failed" in run else runs).append(run["problem"])
        if "failed" not in run:
            runs[-1] = run
    return [r for r in runs if isinstance(r, dict)], [p for p in failed if isinstance(p, str)]


def x_load__mutmut_4(folder: Path) -> tuple[list[dict], list[str]]:
    runs, failed = [], []
    for path in sorted(folder.glob("XX*.jsonXX")):
        run = json.loads(path.read_text())
        (failed if "failed" in run else runs).append(run["problem"])
        if "failed" not in run:
            runs[-1] = run
    return [r for r in runs if isinstance(r, dict)], [p for p in failed if isinstance(p, str)]


def x_load__mutmut_5(folder: Path) -> tuple[list[dict], list[str]]:
    runs, failed = [], []
    for path in sorted(folder.glob("*.JSON")):
        run = json.loads(path.read_text())
        (failed if "failed" in run else runs).append(run["problem"])
        if "failed" not in run:
            runs[-1] = run
    return [r for r in runs if isinstance(r, dict)], [p for p in failed if isinstance(p, str)]


def x_load__mutmut_6(folder: Path) -> tuple[list[dict], list[str]]:
    runs, failed = [], []
    for path in sorted(folder.glob("*.json")):
        run = None
        (failed if "failed" in run else runs).append(run["problem"])
        if "failed" not in run:
            runs[-1] = run
    return [r for r in runs if isinstance(r, dict)], [p for p in failed if isinstance(p, str)]


def x_load__mutmut_7(folder: Path) -> tuple[list[dict], list[str]]:
    runs, failed = [], []
    for path in sorted(folder.glob("*.json")):
        run = json.loads(None)
        (failed if "failed" in run else runs).append(run["problem"])
        if "failed" not in run:
            runs[-1] = run
    return [r for r in runs if isinstance(r, dict)], [p for p in failed if isinstance(p, str)]


def x_load__mutmut_8(folder: Path) -> tuple[list[dict], list[str]]:
    runs, failed = [], []
    for path in sorted(folder.glob("*.json")):
        run = json.loads(path.read_text())
        (failed if "failed" in run else runs).append(None)
        if "failed" not in run:
            runs[-1] = run
    return [r for r in runs if isinstance(r, dict)], [p for p in failed if isinstance(p, str)]


def x_load__mutmut_9(folder: Path) -> tuple[list[dict], list[str]]:
    runs, failed = [], []
    for path in sorted(folder.glob("*.json")):
        run = json.loads(path.read_text())
        (failed if ("failed" in run) and False else runs).append(run["problem"])
        if "failed" not in run:
            runs[-1] = run
    return [r for r in runs if isinstance(r, dict)], [p for p in failed if isinstance(p, str)]


def x_load__mutmut_10(folder: Path) -> tuple[list[dict], list[str]]:
    runs, failed = [], []
    for path in sorted(folder.glob("*.json")):
        run = json.loads(path.read_text())
        (failed if ("failed" in run) or True else runs).append(run["problem"])
        if "failed" not in run:
            runs[-1] = run
    return [r for r in runs if isinstance(r, dict)], [p for p in failed if isinstance(p, str)]


def x_load__mutmut_11(folder: Path) -> tuple[list[dict], list[str]]:
    runs, failed = [], []
    for path in sorted(folder.glob("*.json")):
        run = json.loads(path.read_text())
        (failed if "XXfailedXX" in run else runs).append(run["problem"])
        if "failed" not in run:
            runs[-1] = run
    return [r for r in runs if isinstance(r, dict)], [p for p in failed if isinstance(p, str)]


def x_load__mutmut_12(folder: Path) -> tuple[list[dict], list[str]]:
    runs, failed = [], []
    for path in sorted(folder.glob("*.json")):
        run = json.loads(path.read_text())
        (failed if "FAILED" in run else runs).append(run["problem"])
        if "failed" not in run:
            runs[-1] = run
    return [r for r in runs if isinstance(r, dict)], [p for p in failed if isinstance(p, str)]


def x_load__mutmut_13(folder: Path) -> tuple[list[dict], list[str]]:
    runs, failed = [], []
    for path in sorted(folder.glob("*.json")):
        run = json.loads(path.read_text())
        (failed if "failed" not in run else runs).append(run["problem"])
        if "failed" not in run:
            runs[-1] = run
    return [r for r in runs if isinstance(r, dict)], [p for p in failed if isinstance(p, str)]


def x_load__mutmut_14(folder: Path) -> tuple[list[dict], list[str]]:
    runs, failed = [], []
    for path in sorted(folder.glob("*.json")):
        run = json.loads(path.read_text())
        (failed if "failed" in run else runs).append(run["XXproblemXX"])
        if "failed" not in run:
            runs[-1] = run
    return [r for r in runs if isinstance(r, dict)], [p for p in failed if isinstance(p, str)]


def x_load__mutmut_15(folder: Path) -> tuple[list[dict], list[str]]:
    runs, failed = [], []
    for path in sorted(folder.glob("*.json")):
        run = json.loads(path.read_text())
        (failed if "failed" in run else runs).append(run["PROBLEM"])
        if "failed" not in run:
            runs[-1] = run
    return [r for r in runs if isinstance(r, dict)], [p for p in failed if isinstance(p, str)]


def x_load__mutmut_16(folder: Path) -> tuple[list[dict], list[str]]:
    runs, failed = [], []
    for path in sorted(folder.glob("*.json")):
        run = json.loads(path.read_text())
        (failed if "failed" in run else runs).append(run["problem"])
        if "XXfailedXX" not in run:
            runs[-1] = run
    return [r for r in runs if isinstance(r, dict)], [p for p in failed if isinstance(p, str)]


def x_load__mutmut_17(folder: Path) -> tuple[list[dict], list[str]]:
    runs, failed = [], []
    for path in sorted(folder.glob("*.json")):
        run = json.loads(path.read_text())
        (failed if "failed" in run else runs).append(run["problem"])
        if "FAILED" not in run:
            runs[-1] = run
    return [r for r in runs if isinstance(r, dict)], [p for p in failed if isinstance(p, str)]


def x_load__mutmut_18(folder: Path) -> tuple[list[dict], list[str]]:
    runs, failed = [], []
    for path in sorted(folder.glob("*.json")):
        run = json.loads(path.read_text())
        (failed if "failed" in run else runs).append(run["problem"])
        if "failed" in run:
            runs[-1] = run
    return [r for r in runs if isinstance(r, dict)], [p for p in failed if isinstance(p, str)]


def x_load__mutmut_19(folder: Path) -> tuple[list[dict], list[str]]:
    runs, failed = [], []
    for path in sorted(folder.glob("*.json")):
        run = json.loads(path.read_text())
        (failed if "failed" in run else runs).append(run["problem"])
        if "failed" not in run:
            runs[-1] = None
    return [r for r in runs if isinstance(r, dict)], [p for p in failed if isinstance(p, str)]


def x_load__mutmut_20(folder: Path) -> tuple[list[dict], list[str]]:
    runs, failed = [], []
    for path in sorted(folder.glob("*.json")):
        run = json.loads(path.read_text())
        (failed if "failed" in run else runs).append(run["problem"])
        if "failed" not in run:
            runs[+1] = run
    return [r for r in runs if isinstance(r, dict)], [p for p in failed if isinstance(p, str)]


def x_load__mutmut_21(folder: Path) -> tuple[list[dict], list[str]]:
    runs, failed = [], []
    for path in sorted(folder.glob("*.json")):
        run = json.loads(path.read_text())
        (failed if "failed" in run else runs).append(run["problem"])
        if "failed" not in run:
            runs[-2] = run
    return [r for r in runs if isinstance(r, dict)], [p for p in failed if isinstance(p, str)]

mutants_x_load__mutmut['_mutmut_orig'] = x_load__mutmut_orig # type: ignore # mutmut generated
mutants_x_load__mutmut['x_load__mutmut_1'] = x_load__mutmut_1 # type: ignore # mutmut generated
mutants_x_load__mutmut['x_load__mutmut_2'] = x_load__mutmut_2 # type: ignore # mutmut generated
mutants_x_load__mutmut['x_load__mutmut_3'] = x_load__mutmut_3 # type: ignore # mutmut generated
mutants_x_load__mutmut['x_load__mutmut_4'] = x_load__mutmut_4 # type: ignore # mutmut generated
mutants_x_load__mutmut['x_load__mutmut_5'] = x_load__mutmut_5 # type: ignore # mutmut generated
mutants_x_load__mutmut['x_load__mutmut_6'] = x_load__mutmut_6 # type: ignore # mutmut generated
mutants_x_load__mutmut['x_load__mutmut_7'] = x_load__mutmut_7 # type: ignore # mutmut generated
mutants_x_load__mutmut['x_load__mutmut_8'] = x_load__mutmut_8 # type: ignore # mutmut generated
mutants_x_load__mutmut['x_load__mutmut_9'] = x_load__mutmut_9 # type: ignore # mutmut generated
mutants_x_load__mutmut['x_load__mutmut_10'] = x_load__mutmut_10 # type: ignore # mutmut generated
mutants_x_load__mutmut['x_load__mutmut_11'] = x_load__mutmut_11 # type: ignore # mutmut generated
mutants_x_load__mutmut['x_load__mutmut_12'] = x_load__mutmut_12 # type: ignore # mutmut generated
mutants_x_load__mutmut['x_load__mutmut_13'] = x_load__mutmut_13 # type: ignore # mutmut generated
mutants_x_load__mutmut['x_load__mutmut_14'] = x_load__mutmut_14 # type: ignore # mutmut generated
mutants_x_load__mutmut['x_load__mutmut_15'] = x_load__mutmut_15 # type: ignore # mutmut generated
mutants_x_load__mutmut['x_load__mutmut_16'] = x_load__mutmut_16 # type: ignore # mutmut generated
mutants_x_load__mutmut['x_load__mutmut_17'] = x_load__mutmut_17 # type: ignore # mutmut generated
mutants_x_load__mutmut['x_load__mutmut_18'] = x_load__mutmut_18 # type: ignore # mutmut generated
mutants_x_load__mutmut['x_load__mutmut_19'] = x_load__mutmut_19 # type: ignore # mutmut generated
mutants_x_load__mutmut['x_load__mutmut_20'] = x_load__mutmut_20 # type: ignore # mutmut generated
mutants_x_load__mutmut['x_load__mutmut_21'] = x_load__mutmut_21 # type: ignore # mutmut generated
mutants_x_markdown__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_markdown__mutmut)
def markdown(table: dict, accounting: dict, failed: list[str]) -> str:
    lines = [
        f"Problems evaluated: {accounting['problems']}; "
        f"problems that failed to load: {len(failed)}; "
        f"failed seed runs: {accounting['failed_runs']}; skipped (problem, detector) pairs: "
        f"{accounting['skipped_detectors']}.",
        "",
        "| Detector | Budget | Problems | Seed runs | Median alert rate | Alert/budget | "
        "Precision | Recall | F1 | FPR |",
        "| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |",
    ]
    for method, cells in table.items():
        for budget, c in cells.items():
            lines.append(
                f"| {method} | {float(budget):.3f} | {c['problems']} | {c['seed_runs']} | "
                f"{c['median_test_alert_rate']:.4f} | {c['median_realized_over_nominal']:.2f} | "
                f"{c['median_precision']:.3f} | {c['median_recall']:.3f} | {c['median_f1']:.3f} | "
                f"{c['median_fpr']:.4f} |"
            )
    return "\n".join(lines) + "\n"


def x_markdown__mutmut_orig(table: dict, accounting: dict, failed: list[str]) -> str:
    lines = [
        f"Problems evaluated: {accounting['problems']}; "
        f"problems that failed to load: {len(failed)}; "
        f"failed seed runs: {accounting['failed_runs']}; skipped (problem, detector) pairs: "
        f"{accounting['skipped_detectors']}.",
        "",
        "| Detector | Budget | Problems | Seed runs | Median alert rate | Alert/budget | "
        "Precision | Recall | F1 | FPR |",
        "| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |",
    ]
    for method, cells in table.items():
        for budget, c in cells.items():
            lines.append(
                f"| {method} | {float(budget):.3f} | {c['problems']} | {c['seed_runs']} | "
                f"{c['median_test_alert_rate']:.4f} | {c['median_realized_over_nominal']:.2f} | "
                f"{c['median_precision']:.3f} | {c['median_recall']:.3f} | {c['median_f1']:.3f} | "
                f"{c['median_fpr']:.4f} |"
            )
    return "\n".join(lines) + "\n"


def x_markdown__mutmut_1(table: dict, accounting: dict, failed: list[str]) -> str:
    lines = None
    for method, cells in table.items():
        for budget, c in cells.items():
            lines.append(
                f"| {method} | {float(budget):.3f} | {c['problems']} | {c['seed_runs']} | "
                f"{c['median_test_alert_rate']:.4f} | {c['median_realized_over_nominal']:.2f} | "
                f"{c['median_precision']:.3f} | {c['median_recall']:.3f} | {c['median_f1']:.3f} | "
                f"{c['median_fpr']:.4f} |"
            )
    return "\n".join(lines) + "\n"


def x_markdown__mutmut_2(table: dict, accounting: dict, failed: list[str]) -> str:
    lines = [
        f"Problems evaluated: {accounting['XXproblemsXX']}; "
        f"problems that failed to load: {len(failed)}; "
        f"failed seed runs: {accounting['failed_runs']}; skipped (problem, detector) pairs: "
        f"{accounting['skipped_detectors']}.",
        "",
        "| Detector | Budget | Problems | Seed runs | Median alert rate | Alert/budget | "
        "Precision | Recall | F1 | FPR |",
        "| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |",
    ]
    for method, cells in table.items():
        for budget, c in cells.items():
            lines.append(
                f"| {method} | {float(budget):.3f} | {c['problems']} | {c['seed_runs']} | "
                f"{c['median_test_alert_rate']:.4f} | {c['median_realized_over_nominal']:.2f} | "
                f"{c['median_precision']:.3f} | {c['median_recall']:.3f} | {c['median_f1']:.3f} | "
                f"{c['median_fpr']:.4f} |"
            )
    return "\n".join(lines) + "\n"


def x_markdown__mutmut_3(table: dict, accounting: dict, failed: list[str]) -> str:
    lines = [
        f"Problems evaluated: {accounting['PROBLEMS']}; "
        f"problems that failed to load: {len(failed)}; "
        f"failed seed runs: {accounting['failed_runs']}; skipped (problem, detector) pairs: "
        f"{accounting['skipped_detectors']}.",
        "",
        "| Detector | Budget | Problems | Seed runs | Median alert rate | Alert/budget | "
        "Precision | Recall | F1 | FPR |",
        "| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |",
    ]
    for method, cells in table.items():
        for budget, c in cells.items():
            lines.append(
                f"| {method} | {float(budget):.3f} | {c['problems']} | {c['seed_runs']} | "
                f"{c['median_test_alert_rate']:.4f} | {c['median_realized_over_nominal']:.2f} | "
                f"{c['median_precision']:.3f} | {c['median_recall']:.3f} | {c['median_f1']:.3f} | "
                f"{c['median_fpr']:.4f} |"
            )
    return "\n".join(lines) + "\n"


def x_markdown__mutmut_4(table: dict, accounting: dict, failed: list[str]) -> str:
    lines = [
        f"Problems evaluated: {accounting['problems']}; "
        f"problems that failed to load: {len(failed)}; "
        f"failed seed runs: {accounting['XXfailed_runsXX']}; skipped (problem, detector) pairs: "
        f"{accounting['skipped_detectors']}.",
        "",
        "| Detector | Budget | Problems | Seed runs | Median alert rate | Alert/budget | "
        "Precision | Recall | F1 | FPR |",
        "| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |",
    ]
    for method, cells in table.items():
        for budget, c in cells.items():
            lines.append(
                f"| {method} | {float(budget):.3f} | {c['problems']} | {c['seed_runs']} | "
                f"{c['median_test_alert_rate']:.4f} | {c['median_realized_over_nominal']:.2f} | "
                f"{c['median_precision']:.3f} | {c['median_recall']:.3f} | {c['median_f1']:.3f} | "
                f"{c['median_fpr']:.4f} |"
            )
    return "\n".join(lines) + "\n"


def x_markdown__mutmut_5(table: dict, accounting: dict, failed: list[str]) -> str:
    lines = [
        f"Problems evaluated: {accounting['problems']}; "
        f"problems that failed to load: {len(failed)}; "
        f"failed seed runs: {accounting['FAILED_RUNS']}; skipped (problem, detector) pairs: "
        f"{accounting['skipped_detectors']}.",
        "",
        "| Detector | Budget | Problems | Seed runs | Median alert rate | Alert/budget | "
        "Precision | Recall | F1 | FPR |",
        "| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |",
    ]
    for method, cells in table.items():
        for budget, c in cells.items():
            lines.append(
                f"| {method} | {float(budget):.3f} | {c['problems']} | {c['seed_runs']} | "
                f"{c['median_test_alert_rate']:.4f} | {c['median_realized_over_nominal']:.2f} | "
                f"{c['median_precision']:.3f} | {c['median_recall']:.3f} | {c['median_f1']:.3f} | "
                f"{c['median_fpr']:.4f} |"
            )
    return "\n".join(lines) + "\n"


def x_markdown__mutmut_6(table: dict, accounting: dict, failed: list[str]) -> str:
    lines = [
        f"Problems evaluated: {accounting['problems']}; "
        f"problems that failed to load: {len(failed)}; "
        f"failed seed runs: {accounting['failed_runs']}; skipped (problem, detector) pairs: "
        f"{accounting['XXskipped_detectorsXX']}.",
        "",
        "| Detector | Budget | Problems | Seed runs | Median alert rate | Alert/budget | "
        "Precision | Recall | F1 | FPR |",
        "| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |",
    ]
    for method, cells in table.items():
        for budget, c in cells.items():
            lines.append(
                f"| {method} | {float(budget):.3f} | {c['problems']} | {c['seed_runs']} | "
                f"{c['median_test_alert_rate']:.4f} | {c['median_realized_over_nominal']:.2f} | "
                f"{c['median_precision']:.3f} | {c['median_recall']:.3f} | {c['median_f1']:.3f} | "
                f"{c['median_fpr']:.4f} |"
            )
    return "\n".join(lines) + "\n"


def x_markdown__mutmut_7(table: dict, accounting: dict, failed: list[str]) -> str:
    lines = [
        f"Problems evaluated: {accounting['problems']}; "
        f"problems that failed to load: {len(failed)}; "
        f"failed seed runs: {accounting['failed_runs']}; skipped (problem, detector) pairs: "
        f"{accounting['SKIPPED_DETECTORS']}.",
        "",
        "| Detector | Budget | Problems | Seed runs | Median alert rate | Alert/budget | "
        "Precision | Recall | F1 | FPR |",
        "| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |",
    ]
    for method, cells in table.items():
        for budget, c in cells.items():
            lines.append(
                f"| {method} | {float(budget):.3f} | {c['problems']} | {c['seed_runs']} | "
                f"{c['median_test_alert_rate']:.4f} | {c['median_realized_over_nominal']:.2f} | "
                f"{c['median_precision']:.3f} | {c['median_recall']:.3f} | {c['median_f1']:.3f} | "
                f"{c['median_fpr']:.4f} |"
            )
    return "\n".join(lines) + "\n"


def x_markdown__mutmut_8(table: dict, accounting: dict, failed: list[str]) -> str:
    lines = [
        f"Problems evaluated: {accounting['problems']}; "
        f"problems that failed to load: {len(failed)}; "
        f"failed seed runs: {accounting['failed_runs']}; skipped (problem, detector) pairs: "
        f"{accounting['skipped_detectors']}.",
        "XXXX",
        "| Detector | Budget | Problems | Seed runs | Median alert rate | Alert/budget | "
        "Precision | Recall | F1 | FPR |",
        "| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |",
    ]
    for method, cells in table.items():
        for budget, c in cells.items():
            lines.append(
                f"| {method} | {float(budget):.3f} | {c['problems']} | {c['seed_runs']} | "
                f"{c['median_test_alert_rate']:.4f} | {c['median_realized_over_nominal']:.2f} | "
                f"{c['median_precision']:.3f} | {c['median_recall']:.3f} | {c['median_f1']:.3f} | "
                f"{c['median_fpr']:.4f} |"
            )
    return "\n".join(lines) + "\n"


def x_markdown__mutmut_9(table: dict, accounting: dict, failed: list[str]) -> str:
    lines = [
        f"Problems evaluated: {accounting['problems']}; "
        f"problems that failed to load: {len(failed)}; "
        f"failed seed runs: {accounting['failed_runs']}; skipped (problem, detector) pairs: "
        f"{accounting['skipped_detectors']}.",
        "",
        "XX| Detector | Budget | Problems | Seed runs | Median alert rate | Alert/budget | XX"
        "Precision | Recall | F1 | FPR |",
        "| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |",
    ]
    for method, cells in table.items():
        for budget, c in cells.items():
            lines.append(
                f"| {method} | {float(budget):.3f} | {c['problems']} | {c['seed_runs']} | "
                f"{c['median_test_alert_rate']:.4f} | {c['median_realized_over_nominal']:.2f} | "
                f"{c['median_precision']:.3f} | {c['median_recall']:.3f} | {c['median_f1']:.3f} | "
                f"{c['median_fpr']:.4f} |"
            )
    return "\n".join(lines) + "\n"


def x_markdown__mutmut_10(table: dict, accounting: dict, failed: list[str]) -> str:
    lines = [
        f"Problems evaluated: {accounting['problems']}; "
        f"problems that failed to load: {len(failed)}; "
        f"failed seed runs: {accounting['failed_runs']}; skipped (problem, detector) pairs: "
        f"{accounting['skipped_detectors']}.",
        "",
        "| detector | budget | problems | seed runs | median alert rate | alert/budget | "
        "Precision | Recall | F1 | FPR |",
        "| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |",
    ]
    for method, cells in table.items():
        for budget, c in cells.items():
            lines.append(
                f"| {method} | {float(budget):.3f} | {c['problems']} | {c['seed_runs']} | "
                f"{c['median_test_alert_rate']:.4f} | {c['median_realized_over_nominal']:.2f} | "
                f"{c['median_precision']:.3f} | {c['median_recall']:.3f} | {c['median_f1']:.3f} | "
                f"{c['median_fpr']:.4f} |"
            )
    return "\n".join(lines) + "\n"


def x_markdown__mutmut_11(table: dict, accounting: dict, failed: list[str]) -> str:
    lines = [
        f"Problems evaluated: {accounting['problems']}; "
        f"problems that failed to load: {len(failed)}; "
        f"failed seed runs: {accounting['failed_runs']}; skipped (problem, detector) pairs: "
        f"{accounting['skipped_detectors']}.",
        "",
        "| DETECTOR | BUDGET | PROBLEMS | SEED RUNS | MEDIAN ALERT RATE | ALERT/BUDGET | "
        "Precision | Recall | F1 | FPR |",
        "| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |",
    ]
    for method, cells in table.items():
        for budget, c in cells.items():
            lines.append(
                f"| {method} | {float(budget):.3f} | {c['problems']} | {c['seed_runs']} | "
                f"{c['median_test_alert_rate']:.4f} | {c['median_realized_over_nominal']:.2f} | "
                f"{c['median_precision']:.3f} | {c['median_recall']:.3f} | {c['median_f1']:.3f} | "
                f"{c['median_fpr']:.4f} |"
            )
    return "\n".join(lines) + "\n"


def x_markdown__mutmut_12(table: dict, accounting: dict, failed: list[str]) -> str:
    lines = [
        f"Problems evaluated: {accounting['problems']}; "
        f"problems that failed to load: {len(failed)}; "
        f"failed seed runs: {accounting['failed_runs']}; skipped (problem, detector) pairs: "
        f"{accounting['skipped_detectors']}.",
        "",
        "| Detector | Budget | Problems | Seed runs | Median alert rate | Alert/budget | "
        "XXPrecision | Recall | F1 | FPR |XX",
        "| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |",
    ]
    for method, cells in table.items():
        for budget, c in cells.items():
            lines.append(
                f"| {method} | {float(budget):.3f} | {c['problems']} | {c['seed_runs']} | "
                f"{c['median_test_alert_rate']:.4f} | {c['median_realized_over_nominal']:.2f} | "
                f"{c['median_precision']:.3f} | {c['median_recall']:.3f} | {c['median_f1']:.3f} | "
                f"{c['median_fpr']:.4f} |"
            )
    return "\n".join(lines) + "\n"


def x_markdown__mutmut_13(table: dict, accounting: dict, failed: list[str]) -> str:
    lines = [
        f"Problems evaluated: {accounting['problems']}; "
        f"problems that failed to load: {len(failed)}; "
        f"failed seed runs: {accounting['failed_runs']}; skipped (problem, detector) pairs: "
        f"{accounting['skipped_detectors']}.",
        "",
        "| Detector | Budget | Problems | Seed runs | Median alert rate | Alert/budget | "
        "precision | recall | f1 | fpr |",
        "| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |",
    ]
    for method, cells in table.items():
        for budget, c in cells.items():
            lines.append(
                f"| {method} | {float(budget):.3f} | {c['problems']} | {c['seed_runs']} | "
                f"{c['median_test_alert_rate']:.4f} | {c['median_realized_over_nominal']:.2f} | "
                f"{c['median_precision']:.3f} | {c['median_recall']:.3f} | {c['median_f1']:.3f} | "
                f"{c['median_fpr']:.4f} |"
            )
    return "\n".join(lines) + "\n"


def x_markdown__mutmut_14(table: dict, accounting: dict, failed: list[str]) -> str:
    lines = [
        f"Problems evaluated: {accounting['problems']}; "
        f"problems that failed to load: {len(failed)}; "
        f"failed seed runs: {accounting['failed_runs']}; skipped (problem, detector) pairs: "
        f"{accounting['skipped_detectors']}.",
        "",
        "| Detector | Budget | Problems | Seed runs | Median alert rate | Alert/budget | "
        "PRECISION | RECALL | F1 | FPR |",
        "| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |",
    ]
    for method, cells in table.items():
        for budget, c in cells.items():
            lines.append(
                f"| {method} | {float(budget):.3f} | {c['problems']} | {c['seed_runs']} | "
                f"{c['median_test_alert_rate']:.4f} | {c['median_realized_over_nominal']:.2f} | "
                f"{c['median_precision']:.3f} | {c['median_recall']:.3f} | {c['median_f1']:.3f} | "
                f"{c['median_fpr']:.4f} |"
            )
    return "\n".join(lines) + "\n"


def x_markdown__mutmut_15(table: dict, accounting: dict, failed: list[str]) -> str:
    lines = [
        f"Problems evaluated: {accounting['problems']}; "
        f"problems that failed to load: {len(failed)}; "
        f"failed seed runs: {accounting['failed_runs']}; skipped (problem, detector) pairs: "
        f"{accounting['skipped_detectors']}.",
        "",
        "| Detector | Budget | Problems | Seed runs | Median alert rate | Alert/budget | "
        "Precision | Recall | F1 | FPR |",
        "XX| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |XX",
    ]
    for method, cells in table.items():
        for budget, c in cells.items():
            lines.append(
                f"| {method} | {float(budget):.3f} | {c['problems']} | {c['seed_runs']} | "
                f"{c['median_test_alert_rate']:.4f} | {c['median_realized_over_nominal']:.2f} | "
                f"{c['median_precision']:.3f} | {c['median_recall']:.3f} | {c['median_f1']:.3f} | "
                f"{c['median_fpr']:.4f} |"
            )
    return "\n".join(lines) + "\n"


def x_markdown__mutmut_16(table: dict, accounting: dict, failed: list[str]) -> str:
    lines = [
        f"Problems evaluated: {accounting['problems']}; "
        f"problems that failed to load: {len(failed)}; "
        f"failed seed runs: {accounting['failed_runs']}; skipped (problem, detector) pairs: "
        f"{accounting['skipped_detectors']}.",
        "",
        "| Detector | Budget | Problems | Seed runs | Median alert rate | Alert/budget | "
        "Precision | Recall | F1 | FPR |",
        "| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |",
    ]
    for method, cells in table.items():
        for budget, c in cells.items():
            lines.append(
                None
            )
    return "\n".join(lines) + "\n"


def x_markdown__mutmut_17(table: dict, accounting: dict, failed: list[str]) -> str:
    lines = [
        f"Problems evaluated: {accounting['problems']}; "
        f"problems that failed to load: {len(failed)}; "
        f"failed seed runs: {accounting['failed_runs']}; skipped (problem, detector) pairs: "
        f"{accounting['skipped_detectors']}.",
        "",
        "| Detector | Budget | Problems | Seed runs | Median alert rate | Alert/budget | "
        "Precision | Recall | F1 | FPR |",
        "| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |",
    ]
    for method, cells in table.items():
        for budget, c in cells.items():
            lines.append(
                f"| {method} | {float(None):.3f} | {c['problems']} | {c['seed_runs']} | "
                f"{c['median_test_alert_rate']:.4f} | {c['median_realized_over_nominal']:.2f} | "
                f"{c['median_precision']:.3f} | {c['median_recall']:.3f} | {c['median_f1']:.3f} | "
                f"{c['median_fpr']:.4f} |"
            )
    return "\n".join(lines) + "\n"


def x_markdown__mutmut_18(table: dict, accounting: dict, failed: list[str]) -> str:
    lines = [
        f"Problems evaluated: {accounting['problems']}; "
        f"problems that failed to load: {len(failed)}; "
        f"failed seed runs: {accounting['failed_runs']}; skipped (problem, detector) pairs: "
        f"{accounting['skipped_detectors']}.",
        "",
        "| Detector | Budget | Problems | Seed runs | Median alert rate | Alert/budget | "
        "Precision | Recall | F1 | FPR |",
        "| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |",
    ]
    for method, cells in table.items():
        for budget, c in cells.items():
            lines.append(
                f"| {method} | {float(budget):.3f} | {c['XXproblemsXX']} | {c['seed_runs']} | "
                f"{c['median_test_alert_rate']:.4f} | {c['median_realized_over_nominal']:.2f} | "
                f"{c['median_precision']:.3f} | {c['median_recall']:.3f} | {c['median_f1']:.3f} | "
                f"{c['median_fpr']:.4f} |"
            )
    return "\n".join(lines) + "\n"


def x_markdown__mutmut_19(table: dict, accounting: dict, failed: list[str]) -> str:
    lines = [
        f"Problems evaluated: {accounting['problems']}; "
        f"problems that failed to load: {len(failed)}; "
        f"failed seed runs: {accounting['failed_runs']}; skipped (problem, detector) pairs: "
        f"{accounting['skipped_detectors']}.",
        "",
        "| Detector | Budget | Problems | Seed runs | Median alert rate | Alert/budget | "
        "Precision | Recall | F1 | FPR |",
        "| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |",
    ]
    for method, cells in table.items():
        for budget, c in cells.items():
            lines.append(
                f"| {method} | {float(budget):.3f} | {c['PROBLEMS']} | {c['seed_runs']} | "
                f"{c['median_test_alert_rate']:.4f} | {c['median_realized_over_nominal']:.2f} | "
                f"{c['median_precision']:.3f} | {c['median_recall']:.3f} | {c['median_f1']:.3f} | "
                f"{c['median_fpr']:.4f} |"
            )
    return "\n".join(lines) + "\n"


def x_markdown__mutmut_20(table: dict, accounting: dict, failed: list[str]) -> str:
    lines = [
        f"Problems evaluated: {accounting['problems']}; "
        f"problems that failed to load: {len(failed)}; "
        f"failed seed runs: {accounting['failed_runs']}; skipped (problem, detector) pairs: "
        f"{accounting['skipped_detectors']}.",
        "",
        "| Detector | Budget | Problems | Seed runs | Median alert rate | Alert/budget | "
        "Precision | Recall | F1 | FPR |",
        "| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |",
    ]
    for method, cells in table.items():
        for budget, c in cells.items():
            lines.append(
                f"| {method} | {float(budget):.3f} | {c['problems']} | {c['XXseed_runsXX']} | "
                f"{c['median_test_alert_rate']:.4f} | {c['median_realized_over_nominal']:.2f} | "
                f"{c['median_precision']:.3f} | {c['median_recall']:.3f} | {c['median_f1']:.3f} | "
                f"{c['median_fpr']:.4f} |"
            )
    return "\n".join(lines) + "\n"


def x_markdown__mutmut_21(table: dict, accounting: dict, failed: list[str]) -> str:
    lines = [
        f"Problems evaluated: {accounting['problems']}; "
        f"problems that failed to load: {len(failed)}; "
        f"failed seed runs: {accounting['failed_runs']}; skipped (problem, detector) pairs: "
        f"{accounting['skipped_detectors']}.",
        "",
        "| Detector | Budget | Problems | Seed runs | Median alert rate | Alert/budget | "
        "Precision | Recall | F1 | FPR |",
        "| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |",
    ]
    for method, cells in table.items():
        for budget, c in cells.items():
            lines.append(
                f"| {method} | {float(budget):.3f} | {c['problems']} | {c['SEED_RUNS']} | "
                f"{c['median_test_alert_rate']:.4f} | {c['median_realized_over_nominal']:.2f} | "
                f"{c['median_precision']:.3f} | {c['median_recall']:.3f} | {c['median_f1']:.3f} | "
                f"{c['median_fpr']:.4f} |"
            )
    return "\n".join(lines) + "\n"


def x_markdown__mutmut_22(table: dict, accounting: dict, failed: list[str]) -> str:
    lines = [
        f"Problems evaluated: {accounting['problems']}; "
        f"problems that failed to load: {len(failed)}; "
        f"failed seed runs: {accounting['failed_runs']}; skipped (problem, detector) pairs: "
        f"{accounting['skipped_detectors']}.",
        "",
        "| Detector | Budget | Problems | Seed runs | Median alert rate | Alert/budget | "
        "Precision | Recall | F1 | FPR |",
        "| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |",
    ]
    for method, cells in table.items():
        for budget, c in cells.items():
            lines.append(
                f"| {method} | {float(budget):.3f} | {c['problems']} | {c['seed_runs']} | "
                f"{c['XXmedian_test_alert_rateXX']:.4f} | {c['median_realized_over_nominal']:.2f} | "
                f"{c['median_precision']:.3f} | {c['median_recall']:.3f} | {c['median_f1']:.3f} | "
                f"{c['median_fpr']:.4f} |"
            )
    return "\n".join(lines) + "\n"


def x_markdown__mutmut_23(table: dict, accounting: dict, failed: list[str]) -> str:
    lines = [
        f"Problems evaluated: {accounting['problems']}; "
        f"problems that failed to load: {len(failed)}; "
        f"failed seed runs: {accounting['failed_runs']}; skipped (problem, detector) pairs: "
        f"{accounting['skipped_detectors']}.",
        "",
        "| Detector | Budget | Problems | Seed runs | Median alert rate | Alert/budget | "
        "Precision | Recall | F1 | FPR |",
        "| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |",
    ]
    for method, cells in table.items():
        for budget, c in cells.items():
            lines.append(
                f"| {method} | {float(budget):.3f} | {c['problems']} | {c['seed_runs']} | "
                f"{c['MEDIAN_TEST_ALERT_RATE']:.4f} | {c['median_realized_over_nominal']:.2f} | "
                f"{c['median_precision']:.3f} | {c['median_recall']:.3f} | {c['median_f1']:.3f} | "
                f"{c['median_fpr']:.4f} |"
            )
    return "\n".join(lines) + "\n"


def x_markdown__mutmut_24(table: dict, accounting: dict, failed: list[str]) -> str:
    lines = [
        f"Problems evaluated: {accounting['problems']}; "
        f"problems that failed to load: {len(failed)}; "
        f"failed seed runs: {accounting['failed_runs']}; skipped (problem, detector) pairs: "
        f"{accounting['skipped_detectors']}.",
        "",
        "| Detector | Budget | Problems | Seed runs | Median alert rate | Alert/budget | "
        "Precision | Recall | F1 | FPR |",
        "| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |",
    ]
    for method, cells in table.items():
        for budget, c in cells.items():
            lines.append(
                f"| {method} | {float(budget):.3f} | {c['problems']} | {c['seed_runs']} | "
                f"{c['median_test_alert_rate']:.4f} | {c['XXmedian_realized_over_nominalXX']:.2f} | "
                f"{c['median_precision']:.3f} | {c['median_recall']:.3f} | {c['median_f1']:.3f} | "
                f"{c['median_fpr']:.4f} |"
            )
    return "\n".join(lines) + "\n"


def x_markdown__mutmut_25(table: dict, accounting: dict, failed: list[str]) -> str:
    lines = [
        f"Problems evaluated: {accounting['problems']}; "
        f"problems that failed to load: {len(failed)}; "
        f"failed seed runs: {accounting['failed_runs']}; skipped (problem, detector) pairs: "
        f"{accounting['skipped_detectors']}.",
        "",
        "| Detector | Budget | Problems | Seed runs | Median alert rate | Alert/budget | "
        "Precision | Recall | F1 | FPR |",
        "| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |",
    ]
    for method, cells in table.items():
        for budget, c in cells.items():
            lines.append(
                f"| {method} | {float(budget):.3f} | {c['problems']} | {c['seed_runs']} | "
                f"{c['median_test_alert_rate']:.4f} | {c['MEDIAN_REALIZED_OVER_NOMINAL']:.2f} | "
                f"{c['median_precision']:.3f} | {c['median_recall']:.3f} | {c['median_f1']:.3f} | "
                f"{c['median_fpr']:.4f} |"
            )
    return "\n".join(lines) + "\n"


def x_markdown__mutmut_26(table: dict, accounting: dict, failed: list[str]) -> str:
    lines = [
        f"Problems evaluated: {accounting['problems']}; "
        f"problems that failed to load: {len(failed)}; "
        f"failed seed runs: {accounting['failed_runs']}; skipped (problem, detector) pairs: "
        f"{accounting['skipped_detectors']}.",
        "",
        "| Detector | Budget | Problems | Seed runs | Median alert rate | Alert/budget | "
        "Precision | Recall | F1 | FPR |",
        "| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |",
    ]
    for method, cells in table.items():
        for budget, c in cells.items():
            lines.append(
                f"| {method} | {float(budget):.3f} | {c['problems']} | {c['seed_runs']} | "
                f"{c['median_test_alert_rate']:.4f} | {c['median_realized_over_nominal']:.2f} | "
                f"{c['XXmedian_precisionXX']:.3f} | {c['median_recall']:.3f} | {c['median_f1']:.3f} | "
                f"{c['median_fpr']:.4f} |"
            )
    return "\n".join(lines) + "\n"


def x_markdown__mutmut_27(table: dict, accounting: dict, failed: list[str]) -> str:
    lines = [
        f"Problems evaluated: {accounting['problems']}; "
        f"problems that failed to load: {len(failed)}; "
        f"failed seed runs: {accounting['failed_runs']}; skipped (problem, detector) pairs: "
        f"{accounting['skipped_detectors']}.",
        "",
        "| Detector | Budget | Problems | Seed runs | Median alert rate | Alert/budget | "
        "Precision | Recall | F1 | FPR |",
        "| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |",
    ]
    for method, cells in table.items():
        for budget, c in cells.items():
            lines.append(
                f"| {method} | {float(budget):.3f} | {c['problems']} | {c['seed_runs']} | "
                f"{c['median_test_alert_rate']:.4f} | {c['median_realized_over_nominal']:.2f} | "
                f"{c['MEDIAN_PRECISION']:.3f} | {c['median_recall']:.3f} | {c['median_f1']:.3f} | "
                f"{c['median_fpr']:.4f} |"
            )
    return "\n".join(lines) + "\n"


def x_markdown__mutmut_28(table: dict, accounting: dict, failed: list[str]) -> str:
    lines = [
        f"Problems evaluated: {accounting['problems']}; "
        f"problems that failed to load: {len(failed)}; "
        f"failed seed runs: {accounting['failed_runs']}; skipped (problem, detector) pairs: "
        f"{accounting['skipped_detectors']}.",
        "",
        "| Detector | Budget | Problems | Seed runs | Median alert rate | Alert/budget | "
        "Precision | Recall | F1 | FPR |",
        "| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |",
    ]
    for method, cells in table.items():
        for budget, c in cells.items():
            lines.append(
                f"| {method} | {float(budget):.3f} | {c['problems']} | {c['seed_runs']} | "
                f"{c['median_test_alert_rate']:.4f} | {c['median_realized_over_nominal']:.2f} | "
                f"{c['median_precision']:.3f} | {c['XXmedian_recallXX']:.3f} | {c['median_f1']:.3f} | "
                f"{c['median_fpr']:.4f} |"
            )
    return "\n".join(lines) + "\n"


def x_markdown__mutmut_29(table: dict, accounting: dict, failed: list[str]) -> str:
    lines = [
        f"Problems evaluated: {accounting['problems']}; "
        f"problems that failed to load: {len(failed)}; "
        f"failed seed runs: {accounting['failed_runs']}; skipped (problem, detector) pairs: "
        f"{accounting['skipped_detectors']}.",
        "",
        "| Detector | Budget | Problems | Seed runs | Median alert rate | Alert/budget | "
        "Precision | Recall | F1 | FPR |",
        "| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |",
    ]
    for method, cells in table.items():
        for budget, c in cells.items():
            lines.append(
                f"| {method} | {float(budget):.3f} | {c['problems']} | {c['seed_runs']} | "
                f"{c['median_test_alert_rate']:.4f} | {c['median_realized_over_nominal']:.2f} | "
                f"{c['median_precision']:.3f} | {c['MEDIAN_RECALL']:.3f} | {c['median_f1']:.3f} | "
                f"{c['median_fpr']:.4f} |"
            )
    return "\n".join(lines) + "\n"


def x_markdown__mutmut_30(table: dict, accounting: dict, failed: list[str]) -> str:
    lines = [
        f"Problems evaluated: {accounting['problems']}; "
        f"problems that failed to load: {len(failed)}; "
        f"failed seed runs: {accounting['failed_runs']}; skipped (problem, detector) pairs: "
        f"{accounting['skipped_detectors']}.",
        "",
        "| Detector | Budget | Problems | Seed runs | Median alert rate | Alert/budget | "
        "Precision | Recall | F1 | FPR |",
        "| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |",
    ]
    for method, cells in table.items():
        for budget, c in cells.items():
            lines.append(
                f"| {method} | {float(budget):.3f} | {c['problems']} | {c['seed_runs']} | "
                f"{c['median_test_alert_rate']:.4f} | {c['median_realized_over_nominal']:.2f} | "
                f"{c['median_precision']:.3f} | {c['median_recall']:.3f} | {c['XXmedian_f1XX']:.3f} | "
                f"{c['median_fpr']:.4f} |"
            )
    return "\n".join(lines) + "\n"


def x_markdown__mutmut_31(table: dict, accounting: dict, failed: list[str]) -> str:
    lines = [
        f"Problems evaluated: {accounting['problems']}; "
        f"problems that failed to load: {len(failed)}; "
        f"failed seed runs: {accounting['failed_runs']}; skipped (problem, detector) pairs: "
        f"{accounting['skipped_detectors']}.",
        "",
        "| Detector | Budget | Problems | Seed runs | Median alert rate | Alert/budget | "
        "Precision | Recall | F1 | FPR |",
        "| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |",
    ]
    for method, cells in table.items():
        for budget, c in cells.items():
            lines.append(
                f"| {method} | {float(budget):.3f} | {c['problems']} | {c['seed_runs']} | "
                f"{c['median_test_alert_rate']:.4f} | {c['median_realized_over_nominal']:.2f} | "
                f"{c['median_precision']:.3f} | {c['median_recall']:.3f} | {c['MEDIAN_F1']:.3f} | "
                f"{c['median_fpr']:.4f} |"
            )
    return "\n".join(lines) + "\n"


def x_markdown__mutmut_32(table: dict, accounting: dict, failed: list[str]) -> str:
    lines = [
        f"Problems evaluated: {accounting['problems']}; "
        f"problems that failed to load: {len(failed)}; "
        f"failed seed runs: {accounting['failed_runs']}; skipped (problem, detector) pairs: "
        f"{accounting['skipped_detectors']}.",
        "",
        "| Detector | Budget | Problems | Seed runs | Median alert rate | Alert/budget | "
        "Precision | Recall | F1 | FPR |",
        "| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |",
    ]
    for method, cells in table.items():
        for budget, c in cells.items():
            lines.append(
                f"| {method} | {float(budget):.3f} | {c['problems']} | {c['seed_runs']} | "
                f"{c['median_test_alert_rate']:.4f} | {c['median_realized_over_nominal']:.2f} | "
                f"{c['median_precision']:.3f} | {c['median_recall']:.3f} | {c['median_f1']:.3f} | "
                f"{c['XXmedian_fprXX']:.4f} |"
            )
    return "\n".join(lines) + "\n"


def x_markdown__mutmut_33(table: dict, accounting: dict, failed: list[str]) -> str:
    lines = [
        f"Problems evaluated: {accounting['problems']}; "
        f"problems that failed to load: {len(failed)}; "
        f"failed seed runs: {accounting['failed_runs']}; skipped (problem, detector) pairs: "
        f"{accounting['skipped_detectors']}.",
        "",
        "| Detector | Budget | Problems | Seed runs | Median alert rate | Alert/budget | "
        "Precision | Recall | F1 | FPR |",
        "| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |",
    ]
    for method, cells in table.items():
        for budget, c in cells.items():
            lines.append(
                f"| {method} | {float(budget):.3f} | {c['problems']} | {c['seed_runs']} | "
                f"{c['median_test_alert_rate']:.4f} | {c['median_realized_over_nominal']:.2f} | "
                f"{c['median_precision']:.3f} | {c['median_recall']:.3f} | {c['median_f1']:.3f} | "
                f"{c['MEDIAN_FPR']:.4f} |"
            )
    return "\n".join(lines) + "\n"


def x_markdown__mutmut_34(table: dict, accounting: dict, failed: list[str]) -> str:
    lines = [
        f"Problems evaluated: {accounting['problems']}; "
        f"problems that failed to load: {len(failed)}; "
        f"failed seed runs: {accounting['failed_runs']}; skipped (problem, detector) pairs: "
        f"{accounting['skipped_detectors']}.",
        "",
        "| Detector | Budget | Problems | Seed runs | Median alert rate | Alert/budget | "
        "Precision | Recall | F1 | FPR |",
        "| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |",
    ]
    for method, cells in table.items():
        for budget, c in cells.items():
            lines.append(
                f"| {method} | {float(budget):.3f} | {c['problems']} | {c['seed_runs']} | "
                f"{c['median_test_alert_rate']:.4f} | {c['median_realized_over_nominal']:.2f} | "
                f"{c['median_precision']:.3f} | {c['median_recall']:.3f} | {c['median_f1']:.3f} | "
                f"{c['median_fpr']:.4f} |"
            )
    return "\n".join(lines) - "\n"


def x_markdown__mutmut_35(table: dict, accounting: dict, failed: list[str]) -> str:
    lines = [
        f"Problems evaluated: {accounting['problems']}; "
        f"problems that failed to load: {len(failed)}; "
        f"failed seed runs: {accounting['failed_runs']}; skipped (problem, detector) pairs: "
        f"{accounting['skipped_detectors']}.",
        "",
        "| Detector | Budget | Problems | Seed runs | Median alert rate | Alert/budget | "
        "Precision | Recall | F1 | FPR |",
        "| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |",
    ]
    for method, cells in table.items():
        for budget, c in cells.items():
            lines.append(
                f"| {method} | {float(budget):.3f} | {c['problems']} | {c['seed_runs']} | "
                f"{c['median_test_alert_rate']:.4f} | {c['median_realized_over_nominal']:.2f} | "
                f"{c['median_precision']:.3f} | {c['median_recall']:.3f} | {c['median_f1']:.3f} | "
                f"{c['median_fpr']:.4f} |"
            )
    return "\n".join(None) + "\n"


def x_markdown__mutmut_36(table: dict, accounting: dict, failed: list[str]) -> str:
    lines = [
        f"Problems evaluated: {accounting['problems']}; "
        f"problems that failed to load: {len(failed)}; "
        f"failed seed runs: {accounting['failed_runs']}; skipped (problem, detector) pairs: "
        f"{accounting['skipped_detectors']}.",
        "",
        "| Detector | Budget | Problems | Seed runs | Median alert rate | Alert/budget | "
        "Precision | Recall | F1 | FPR |",
        "| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |",
    ]
    for method, cells in table.items():
        for budget, c in cells.items():
            lines.append(
                f"| {method} | {float(budget):.3f} | {c['problems']} | {c['seed_runs']} | "
                f"{c['median_test_alert_rate']:.4f} | {c['median_realized_over_nominal']:.2f} | "
                f"{c['median_precision']:.3f} | {c['median_recall']:.3f} | {c['median_f1']:.3f} | "
                f"{c['median_fpr']:.4f} |"
            )
    return "XX\nXX".join(lines) + "\n"


def x_markdown__mutmut_37(table: dict, accounting: dict, failed: list[str]) -> str:
    lines = [
        f"Problems evaluated: {accounting['problems']}; "
        f"problems that failed to load: {len(failed)}; "
        f"failed seed runs: {accounting['failed_runs']}; skipped (problem, detector) pairs: "
        f"{accounting['skipped_detectors']}.",
        "",
        "| Detector | Budget | Problems | Seed runs | Median alert rate | Alert/budget | "
        "Precision | Recall | F1 | FPR |",
        "| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |",
    ]
    for method, cells in table.items():
        for budget, c in cells.items():
            lines.append(
                f"| {method} | {float(budget):.3f} | {c['problems']} | {c['seed_runs']} | "
                f"{c['median_test_alert_rate']:.4f} | {c['median_realized_over_nominal']:.2f} | "
                f"{c['median_precision']:.3f} | {c['median_recall']:.3f} | {c['median_f1']:.3f} | "
                f"{c['median_fpr']:.4f} |"
            )
    return "\n".join(lines) + "XX\nXX"

mutants_x_markdown__mutmut['_mutmut_orig'] = x_markdown__mutmut_orig # type: ignore # mutmut generated
mutants_x_markdown__mutmut['x_markdown__mutmut_1'] = x_markdown__mutmut_1 # type: ignore # mutmut generated
mutants_x_markdown__mutmut['x_markdown__mutmut_2'] = x_markdown__mutmut_2 # type: ignore # mutmut generated
mutants_x_markdown__mutmut['x_markdown__mutmut_3'] = x_markdown__mutmut_3 # type: ignore # mutmut generated
mutants_x_markdown__mutmut['x_markdown__mutmut_4'] = x_markdown__mutmut_4 # type: ignore # mutmut generated
mutants_x_markdown__mutmut['x_markdown__mutmut_5'] = x_markdown__mutmut_5 # type: ignore # mutmut generated
mutants_x_markdown__mutmut['x_markdown__mutmut_6'] = x_markdown__mutmut_6 # type: ignore # mutmut generated
mutants_x_markdown__mutmut['x_markdown__mutmut_7'] = x_markdown__mutmut_7 # type: ignore # mutmut generated
mutants_x_markdown__mutmut['x_markdown__mutmut_8'] = x_markdown__mutmut_8 # type: ignore # mutmut generated
mutants_x_markdown__mutmut['x_markdown__mutmut_9'] = x_markdown__mutmut_9 # type: ignore # mutmut generated
mutants_x_markdown__mutmut['x_markdown__mutmut_10'] = x_markdown__mutmut_10 # type: ignore # mutmut generated
mutants_x_markdown__mutmut['x_markdown__mutmut_11'] = x_markdown__mutmut_11 # type: ignore # mutmut generated
mutants_x_markdown__mutmut['x_markdown__mutmut_12'] = x_markdown__mutmut_12 # type: ignore # mutmut generated
mutants_x_markdown__mutmut['x_markdown__mutmut_13'] = x_markdown__mutmut_13 # type: ignore # mutmut generated
mutants_x_markdown__mutmut['x_markdown__mutmut_14'] = x_markdown__mutmut_14 # type: ignore # mutmut generated
mutants_x_markdown__mutmut['x_markdown__mutmut_15'] = x_markdown__mutmut_15 # type: ignore # mutmut generated
mutants_x_markdown__mutmut['x_markdown__mutmut_16'] = x_markdown__mutmut_16 # type: ignore # mutmut generated
mutants_x_markdown__mutmut['x_markdown__mutmut_17'] = x_markdown__mutmut_17 # type: ignore # mutmut generated
mutants_x_markdown__mutmut['x_markdown__mutmut_18'] = x_markdown__mutmut_18 # type: ignore # mutmut generated
mutants_x_markdown__mutmut['x_markdown__mutmut_19'] = x_markdown__mutmut_19 # type: ignore # mutmut generated
mutants_x_markdown__mutmut['x_markdown__mutmut_20'] = x_markdown__mutmut_20 # type: ignore # mutmut generated
mutants_x_markdown__mutmut['x_markdown__mutmut_21'] = x_markdown__mutmut_21 # type: ignore # mutmut generated
mutants_x_markdown__mutmut['x_markdown__mutmut_22'] = x_markdown__mutmut_22 # type: ignore # mutmut generated
mutants_x_markdown__mutmut['x_markdown__mutmut_23'] = x_markdown__mutmut_23 # type: ignore # mutmut generated
mutants_x_markdown__mutmut['x_markdown__mutmut_24'] = x_markdown__mutmut_24 # type: ignore # mutmut generated
mutants_x_markdown__mutmut['x_markdown__mutmut_25'] = x_markdown__mutmut_25 # type: ignore # mutmut generated
mutants_x_markdown__mutmut['x_markdown__mutmut_26'] = x_markdown__mutmut_26 # type: ignore # mutmut generated
mutants_x_markdown__mutmut['x_markdown__mutmut_27'] = x_markdown__mutmut_27 # type: ignore # mutmut generated
mutants_x_markdown__mutmut['x_markdown__mutmut_28'] = x_markdown__mutmut_28 # type: ignore # mutmut generated
mutants_x_markdown__mutmut['x_markdown__mutmut_29'] = x_markdown__mutmut_29 # type: ignore # mutmut generated
mutants_x_markdown__mutmut['x_markdown__mutmut_30'] = x_markdown__mutmut_30 # type: ignore # mutmut generated
mutants_x_markdown__mutmut['x_markdown__mutmut_31'] = x_markdown__mutmut_31 # type: ignore # mutmut generated
mutants_x_markdown__mutmut['x_markdown__mutmut_32'] = x_markdown__mutmut_32 # type: ignore # mutmut generated
mutants_x_markdown__mutmut['x_markdown__mutmut_33'] = x_markdown__mutmut_33 # type: ignore # mutmut generated
mutants_x_markdown__mutmut['x_markdown__mutmut_34'] = x_markdown__mutmut_34 # type: ignore # mutmut generated
mutants_x_markdown__mutmut['x_markdown__mutmut_35'] = x_markdown__mutmut_35 # type: ignore # mutmut generated
mutants_x_markdown__mutmut['x_markdown__mutmut_36'] = x_markdown__mutmut_36 # type: ignore # mutmut generated
mutants_x_markdown__mutmut['x_markdown__mutmut_37'] = x_markdown__mutmut_37 # type: ignore # mutmut generated
mutants_x_main__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_main__mutmut)
def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", type=Path)
    parser.add_argument("--json", type=Path, required=True)
    parser.add_argument("--markdown", type=Path, required=True)
    args = parser.parse_args(argv)
    runs, failed = load(args.folder)
    table = ab.summarize(runs)
    accounting = ab.accounting(runs)
    args.json.write_text(
        json.dumps(
            {"budgets": list(ab.BUDGETS), "accounting": accounting, "failed_problems": failed,
             "rules": ab.rule_reference(runs),
             "table": table}, indent=1, sort_keys=True) + "\n"
    )  # fmt: skip
    args.markdown.write_text(markdown(table, accounting, failed))
    return 0


def x_main__mutmut_orig(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", type=Path)
    parser.add_argument("--json", type=Path, required=True)
    parser.add_argument("--markdown", type=Path, required=True)
    args = parser.parse_args(argv)
    runs, failed = load(args.folder)
    table = ab.summarize(runs)
    accounting = ab.accounting(runs)
    args.json.write_text(
        json.dumps(
            {"budgets": list(ab.BUDGETS), "accounting": accounting, "failed_problems": failed,
             "rules": ab.rule_reference(runs),
             "table": table}, indent=1, sort_keys=True) + "\n"
    )  # fmt: skip
    args.markdown.write_text(markdown(table, accounting, failed))
    return 0


def x_main__mutmut_1(argv: list[str] | None = None) -> int:
    parser = None
    parser.add_argument("folder", type=Path)
    parser.add_argument("--json", type=Path, required=True)
    parser.add_argument("--markdown", type=Path, required=True)
    args = parser.parse_args(argv)
    runs, failed = load(args.folder)
    table = ab.summarize(runs)
    accounting = ab.accounting(runs)
    args.json.write_text(
        json.dumps(
            {"budgets": list(ab.BUDGETS), "accounting": accounting, "failed_problems": failed,
             "rules": ab.rule_reference(runs),
             "table": table}, indent=1, sort_keys=True) + "\n"
    )  # fmt: skip
    args.markdown.write_text(markdown(table, accounting, failed))
    return 0


def x_main__mutmut_2(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=None)
    parser.add_argument("folder", type=Path)
    parser.add_argument("--json", type=Path, required=True)
    parser.add_argument("--markdown", type=Path, required=True)
    args = parser.parse_args(argv)
    runs, failed = load(args.folder)
    table = ab.summarize(runs)
    accounting = ab.accounting(runs)
    args.json.write_text(
        json.dumps(
            {"budgets": list(ab.BUDGETS), "accounting": accounting, "failed_problems": failed,
             "rules": ab.rule_reference(runs),
             "table": table}, indent=1, sort_keys=True) + "\n"
    )  # fmt: skip
    args.markdown.write_text(markdown(table, accounting, failed))
    return 0


def x_main__mutmut_3(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(None, type=Path)
    parser.add_argument("--json", type=Path, required=True)
    parser.add_argument("--markdown", type=Path, required=True)
    args = parser.parse_args(argv)
    runs, failed = load(args.folder)
    table = ab.summarize(runs)
    accounting = ab.accounting(runs)
    args.json.write_text(
        json.dumps(
            {"budgets": list(ab.BUDGETS), "accounting": accounting, "failed_problems": failed,
             "rules": ab.rule_reference(runs),
             "table": table}, indent=1, sort_keys=True) + "\n"
    )  # fmt: skip
    args.markdown.write_text(markdown(table, accounting, failed))
    return 0


def x_main__mutmut_4(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", type=None)
    parser.add_argument("--json", type=Path, required=True)
    parser.add_argument("--markdown", type=Path, required=True)
    args = parser.parse_args(argv)
    runs, failed = load(args.folder)
    table = ab.summarize(runs)
    accounting = ab.accounting(runs)
    args.json.write_text(
        json.dumps(
            {"budgets": list(ab.BUDGETS), "accounting": accounting, "failed_problems": failed,
             "rules": ab.rule_reference(runs),
             "table": table}, indent=1, sort_keys=True) + "\n"
    )  # fmt: skip
    args.markdown.write_text(markdown(table, accounting, failed))
    return 0


def x_main__mutmut_5(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(type=Path)
    parser.add_argument("--json", type=Path, required=True)
    parser.add_argument("--markdown", type=Path, required=True)
    args = parser.parse_args(argv)
    runs, failed = load(args.folder)
    table = ab.summarize(runs)
    accounting = ab.accounting(runs)
    args.json.write_text(
        json.dumps(
            {"budgets": list(ab.BUDGETS), "accounting": accounting, "failed_problems": failed,
             "rules": ab.rule_reference(runs),
             "table": table}, indent=1, sort_keys=True) + "\n"
    )  # fmt: skip
    args.markdown.write_text(markdown(table, accounting, failed))
    return 0


def x_main__mutmut_6(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", )
    parser.add_argument("--json", type=Path, required=True)
    parser.add_argument("--markdown", type=Path, required=True)
    args = parser.parse_args(argv)
    runs, failed = load(args.folder)
    table = ab.summarize(runs)
    accounting = ab.accounting(runs)
    args.json.write_text(
        json.dumps(
            {"budgets": list(ab.BUDGETS), "accounting": accounting, "failed_problems": failed,
             "rules": ab.rule_reference(runs),
             "table": table}, indent=1, sort_keys=True) + "\n"
    )  # fmt: skip
    args.markdown.write_text(markdown(table, accounting, failed))
    return 0


def x_main__mutmut_7(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("XXfolderXX", type=Path)
    parser.add_argument("--json", type=Path, required=True)
    parser.add_argument("--markdown", type=Path, required=True)
    args = parser.parse_args(argv)
    runs, failed = load(args.folder)
    table = ab.summarize(runs)
    accounting = ab.accounting(runs)
    args.json.write_text(
        json.dumps(
            {"budgets": list(ab.BUDGETS), "accounting": accounting, "failed_problems": failed,
             "rules": ab.rule_reference(runs),
             "table": table}, indent=1, sort_keys=True) + "\n"
    )  # fmt: skip
    args.markdown.write_text(markdown(table, accounting, failed))
    return 0


def x_main__mutmut_8(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("FOLDER", type=Path)
    parser.add_argument("--json", type=Path, required=True)
    parser.add_argument("--markdown", type=Path, required=True)
    args = parser.parse_args(argv)
    runs, failed = load(args.folder)
    table = ab.summarize(runs)
    accounting = ab.accounting(runs)
    args.json.write_text(
        json.dumps(
            {"budgets": list(ab.BUDGETS), "accounting": accounting, "failed_problems": failed,
             "rules": ab.rule_reference(runs),
             "table": table}, indent=1, sort_keys=True) + "\n"
    )  # fmt: skip
    args.markdown.write_text(markdown(table, accounting, failed))
    return 0


def x_main__mutmut_9(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", type=Path)
    parser.add_argument(None, type=Path, required=True)
    parser.add_argument("--markdown", type=Path, required=True)
    args = parser.parse_args(argv)
    runs, failed = load(args.folder)
    table = ab.summarize(runs)
    accounting = ab.accounting(runs)
    args.json.write_text(
        json.dumps(
            {"budgets": list(ab.BUDGETS), "accounting": accounting, "failed_problems": failed,
             "rules": ab.rule_reference(runs),
             "table": table}, indent=1, sort_keys=True) + "\n"
    )  # fmt: skip
    args.markdown.write_text(markdown(table, accounting, failed))
    return 0


def x_main__mutmut_10(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", type=Path)
    parser.add_argument("--json", type=None, required=True)
    parser.add_argument("--markdown", type=Path, required=True)
    args = parser.parse_args(argv)
    runs, failed = load(args.folder)
    table = ab.summarize(runs)
    accounting = ab.accounting(runs)
    args.json.write_text(
        json.dumps(
            {"budgets": list(ab.BUDGETS), "accounting": accounting, "failed_problems": failed,
             "rules": ab.rule_reference(runs),
             "table": table}, indent=1, sort_keys=True) + "\n"
    )  # fmt: skip
    args.markdown.write_text(markdown(table, accounting, failed))
    return 0


def x_main__mutmut_11(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", type=Path)
    parser.add_argument("--json", type=Path, required=None)
    parser.add_argument("--markdown", type=Path, required=True)
    args = parser.parse_args(argv)
    runs, failed = load(args.folder)
    table = ab.summarize(runs)
    accounting = ab.accounting(runs)
    args.json.write_text(
        json.dumps(
            {"budgets": list(ab.BUDGETS), "accounting": accounting, "failed_problems": failed,
             "rules": ab.rule_reference(runs),
             "table": table}, indent=1, sort_keys=True) + "\n"
    )  # fmt: skip
    args.markdown.write_text(markdown(table, accounting, failed))
    return 0


def x_main__mutmut_12(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", type=Path)
    parser.add_argument(type=Path, required=True)
    parser.add_argument("--markdown", type=Path, required=True)
    args = parser.parse_args(argv)
    runs, failed = load(args.folder)
    table = ab.summarize(runs)
    accounting = ab.accounting(runs)
    args.json.write_text(
        json.dumps(
            {"budgets": list(ab.BUDGETS), "accounting": accounting, "failed_problems": failed,
             "rules": ab.rule_reference(runs),
             "table": table}, indent=1, sort_keys=True) + "\n"
    )  # fmt: skip
    args.markdown.write_text(markdown(table, accounting, failed))
    return 0


def x_main__mutmut_13(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", type=Path)
    parser.add_argument("--json", required=True)
    parser.add_argument("--markdown", type=Path, required=True)
    args = parser.parse_args(argv)
    runs, failed = load(args.folder)
    table = ab.summarize(runs)
    accounting = ab.accounting(runs)
    args.json.write_text(
        json.dumps(
            {"budgets": list(ab.BUDGETS), "accounting": accounting, "failed_problems": failed,
             "rules": ab.rule_reference(runs),
             "table": table}, indent=1, sort_keys=True) + "\n"
    )  # fmt: skip
    args.markdown.write_text(markdown(table, accounting, failed))
    return 0


def x_main__mutmut_14(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", type=Path)
    parser.add_argument("--json", type=Path, )
    parser.add_argument("--markdown", type=Path, required=True)
    args = parser.parse_args(argv)
    runs, failed = load(args.folder)
    table = ab.summarize(runs)
    accounting = ab.accounting(runs)
    args.json.write_text(
        json.dumps(
            {"budgets": list(ab.BUDGETS), "accounting": accounting, "failed_problems": failed,
             "rules": ab.rule_reference(runs),
             "table": table}, indent=1, sort_keys=True) + "\n"
    )  # fmt: skip
    args.markdown.write_text(markdown(table, accounting, failed))
    return 0


def x_main__mutmut_15(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", type=Path)
    parser.add_argument("XX--jsonXX", type=Path, required=True)
    parser.add_argument("--markdown", type=Path, required=True)
    args = parser.parse_args(argv)
    runs, failed = load(args.folder)
    table = ab.summarize(runs)
    accounting = ab.accounting(runs)
    args.json.write_text(
        json.dumps(
            {"budgets": list(ab.BUDGETS), "accounting": accounting, "failed_problems": failed,
             "rules": ab.rule_reference(runs),
             "table": table}, indent=1, sort_keys=True) + "\n"
    )  # fmt: skip
    args.markdown.write_text(markdown(table, accounting, failed))
    return 0


def x_main__mutmut_16(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", type=Path)
    parser.add_argument("--JSON", type=Path, required=True)
    parser.add_argument("--markdown", type=Path, required=True)
    args = parser.parse_args(argv)
    runs, failed = load(args.folder)
    table = ab.summarize(runs)
    accounting = ab.accounting(runs)
    args.json.write_text(
        json.dumps(
            {"budgets": list(ab.BUDGETS), "accounting": accounting, "failed_problems": failed,
             "rules": ab.rule_reference(runs),
             "table": table}, indent=1, sort_keys=True) + "\n"
    )  # fmt: skip
    args.markdown.write_text(markdown(table, accounting, failed))
    return 0


def x_main__mutmut_17(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", type=Path)
    parser.add_argument("--json", type=Path, required=False)
    parser.add_argument("--markdown", type=Path, required=True)
    args = parser.parse_args(argv)
    runs, failed = load(args.folder)
    table = ab.summarize(runs)
    accounting = ab.accounting(runs)
    args.json.write_text(
        json.dumps(
            {"budgets": list(ab.BUDGETS), "accounting": accounting, "failed_problems": failed,
             "rules": ab.rule_reference(runs),
             "table": table}, indent=1, sort_keys=True) + "\n"
    )  # fmt: skip
    args.markdown.write_text(markdown(table, accounting, failed))
    return 0


def x_main__mutmut_18(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", type=Path)
    parser.add_argument("--json", type=Path, required=True)
    parser.add_argument(None, type=Path, required=True)
    args = parser.parse_args(argv)
    runs, failed = load(args.folder)
    table = ab.summarize(runs)
    accounting = ab.accounting(runs)
    args.json.write_text(
        json.dumps(
            {"budgets": list(ab.BUDGETS), "accounting": accounting, "failed_problems": failed,
             "rules": ab.rule_reference(runs),
             "table": table}, indent=1, sort_keys=True) + "\n"
    )  # fmt: skip
    args.markdown.write_text(markdown(table, accounting, failed))
    return 0


def x_main__mutmut_19(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", type=Path)
    parser.add_argument("--json", type=Path, required=True)
    parser.add_argument("--markdown", type=None, required=True)
    args = parser.parse_args(argv)
    runs, failed = load(args.folder)
    table = ab.summarize(runs)
    accounting = ab.accounting(runs)
    args.json.write_text(
        json.dumps(
            {"budgets": list(ab.BUDGETS), "accounting": accounting, "failed_problems": failed,
             "rules": ab.rule_reference(runs),
             "table": table}, indent=1, sort_keys=True) + "\n"
    )  # fmt: skip
    args.markdown.write_text(markdown(table, accounting, failed))
    return 0


def x_main__mutmut_20(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", type=Path)
    parser.add_argument("--json", type=Path, required=True)
    parser.add_argument("--markdown", type=Path, required=None)
    args = parser.parse_args(argv)
    runs, failed = load(args.folder)
    table = ab.summarize(runs)
    accounting = ab.accounting(runs)
    args.json.write_text(
        json.dumps(
            {"budgets": list(ab.BUDGETS), "accounting": accounting, "failed_problems": failed,
             "rules": ab.rule_reference(runs),
             "table": table}, indent=1, sort_keys=True) + "\n"
    )  # fmt: skip
    args.markdown.write_text(markdown(table, accounting, failed))
    return 0


def x_main__mutmut_21(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", type=Path)
    parser.add_argument("--json", type=Path, required=True)
    parser.add_argument(type=Path, required=True)
    args = parser.parse_args(argv)
    runs, failed = load(args.folder)
    table = ab.summarize(runs)
    accounting = ab.accounting(runs)
    args.json.write_text(
        json.dumps(
            {"budgets": list(ab.BUDGETS), "accounting": accounting, "failed_problems": failed,
             "rules": ab.rule_reference(runs),
             "table": table}, indent=1, sort_keys=True) + "\n"
    )  # fmt: skip
    args.markdown.write_text(markdown(table, accounting, failed))
    return 0


def x_main__mutmut_22(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", type=Path)
    parser.add_argument("--json", type=Path, required=True)
    parser.add_argument("--markdown", required=True)
    args = parser.parse_args(argv)
    runs, failed = load(args.folder)
    table = ab.summarize(runs)
    accounting = ab.accounting(runs)
    args.json.write_text(
        json.dumps(
            {"budgets": list(ab.BUDGETS), "accounting": accounting, "failed_problems": failed,
             "rules": ab.rule_reference(runs),
             "table": table}, indent=1, sort_keys=True) + "\n"
    )  # fmt: skip
    args.markdown.write_text(markdown(table, accounting, failed))
    return 0


def x_main__mutmut_23(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", type=Path)
    parser.add_argument("--json", type=Path, required=True)
    parser.add_argument("--markdown", type=Path, )
    args = parser.parse_args(argv)
    runs, failed = load(args.folder)
    table = ab.summarize(runs)
    accounting = ab.accounting(runs)
    args.json.write_text(
        json.dumps(
            {"budgets": list(ab.BUDGETS), "accounting": accounting, "failed_problems": failed,
             "rules": ab.rule_reference(runs),
             "table": table}, indent=1, sort_keys=True) + "\n"
    )  # fmt: skip
    args.markdown.write_text(markdown(table, accounting, failed))
    return 0


def x_main__mutmut_24(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", type=Path)
    parser.add_argument("--json", type=Path, required=True)
    parser.add_argument("XX--markdownXX", type=Path, required=True)
    args = parser.parse_args(argv)
    runs, failed = load(args.folder)
    table = ab.summarize(runs)
    accounting = ab.accounting(runs)
    args.json.write_text(
        json.dumps(
            {"budgets": list(ab.BUDGETS), "accounting": accounting, "failed_problems": failed,
             "rules": ab.rule_reference(runs),
             "table": table}, indent=1, sort_keys=True) + "\n"
    )  # fmt: skip
    args.markdown.write_text(markdown(table, accounting, failed))
    return 0


def x_main__mutmut_25(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", type=Path)
    parser.add_argument("--json", type=Path, required=True)
    parser.add_argument("--MARKDOWN", type=Path, required=True)
    args = parser.parse_args(argv)
    runs, failed = load(args.folder)
    table = ab.summarize(runs)
    accounting = ab.accounting(runs)
    args.json.write_text(
        json.dumps(
            {"budgets": list(ab.BUDGETS), "accounting": accounting, "failed_problems": failed,
             "rules": ab.rule_reference(runs),
             "table": table}, indent=1, sort_keys=True) + "\n"
    )  # fmt: skip
    args.markdown.write_text(markdown(table, accounting, failed))
    return 0


def x_main__mutmut_26(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", type=Path)
    parser.add_argument("--json", type=Path, required=True)
    parser.add_argument("--markdown", type=Path, required=False)
    args = parser.parse_args(argv)
    runs, failed = load(args.folder)
    table = ab.summarize(runs)
    accounting = ab.accounting(runs)
    args.json.write_text(
        json.dumps(
            {"budgets": list(ab.BUDGETS), "accounting": accounting, "failed_problems": failed,
             "rules": ab.rule_reference(runs),
             "table": table}, indent=1, sort_keys=True) + "\n"
    )  # fmt: skip
    args.markdown.write_text(markdown(table, accounting, failed))
    return 0


def x_main__mutmut_27(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", type=Path)
    parser.add_argument("--json", type=Path, required=True)
    parser.add_argument("--markdown", type=Path, required=True)
    args = None
    runs, failed = load(args.folder)
    table = ab.summarize(runs)
    accounting = ab.accounting(runs)
    args.json.write_text(
        json.dumps(
            {"budgets": list(ab.BUDGETS), "accounting": accounting, "failed_problems": failed,
             "rules": ab.rule_reference(runs),
             "table": table}, indent=1, sort_keys=True) + "\n"
    )  # fmt: skip
    args.markdown.write_text(markdown(table, accounting, failed))
    return 0


def x_main__mutmut_28(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", type=Path)
    parser.add_argument("--json", type=Path, required=True)
    parser.add_argument("--markdown", type=Path, required=True)
    args = parser.parse_args(None)
    runs, failed = load(args.folder)
    table = ab.summarize(runs)
    accounting = ab.accounting(runs)
    args.json.write_text(
        json.dumps(
            {"budgets": list(ab.BUDGETS), "accounting": accounting, "failed_problems": failed,
             "rules": ab.rule_reference(runs),
             "table": table}, indent=1, sort_keys=True) + "\n"
    )  # fmt: skip
    args.markdown.write_text(markdown(table, accounting, failed))
    return 0


def x_main__mutmut_29(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", type=Path)
    parser.add_argument("--json", type=Path, required=True)
    parser.add_argument("--markdown", type=Path, required=True)
    args = parser.parse_args(argv)
    runs, failed = None
    table = ab.summarize(runs)
    accounting = ab.accounting(runs)
    args.json.write_text(
        json.dumps(
            {"budgets": list(ab.BUDGETS), "accounting": accounting, "failed_problems": failed,
             "rules": ab.rule_reference(runs),
             "table": table}, indent=1, sort_keys=True) + "\n"
    )  # fmt: skip
    args.markdown.write_text(markdown(table, accounting, failed))
    return 0


def x_main__mutmut_30(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", type=Path)
    parser.add_argument("--json", type=Path, required=True)
    parser.add_argument("--markdown", type=Path, required=True)
    args = parser.parse_args(argv)
    runs, failed = load(None)
    table = ab.summarize(runs)
    accounting = ab.accounting(runs)
    args.json.write_text(
        json.dumps(
            {"budgets": list(ab.BUDGETS), "accounting": accounting, "failed_problems": failed,
             "rules": ab.rule_reference(runs),
             "table": table}, indent=1, sort_keys=True) + "\n"
    )  # fmt: skip
    args.markdown.write_text(markdown(table, accounting, failed))
    return 0


def x_main__mutmut_31(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", type=Path)
    parser.add_argument("--json", type=Path, required=True)
    parser.add_argument("--markdown", type=Path, required=True)
    args = parser.parse_args(argv)
    runs, failed = load(args.folder)
    table = None
    accounting = ab.accounting(runs)
    args.json.write_text(
        json.dumps(
            {"budgets": list(ab.BUDGETS), "accounting": accounting, "failed_problems": failed,
             "rules": ab.rule_reference(runs),
             "table": table}, indent=1, sort_keys=True) + "\n"
    )  # fmt: skip
    args.markdown.write_text(markdown(table, accounting, failed))
    return 0


def x_main__mutmut_32(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", type=Path)
    parser.add_argument("--json", type=Path, required=True)
    parser.add_argument("--markdown", type=Path, required=True)
    args = parser.parse_args(argv)
    runs, failed = load(args.folder)
    table = ab.summarize(None)
    accounting = ab.accounting(runs)
    args.json.write_text(
        json.dumps(
            {"budgets": list(ab.BUDGETS), "accounting": accounting, "failed_problems": failed,
             "rules": ab.rule_reference(runs),
             "table": table}, indent=1, sort_keys=True) + "\n"
    )  # fmt: skip
    args.markdown.write_text(markdown(table, accounting, failed))
    return 0


def x_main__mutmut_33(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", type=Path)
    parser.add_argument("--json", type=Path, required=True)
    parser.add_argument("--markdown", type=Path, required=True)
    args = parser.parse_args(argv)
    runs, failed = load(args.folder)
    table = ab.summarize(runs)
    accounting = None
    args.json.write_text(
        json.dumps(
            {"budgets": list(ab.BUDGETS), "accounting": accounting, "failed_problems": failed,
             "rules": ab.rule_reference(runs),
             "table": table}, indent=1, sort_keys=True) + "\n"
    )  # fmt: skip
    args.markdown.write_text(markdown(table, accounting, failed))
    return 0


def x_main__mutmut_34(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", type=Path)
    parser.add_argument("--json", type=Path, required=True)
    parser.add_argument("--markdown", type=Path, required=True)
    args = parser.parse_args(argv)
    runs, failed = load(args.folder)
    table = ab.summarize(runs)
    accounting = ab.accounting(None)
    args.json.write_text(
        json.dumps(
            {"budgets": list(ab.BUDGETS), "accounting": accounting, "failed_problems": failed,
             "rules": ab.rule_reference(runs),
             "table": table}, indent=1, sort_keys=True) + "\n"
    )  # fmt: skip
    args.markdown.write_text(markdown(table, accounting, failed))
    return 0


def x_main__mutmut_35(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", type=Path)
    parser.add_argument("--json", type=Path, required=True)
    parser.add_argument("--markdown", type=Path, required=True)
    args = parser.parse_args(argv)
    runs, failed = load(args.folder)
    table = ab.summarize(runs)
    accounting = ab.accounting(runs)
    args.json.write_text(
        None
    )  # fmt: skip
    args.markdown.write_text(markdown(table, accounting, failed))
    return 0


def x_main__mutmut_36(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", type=Path)
    parser.add_argument("--json", type=Path, required=True)
    parser.add_argument("--markdown", type=Path, required=True)
    args = parser.parse_args(argv)
    runs, failed = load(args.folder)
    table = ab.summarize(runs)
    accounting = ab.accounting(runs)
    args.json.write_text(
        json.dumps(
            {"budgets": list(ab.BUDGETS), "accounting": accounting, "failed_problems": failed,
             "rules": ab.rule_reference(runs),
             "table": table}, indent=1, sort_keys=True) - "\n"
    )  # fmt: skip
    args.markdown.write_text(markdown(table, accounting, failed))
    return 0


def x_main__mutmut_37(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", type=Path)
    parser.add_argument("--json", type=Path, required=True)
    parser.add_argument("--markdown", type=Path, required=True)
    args = parser.parse_args(argv)
    runs, failed = load(args.folder)
    table = ab.summarize(runs)
    accounting = ab.accounting(runs)
    args.json.write_text(
        json.dumps(
            None, indent=1, sort_keys=True) + "\n"
    )  # fmt: skip
    args.markdown.write_text(markdown(table, accounting, failed))
    return 0


def x_main__mutmut_38(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", type=Path)
    parser.add_argument("--json", type=Path, required=True)
    parser.add_argument("--markdown", type=Path, required=True)
    args = parser.parse_args(argv)
    runs, failed = load(args.folder)
    table = ab.summarize(runs)
    accounting = ab.accounting(runs)
    args.json.write_text(
        json.dumps(
            {"budgets": list(ab.BUDGETS), "accounting": accounting, "failed_problems": failed,
             "rules": ab.rule_reference(runs),
             "table": table}, indent=None, sort_keys=True) + "\n"
    )  # fmt: skip
    args.markdown.write_text(markdown(table, accounting, failed))
    return 0


def x_main__mutmut_39(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", type=Path)
    parser.add_argument("--json", type=Path, required=True)
    parser.add_argument("--markdown", type=Path, required=True)
    args = parser.parse_args(argv)
    runs, failed = load(args.folder)
    table = ab.summarize(runs)
    accounting = ab.accounting(runs)
    args.json.write_text(
        json.dumps(
            {"budgets": list(ab.BUDGETS), "accounting": accounting, "failed_problems": failed,
             "rules": ab.rule_reference(runs),
             "table": table}, indent=1, sort_keys=None) + "\n"
    )  # fmt: skip
    args.markdown.write_text(markdown(table, accounting, failed))
    return 0


def x_main__mutmut_40(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", type=Path)
    parser.add_argument("--json", type=Path, required=True)
    parser.add_argument("--markdown", type=Path, required=True)
    args = parser.parse_args(argv)
    runs, failed = load(args.folder)
    table = ab.summarize(runs)
    accounting = ab.accounting(runs)
    args.json.write_text(
        json.dumps(
            indent=1, sort_keys=True) + "\n"
    )  # fmt: skip
    args.markdown.write_text(markdown(table, accounting, failed))
    return 0


def x_main__mutmut_41(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", type=Path)
    parser.add_argument("--json", type=Path, required=True)
    parser.add_argument("--markdown", type=Path, required=True)
    args = parser.parse_args(argv)
    runs, failed = load(args.folder)
    table = ab.summarize(runs)
    accounting = ab.accounting(runs)
    args.json.write_text(
        json.dumps(
            {"budgets": list(ab.BUDGETS), "accounting": accounting, "failed_problems": failed,
             "rules": ab.rule_reference(runs),
             "table": table}, sort_keys=True) + "\n"
    )  # fmt: skip
    args.markdown.write_text(markdown(table, accounting, failed))
    return 0


def x_main__mutmut_42(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", type=Path)
    parser.add_argument("--json", type=Path, required=True)
    parser.add_argument("--markdown", type=Path, required=True)
    args = parser.parse_args(argv)
    runs, failed = load(args.folder)
    table = ab.summarize(runs)
    accounting = ab.accounting(runs)
    args.json.write_text(
        json.dumps(
            {"budgets": list(ab.BUDGETS), "accounting": accounting, "failed_problems": failed,
             "rules": ab.rule_reference(runs),
             "table": table}, indent=1, ) + "\n"
    )  # fmt: skip
    args.markdown.write_text(markdown(table, accounting, failed))
    return 0


def x_main__mutmut_43(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", type=Path)
    parser.add_argument("--json", type=Path, required=True)
    parser.add_argument("--markdown", type=Path, required=True)
    args = parser.parse_args(argv)
    runs, failed = load(args.folder)
    table = ab.summarize(runs)
    accounting = ab.accounting(runs)
    args.json.write_text(
        json.dumps(
            {"XXbudgetsXX": list(ab.BUDGETS), "accounting": accounting, "failed_problems": failed,
             "rules": ab.rule_reference(runs),
             "table": table}, indent=1, sort_keys=True) + "\n"
    )  # fmt: skip
    args.markdown.write_text(markdown(table, accounting, failed))
    return 0


def x_main__mutmut_44(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", type=Path)
    parser.add_argument("--json", type=Path, required=True)
    parser.add_argument("--markdown", type=Path, required=True)
    args = parser.parse_args(argv)
    runs, failed = load(args.folder)
    table = ab.summarize(runs)
    accounting = ab.accounting(runs)
    args.json.write_text(
        json.dumps(
            {"BUDGETS": list(ab.BUDGETS), "accounting": accounting, "failed_problems": failed,
             "rules": ab.rule_reference(runs),
             "table": table}, indent=1, sort_keys=True) + "\n"
    )  # fmt: skip
    args.markdown.write_text(markdown(table, accounting, failed))
    return 0


def x_main__mutmut_45(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", type=Path)
    parser.add_argument("--json", type=Path, required=True)
    parser.add_argument("--markdown", type=Path, required=True)
    args = parser.parse_args(argv)
    runs, failed = load(args.folder)
    table = ab.summarize(runs)
    accounting = ab.accounting(runs)
    args.json.write_text(
        json.dumps(
            {"budgets": list(None), "accounting": accounting, "failed_problems": failed,
             "rules": ab.rule_reference(runs),
             "table": table}, indent=1, sort_keys=True) + "\n"
    )  # fmt: skip
    args.markdown.write_text(markdown(table, accounting, failed))
    return 0


def x_main__mutmut_46(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", type=Path)
    parser.add_argument("--json", type=Path, required=True)
    parser.add_argument("--markdown", type=Path, required=True)
    args = parser.parse_args(argv)
    runs, failed = load(args.folder)
    table = ab.summarize(runs)
    accounting = ab.accounting(runs)
    args.json.write_text(
        json.dumps(
            {"budgets": list(ab.BUDGETS), "XXaccountingXX": accounting, "failed_problems": failed,
             "rules": ab.rule_reference(runs),
             "table": table}, indent=1, sort_keys=True) + "\n"
    )  # fmt: skip
    args.markdown.write_text(markdown(table, accounting, failed))
    return 0


def x_main__mutmut_47(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", type=Path)
    parser.add_argument("--json", type=Path, required=True)
    parser.add_argument("--markdown", type=Path, required=True)
    args = parser.parse_args(argv)
    runs, failed = load(args.folder)
    table = ab.summarize(runs)
    accounting = ab.accounting(runs)
    args.json.write_text(
        json.dumps(
            {"budgets": list(ab.BUDGETS), "ACCOUNTING": accounting, "failed_problems": failed,
             "rules": ab.rule_reference(runs),
             "table": table}, indent=1, sort_keys=True) + "\n"
    )  # fmt: skip
    args.markdown.write_text(markdown(table, accounting, failed))
    return 0


def x_main__mutmut_48(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", type=Path)
    parser.add_argument("--json", type=Path, required=True)
    parser.add_argument("--markdown", type=Path, required=True)
    args = parser.parse_args(argv)
    runs, failed = load(args.folder)
    table = ab.summarize(runs)
    accounting = ab.accounting(runs)
    args.json.write_text(
        json.dumps(
            {"budgets": list(ab.BUDGETS), "accounting": accounting, "XXfailed_problemsXX": failed,
             "rules": ab.rule_reference(runs),
             "table": table}, indent=1, sort_keys=True) + "\n"
    )  # fmt: skip
    args.markdown.write_text(markdown(table, accounting, failed))
    return 0


def x_main__mutmut_49(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", type=Path)
    parser.add_argument("--json", type=Path, required=True)
    parser.add_argument("--markdown", type=Path, required=True)
    args = parser.parse_args(argv)
    runs, failed = load(args.folder)
    table = ab.summarize(runs)
    accounting = ab.accounting(runs)
    args.json.write_text(
        json.dumps(
            {"budgets": list(ab.BUDGETS), "accounting": accounting, "FAILED_PROBLEMS": failed,
             "rules": ab.rule_reference(runs),
             "table": table}, indent=1, sort_keys=True) + "\n"
    )  # fmt: skip
    args.markdown.write_text(markdown(table, accounting, failed))
    return 0


def x_main__mutmut_50(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", type=Path)
    parser.add_argument("--json", type=Path, required=True)
    parser.add_argument("--markdown", type=Path, required=True)
    args = parser.parse_args(argv)
    runs, failed = load(args.folder)
    table = ab.summarize(runs)
    accounting = ab.accounting(runs)
    args.json.write_text(
        json.dumps(
            {"budgets": list(ab.BUDGETS), "accounting": accounting, "failed_problems": failed,
             "XXrulesXX": ab.rule_reference(runs),
             "table": table}, indent=1, sort_keys=True) + "\n"
    )  # fmt: skip
    args.markdown.write_text(markdown(table, accounting, failed))
    return 0


def x_main__mutmut_51(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", type=Path)
    parser.add_argument("--json", type=Path, required=True)
    parser.add_argument("--markdown", type=Path, required=True)
    args = parser.parse_args(argv)
    runs, failed = load(args.folder)
    table = ab.summarize(runs)
    accounting = ab.accounting(runs)
    args.json.write_text(
        json.dumps(
            {"budgets": list(ab.BUDGETS), "accounting": accounting, "failed_problems": failed,
             "RULES": ab.rule_reference(runs),
             "table": table}, indent=1, sort_keys=True) + "\n"
    )  # fmt: skip
    args.markdown.write_text(markdown(table, accounting, failed))
    return 0


def x_main__mutmut_52(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", type=Path)
    parser.add_argument("--json", type=Path, required=True)
    parser.add_argument("--markdown", type=Path, required=True)
    args = parser.parse_args(argv)
    runs, failed = load(args.folder)
    table = ab.summarize(runs)
    accounting = ab.accounting(runs)
    args.json.write_text(
        json.dumps(
            {"budgets": list(ab.BUDGETS), "accounting": accounting, "failed_problems": failed,
             "rules": ab.rule_reference(None),
             "table": table}, indent=1, sort_keys=True) + "\n"
    )  # fmt: skip
    args.markdown.write_text(markdown(table, accounting, failed))
    return 0


def x_main__mutmut_53(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", type=Path)
    parser.add_argument("--json", type=Path, required=True)
    parser.add_argument("--markdown", type=Path, required=True)
    args = parser.parse_args(argv)
    runs, failed = load(args.folder)
    table = ab.summarize(runs)
    accounting = ab.accounting(runs)
    args.json.write_text(
        json.dumps(
            {"budgets": list(ab.BUDGETS), "accounting": accounting, "failed_problems": failed,
             "rules": ab.rule_reference(runs),
             "XXtableXX": table}, indent=1, sort_keys=True) + "\n"
    )  # fmt: skip
    args.markdown.write_text(markdown(table, accounting, failed))
    return 0


def x_main__mutmut_54(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", type=Path)
    parser.add_argument("--json", type=Path, required=True)
    parser.add_argument("--markdown", type=Path, required=True)
    args = parser.parse_args(argv)
    runs, failed = load(args.folder)
    table = ab.summarize(runs)
    accounting = ab.accounting(runs)
    args.json.write_text(
        json.dumps(
            {"budgets": list(ab.BUDGETS), "accounting": accounting, "failed_problems": failed,
             "rules": ab.rule_reference(runs),
             "TABLE": table}, indent=1, sort_keys=True) + "\n"
    )  # fmt: skip
    args.markdown.write_text(markdown(table, accounting, failed))
    return 0


def x_main__mutmut_55(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", type=Path)
    parser.add_argument("--json", type=Path, required=True)
    parser.add_argument("--markdown", type=Path, required=True)
    args = parser.parse_args(argv)
    runs, failed = load(args.folder)
    table = ab.summarize(runs)
    accounting = ab.accounting(runs)
    args.json.write_text(
        json.dumps(
            {"budgets": list(ab.BUDGETS), "accounting": accounting, "failed_problems": failed,
             "rules": ab.rule_reference(runs),
             "table": table}, indent=2, sort_keys=True) + "\n"
    )  # fmt: skip
    args.markdown.write_text(markdown(table, accounting, failed))
    return 0


def x_main__mutmut_56(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", type=Path)
    parser.add_argument("--json", type=Path, required=True)
    parser.add_argument("--markdown", type=Path, required=True)
    args = parser.parse_args(argv)
    runs, failed = load(args.folder)
    table = ab.summarize(runs)
    accounting = ab.accounting(runs)
    args.json.write_text(
        json.dumps(
            {"budgets": list(ab.BUDGETS), "accounting": accounting, "failed_problems": failed,
             "rules": ab.rule_reference(runs),
             "table": table}, indent=1, sort_keys=False) + "\n"
    )  # fmt: skip
    args.markdown.write_text(markdown(table, accounting, failed))
    return 0


def x_main__mutmut_57(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", type=Path)
    parser.add_argument("--json", type=Path, required=True)
    parser.add_argument("--markdown", type=Path, required=True)
    args = parser.parse_args(argv)
    runs, failed = load(args.folder)
    table = ab.summarize(runs)
    accounting = ab.accounting(runs)
    args.json.write_text(
        json.dumps(
            {"budgets": list(ab.BUDGETS), "accounting": accounting, "failed_problems": failed,
             "rules": ab.rule_reference(runs),
             "table": table}, indent=1, sort_keys=True) + "XX\nXX"
    )  # fmt: skip
    args.markdown.write_text(markdown(table, accounting, failed))
    return 0


def x_main__mutmut_58(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", type=Path)
    parser.add_argument("--json", type=Path, required=True)
    parser.add_argument("--markdown", type=Path, required=True)
    args = parser.parse_args(argv)
    runs, failed = load(args.folder)
    table = ab.summarize(runs)
    accounting = ab.accounting(runs)
    args.json.write_text(
        json.dumps(
            {"budgets": list(ab.BUDGETS), "accounting": accounting, "failed_problems": failed,
             "rules": ab.rule_reference(runs),
             "table": table}, indent=1, sort_keys=True) + "\n"
    )  # fmt: skip
    args.markdown.write_text(None)
    return 0


def x_main__mutmut_59(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", type=Path)
    parser.add_argument("--json", type=Path, required=True)
    parser.add_argument("--markdown", type=Path, required=True)
    args = parser.parse_args(argv)
    runs, failed = load(args.folder)
    table = ab.summarize(runs)
    accounting = ab.accounting(runs)
    args.json.write_text(
        json.dumps(
            {"budgets": list(ab.BUDGETS), "accounting": accounting, "failed_problems": failed,
             "rules": ab.rule_reference(runs),
             "table": table}, indent=1, sort_keys=True) + "\n"
    )  # fmt: skip
    args.markdown.write_text(markdown(None, accounting, failed))
    return 0


def x_main__mutmut_60(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", type=Path)
    parser.add_argument("--json", type=Path, required=True)
    parser.add_argument("--markdown", type=Path, required=True)
    args = parser.parse_args(argv)
    runs, failed = load(args.folder)
    table = ab.summarize(runs)
    accounting = ab.accounting(runs)
    args.json.write_text(
        json.dumps(
            {"budgets": list(ab.BUDGETS), "accounting": accounting, "failed_problems": failed,
             "rules": ab.rule_reference(runs),
             "table": table}, indent=1, sort_keys=True) + "\n"
    )  # fmt: skip
    args.markdown.write_text(markdown(table, None, failed))
    return 0


def x_main__mutmut_61(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", type=Path)
    parser.add_argument("--json", type=Path, required=True)
    parser.add_argument("--markdown", type=Path, required=True)
    args = parser.parse_args(argv)
    runs, failed = load(args.folder)
    table = ab.summarize(runs)
    accounting = ab.accounting(runs)
    args.json.write_text(
        json.dumps(
            {"budgets": list(ab.BUDGETS), "accounting": accounting, "failed_problems": failed,
             "rules": ab.rule_reference(runs),
             "table": table}, indent=1, sort_keys=True) + "\n"
    )  # fmt: skip
    args.markdown.write_text(markdown(table, accounting, None))
    return 0


def x_main__mutmut_62(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", type=Path)
    parser.add_argument("--json", type=Path, required=True)
    parser.add_argument("--markdown", type=Path, required=True)
    args = parser.parse_args(argv)
    runs, failed = load(args.folder)
    table = ab.summarize(runs)
    accounting = ab.accounting(runs)
    args.json.write_text(
        json.dumps(
            {"budgets": list(ab.BUDGETS), "accounting": accounting, "failed_problems": failed,
             "rules": ab.rule_reference(runs),
             "table": table}, indent=1, sort_keys=True) + "\n"
    )  # fmt: skip
    args.markdown.write_text(markdown(accounting, failed))
    return 0


def x_main__mutmut_63(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", type=Path)
    parser.add_argument("--json", type=Path, required=True)
    parser.add_argument("--markdown", type=Path, required=True)
    args = parser.parse_args(argv)
    runs, failed = load(args.folder)
    table = ab.summarize(runs)
    accounting = ab.accounting(runs)
    args.json.write_text(
        json.dumps(
            {"budgets": list(ab.BUDGETS), "accounting": accounting, "failed_problems": failed,
             "rules": ab.rule_reference(runs),
             "table": table}, indent=1, sort_keys=True) + "\n"
    )  # fmt: skip
    args.markdown.write_text(markdown(table, failed))
    return 0


def x_main__mutmut_64(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", type=Path)
    parser.add_argument("--json", type=Path, required=True)
    parser.add_argument("--markdown", type=Path, required=True)
    args = parser.parse_args(argv)
    runs, failed = load(args.folder)
    table = ab.summarize(runs)
    accounting = ab.accounting(runs)
    args.json.write_text(
        json.dumps(
            {"budgets": list(ab.BUDGETS), "accounting": accounting, "failed_problems": failed,
             "rules": ab.rule_reference(runs),
             "table": table}, indent=1, sort_keys=True) + "\n"
    )  # fmt: skip
    args.markdown.write_text(markdown(table, accounting, ))
    return 0


def x_main__mutmut_65(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", type=Path)
    parser.add_argument("--json", type=Path, required=True)
    parser.add_argument("--markdown", type=Path, required=True)
    args = parser.parse_args(argv)
    runs, failed = load(args.folder)
    table = ab.summarize(runs)
    accounting = ab.accounting(runs)
    args.json.write_text(
        json.dumps(
            {"budgets": list(ab.BUDGETS), "accounting": accounting, "failed_problems": failed,
             "rules": ab.rule_reference(runs),
             "table": table}, indent=1, sort_keys=True) + "\n"
    )  # fmt: skip
    args.markdown.write_text(markdown(table, accounting, failed))
    return 1

mutants_x_main__mutmut['_mutmut_orig'] = x_main__mutmut_orig # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_1'] = x_main__mutmut_1 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_2'] = x_main__mutmut_2 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_3'] = x_main__mutmut_3 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_4'] = x_main__mutmut_4 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_5'] = x_main__mutmut_5 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_6'] = x_main__mutmut_6 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_7'] = x_main__mutmut_7 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_8'] = x_main__mutmut_8 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_9'] = x_main__mutmut_9 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_10'] = x_main__mutmut_10 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_11'] = x_main__mutmut_11 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_12'] = x_main__mutmut_12 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_13'] = x_main__mutmut_13 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_14'] = x_main__mutmut_14 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_15'] = x_main__mutmut_15 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_16'] = x_main__mutmut_16 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_17'] = x_main__mutmut_17 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_18'] = x_main__mutmut_18 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_19'] = x_main__mutmut_19 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_20'] = x_main__mutmut_20 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_21'] = x_main__mutmut_21 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_22'] = x_main__mutmut_22 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_23'] = x_main__mutmut_23 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_24'] = x_main__mutmut_24 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_25'] = x_main__mutmut_25 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_26'] = x_main__mutmut_26 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_27'] = x_main__mutmut_27 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_28'] = x_main__mutmut_28 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_29'] = x_main__mutmut_29 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_30'] = x_main__mutmut_30 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_31'] = x_main__mutmut_31 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_32'] = x_main__mutmut_32 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_33'] = x_main__mutmut_33 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_34'] = x_main__mutmut_34 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_35'] = x_main__mutmut_35 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_36'] = x_main__mutmut_36 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_37'] = x_main__mutmut_37 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_38'] = x_main__mutmut_38 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_39'] = x_main__mutmut_39 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_40'] = x_main__mutmut_40 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_41'] = x_main__mutmut_41 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_42'] = x_main__mutmut_42 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_43'] = x_main__mutmut_43 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_44'] = x_main__mutmut_44 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_45'] = x_main__mutmut_45 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_46'] = x_main__mutmut_46 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_47'] = x_main__mutmut_47 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_48'] = x_main__mutmut_48 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_49'] = x_main__mutmut_49 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_50'] = x_main__mutmut_50 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_51'] = x_main__mutmut_51 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_52'] = x_main__mutmut_52 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_53'] = x_main__mutmut_53 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_54'] = x_main__mutmut_54 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_55'] = x_main__mutmut_55 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_56'] = x_main__mutmut_56 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_57'] = x_main__mutmut_57 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_58'] = x_main__mutmut_58 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_59'] = x_main__mutmut_59 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_60'] = x_main__mutmut_60 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_61'] = x_main__mutmut_61 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_62'] = x_main__mutmut_62 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_63'] = x_main__mutmut_63 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_64'] = x_main__mutmut_64 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_65'] = x_main__mutmut_65 # type: ignore # mutmut generated


if __name__ == "__main__":
    raise SystemExit(main())
