"""Download the curated UCI sets, record their digests and the roles each can serve."""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path
from typing import Any

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import dataset_registry as dr  # noqa: E402
import normalise as nm  # noqa: E402
import uci_loader as ul  # noqa: E402


from mutmut.mutation.trampoline import wrap_in_trampoline as _mutmut_mutated, MutantDict
mutants_x_pool_row__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_pool_row__mutmut)
def pool_row(meta: dict[str, Any], path: Path, digest: str) -> dict[str, Any]:
    frame = ul.read_table(path)
    row: dict[str, Any] = {
        "uci_id": meta["uci_id"],
        "name": meta.get("name"),
        "licence": meta.get("licence"),
        "url": meta.get("data_url"),
        "sha256": digest,
        "roles": [],
    }
    try:
        features, _ = ul.split_columns(frame, meta)
        _, _, report = nm.clean(features, [0] * len(features))
        row["carrier"] = report
        row["roles"].append("carrier")
    except nm.NormaliseError as error:
        row["carrier_refused"] = str(error)
    try:
        features, labels, info = ul.derive_labels(frame, meta)
        x, y, report = nm.clean(features, labels)
        nm.split(x, y, 0)
        row.update(label={**info, **report}, roles=[*row["roles"], "labelled"])
        row["skipped_detectors"] = nm.skipped_detectors(int(0.7 * len(y)))
    except (ul.NoLabels, nm.NormaliseError) as error:
        row["label_refused"] = str(error)
    return row


def x_pool_row__mutmut_orig(meta: dict[str, Any], path: Path, digest: str) -> dict[str, Any]:
    frame = ul.read_table(path)
    row: dict[str, Any] = {
        "uci_id": meta["uci_id"],
        "name": meta.get("name"),
        "licence": meta.get("licence"),
        "url": meta.get("data_url"),
        "sha256": digest,
        "roles": [],
    }
    try:
        features, _ = ul.split_columns(frame, meta)
        _, _, report = nm.clean(features, [0] * len(features))
        row["carrier"] = report
        row["roles"].append("carrier")
    except nm.NormaliseError as error:
        row["carrier_refused"] = str(error)
    try:
        features, labels, info = ul.derive_labels(frame, meta)
        x, y, report = nm.clean(features, labels)
        nm.split(x, y, 0)
        row.update(label={**info, **report}, roles=[*row["roles"], "labelled"])
        row["skipped_detectors"] = nm.skipped_detectors(int(0.7 * len(y)))
    except (ul.NoLabels, nm.NormaliseError) as error:
        row["label_refused"] = str(error)
    return row


def x_pool_row__mutmut_1(meta: dict[str, Any], path: Path, digest: str) -> dict[str, Any]:
    frame = None
    row: dict[str, Any] = {
        "uci_id": meta["uci_id"],
        "name": meta.get("name"),
        "licence": meta.get("licence"),
        "url": meta.get("data_url"),
        "sha256": digest,
        "roles": [],
    }
    try:
        features, _ = ul.split_columns(frame, meta)
        _, _, report = nm.clean(features, [0] * len(features))
        row["carrier"] = report
        row["roles"].append("carrier")
    except nm.NormaliseError as error:
        row["carrier_refused"] = str(error)
    try:
        features, labels, info = ul.derive_labels(frame, meta)
        x, y, report = nm.clean(features, labels)
        nm.split(x, y, 0)
        row.update(label={**info, **report}, roles=[*row["roles"], "labelled"])
        row["skipped_detectors"] = nm.skipped_detectors(int(0.7 * len(y)))
    except (ul.NoLabels, nm.NormaliseError) as error:
        row["label_refused"] = str(error)
    return row


def x_pool_row__mutmut_2(meta: dict[str, Any], path: Path, digest: str) -> dict[str, Any]:
    frame = ul.read_table(None)
    row: dict[str, Any] = {
        "uci_id": meta["uci_id"],
        "name": meta.get("name"),
        "licence": meta.get("licence"),
        "url": meta.get("data_url"),
        "sha256": digest,
        "roles": [],
    }
    try:
        features, _ = ul.split_columns(frame, meta)
        _, _, report = nm.clean(features, [0] * len(features))
        row["carrier"] = report
        row["roles"].append("carrier")
    except nm.NormaliseError as error:
        row["carrier_refused"] = str(error)
    try:
        features, labels, info = ul.derive_labels(frame, meta)
        x, y, report = nm.clean(features, labels)
        nm.split(x, y, 0)
        row.update(label={**info, **report}, roles=[*row["roles"], "labelled"])
        row["skipped_detectors"] = nm.skipped_detectors(int(0.7 * len(y)))
    except (ul.NoLabels, nm.NormaliseError) as error:
        row["label_refused"] = str(error)
    return row


def x_pool_row__mutmut_3(meta: dict[str, Any], path: Path, digest: str) -> dict[str, Any]:
    frame = ul.read_table(path)
    row: dict[str, Any] = None
    try:
        features, _ = ul.split_columns(frame, meta)
        _, _, report = nm.clean(features, [0] * len(features))
        row["carrier"] = report
        row["roles"].append("carrier")
    except nm.NormaliseError as error:
        row["carrier_refused"] = str(error)
    try:
        features, labels, info = ul.derive_labels(frame, meta)
        x, y, report = nm.clean(features, labels)
        nm.split(x, y, 0)
        row.update(label={**info, **report}, roles=[*row["roles"], "labelled"])
        row["skipped_detectors"] = nm.skipped_detectors(int(0.7 * len(y)))
    except (ul.NoLabels, nm.NormaliseError) as error:
        row["label_refused"] = str(error)
    return row


def x_pool_row__mutmut_4(meta: dict[str, Any], path: Path, digest: str) -> dict[str, Any]:
    frame = ul.read_table(path)
    row: dict[str, Any] = {
        "XXuci_idXX": meta["uci_id"],
        "name": meta.get("name"),
        "licence": meta.get("licence"),
        "url": meta.get("data_url"),
        "sha256": digest,
        "roles": [],
    }
    try:
        features, _ = ul.split_columns(frame, meta)
        _, _, report = nm.clean(features, [0] * len(features))
        row["carrier"] = report
        row["roles"].append("carrier")
    except nm.NormaliseError as error:
        row["carrier_refused"] = str(error)
    try:
        features, labels, info = ul.derive_labels(frame, meta)
        x, y, report = nm.clean(features, labels)
        nm.split(x, y, 0)
        row.update(label={**info, **report}, roles=[*row["roles"], "labelled"])
        row["skipped_detectors"] = nm.skipped_detectors(int(0.7 * len(y)))
    except (ul.NoLabels, nm.NormaliseError) as error:
        row["label_refused"] = str(error)
    return row


def x_pool_row__mutmut_5(meta: dict[str, Any], path: Path, digest: str) -> dict[str, Any]:
    frame = ul.read_table(path)
    row: dict[str, Any] = {
        "UCI_ID": meta["uci_id"],
        "name": meta.get("name"),
        "licence": meta.get("licence"),
        "url": meta.get("data_url"),
        "sha256": digest,
        "roles": [],
    }
    try:
        features, _ = ul.split_columns(frame, meta)
        _, _, report = nm.clean(features, [0] * len(features))
        row["carrier"] = report
        row["roles"].append("carrier")
    except nm.NormaliseError as error:
        row["carrier_refused"] = str(error)
    try:
        features, labels, info = ul.derive_labels(frame, meta)
        x, y, report = nm.clean(features, labels)
        nm.split(x, y, 0)
        row.update(label={**info, **report}, roles=[*row["roles"], "labelled"])
        row["skipped_detectors"] = nm.skipped_detectors(int(0.7 * len(y)))
    except (ul.NoLabels, nm.NormaliseError) as error:
        row["label_refused"] = str(error)
    return row


def x_pool_row__mutmut_6(meta: dict[str, Any], path: Path, digest: str) -> dict[str, Any]:
    frame = ul.read_table(path)
    row: dict[str, Any] = {
        "uci_id": meta["XXuci_idXX"],
        "name": meta.get("name"),
        "licence": meta.get("licence"),
        "url": meta.get("data_url"),
        "sha256": digest,
        "roles": [],
    }
    try:
        features, _ = ul.split_columns(frame, meta)
        _, _, report = nm.clean(features, [0] * len(features))
        row["carrier"] = report
        row["roles"].append("carrier")
    except nm.NormaliseError as error:
        row["carrier_refused"] = str(error)
    try:
        features, labels, info = ul.derive_labels(frame, meta)
        x, y, report = nm.clean(features, labels)
        nm.split(x, y, 0)
        row.update(label={**info, **report}, roles=[*row["roles"], "labelled"])
        row["skipped_detectors"] = nm.skipped_detectors(int(0.7 * len(y)))
    except (ul.NoLabels, nm.NormaliseError) as error:
        row["label_refused"] = str(error)
    return row


def x_pool_row__mutmut_7(meta: dict[str, Any], path: Path, digest: str) -> dict[str, Any]:
    frame = ul.read_table(path)
    row: dict[str, Any] = {
        "uci_id": meta["UCI_ID"],
        "name": meta.get("name"),
        "licence": meta.get("licence"),
        "url": meta.get("data_url"),
        "sha256": digest,
        "roles": [],
    }
    try:
        features, _ = ul.split_columns(frame, meta)
        _, _, report = nm.clean(features, [0] * len(features))
        row["carrier"] = report
        row["roles"].append("carrier")
    except nm.NormaliseError as error:
        row["carrier_refused"] = str(error)
    try:
        features, labels, info = ul.derive_labels(frame, meta)
        x, y, report = nm.clean(features, labels)
        nm.split(x, y, 0)
        row.update(label={**info, **report}, roles=[*row["roles"], "labelled"])
        row["skipped_detectors"] = nm.skipped_detectors(int(0.7 * len(y)))
    except (ul.NoLabels, nm.NormaliseError) as error:
        row["label_refused"] = str(error)
    return row


def x_pool_row__mutmut_8(meta: dict[str, Any], path: Path, digest: str) -> dict[str, Any]:
    frame = ul.read_table(path)
    row: dict[str, Any] = {
        "uci_id": meta["uci_id"],
        "XXnameXX": meta.get("name"),
        "licence": meta.get("licence"),
        "url": meta.get("data_url"),
        "sha256": digest,
        "roles": [],
    }
    try:
        features, _ = ul.split_columns(frame, meta)
        _, _, report = nm.clean(features, [0] * len(features))
        row["carrier"] = report
        row["roles"].append("carrier")
    except nm.NormaliseError as error:
        row["carrier_refused"] = str(error)
    try:
        features, labels, info = ul.derive_labels(frame, meta)
        x, y, report = nm.clean(features, labels)
        nm.split(x, y, 0)
        row.update(label={**info, **report}, roles=[*row["roles"], "labelled"])
        row["skipped_detectors"] = nm.skipped_detectors(int(0.7 * len(y)))
    except (ul.NoLabels, nm.NormaliseError) as error:
        row["label_refused"] = str(error)
    return row


def x_pool_row__mutmut_9(meta: dict[str, Any], path: Path, digest: str) -> dict[str, Any]:
    frame = ul.read_table(path)
    row: dict[str, Any] = {
        "uci_id": meta["uci_id"],
        "NAME": meta.get("name"),
        "licence": meta.get("licence"),
        "url": meta.get("data_url"),
        "sha256": digest,
        "roles": [],
    }
    try:
        features, _ = ul.split_columns(frame, meta)
        _, _, report = nm.clean(features, [0] * len(features))
        row["carrier"] = report
        row["roles"].append("carrier")
    except nm.NormaliseError as error:
        row["carrier_refused"] = str(error)
    try:
        features, labels, info = ul.derive_labels(frame, meta)
        x, y, report = nm.clean(features, labels)
        nm.split(x, y, 0)
        row.update(label={**info, **report}, roles=[*row["roles"], "labelled"])
        row["skipped_detectors"] = nm.skipped_detectors(int(0.7 * len(y)))
    except (ul.NoLabels, nm.NormaliseError) as error:
        row["label_refused"] = str(error)
    return row


def x_pool_row__mutmut_10(meta: dict[str, Any], path: Path, digest: str) -> dict[str, Any]:
    frame = ul.read_table(path)
    row: dict[str, Any] = {
        "uci_id": meta["uci_id"],
        "name": meta.get(None),
        "licence": meta.get("licence"),
        "url": meta.get("data_url"),
        "sha256": digest,
        "roles": [],
    }
    try:
        features, _ = ul.split_columns(frame, meta)
        _, _, report = nm.clean(features, [0] * len(features))
        row["carrier"] = report
        row["roles"].append("carrier")
    except nm.NormaliseError as error:
        row["carrier_refused"] = str(error)
    try:
        features, labels, info = ul.derive_labels(frame, meta)
        x, y, report = nm.clean(features, labels)
        nm.split(x, y, 0)
        row.update(label={**info, **report}, roles=[*row["roles"], "labelled"])
        row["skipped_detectors"] = nm.skipped_detectors(int(0.7 * len(y)))
    except (ul.NoLabels, nm.NormaliseError) as error:
        row["label_refused"] = str(error)
    return row


def x_pool_row__mutmut_11(meta: dict[str, Any], path: Path, digest: str) -> dict[str, Any]:
    frame = ul.read_table(path)
    row: dict[str, Any] = {
        "uci_id": meta["uci_id"],
        "name": meta.get("XXnameXX"),
        "licence": meta.get("licence"),
        "url": meta.get("data_url"),
        "sha256": digest,
        "roles": [],
    }
    try:
        features, _ = ul.split_columns(frame, meta)
        _, _, report = nm.clean(features, [0] * len(features))
        row["carrier"] = report
        row["roles"].append("carrier")
    except nm.NormaliseError as error:
        row["carrier_refused"] = str(error)
    try:
        features, labels, info = ul.derive_labels(frame, meta)
        x, y, report = nm.clean(features, labels)
        nm.split(x, y, 0)
        row.update(label={**info, **report}, roles=[*row["roles"], "labelled"])
        row["skipped_detectors"] = nm.skipped_detectors(int(0.7 * len(y)))
    except (ul.NoLabels, nm.NormaliseError) as error:
        row["label_refused"] = str(error)
    return row


def x_pool_row__mutmut_12(meta: dict[str, Any], path: Path, digest: str) -> dict[str, Any]:
    frame = ul.read_table(path)
    row: dict[str, Any] = {
        "uci_id": meta["uci_id"],
        "name": meta.get("NAME"),
        "licence": meta.get("licence"),
        "url": meta.get("data_url"),
        "sha256": digest,
        "roles": [],
    }
    try:
        features, _ = ul.split_columns(frame, meta)
        _, _, report = nm.clean(features, [0] * len(features))
        row["carrier"] = report
        row["roles"].append("carrier")
    except nm.NormaliseError as error:
        row["carrier_refused"] = str(error)
    try:
        features, labels, info = ul.derive_labels(frame, meta)
        x, y, report = nm.clean(features, labels)
        nm.split(x, y, 0)
        row.update(label={**info, **report}, roles=[*row["roles"], "labelled"])
        row["skipped_detectors"] = nm.skipped_detectors(int(0.7 * len(y)))
    except (ul.NoLabels, nm.NormaliseError) as error:
        row["label_refused"] = str(error)
    return row


def x_pool_row__mutmut_13(meta: dict[str, Any], path: Path, digest: str) -> dict[str, Any]:
    frame = ul.read_table(path)
    row: dict[str, Any] = {
        "uci_id": meta["uci_id"],
        "name": meta.get("name"),
        "XXlicenceXX": meta.get("licence"),
        "url": meta.get("data_url"),
        "sha256": digest,
        "roles": [],
    }
    try:
        features, _ = ul.split_columns(frame, meta)
        _, _, report = nm.clean(features, [0] * len(features))
        row["carrier"] = report
        row["roles"].append("carrier")
    except nm.NormaliseError as error:
        row["carrier_refused"] = str(error)
    try:
        features, labels, info = ul.derive_labels(frame, meta)
        x, y, report = nm.clean(features, labels)
        nm.split(x, y, 0)
        row.update(label={**info, **report}, roles=[*row["roles"], "labelled"])
        row["skipped_detectors"] = nm.skipped_detectors(int(0.7 * len(y)))
    except (ul.NoLabels, nm.NormaliseError) as error:
        row["label_refused"] = str(error)
    return row


def x_pool_row__mutmut_14(meta: dict[str, Any], path: Path, digest: str) -> dict[str, Any]:
    frame = ul.read_table(path)
    row: dict[str, Any] = {
        "uci_id": meta["uci_id"],
        "name": meta.get("name"),
        "LICENCE": meta.get("licence"),
        "url": meta.get("data_url"),
        "sha256": digest,
        "roles": [],
    }
    try:
        features, _ = ul.split_columns(frame, meta)
        _, _, report = nm.clean(features, [0] * len(features))
        row["carrier"] = report
        row["roles"].append("carrier")
    except nm.NormaliseError as error:
        row["carrier_refused"] = str(error)
    try:
        features, labels, info = ul.derive_labels(frame, meta)
        x, y, report = nm.clean(features, labels)
        nm.split(x, y, 0)
        row.update(label={**info, **report}, roles=[*row["roles"], "labelled"])
        row["skipped_detectors"] = nm.skipped_detectors(int(0.7 * len(y)))
    except (ul.NoLabels, nm.NormaliseError) as error:
        row["label_refused"] = str(error)
    return row


def x_pool_row__mutmut_15(meta: dict[str, Any], path: Path, digest: str) -> dict[str, Any]:
    frame = ul.read_table(path)
    row: dict[str, Any] = {
        "uci_id": meta["uci_id"],
        "name": meta.get("name"),
        "licence": meta.get(None),
        "url": meta.get("data_url"),
        "sha256": digest,
        "roles": [],
    }
    try:
        features, _ = ul.split_columns(frame, meta)
        _, _, report = nm.clean(features, [0] * len(features))
        row["carrier"] = report
        row["roles"].append("carrier")
    except nm.NormaliseError as error:
        row["carrier_refused"] = str(error)
    try:
        features, labels, info = ul.derive_labels(frame, meta)
        x, y, report = nm.clean(features, labels)
        nm.split(x, y, 0)
        row.update(label={**info, **report}, roles=[*row["roles"], "labelled"])
        row["skipped_detectors"] = nm.skipped_detectors(int(0.7 * len(y)))
    except (ul.NoLabels, nm.NormaliseError) as error:
        row["label_refused"] = str(error)
    return row


def x_pool_row__mutmut_16(meta: dict[str, Any], path: Path, digest: str) -> dict[str, Any]:
    frame = ul.read_table(path)
    row: dict[str, Any] = {
        "uci_id": meta["uci_id"],
        "name": meta.get("name"),
        "licence": meta.get("XXlicenceXX"),
        "url": meta.get("data_url"),
        "sha256": digest,
        "roles": [],
    }
    try:
        features, _ = ul.split_columns(frame, meta)
        _, _, report = nm.clean(features, [0] * len(features))
        row["carrier"] = report
        row["roles"].append("carrier")
    except nm.NormaliseError as error:
        row["carrier_refused"] = str(error)
    try:
        features, labels, info = ul.derive_labels(frame, meta)
        x, y, report = nm.clean(features, labels)
        nm.split(x, y, 0)
        row.update(label={**info, **report}, roles=[*row["roles"], "labelled"])
        row["skipped_detectors"] = nm.skipped_detectors(int(0.7 * len(y)))
    except (ul.NoLabels, nm.NormaliseError) as error:
        row["label_refused"] = str(error)
    return row


def x_pool_row__mutmut_17(meta: dict[str, Any], path: Path, digest: str) -> dict[str, Any]:
    frame = ul.read_table(path)
    row: dict[str, Any] = {
        "uci_id": meta["uci_id"],
        "name": meta.get("name"),
        "licence": meta.get("LICENCE"),
        "url": meta.get("data_url"),
        "sha256": digest,
        "roles": [],
    }
    try:
        features, _ = ul.split_columns(frame, meta)
        _, _, report = nm.clean(features, [0] * len(features))
        row["carrier"] = report
        row["roles"].append("carrier")
    except nm.NormaliseError as error:
        row["carrier_refused"] = str(error)
    try:
        features, labels, info = ul.derive_labels(frame, meta)
        x, y, report = nm.clean(features, labels)
        nm.split(x, y, 0)
        row.update(label={**info, **report}, roles=[*row["roles"], "labelled"])
        row["skipped_detectors"] = nm.skipped_detectors(int(0.7 * len(y)))
    except (ul.NoLabels, nm.NormaliseError) as error:
        row["label_refused"] = str(error)
    return row


def x_pool_row__mutmut_18(meta: dict[str, Any], path: Path, digest: str) -> dict[str, Any]:
    frame = ul.read_table(path)
    row: dict[str, Any] = {
        "uci_id": meta["uci_id"],
        "name": meta.get("name"),
        "licence": meta.get("licence"),
        "XXurlXX": meta.get("data_url"),
        "sha256": digest,
        "roles": [],
    }
    try:
        features, _ = ul.split_columns(frame, meta)
        _, _, report = nm.clean(features, [0] * len(features))
        row["carrier"] = report
        row["roles"].append("carrier")
    except nm.NormaliseError as error:
        row["carrier_refused"] = str(error)
    try:
        features, labels, info = ul.derive_labels(frame, meta)
        x, y, report = nm.clean(features, labels)
        nm.split(x, y, 0)
        row.update(label={**info, **report}, roles=[*row["roles"], "labelled"])
        row["skipped_detectors"] = nm.skipped_detectors(int(0.7 * len(y)))
    except (ul.NoLabels, nm.NormaliseError) as error:
        row["label_refused"] = str(error)
    return row


def x_pool_row__mutmut_19(meta: dict[str, Any], path: Path, digest: str) -> dict[str, Any]:
    frame = ul.read_table(path)
    row: dict[str, Any] = {
        "uci_id": meta["uci_id"],
        "name": meta.get("name"),
        "licence": meta.get("licence"),
        "URL": meta.get("data_url"),
        "sha256": digest,
        "roles": [],
    }
    try:
        features, _ = ul.split_columns(frame, meta)
        _, _, report = nm.clean(features, [0] * len(features))
        row["carrier"] = report
        row["roles"].append("carrier")
    except nm.NormaliseError as error:
        row["carrier_refused"] = str(error)
    try:
        features, labels, info = ul.derive_labels(frame, meta)
        x, y, report = nm.clean(features, labels)
        nm.split(x, y, 0)
        row.update(label={**info, **report}, roles=[*row["roles"], "labelled"])
        row["skipped_detectors"] = nm.skipped_detectors(int(0.7 * len(y)))
    except (ul.NoLabels, nm.NormaliseError) as error:
        row["label_refused"] = str(error)
    return row


def x_pool_row__mutmut_20(meta: dict[str, Any], path: Path, digest: str) -> dict[str, Any]:
    frame = ul.read_table(path)
    row: dict[str, Any] = {
        "uci_id": meta["uci_id"],
        "name": meta.get("name"),
        "licence": meta.get("licence"),
        "url": meta.get(None),
        "sha256": digest,
        "roles": [],
    }
    try:
        features, _ = ul.split_columns(frame, meta)
        _, _, report = nm.clean(features, [0] * len(features))
        row["carrier"] = report
        row["roles"].append("carrier")
    except nm.NormaliseError as error:
        row["carrier_refused"] = str(error)
    try:
        features, labels, info = ul.derive_labels(frame, meta)
        x, y, report = nm.clean(features, labels)
        nm.split(x, y, 0)
        row.update(label={**info, **report}, roles=[*row["roles"], "labelled"])
        row["skipped_detectors"] = nm.skipped_detectors(int(0.7 * len(y)))
    except (ul.NoLabels, nm.NormaliseError) as error:
        row["label_refused"] = str(error)
    return row


def x_pool_row__mutmut_21(meta: dict[str, Any], path: Path, digest: str) -> dict[str, Any]:
    frame = ul.read_table(path)
    row: dict[str, Any] = {
        "uci_id": meta["uci_id"],
        "name": meta.get("name"),
        "licence": meta.get("licence"),
        "url": meta.get("XXdata_urlXX"),
        "sha256": digest,
        "roles": [],
    }
    try:
        features, _ = ul.split_columns(frame, meta)
        _, _, report = nm.clean(features, [0] * len(features))
        row["carrier"] = report
        row["roles"].append("carrier")
    except nm.NormaliseError as error:
        row["carrier_refused"] = str(error)
    try:
        features, labels, info = ul.derive_labels(frame, meta)
        x, y, report = nm.clean(features, labels)
        nm.split(x, y, 0)
        row.update(label={**info, **report}, roles=[*row["roles"], "labelled"])
        row["skipped_detectors"] = nm.skipped_detectors(int(0.7 * len(y)))
    except (ul.NoLabels, nm.NormaliseError) as error:
        row["label_refused"] = str(error)
    return row


def x_pool_row__mutmut_22(meta: dict[str, Any], path: Path, digest: str) -> dict[str, Any]:
    frame = ul.read_table(path)
    row: dict[str, Any] = {
        "uci_id": meta["uci_id"],
        "name": meta.get("name"),
        "licence": meta.get("licence"),
        "url": meta.get("DATA_URL"),
        "sha256": digest,
        "roles": [],
    }
    try:
        features, _ = ul.split_columns(frame, meta)
        _, _, report = nm.clean(features, [0] * len(features))
        row["carrier"] = report
        row["roles"].append("carrier")
    except nm.NormaliseError as error:
        row["carrier_refused"] = str(error)
    try:
        features, labels, info = ul.derive_labels(frame, meta)
        x, y, report = nm.clean(features, labels)
        nm.split(x, y, 0)
        row.update(label={**info, **report}, roles=[*row["roles"], "labelled"])
        row["skipped_detectors"] = nm.skipped_detectors(int(0.7 * len(y)))
    except (ul.NoLabels, nm.NormaliseError) as error:
        row["label_refused"] = str(error)
    return row


def x_pool_row__mutmut_23(meta: dict[str, Any], path: Path, digest: str) -> dict[str, Any]:
    frame = ul.read_table(path)
    row: dict[str, Any] = {
        "uci_id": meta["uci_id"],
        "name": meta.get("name"),
        "licence": meta.get("licence"),
        "url": meta.get("data_url"),
        "XXsha256XX": digest,
        "roles": [],
    }
    try:
        features, _ = ul.split_columns(frame, meta)
        _, _, report = nm.clean(features, [0] * len(features))
        row["carrier"] = report
        row["roles"].append("carrier")
    except nm.NormaliseError as error:
        row["carrier_refused"] = str(error)
    try:
        features, labels, info = ul.derive_labels(frame, meta)
        x, y, report = nm.clean(features, labels)
        nm.split(x, y, 0)
        row.update(label={**info, **report}, roles=[*row["roles"], "labelled"])
        row["skipped_detectors"] = nm.skipped_detectors(int(0.7 * len(y)))
    except (ul.NoLabels, nm.NormaliseError) as error:
        row["label_refused"] = str(error)
    return row


def x_pool_row__mutmut_24(meta: dict[str, Any], path: Path, digest: str) -> dict[str, Any]:
    frame = ul.read_table(path)
    row: dict[str, Any] = {
        "uci_id": meta["uci_id"],
        "name": meta.get("name"),
        "licence": meta.get("licence"),
        "url": meta.get("data_url"),
        "SHA256": digest,
        "roles": [],
    }
    try:
        features, _ = ul.split_columns(frame, meta)
        _, _, report = nm.clean(features, [0] * len(features))
        row["carrier"] = report
        row["roles"].append("carrier")
    except nm.NormaliseError as error:
        row["carrier_refused"] = str(error)
    try:
        features, labels, info = ul.derive_labels(frame, meta)
        x, y, report = nm.clean(features, labels)
        nm.split(x, y, 0)
        row.update(label={**info, **report}, roles=[*row["roles"], "labelled"])
        row["skipped_detectors"] = nm.skipped_detectors(int(0.7 * len(y)))
    except (ul.NoLabels, nm.NormaliseError) as error:
        row["label_refused"] = str(error)
    return row


def x_pool_row__mutmut_25(meta: dict[str, Any], path: Path, digest: str) -> dict[str, Any]:
    frame = ul.read_table(path)
    row: dict[str, Any] = {
        "uci_id": meta["uci_id"],
        "name": meta.get("name"),
        "licence": meta.get("licence"),
        "url": meta.get("data_url"),
        "sha256": digest,
        "XXrolesXX": [],
    }
    try:
        features, _ = ul.split_columns(frame, meta)
        _, _, report = nm.clean(features, [0] * len(features))
        row["carrier"] = report
        row["roles"].append("carrier")
    except nm.NormaliseError as error:
        row["carrier_refused"] = str(error)
    try:
        features, labels, info = ul.derive_labels(frame, meta)
        x, y, report = nm.clean(features, labels)
        nm.split(x, y, 0)
        row.update(label={**info, **report}, roles=[*row["roles"], "labelled"])
        row["skipped_detectors"] = nm.skipped_detectors(int(0.7 * len(y)))
    except (ul.NoLabels, nm.NormaliseError) as error:
        row["label_refused"] = str(error)
    return row


def x_pool_row__mutmut_26(meta: dict[str, Any], path: Path, digest: str) -> dict[str, Any]:
    frame = ul.read_table(path)
    row: dict[str, Any] = {
        "uci_id": meta["uci_id"],
        "name": meta.get("name"),
        "licence": meta.get("licence"),
        "url": meta.get("data_url"),
        "sha256": digest,
        "ROLES": [],
    }
    try:
        features, _ = ul.split_columns(frame, meta)
        _, _, report = nm.clean(features, [0] * len(features))
        row["carrier"] = report
        row["roles"].append("carrier")
    except nm.NormaliseError as error:
        row["carrier_refused"] = str(error)
    try:
        features, labels, info = ul.derive_labels(frame, meta)
        x, y, report = nm.clean(features, labels)
        nm.split(x, y, 0)
        row.update(label={**info, **report}, roles=[*row["roles"], "labelled"])
        row["skipped_detectors"] = nm.skipped_detectors(int(0.7 * len(y)))
    except (ul.NoLabels, nm.NormaliseError) as error:
        row["label_refused"] = str(error)
    return row


def x_pool_row__mutmut_27(meta: dict[str, Any], path: Path, digest: str) -> dict[str, Any]:
    frame = ul.read_table(path)
    row: dict[str, Any] = {
        "uci_id": meta["uci_id"],
        "name": meta.get("name"),
        "licence": meta.get("licence"),
        "url": meta.get("data_url"),
        "sha256": digest,
        "roles": [],
    }
    try:
        features, _ = None
        _, _, report = nm.clean(features, [0] * len(features))
        row["carrier"] = report
        row["roles"].append("carrier")
    except nm.NormaliseError as error:
        row["carrier_refused"] = str(error)
    try:
        features, labels, info = ul.derive_labels(frame, meta)
        x, y, report = nm.clean(features, labels)
        nm.split(x, y, 0)
        row.update(label={**info, **report}, roles=[*row["roles"], "labelled"])
        row["skipped_detectors"] = nm.skipped_detectors(int(0.7 * len(y)))
    except (ul.NoLabels, nm.NormaliseError) as error:
        row["label_refused"] = str(error)
    return row


def x_pool_row__mutmut_28(meta: dict[str, Any], path: Path, digest: str) -> dict[str, Any]:
    frame = ul.read_table(path)
    row: dict[str, Any] = {
        "uci_id": meta["uci_id"],
        "name": meta.get("name"),
        "licence": meta.get("licence"),
        "url": meta.get("data_url"),
        "sha256": digest,
        "roles": [],
    }
    try:
        features, _ = ul.split_columns(None, meta)
        _, _, report = nm.clean(features, [0] * len(features))
        row["carrier"] = report
        row["roles"].append("carrier")
    except nm.NormaliseError as error:
        row["carrier_refused"] = str(error)
    try:
        features, labels, info = ul.derive_labels(frame, meta)
        x, y, report = nm.clean(features, labels)
        nm.split(x, y, 0)
        row.update(label={**info, **report}, roles=[*row["roles"], "labelled"])
        row["skipped_detectors"] = nm.skipped_detectors(int(0.7 * len(y)))
    except (ul.NoLabels, nm.NormaliseError) as error:
        row["label_refused"] = str(error)
    return row


def x_pool_row__mutmut_29(meta: dict[str, Any], path: Path, digest: str) -> dict[str, Any]:
    frame = ul.read_table(path)
    row: dict[str, Any] = {
        "uci_id": meta["uci_id"],
        "name": meta.get("name"),
        "licence": meta.get("licence"),
        "url": meta.get("data_url"),
        "sha256": digest,
        "roles": [],
    }
    try:
        features, _ = ul.split_columns(frame, None)
        _, _, report = nm.clean(features, [0] * len(features))
        row["carrier"] = report
        row["roles"].append("carrier")
    except nm.NormaliseError as error:
        row["carrier_refused"] = str(error)
    try:
        features, labels, info = ul.derive_labels(frame, meta)
        x, y, report = nm.clean(features, labels)
        nm.split(x, y, 0)
        row.update(label={**info, **report}, roles=[*row["roles"], "labelled"])
        row["skipped_detectors"] = nm.skipped_detectors(int(0.7 * len(y)))
    except (ul.NoLabels, nm.NormaliseError) as error:
        row["label_refused"] = str(error)
    return row


def x_pool_row__mutmut_30(meta: dict[str, Any], path: Path, digest: str) -> dict[str, Any]:
    frame = ul.read_table(path)
    row: dict[str, Any] = {
        "uci_id": meta["uci_id"],
        "name": meta.get("name"),
        "licence": meta.get("licence"),
        "url": meta.get("data_url"),
        "sha256": digest,
        "roles": [],
    }
    try:
        features, _ = ul.split_columns(meta)
        _, _, report = nm.clean(features, [0] * len(features))
        row["carrier"] = report
        row["roles"].append("carrier")
    except nm.NormaliseError as error:
        row["carrier_refused"] = str(error)
    try:
        features, labels, info = ul.derive_labels(frame, meta)
        x, y, report = nm.clean(features, labels)
        nm.split(x, y, 0)
        row.update(label={**info, **report}, roles=[*row["roles"], "labelled"])
        row["skipped_detectors"] = nm.skipped_detectors(int(0.7 * len(y)))
    except (ul.NoLabels, nm.NormaliseError) as error:
        row["label_refused"] = str(error)
    return row


def x_pool_row__mutmut_31(meta: dict[str, Any], path: Path, digest: str) -> dict[str, Any]:
    frame = ul.read_table(path)
    row: dict[str, Any] = {
        "uci_id": meta["uci_id"],
        "name": meta.get("name"),
        "licence": meta.get("licence"),
        "url": meta.get("data_url"),
        "sha256": digest,
        "roles": [],
    }
    try:
        features, _ = ul.split_columns(frame, )
        _, _, report = nm.clean(features, [0] * len(features))
        row["carrier"] = report
        row["roles"].append("carrier")
    except nm.NormaliseError as error:
        row["carrier_refused"] = str(error)
    try:
        features, labels, info = ul.derive_labels(frame, meta)
        x, y, report = nm.clean(features, labels)
        nm.split(x, y, 0)
        row.update(label={**info, **report}, roles=[*row["roles"], "labelled"])
        row["skipped_detectors"] = nm.skipped_detectors(int(0.7 * len(y)))
    except (ul.NoLabels, nm.NormaliseError) as error:
        row["label_refused"] = str(error)
    return row


def x_pool_row__mutmut_32(meta: dict[str, Any], path: Path, digest: str) -> dict[str, Any]:
    frame = ul.read_table(path)
    row: dict[str, Any] = {
        "uci_id": meta["uci_id"],
        "name": meta.get("name"),
        "licence": meta.get("licence"),
        "url": meta.get("data_url"),
        "sha256": digest,
        "roles": [],
    }
    try:
        features, _ = ul.split_columns(frame, meta)
        _, _, report = None
        row["carrier"] = report
        row["roles"].append("carrier")
    except nm.NormaliseError as error:
        row["carrier_refused"] = str(error)
    try:
        features, labels, info = ul.derive_labels(frame, meta)
        x, y, report = nm.clean(features, labels)
        nm.split(x, y, 0)
        row.update(label={**info, **report}, roles=[*row["roles"], "labelled"])
        row["skipped_detectors"] = nm.skipped_detectors(int(0.7 * len(y)))
    except (ul.NoLabels, nm.NormaliseError) as error:
        row["label_refused"] = str(error)
    return row


def x_pool_row__mutmut_33(meta: dict[str, Any], path: Path, digest: str) -> dict[str, Any]:
    frame = ul.read_table(path)
    row: dict[str, Any] = {
        "uci_id": meta["uci_id"],
        "name": meta.get("name"),
        "licence": meta.get("licence"),
        "url": meta.get("data_url"),
        "sha256": digest,
        "roles": [],
    }
    try:
        features, _ = ul.split_columns(frame, meta)
        _, _, report = nm.clean(None, [0] * len(features))
        row["carrier"] = report
        row["roles"].append("carrier")
    except nm.NormaliseError as error:
        row["carrier_refused"] = str(error)
    try:
        features, labels, info = ul.derive_labels(frame, meta)
        x, y, report = nm.clean(features, labels)
        nm.split(x, y, 0)
        row.update(label={**info, **report}, roles=[*row["roles"], "labelled"])
        row["skipped_detectors"] = nm.skipped_detectors(int(0.7 * len(y)))
    except (ul.NoLabels, nm.NormaliseError) as error:
        row["label_refused"] = str(error)
    return row


def x_pool_row__mutmut_34(meta: dict[str, Any], path: Path, digest: str) -> dict[str, Any]:
    frame = ul.read_table(path)
    row: dict[str, Any] = {
        "uci_id": meta["uci_id"],
        "name": meta.get("name"),
        "licence": meta.get("licence"),
        "url": meta.get("data_url"),
        "sha256": digest,
        "roles": [],
    }
    try:
        features, _ = ul.split_columns(frame, meta)
        _, _, report = nm.clean(features, None)
        row["carrier"] = report
        row["roles"].append("carrier")
    except nm.NormaliseError as error:
        row["carrier_refused"] = str(error)
    try:
        features, labels, info = ul.derive_labels(frame, meta)
        x, y, report = nm.clean(features, labels)
        nm.split(x, y, 0)
        row.update(label={**info, **report}, roles=[*row["roles"], "labelled"])
        row["skipped_detectors"] = nm.skipped_detectors(int(0.7 * len(y)))
    except (ul.NoLabels, nm.NormaliseError) as error:
        row["label_refused"] = str(error)
    return row


def x_pool_row__mutmut_35(meta: dict[str, Any], path: Path, digest: str) -> dict[str, Any]:
    frame = ul.read_table(path)
    row: dict[str, Any] = {
        "uci_id": meta["uci_id"],
        "name": meta.get("name"),
        "licence": meta.get("licence"),
        "url": meta.get("data_url"),
        "sha256": digest,
        "roles": [],
    }
    try:
        features, _ = ul.split_columns(frame, meta)
        _, _, report = nm.clean([0] * len(features))
        row["carrier"] = report
        row["roles"].append("carrier")
    except nm.NormaliseError as error:
        row["carrier_refused"] = str(error)
    try:
        features, labels, info = ul.derive_labels(frame, meta)
        x, y, report = nm.clean(features, labels)
        nm.split(x, y, 0)
        row.update(label={**info, **report}, roles=[*row["roles"], "labelled"])
        row["skipped_detectors"] = nm.skipped_detectors(int(0.7 * len(y)))
    except (ul.NoLabels, nm.NormaliseError) as error:
        row["label_refused"] = str(error)
    return row


def x_pool_row__mutmut_36(meta: dict[str, Any], path: Path, digest: str) -> dict[str, Any]:
    frame = ul.read_table(path)
    row: dict[str, Any] = {
        "uci_id": meta["uci_id"],
        "name": meta.get("name"),
        "licence": meta.get("licence"),
        "url": meta.get("data_url"),
        "sha256": digest,
        "roles": [],
    }
    try:
        features, _ = ul.split_columns(frame, meta)
        _, _, report = nm.clean(features, )
        row["carrier"] = report
        row["roles"].append("carrier")
    except nm.NormaliseError as error:
        row["carrier_refused"] = str(error)
    try:
        features, labels, info = ul.derive_labels(frame, meta)
        x, y, report = nm.clean(features, labels)
        nm.split(x, y, 0)
        row.update(label={**info, **report}, roles=[*row["roles"], "labelled"])
        row["skipped_detectors"] = nm.skipped_detectors(int(0.7 * len(y)))
    except (ul.NoLabels, nm.NormaliseError) as error:
        row["label_refused"] = str(error)
    return row


def x_pool_row__mutmut_37(meta: dict[str, Any], path: Path, digest: str) -> dict[str, Any]:
    frame = ul.read_table(path)
    row: dict[str, Any] = {
        "uci_id": meta["uci_id"],
        "name": meta.get("name"),
        "licence": meta.get("licence"),
        "url": meta.get("data_url"),
        "sha256": digest,
        "roles": [],
    }
    try:
        features, _ = ul.split_columns(frame, meta)
        _, _, report = nm.clean(features, [0] / len(features))
        row["carrier"] = report
        row["roles"].append("carrier")
    except nm.NormaliseError as error:
        row["carrier_refused"] = str(error)
    try:
        features, labels, info = ul.derive_labels(frame, meta)
        x, y, report = nm.clean(features, labels)
        nm.split(x, y, 0)
        row.update(label={**info, **report}, roles=[*row["roles"], "labelled"])
        row["skipped_detectors"] = nm.skipped_detectors(int(0.7 * len(y)))
    except (ul.NoLabels, nm.NormaliseError) as error:
        row["label_refused"] = str(error)
    return row


def x_pool_row__mutmut_38(meta: dict[str, Any], path: Path, digest: str) -> dict[str, Any]:
    frame = ul.read_table(path)
    row: dict[str, Any] = {
        "uci_id": meta["uci_id"],
        "name": meta.get("name"),
        "licence": meta.get("licence"),
        "url": meta.get("data_url"),
        "sha256": digest,
        "roles": [],
    }
    try:
        features, _ = ul.split_columns(frame, meta)
        _, _, report = nm.clean(features, [1] * len(features))
        row["carrier"] = report
        row["roles"].append("carrier")
    except nm.NormaliseError as error:
        row["carrier_refused"] = str(error)
    try:
        features, labels, info = ul.derive_labels(frame, meta)
        x, y, report = nm.clean(features, labels)
        nm.split(x, y, 0)
        row.update(label={**info, **report}, roles=[*row["roles"], "labelled"])
        row["skipped_detectors"] = nm.skipped_detectors(int(0.7 * len(y)))
    except (ul.NoLabels, nm.NormaliseError) as error:
        row["label_refused"] = str(error)
    return row


def x_pool_row__mutmut_39(meta: dict[str, Any], path: Path, digest: str) -> dict[str, Any]:
    frame = ul.read_table(path)
    row: dict[str, Any] = {
        "uci_id": meta["uci_id"],
        "name": meta.get("name"),
        "licence": meta.get("licence"),
        "url": meta.get("data_url"),
        "sha256": digest,
        "roles": [],
    }
    try:
        features, _ = ul.split_columns(frame, meta)
        _, _, report = nm.clean(features, [0] * len(features))
        row["carrier"] = None
        row["roles"].append("carrier")
    except nm.NormaliseError as error:
        row["carrier_refused"] = str(error)
    try:
        features, labels, info = ul.derive_labels(frame, meta)
        x, y, report = nm.clean(features, labels)
        nm.split(x, y, 0)
        row.update(label={**info, **report}, roles=[*row["roles"], "labelled"])
        row["skipped_detectors"] = nm.skipped_detectors(int(0.7 * len(y)))
    except (ul.NoLabels, nm.NormaliseError) as error:
        row["label_refused"] = str(error)
    return row


def x_pool_row__mutmut_40(meta: dict[str, Any], path: Path, digest: str) -> dict[str, Any]:
    frame = ul.read_table(path)
    row: dict[str, Any] = {
        "uci_id": meta["uci_id"],
        "name": meta.get("name"),
        "licence": meta.get("licence"),
        "url": meta.get("data_url"),
        "sha256": digest,
        "roles": [],
    }
    try:
        features, _ = ul.split_columns(frame, meta)
        _, _, report = nm.clean(features, [0] * len(features))
        row["XXcarrierXX"] = report
        row["roles"].append("carrier")
    except nm.NormaliseError as error:
        row["carrier_refused"] = str(error)
    try:
        features, labels, info = ul.derive_labels(frame, meta)
        x, y, report = nm.clean(features, labels)
        nm.split(x, y, 0)
        row.update(label={**info, **report}, roles=[*row["roles"], "labelled"])
        row["skipped_detectors"] = nm.skipped_detectors(int(0.7 * len(y)))
    except (ul.NoLabels, nm.NormaliseError) as error:
        row["label_refused"] = str(error)
    return row


def x_pool_row__mutmut_41(meta: dict[str, Any], path: Path, digest: str) -> dict[str, Any]:
    frame = ul.read_table(path)
    row: dict[str, Any] = {
        "uci_id": meta["uci_id"],
        "name": meta.get("name"),
        "licence": meta.get("licence"),
        "url": meta.get("data_url"),
        "sha256": digest,
        "roles": [],
    }
    try:
        features, _ = ul.split_columns(frame, meta)
        _, _, report = nm.clean(features, [0] * len(features))
        row["CARRIER"] = report
        row["roles"].append("carrier")
    except nm.NormaliseError as error:
        row["carrier_refused"] = str(error)
    try:
        features, labels, info = ul.derive_labels(frame, meta)
        x, y, report = nm.clean(features, labels)
        nm.split(x, y, 0)
        row.update(label={**info, **report}, roles=[*row["roles"], "labelled"])
        row["skipped_detectors"] = nm.skipped_detectors(int(0.7 * len(y)))
    except (ul.NoLabels, nm.NormaliseError) as error:
        row["label_refused"] = str(error)
    return row


def x_pool_row__mutmut_42(meta: dict[str, Any], path: Path, digest: str) -> dict[str, Any]:
    frame = ul.read_table(path)
    row: dict[str, Any] = {
        "uci_id": meta["uci_id"],
        "name": meta.get("name"),
        "licence": meta.get("licence"),
        "url": meta.get("data_url"),
        "sha256": digest,
        "roles": [],
    }
    try:
        features, _ = ul.split_columns(frame, meta)
        _, _, report = nm.clean(features, [0] * len(features))
        row["carrier"] = report
        row["roles"].append(None)
    except nm.NormaliseError as error:
        row["carrier_refused"] = str(error)
    try:
        features, labels, info = ul.derive_labels(frame, meta)
        x, y, report = nm.clean(features, labels)
        nm.split(x, y, 0)
        row.update(label={**info, **report}, roles=[*row["roles"], "labelled"])
        row["skipped_detectors"] = nm.skipped_detectors(int(0.7 * len(y)))
    except (ul.NoLabels, nm.NormaliseError) as error:
        row["label_refused"] = str(error)
    return row


def x_pool_row__mutmut_43(meta: dict[str, Any], path: Path, digest: str) -> dict[str, Any]:
    frame = ul.read_table(path)
    row: dict[str, Any] = {
        "uci_id": meta["uci_id"],
        "name": meta.get("name"),
        "licence": meta.get("licence"),
        "url": meta.get("data_url"),
        "sha256": digest,
        "roles": [],
    }
    try:
        features, _ = ul.split_columns(frame, meta)
        _, _, report = nm.clean(features, [0] * len(features))
        row["carrier"] = report
        row["XXrolesXX"].append("carrier")
    except nm.NormaliseError as error:
        row["carrier_refused"] = str(error)
    try:
        features, labels, info = ul.derive_labels(frame, meta)
        x, y, report = nm.clean(features, labels)
        nm.split(x, y, 0)
        row.update(label={**info, **report}, roles=[*row["roles"], "labelled"])
        row["skipped_detectors"] = nm.skipped_detectors(int(0.7 * len(y)))
    except (ul.NoLabels, nm.NormaliseError) as error:
        row["label_refused"] = str(error)
    return row


def x_pool_row__mutmut_44(meta: dict[str, Any], path: Path, digest: str) -> dict[str, Any]:
    frame = ul.read_table(path)
    row: dict[str, Any] = {
        "uci_id": meta["uci_id"],
        "name": meta.get("name"),
        "licence": meta.get("licence"),
        "url": meta.get("data_url"),
        "sha256": digest,
        "roles": [],
    }
    try:
        features, _ = ul.split_columns(frame, meta)
        _, _, report = nm.clean(features, [0] * len(features))
        row["carrier"] = report
        row["ROLES"].append("carrier")
    except nm.NormaliseError as error:
        row["carrier_refused"] = str(error)
    try:
        features, labels, info = ul.derive_labels(frame, meta)
        x, y, report = nm.clean(features, labels)
        nm.split(x, y, 0)
        row.update(label={**info, **report}, roles=[*row["roles"], "labelled"])
        row["skipped_detectors"] = nm.skipped_detectors(int(0.7 * len(y)))
    except (ul.NoLabels, nm.NormaliseError) as error:
        row["label_refused"] = str(error)
    return row


def x_pool_row__mutmut_45(meta: dict[str, Any], path: Path, digest: str) -> dict[str, Any]:
    frame = ul.read_table(path)
    row: dict[str, Any] = {
        "uci_id": meta["uci_id"],
        "name": meta.get("name"),
        "licence": meta.get("licence"),
        "url": meta.get("data_url"),
        "sha256": digest,
        "roles": [],
    }
    try:
        features, _ = ul.split_columns(frame, meta)
        _, _, report = nm.clean(features, [0] * len(features))
        row["carrier"] = report
        row["roles"].append("XXcarrierXX")
    except nm.NormaliseError as error:
        row["carrier_refused"] = str(error)
    try:
        features, labels, info = ul.derive_labels(frame, meta)
        x, y, report = nm.clean(features, labels)
        nm.split(x, y, 0)
        row.update(label={**info, **report}, roles=[*row["roles"], "labelled"])
        row["skipped_detectors"] = nm.skipped_detectors(int(0.7 * len(y)))
    except (ul.NoLabels, nm.NormaliseError) as error:
        row["label_refused"] = str(error)
    return row


def x_pool_row__mutmut_46(meta: dict[str, Any], path: Path, digest: str) -> dict[str, Any]:
    frame = ul.read_table(path)
    row: dict[str, Any] = {
        "uci_id": meta["uci_id"],
        "name": meta.get("name"),
        "licence": meta.get("licence"),
        "url": meta.get("data_url"),
        "sha256": digest,
        "roles": [],
    }
    try:
        features, _ = ul.split_columns(frame, meta)
        _, _, report = nm.clean(features, [0] * len(features))
        row["carrier"] = report
        row["roles"].append("CARRIER")
    except nm.NormaliseError as error:
        row["carrier_refused"] = str(error)
    try:
        features, labels, info = ul.derive_labels(frame, meta)
        x, y, report = nm.clean(features, labels)
        nm.split(x, y, 0)
        row.update(label={**info, **report}, roles=[*row["roles"], "labelled"])
        row["skipped_detectors"] = nm.skipped_detectors(int(0.7 * len(y)))
    except (ul.NoLabels, nm.NormaliseError) as error:
        row["label_refused"] = str(error)
    return row


def x_pool_row__mutmut_47(meta: dict[str, Any], path: Path, digest: str) -> dict[str, Any]:
    frame = ul.read_table(path)
    row: dict[str, Any] = {
        "uci_id": meta["uci_id"],
        "name": meta.get("name"),
        "licence": meta.get("licence"),
        "url": meta.get("data_url"),
        "sha256": digest,
        "roles": [],
    }
    try:
        features, _ = ul.split_columns(frame, meta)
        _, _, report = nm.clean(features, [0] * len(features))
        row["carrier"] = report
        row["roles"].append("carrier")
    except nm.NormaliseError as error:
        row["carrier_refused"] = None
    try:
        features, labels, info = ul.derive_labels(frame, meta)
        x, y, report = nm.clean(features, labels)
        nm.split(x, y, 0)
        row.update(label={**info, **report}, roles=[*row["roles"], "labelled"])
        row["skipped_detectors"] = nm.skipped_detectors(int(0.7 * len(y)))
    except (ul.NoLabels, nm.NormaliseError) as error:
        row["label_refused"] = str(error)
    return row


def x_pool_row__mutmut_48(meta: dict[str, Any], path: Path, digest: str) -> dict[str, Any]:
    frame = ul.read_table(path)
    row: dict[str, Any] = {
        "uci_id": meta["uci_id"],
        "name": meta.get("name"),
        "licence": meta.get("licence"),
        "url": meta.get("data_url"),
        "sha256": digest,
        "roles": [],
    }
    try:
        features, _ = ul.split_columns(frame, meta)
        _, _, report = nm.clean(features, [0] * len(features))
        row["carrier"] = report
        row["roles"].append("carrier")
    except nm.NormaliseError as error:
        row["XXcarrier_refusedXX"] = str(error)
    try:
        features, labels, info = ul.derive_labels(frame, meta)
        x, y, report = nm.clean(features, labels)
        nm.split(x, y, 0)
        row.update(label={**info, **report}, roles=[*row["roles"], "labelled"])
        row["skipped_detectors"] = nm.skipped_detectors(int(0.7 * len(y)))
    except (ul.NoLabels, nm.NormaliseError) as error:
        row["label_refused"] = str(error)
    return row


def x_pool_row__mutmut_49(meta: dict[str, Any], path: Path, digest: str) -> dict[str, Any]:
    frame = ul.read_table(path)
    row: dict[str, Any] = {
        "uci_id": meta["uci_id"],
        "name": meta.get("name"),
        "licence": meta.get("licence"),
        "url": meta.get("data_url"),
        "sha256": digest,
        "roles": [],
    }
    try:
        features, _ = ul.split_columns(frame, meta)
        _, _, report = nm.clean(features, [0] * len(features))
        row["carrier"] = report
        row["roles"].append("carrier")
    except nm.NormaliseError as error:
        row["CARRIER_REFUSED"] = str(error)
    try:
        features, labels, info = ul.derive_labels(frame, meta)
        x, y, report = nm.clean(features, labels)
        nm.split(x, y, 0)
        row.update(label={**info, **report}, roles=[*row["roles"], "labelled"])
        row["skipped_detectors"] = nm.skipped_detectors(int(0.7 * len(y)))
    except (ul.NoLabels, nm.NormaliseError) as error:
        row["label_refused"] = str(error)
    return row


def x_pool_row__mutmut_50(meta: dict[str, Any], path: Path, digest: str) -> dict[str, Any]:
    frame = ul.read_table(path)
    row: dict[str, Any] = {
        "uci_id": meta["uci_id"],
        "name": meta.get("name"),
        "licence": meta.get("licence"),
        "url": meta.get("data_url"),
        "sha256": digest,
        "roles": [],
    }
    try:
        features, _ = ul.split_columns(frame, meta)
        _, _, report = nm.clean(features, [0] * len(features))
        row["carrier"] = report
        row["roles"].append("carrier")
    except nm.NormaliseError as error:
        row["carrier_refused"] = str(None)
    try:
        features, labels, info = ul.derive_labels(frame, meta)
        x, y, report = nm.clean(features, labels)
        nm.split(x, y, 0)
        row.update(label={**info, **report}, roles=[*row["roles"], "labelled"])
        row["skipped_detectors"] = nm.skipped_detectors(int(0.7 * len(y)))
    except (ul.NoLabels, nm.NormaliseError) as error:
        row["label_refused"] = str(error)
    return row


def x_pool_row__mutmut_51(meta: dict[str, Any], path: Path, digest: str) -> dict[str, Any]:
    frame = ul.read_table(path)
    row: dict[str, Any] = {
        "uci_id": meta["uci_id"],
        "name": meta.get("name"),
        "licence": meta.get("licence"),
        "url": meta.get("data_url"),
        "sha256": digest,
        "roles": [],
    }
    try:
        features, _ = ul.split_columns(frame, meta)
        _, _, report = nm.clean(features, [0] * len(features))
        row["carrier"] = report
        row["roles"].append("carrier")
    except nm.NormaliseError as error:
        row["carrier_refused"] = str(error)
    try:
        features, labels, info = None
        x, y, report = nm.clean(features, labels)
        nm.split(x, y, 0)
        row.update(label={**info, **report}, roles=[*row["roles"], "labelled"])
        row["skipped_detectors"] = nm.skipped_detectors(int(0.7 * len(y)))
    except (ul.NoLabels, nm.NormaliseError) as error:
        row["label_refused"] = str(error)
    return row


def x_pool_row__mutmut_52(meta: dict[str, Any], path: Path, digest: str) -> dict[str, Any]:
    frame = ul.read_table(path)
    row: dict[str, Any] = {
        "uci_id": meta["uci_id"],
        "name": meta.get("name"),
        "licence": meta.get("licence"),
        "url": meta.get("data_url"),
        "sha256": digest,
        "roles": [],
    }
    try:
        features, _ = ul.split_columns(frame, meta)
        _, _, report = nm.clean(features, [0] * len(features))
        row["carrier"] = report
        row["roles"].append("carrier")
    except nm.NormaliseError as error:
        row["carrier_refused"] = str(error)
    try:
        features, labels, info = ul.derive_labels(None, meta)
        x, y, report = nm.clean(features, labels)
        nm.split(x, y, 0)
        row.update(label={**info, **report}, roles=[*row["roles"], "labelled"])
        row["skipped_detectors"] = nm.skipped_detectors(int(0.7 * len(y)))
    except (ul.NoLabels, nm.NormaliseError) as error:
        row["label_refused"] = str(error)
    return row


def x_pool_row__mutmut_53(meta: dict[str, Any], path: Path, digest: str) -> dict[str, Any]:
    frame = ul.read_table(path)
    row: dict[str, Any] = {
        "uci_id": meta["uci_id"],
        "name": meta.get("name"),
        "licence": meta.get("licence"),
        "url": meta.get("data_url"),
        "sha256": digest,
        "roles": [],
    }
    try:
        features, _ = ul.split_columns(frame, meta)
        _, _, report = nm.clean(features, [0] * len(features))
        row["carrier"] = report
        row["roles"].append("carrier")
    except nm.NormaliseError as error:
        row["carrier_refused"] = str(error)
    try:
        features, labels, info = ul.derive_labels(frame, None)
        x, y, report = nm.clean(features, labels)
        nm.split(x, y, 0)
        row.update(label={**info, **report}, roles=[*row["roles"], "labelled"])
        row["skipped_detectors"] = nm.skipped_detectors(int(0.7 * len(y)))
    except (ul.NoLabels, nm.NormaliseError) as error:
        row["label_refused"] = str(error)
    return row


def x_pool_row__mutmut_54(meta: dict[str, Any], path: Path, digest: str) -> dict[str, Any]:
    frame = ul.read_table(path)
    row: dict[str, Any] = {
        "uci_id": meta["uci_id"],
        "name": meta.get("name"),
        "licence": meta.get("licence"),
        "url": meta.get("data_url"),
        "sha256": digest,
        "roles": [],
    }
    try:
        features, _ = ul.split_columns(frame, meta)
        _, _, report = nm.clean(features, [0] * len(features))
        row["carrier"] = report
        row["roles"].append("carrier")
    except nm.NormaliseError as error:
        row["carrier_refused"] = str(error)
    try:
        features, labels, info = ul.derive_labels(meta)
        x, y, report = nm.clean(features, labels)
        nm.split(x, y, 0)
        row.update(label={**info, **report}, roles=[*row["roles"], "labelled"])
        row["skipped_detectors"] = nm.skipped_detectors(int(0.7 * len(y)))
    except (ul.NoLabels, nm.NormaliseError) as error:
        row["label_refused"] = str(error)
    return row


def x_pool_row__mutmut_55(meta: dict[str, Any], path: Path, digest: str) -> dict[str, Any]:
    frame = ul.read_table(path)
    row: dict[str, Any] = {
        "uci_id": meta["uci_id"],
        "name": meta.get("name"),
        "licence": meta.get("licence"),
        "url": meta.get("data_url"),
        "sha256": digest,
        "roles": [],
    }
    try:
        features, _ = ul.split_columns(frame, meta)
        _, _, report = nm.clean(features, [0] * len(features))
        row["carrier"] = report
        row["roles"].append("carrier")
    except nm.NormaliseError as error:
        row["carrier_refused"] = str(error)
    try:
        features, labels, info = ul.derive_labels(frame, )
        x, y, report = nm.clean(features, labels)
        nm.split(x, y, 0)
        row.update(label={**info, **report}, roles=[*row["roles"], "labelled"])
        row["skipped_detectors"] = nm.skipped_detectors(int(0.7 * len(y)))
    except (ul.NoLabels, nm.NormaliseError) as error:
        row["label_refused"] = str(error)
    return row


def x_pool_row__mutmut_56(meta: dict[str, Any], path: Path, digest: str) -> dict[str, Any]:
    frame = ul.read_table(path)
    row: dict[str, Any] = {
        "uci_id": meta["uci_id"],
        "name": meta.get("name"),
        "licence": meta.get("licence"),
        "url": meta.get("data_url"),
        "sha256": digest,
        "roles": [],
    }
    try:
        features, _ = ul.split_columns(frame, meta)
        _, _, report = nm.clean(features, [0] * len(features))
        row["carrier"] = report
        row["roles"].append("carrier")
    except nm.NormaliseError as error:
        row["carrier_refused"] = str(error)
    try:
        features, labels, info = ul.derive_labels(frame, meta)
        x, y, report = None
        nm.split(x, y, 0)
        row.update(label={**info, **report}, roles=[*row["roles"], "labelled"])
        row["skipped_detectors"] = nm.skipped_detectors(int(0.7 * len(y)))
    except (ul.NoLabels, nm.NormaliseError) as error:
        row["label_refused"] = str(error)
    return row


def x_pool_row__mutmut_57(meta: dict[str, Any], path: Path, digest: str) -> dict[str, Any]:
    frame = ul.read_table(path)
    row: dict[str, Any] = {
        "uci_id": meta["uci_id"],
        "name": meta.get("name"),
        "licence": meta.get("licence"),
        "url": meta.get("data_url"),
        "sha256": digest,
        "roles": [],
    }
    try:
        features, _ = ul.split_columns(frame, meta)
        _, _, report = nm.clean(features, [0] * len(features))
        row["carrier"] = report
        row["roles"].append("carrier")
    except nm.NormaliseError as error:
        row["carrier_refused"] = str(error)
    try:
        features, labels, info = ul.derive_labels(frame, meta)
        x, y, report = nm.clean(None, labels)
        nm.split(x, y, 0)
        row.update(label={**info, **report}, roles=[*row["roles"], "labelled"])
        row["skipped_detectors"] = nm.skipped_detectors(int(0.7 * len(y)))
    except (ul.NoLabels, nm.NormaliseError) as error:
        row["label_refused"] = str(error)
    return row


def x_pool_row__mutmut_58(meta: dict[str, Any], path: Path, digest: str) -> dict[str, Any]:
    frame = ul.read_table(path)
    row: dict[str, Any] = {
        "uci_id": meta["uci_id"],
        "name": meta.get("name"),
        "licence": meta.get("licence"),
        "url": meta.get("data_url"),
        "sha256": digest,
        "roles": [],
    }
    try:
        features, _ = ul.split_columns(frame, meta)
        _, _, report = nm.clean(features, [0] * len(features))
        row["carrier"] = report
        row["roles"].append("carrier")
    except nm.NormaliseError as error:
        row["carrier_refused"] = str(error)
    try:
        features, labels, info = ul.derive_labels(frame, meta)
        x, y, report = nm.clean(features, None)
        nm.split(x, y, 0)
        row.update(label={**info, **report}, roles=[*row["roles"], "labelled"])
        row["skipped_detectors"] = nm.skipped_detectors(int(0.7 * len(y)))
    except (ul.NoLabels, nm.NormaliseError) as error:
        row["label_refused"] = str(error)
    return row


def x_pool_row__mutmut_59(meta: dict[str, Any], path: Path, digest: str) -> dict[str, Any]:
    frame = ul.read_table(path)
    row: dict[str, Any] = {
        "uci_id": meta["uci_id"],
        "name": meta.get("name"),
        "licence": meta.get("licence"),
        "url": meta.get("data_url"),
        "sha256": digest,
        "roles": [],
    }
    try:
        features, _ = ul.split_columns(frame, meta)
        _, _, report = nm.clean(features, [0] * len(features))
        row["carrier"] = report
        row["roles"].append("carrier")
    except nm.NormaliseError as error:
        row["carrier_refused"] = str(error)
    try:
        features, labels, info = ul.derive_labels(frame, meta)
        x, y, report = nm.clean(labels)
        nm.split(x, y, 0)
        row.update(label={**info, **report}, roles=[*row["roles"], "labelled"])
        row["skipped_detectors"] = nm.skipped_detectors(int(0.7 * len(y)))
    except (ul.NoLabels, nm.NormaliseError) as error:
        row["label_refused"] = str(error)
    return row


def x_pool_row__mutmut_60(meta: dict[str, Any], path: Path, digest: str) -> dict[str, Any]:
    frame = ul.read_table(path)
    row: dict[str, Any] = {
        "uci_id": meta["uci_id"],
        "name": meta.get("name"),
        "licence": meta.get("licence"),
        "url": meta.get("data_url"),
        "sha256": digest,
        "roles": [],
    }
    try:
        features, _ = ul.split_columns(frame, meta)
        _, _, report = nm.clean(features, [0] * len(features))
        row["carrier"] = report
        row["roles"].append("carrier")
    except nm.NormaliseError as error:
        row["carrier_refused"] = str(error)
    try:
        features, labels, info = ul.derive_labels(frame, meta)
        x, y, report = nm.clean(features, )
        nm.split(x, y, 0)
        row.update(label={**info, **report}, roles=[*row["roles"], "labelled"])
        row["skipped_detectors"] = nm.skipped_detectors(int(0.7 * len(y)))
    except (ul.NoLabels, nm.NormaliseError) as error:
        row["label_refused"] = str(error)
    return row


def x_pool_row__mutmut_61(meta: dict[str, Any], path: Path, digest: str) -> dict[str, Any]:
    frame = ul.read_table(path)
    row: dict[str, Any] = {
        "uci_id": meta["uci_id"],
        "name": meta.get("name"),
        "licence": meta.get("licence"),
        "url": meta.get("data_url"),
        "sha256": digest,
        "roles": [],
    }
    try:
        features, _ = ul.split_columns(frame, meta)
        _, _, report = nm.clean(features, [0] * len(features))
        row["carrier"] = report
        row["roles"].append("carrier")
    except nm.NormaliseError as error:
        row["carrier_refused"] = str(error)
    try:
        features, labels, info = ul.derive_labels(frame, meta)
        x, y, report = nm.clean(features, labels)
        nm.split(None, y, 0)
        row.update(label={**info, **report}, roles=[*row["roles"], "labelled"])
        row["skipped_detectors"] = nm.skipped_detectors(int(0.7 * len(y)))
    except (ul.NoLabels, nm.NormaliseError) as error:
        row["label_refused"] = str(error)
    return row


def x_pool_row__mutmut_62(meta: dict[str, Any], path: Path, digest: str) -> dict[str, Any]:
    frame = ul.read_table(path)
    row: dict[str, Any] = {
        "uci_id": meta["uci_id"],
        "name": meta.get("name"),
        "licence": meta.get("licence"),
        "url": meta.get("data_url"),
        "sha256": digest,
        "roles": [],
    }
    try:
        features, _ = ul.split_columns(frame, meta)
        _, _, report = nm.clean(features, [0] * len(features))
        row["carrier"] = report
        row["roles"].append("carrier")
    except nm.NormaliseError as error:
        row["carrier_refused"] = str(error)
    try:
        features, labels, info = ul.derive_labels(frame, meta)
        x, y, report = nm.clean(features, labels)
        nm.split(x, None, 0)
        row.update(label={**info, **report}, roles=[*row["roles"], "labelled"])
        row["skipped_detectors"] = nm.skipped_detectors(int(0.7 * len(y)))
    except (ul.NoLabels, nm.NormaliseError) as error:
        row["label_refused"] = str(error)
    return row


def x_pool_row__mutmut_63(meta: dict[str, Any], path: Path, digest: str) -> dict[str, Any]:
    frame = ul.read_table(path)
    row: dict[str, Any] = {
        "uci_id": meta["uci_id"],
        "name": meta.get("name"),
        "licence": meta.get("licence"),
        "url": meta.get("data_url"),
        "sha256": digest,
        "roles": [],
    }
    try:
        features, _ = ul.split_columns(frame, meta)
        _, _, report = nm.clean(features, [0] * len(features))
        row["carrier"] = report
        row["roles"].append("carrier")
    except nm.NormaliseError as error:
        row["carrier_refused"] = str(error)
    try:
        features, labels, info = ul.derive_labels(frame, meta)
        x, y, report = nm.clean(features, labels)
        nm.split(x, y, None)
        row.update(label={**info, **report}, roles=[*row["roles"], "labelled"])
        row["skipped_detectors"] = nm.skipped_detectors(int(0.7 * len(y)))
    except (ul.NoLabels, nm.NormaliseError) as error:
        row["label_refused"] = str(error)
    return row


def x_pool_row__mutmut_64(meta: dict[str, Any], path: Path, digest: str) -> dict[str, Any]:
    frame = ul.read_table(path)
    row: dict[str, Any] = {
        "uci_id": meta["uci_id"],
        "name": meta.get("name"),
        "licence": meta.get("licence"),
        "url": meta.get("data_url"),
        "sha256": digest,
        "roles": [],
    }
    try:
        features, _ = ul.split_columns(frame, meta)
        _, _, report = nm.clean(features, [0] * len(features))
        row["carrier"] = report
        row["roles"].append("carrier")
    except nm.NormaliseError as error:
        row["carrier_refused"] = str(error)
    try:
        features, labels, info = ul.derive_labels(frame, meta)
        x, y, report = nm.clean(features, labels)
        nm.split(y, 0)
        row.update(label={**info, **report}, roles=[*row["roles"], "labelled"])
        row["skipped_detectors"] = nm.skipped_detectors(int(0.7 * len(y)))
    except (ul.NoLabels, nm.NormaliseError) as error:
        row["label_refused"] = str(error)
    return row


def x_pool_row__mutmut_65(meta: dict[str, Any], path: Path, digest: str) -> dict[str, Any]:
    frame = ul.read_table(path)
    row: dict[str, Any] = {
        "uci_id": meta["uci_id"],
        "name": meta.get("name"),
        "licence": meta.get("licence"),
        "url": meta.get("data_url"),
        "sha256": digest,
        "roles": [],
    }
    try:
        features, _ = ul.split_columns(frame, meta)
        _, _, report = nm.clean(features, [0] * len(features))
        row["carrier"] = report
        row["roles"].append("carrier")
    except nm.NormaliseError as error:
        row["carrier_refused"] = str(error)
    try:
        features, labels, info = ul.derive_labels(frame, meta)
        x, y, report = nm.clean(features, labels)
        nm.split(x, 0)
        row.update(label={**info, **report}, roles=[*row["roles"], "labelled"])
        row["skipped_detectors"] = nm.skipped_detectors(int(0.7 * len(y)))
    except (ul.NoLabels, nm.NormaliseError) as error:
        row["label_refused"] = str(error)
    return row


def x_pool_row__mutmut_66(meta: dict[str, Any], path: Path, digest: str) -> dict[str, Any]:
    frame = ul.read_table(path)
    row: dict[str, Any] = {
        "uci_id": meta["uci_id"],
        "name": meta.get("name"),
        "licence": meta.get("licence"),
        "url": meta.get("data_url"),
        "sha256": digest,
        "roles": [],
    }
    try:
        features, _ = ul.split_columns(frame, meta)
        _, _, report = nm.clean(features, [0] * len(features))
        row["carrier"] = report
        row["roles"].append("carrier")
    except nm.NormaliseError as error:
        row["carrier_refused"] = str(error)
    try:
        features, labels, info = ul.derive_labels(frame, meta)
        x, y, report = nm.clean(features, labels)
        nm.split(x, y, )
        row.update(label={**info, **report}, roles=[*row["roles"], "labelled"])
        row["skipped_detectors"] = nm.skipped_detectors(int(0.7 * len(y)))
    except (ul.NoLabels, nm.NormaliseError) as error:
        row["label_refused"] = str(error)
    return row


def x_pool_row__mutmut_67(meta: dict[str, Any], path: Path, digest: str) -> dict[str, Any]:
    frame = ul.read_table(path)
    row: dict[str, Any] = {
        "uci_id": meta["uci_id"],
        "name": meta.get("name"),
        "licence": meta.get("licence"),
        "url": meta.get("data_url"),
        "sha256": digest,
        "roles": [],
    }
    try:
        features, _ = ul.split_columns(frame, meta)
        _, _, report = nm.clean(features, [0] * len(features))
        row["carrier"] = report
        row["roles"].append("carrier")
    except nm.NormaliseError as error:
        row["carrier_refused"] = str(error)
    try:
        features, labels, info = ul.derive_labels(frame, meta)
        x, y, report = nm.clean(features, labels)
        nm.split(x, y, 1)
        row.update(label={**info, **report}, roles=[*row["roles"], "labelled"])
        row["skipped_detectors"] = nm.skipped_detectors(int(0.7 * len(y)))
    except (ul.NoLabels, nm.NormaliseError) as error:
        row["label_refused"] = str(error)
    return row


def x_pool_row__mutmut_68(meta: dict[str, Any], path: Path, digest: str) -> dict[str, Any]:
    frame = ul.read_table(path)
    row: dict[str, Any] = {
        "uci_id": meta["uci_id"],
        "name": meta.get("name"),
        "licence": meta.get("licence"),
        "url": meta.get("data_url"),
        "sha256": digest,
        "roles": [],
    }
    try:
        features, _ = ul.split_columns(frame, meta)
        _, _, report = nm.clean(features, [0] * len(features))
        row["carrier"] = report
        row["roles"].append("carrier")
    except nm.NormaliseError as error:
        row["carrier_refused"] = str(error)
    try:
        features, labels, info = ul.derive_labels(frame, meta)
        x, y, report = nm.clean(features, labels)
        nm.split(x, y, 0)
        row.update(label=None, roles=[*row["roles"], "labelled"])
        row["skipped_detectors"] = nm.skipped_detectors(int(0.7 * len(y)))
    except (ul.NoLabels, nm.NormaliseError) as error:
        row["label_refused"] = str(error)
    return row


def x_pool_row__mutmut_69(meta: dict[str, Any], path: Path, digest: str) -> dict[str, Any]:
    frame = ul.read_table(path)
    row: dict[str, Any] = {
        "uci_id": meta["uci_id"],
        "name": meta.get("name"),
        "licence": meta.get("licence"),
        "url": meta.get("data_url"),
        "sha256": digest,
        "roles": [],
    }
    try:
        features, _ = ul.split_columns(frame, meta)
        _, _, report = nm.clean(features, [0] * len(features))
        row["carrier"] = report
        row["roles"].append("carrier")
    except nm.NormaliseError as error:
        row["carrier_refused"] = str(error)
    try:
        features, labels, info = ul.derive_labels(frame, meta)
        x, y, report = nm.clean(features, labels)
        nm.split(x, y, 0)
        row.update(label={**info, **report}, roles=None)
        row["skipped_detectors"] = nm.skipped_detectors(int(0.7 * len(y)))
    except (ul.NoLabels, nm.NormaliseError) as error:
        row["label_refused"] = str(error)
    return row


def x_pool_row__mutmut_70(meta: dict[str, Any], path: Path, digest: str) -> dict[str, Any]:
    frame = ul.read_table(path)
    row: dict[str, Any] = {
        "uci_id": meta["uci_id"],
        "name": meta.get("name"),
        "licence": meta.get("licence"),
        "url": meta.get("data_url"),
        "sha256": digest,
        "roles": [],
    }
    try:
        features, _ = ul.split_columns(frame, meta)
        _, _, report = nm.clean(features, [0] * len(features))
        row["carrier"] = report
        row["roles"].append("carrier")
    except nm.NormaliseError as error:
        row["carrier_refused"] = str(error)
    try:
        features, labels, info = ul.derive_labels(frame, meta)
        x, y, report = nm.clean(features, labels)
        nm.split(x, y, 0)
        row.update(roles=[*row["roles"], "labelled"])
        row["skipped_detectors"] = nm.skipped_detectors(int(0.7 * len(y)))
    except (ul.NoLabels, nm.NormaliseError) as error:
        row["label_refused"] = str(error)
    return row


def x_pool_row__mutmut_71(meta: dict[str, Any], path: Path, digest: str) -> dict[str, Any]:
    frame = ul.read_table(path)
    row: dict[str, Any] = {
        "uci_id": meta["uci_id"],
        "name": meta.get("name"),
        "licence": meta.get("licence"),
        "url": meta.get("data_url"),
        "sha256": digest,
        "roles": [],
    }
    try:
        features, _ = ul.split_columns(frame, meta)
        _, _, report = nm.clean(features, [0] * len(features))
        row["carrier"] = report
        row["roles"].append("carrier")
    except nm.NormaliseError as error:
        row["carrier_refused"] = str(error)
    try:
        features, labels, info = ul.derive_labels(frame, meta)
        x, y, report = nm.clean(features, labels)
        nm.split(x, y, 0)
        row.update(label={**info, **report}, )
        row["skipped_detectors"] = nm.skipped_detectors(int(0.7 * len(y)))
    except (ul.NoLabels, nm.NormaliseError) as error:
        row["label_refused"] = str(error)
    return row


def x_pool_row__mutmut_72(meta: dict[str, Any], path: Path, digest: str) -> dict[str, Any]:
    frame = ul.read_table(path)
    row: dict[str, Any] = {
        "uci_id": meta["uci_id"],
        "name": meta.get("name"),
        "licence": meta.get("licence"),
        "url": meta.get("data_url"),
        "sha256": digest,
        "roles": [],
    }
    try:
        features, _ = ul.split_columns(frame, meta)
        _, _, report = nm.clean(features, [0] * len(features))
        row["carrier"] = report
        row["roles"].append("carrier")
    except nm.NormaliseError as error:
        row["carrier_refused"] = str(error)
    try:
        features, labels, info = ul.derive_labels(frame, meta)
        x, y, report = nm.clean(features, labels)
        nm.split(x, y, 0)
        row.update(label={**info, **report}, roles=[*row["XXrolesXX"], "labelled"])
        row["skipped_detectors"] = nm.skipped_detectors(int(0.7 * len(y)))
    except (ul.NoLabels, nm.NormaliseError) as error:
        row["label_refused"] = str(error)
    return row


def x_pool_row__mutmut_73(meta: dict[str, Any], path: Path, digest: str) -> dict[str, Any]:
    frame = ul.read_table(path)
    row: dict[str, Any] = {
        "uci_id": meta["uci_id"],
        "name": meta.get("name"),
        "licence": meta.get("licence"),
        "url": meta.get("data_url"),
        "sha256": digest,
        "roles": [],
    }
    try:
        features, _ = ul.split_columns(frame, meta)
        _, _, report = nm.clean(features, [0] * len(features))
        row["carrier"] = report
        row["roles"].append("carrier")
    except nm.NormaliseError as error:
        row["carrier_refused"] = str(error)
    try:
        features, labels, info = ul.derive_labels(frame, meta)
        x, y, report = nm.clean(features, labels)
        nm.split(x, y, 0)
        row.update(label={**info, **report}, roles=[*row["ROLES"], "labelled"])
        row["skipped_detectors"] = nm.skipped_detectors(int(0.7 * len(y)))
    except (ul.NoLabels, nm.NormaliseError) as error:
        row["label_refused"] = str(error)
    return row


def x_pool_row__mutmut_74(meta: dict[str, Any], path: Path, digest: str) -> dict[str, Any]:
    frame = ul.read_table(path)
    row: dict[str, Any] = {
        "uci_id": meta["uci_id"],
        "name": meta.get("name"),
        "licence": meta.get("licence"),
        "url": meta.get("data_url"),
        "sha256": digest,
        "roles": [],
    }
    try:
        features, _ = ul.split_columns(frame, meta)
        _, _, report = nm.clean(features, [0] * len(features))
        row["carrier"] = report
        row["roles"].append("carrier")
    except nm.NormaliseError as error:
        row["carrier_refused"] = str(error)
    try:
        features, labels, info = ul.derive_labels(frame, meta)
        x, y, report = nm.clean(features, labels)
        nm.split(x, y, 0)
        row.update(label={**info, **report}, roles=[*row["roles"], "XXlabelledXX"])
        row["skipped_detectors"] = nm.skipped_detectors(int(0.7 * len(y)))
    except (ul.NoLabels, nm.NormaliseError) as error:
        row["label_refused"] = str(error)
    return row


def x_pool_row__mutmut_75(meta: dict[str, Any], path: Path, digest: str) -> dict[str, Any]:
    frame = ul.read_table(path)
    row: dict[str, Any] = {
        "uci_id": meta["uci_id"],
        "name": meta.get("name"),
        "licence": meta.get("licence"),
        "url": meta.get("data_url"),
        "sha256": digest,
        "roles": [],
    }
    try:
        features, _ = ul.split_columns(frame, meta)
        _, _, report = nm.clean(features, [0] * len(features))
        row["carrier"] = report
        row["roles"].append("carrier")
    except nm.NormaliseError as error:
        row["carrier_refused"] = str(error)
    try:
        features, labels, info = ul.derive_labels(frame, meta)
        x, y, report = nm.clean(features, labels)
        nm.split(x, y, 0)
        row.update(label={**info, **report}, roles=[*row["roles"], "LABELLED"])
        row["skipped_detectors"] = nm.skipped_detectors(int(0.7 * len(y)))
    except (ul.NoLabels, nm.NormaliseError) as error:
        row["label_refused"] = str(error)
    return row


def x_pool_row__mutmut_76(meta: dict[str, Any], path: Path, digest: str) -> dict[str, Any]:
    frame = ul.read_table(path)
    row: dict[str, Any] = {
        "uci_id": meta["uci_id"],
        "name": meta.get("name"),
        "licence": meta.get("licence"),
        "url": meta.get("data_url"),
        "sha256": digest,
        "roles": [],
    }
    try:
        features, _ = ul.split_columns(frame, meta)
        _, _, report = nm.clean(features, [0] * len(features))
        row["carrier"] = report
        row["roles"].append("carrier")
    except nm.NormaliseError as error:
        row["carrier_refused"] = str(error)
    try:
        features, labels, info = ul.derive_labels(frame, meta)
        x, y, report = nm.clean(features, labels)
        nm.split(x, y, 0)
        row.update(label={**info, **report}, roles=[*row["roles"], "labelled"])
        row["skipped_detectors"] = None
    except (ul.NoLabels, nm.NormaliseError) as error:
        row["label_refused"] = str(error)
    return row


def x_pool_row__mutmut_77(meta: dict[str, Any], path: Path, digest: str) -> dict[str, Any]:
    frame = ul.read_table(path)
    row: dict[str, Any] = {
        "uci_id": meta["uci_id"],
        "name": meta.get("name"),
        "licence": meta.get("licence"),
        "url": meta.get("data_url"),
        "sha256": digest,
        "roles": [],
    }
    try:
        features, _ = ul.split_columns(frame, meta)
        _, _, report = nm.clean(features, [0] * len(features))
        row["carrier"] = report
        row["roles"].append("carrier")
    except nm.NormaliseError as error:
        row["carrier_refused"] = str(error)
    try:
        features, labels, info = ul.derive_labels(frame, meta)
        x, y, report = nm.clean(features, labels)
        nm.split(x, y, 0)
        row.update(label={**info, **report}, roles=[*row["roles"], "labelled"])
        row["XXskipped_detectorsXX"] = nm.skipped_detectors(int(0.7 * len(y)))
    except (ul.NoLabels, nm.NormaliseError) as error:
        row["label_refused"] = str(error)
    return row


def x_pool_row__mutmut_78(meta: dict[str, Any], path: Path, digest: str) -> dict[str, Any]:
    frame = ul.read_table(path)
    row: dict[str, Any] = {
        "uci_id": meta["uci_id"],
        "name": meta.get("name"),
        "licence": meta.get("licence"),
        "url": meta.get("data_url"),
        "sha256": digest,
        "roles": [],
    }
    try:
        features, _ = ul.split_columns(frame, meta)
        _, _, report = nm.clean(features, [0] * len(features))
        row["carrier"] = report
        row["roles"].append("carrier")
    except nm.NormaliseError as error:
        row["carrier_refused"] = str(error)
    try:
        features, labels, info = ul.derive_labels(frame, meta)
        x, y, report = nm.clean(features, labels)
        nm.split(x, y, 0)
        row.update(label={**info, **report}, roles=[*row["roles"], "labelled"])
        row["SKIPPED_DETECTORS"] = nm.skipped_detectors(int(0.7 * len(y)))
    except (ul.NoLabels, nm.NormaliseError) as error:
        row["label_refused"] = str(error)
    return row


def x_pool_row__mutmut_79(meta: dict[str, Any], path: Path, digest: str) -> dict[str, Any]:
    frame = ul.read_table(path)
    row: dict[str, Any] = {
        "uci_id": meta["uci_id"],
        "name": meta.get("name"),
        "licence": meta.get("licence"),
        "url": meta.get("data_url"),
        "sha256": digest,
        "roles": [],
    }
    try:
        features, _ = ul.split_columns(frame, meta)
        _, _, report = nm.clean(features, [0] * len(features))
        row["carrier"] = report
        row["roles"].append("carrier")
    except nm.NormaliseError as error:
        row["carrier_refused"] = str(error)
    try:
        features, labels, info = ul.derive_labels(frame, meta)
        x, y, report = nm.clean(features, labels)
        nm.split(x, y, 0)
        row.update(label={**info, **report}, roles=[*row["roles"], "labelled"])
        row["skipped_detectors"] = nm.skipped_detectors(None)
    except (ul.NoLabels, nm.NormaliseError) as error:
        row["label_refused"] = str(error)
    return row


def x_pool_row__mutmut_80(meta: dict[str, Any], path: Path, digest: str) -> dict[str, Any]:
    frame = ul.read_table(path)
    row: dict[str, Any] = {
        "uci_id": meta["uci_id"],
        "name": meta.get("name"),
        "licence": meta.get("licence"),
        "url": meta.get("data_url"),
        "sha256": digest,
        "roles": [],
    }
    try:
        features, _ = ul.split_columns(frame, meta)
        _, _, report = nm.clean(features, [0] * len(features))
        row["carrier"] = report
        row["roles"].append("carrier")
    except nm.NormaliseError as error:
        row["carrier_refused"] = str(error)
    try:
        features, labels, info = ul.derive_labels(frame, meta)
        x, y, report = nm.clean(features, labels)
        nm.split(x, y, 0)
        row.update(label={**info, **report}, roles=[*row["roles"], "labelled"])
        row["skipped_detectors"] = nm.skipped_detectors(int(None))
    except (ul.NoLabels, nm.NormaliseError) as error:
        row["label_refused"] = str(error)
    return row


def x_pool_row__mutmut_81(meta: dict[str, Any], path: Path, digest: str) -> dict[str, Any]:
    frame = ul.read_table(path)
    row: dict[str, Any] = {
        "uci_id": meta["uci_id"],
        "name": meta.get("name"),
        "licence": meta.get("licence"),
        "url": meta.get("data_url"),
        "sha256": digest,
        "roles": [],
    }
    try:
        features, _ = ul.split_columns(frame, meta)
        _, _, report = nm.clean(features, [0] * len(features))
        row["carrier"] = report
        row["roles"].append("carrier")
    except nm.NormaliseError as error:
        row["carrier_refused"] = str(error)
    try:
        features, labels, info = ul.derive_labels(frame, meta)
        x, y, report = nm.clean(features, labels)
        nm.split(x, y, 0)
        row.update(label={**info, **report}, roles=[*row["roles"], "labelled"])
        row["skipped_detectors"] = nm.skipped_detectors(int(0.7 / len(y)))
    except (ul.NoLabels, nm.NormaliseError) as error:
        row["label_refused"] = str(error)
    return row


def x_pool_row__mutmut_82(meta: dict[str, Any], path: Path, digest: str) -> dict[str, Any]:
    frame = ul.read_table(path)
    row: dict[str, Any] = {
        "uci_id": meta["uci_id"],
        "name": meta.get("name"),
        "licence": meta.get("licence"),
        "url": meta.get("data_url"),
        "sha256": digest,
        "roles": [],
    }
    try:
        features, _ = ul.split_columns(frame, meta)
        _, _, report = nm.clean(features, [0] * len(features))
        row["carrier"] = report
        row["roles"].append("carrier")
    except nm.NormaliseError as error:
        row["carrier_refused"] = str(error)
    try:
        features, labels, info = ul.derive_labels(frame, meta)
        x, y, report = nm.clean(features, labels)
        nm.split(x, y, 0)
        row.update(label={**info, **report}, roles=[*row["roles"], "labelled"])
        row["skipped_detectors"] = nm.skipped_detectors(int(1.7 * len(y)))
    except (ul.NoLabels, nm.NormaliseError) as error:
        row["label_refused"] = str(error)
    return row


def x_pool_row__mutmut_83(meta: dict[str, Any], path: Path, digest: str) -> dict[str, Any]:
    frame = ul.read_table(path)
    row: dict[str, Any] = {
        "uci_id": meta["uci_id"],
        "name": meta.get("name"),
        "licence": meta.get("licence"),
        "url": meta.get("data_url"),
        "sha256": digest,
        "roles": [],
    }
    try:
        features, _ = ul.split_columns(frame, meta)
        _, _, report = nm.clean(features, [0] * len(features))
        row["carrier"] = report
        row["roles"].append("carrier")
    except nm.NormaliseError as error:
        row["carrier_refused"] = str(error)
    try:
        features, labels, info = ul.derive_labels(frame, meta)
        x, y, report = nm.clean(features, labels)
        nm.split(x, y, 0)
        row.update(label={**info, **report}, roles=[*row["roles"], "labelled"])
        row["skipped_detectors"] = nm.skipped_detectors(int(0.7 * len(y)))
    except (ul.NoLabels, nm.NormaliseError) as error:
        row["label_refused"] = None
    return row


def x_pool_row__mutmut_84(meta: dict[str, Any], path: Path, digest: str) -> dict[str, Any]:
    frame = ul.read_table(path)
    row: dict[str, Any] = {
        "uci_id": meta["uci_id"],
        "name": meta.get("name"),
        "licence": meta.get("licence"),
        "url": meta.get("data_url"),
        "sha256": digest,
        "roles": [],
    }
    try:
        features, _ = ul.split_columns(frame, meta)
        _, _, report = nm.clean(features, [0] * len(features))
        row["carrier"] = report
        row["roles"].append("carrier")
    except nm.NormaliseError as error:
        row["carrier_refused"] = str(error)
    try:
        features, labels, info = ul.derive_labels(frame, meta)
        x, y, report = nm.clean(features, labels)
        nm.split(x, y, 0)
        row.update(label={**info, **report}, roles=[*row["roles"], "labelled"])
        row["skipped_detectors"] = nm.skipped_detectors(int(0.7 * len(y)))
    except (ul.NoLabels, nm.NormaliseError) as error:
        row["XXlabel_refusedXX"] = str(error)
    return row


def x_pool_row__mutmut_85(meta: dict[str, Any], path: Path, digest: str) -> dict[str, Any]:
    frame = ul.read_table(path)
    row: dict[str, Any] = {
        "uci_id": meta["uci_id"],
        "name": meta.get("name"),
        "licence": meta.get("licence"),
        "url": meta.get("data_url"),
        "sha256": digest,
        "roles": [],
    }
    try:
        features, _ = ul.split_columns(frame, meta)
        _, _, report = nm.clean(features, [0] * len(features))
        row["carrier"] = report
        row["roles"].append("carrier")
    except nm.NormaliseError as error:
        row["carrier_refused"] = str(error)
    try:
        features, labels, info = ul.derive_labels(frame, meta)
        x, y, report = nm.clean(features, labels)
        nm.split(x, y, 0)
        row.update(label={**info, **report}, roles=[*row["roles"], "labelled"])
        row["skipped_detectors"] = nm.skipped_detectors(int(0.7 * len(y)))
    except (ul.NoLabels, nm.NormaliseError) as error:
        row["LABEL_REFUSED"] = str(error)
    return row


def x_pool_row__mutmut_86(meta: dict[str, Any], path: Path, digest: str) -> dict[str, Any]:
    frame = ul.read_table(path)
    row: dict[str, Any] = {
        "uci_id": meta["uci_id"],
        "name": meta.get("name"),
        "licence": meta.get("licence"),
        "url": meta.get("data_url"),
        "sha256": digest,
        "roles": [],
    }
    try:
        features, _ = ul.split_columns(frame, meta)
        _, _, report = nm.clean(features, [0] * len(features))
        row["carrier"] = report
        row["roles"].append("carrier")
    except nm.NormaliseError as error:
        row["carrier_refused"] = str(error)
    try:
        features, labels, info = ul.derive_labels(frame, meta)
        x, y, report = nm.clean(features, labels)
        nm.split(x, y, 0)
        row.update(label={**info, **report}, roles=[*row["roles"], "labelled"])
        row["skipped_detectors"] = nm.skipped_detectors(int(0.7 * len(y)))
    except (ul.NoLabels, nm.NormaliseError) as error:
        row["label_refused"] = str(None)
    return row

mutants_x_pool_row__mutmut['_mutmut_orig'] = x_pool_row__mutmut_orig # type: ignore # mutmut generated
mutants_x_pool_row__mutmut['x_pool_row__mutmut_1'] = x_pool_row__mutmut_1 # type: ignore # mutmut generated
mutants_x_pool_row__mutmut['x_pool_row__mutmut_2'] = x_pool_row__mutmut_2 # type: ignore # mutmut generated
mutants_x_pool_row__mutmut['x_pool_row__mutmut_3'] = x_pool_row__mutmut_3 # type: ignore # mutmut generated
mutants_x_pool_row__mutmut['x_pool_row__mutmut_4'] = x_pool_row__mutmut_4 # type: ignore # mutmut generated
mutants_x_pool_row__mutmut['x_pool_row__mutmut_5'] = x_pool_row__mutmut_5 # type: ignore # mutmut generated
mutants_x_pool_row__mutmut['x_pool_row__mutmut_6'] = x_pool_row__mutmut_6 # type: ignore # mutmut generated
mutants_x_pool_row__mutmut['x_pool_row__mutmut_7'] = x_pool_row__mutmut_7 # type: ignore # mutmut generated
mutants_x_pool_row__mutmut['x_pool_row__mutmut_8'] = x_pool_row__mutmut_8 # type: ignore # mutmut generated
mutants_x_pool_row__mutmut['x_pool_row__mutmut_9'] = x_pool_row__mutmut_9 # type: ignore # mutmut generated
mutants_x_pool_row__mutmut['x_pool_row__mutmut_10'] = x_pool_row__mutmut_10 # type: ignore # mutmut generated
mutants_x_pool_row__mutmut['x_pool_row__mutmut_11'] = x_pool_row__mutmut_11 # type: ignore # mutmut generated
mutants_x_pool_row__mutmut['x_pool_row__mutmut_12'] = x_pool_row__mutmut_12 # type: ignore # mutmut generated
mutants_x_pool_row__mutmut['x_pool_row__mutmut_13'] = x_pool_row__mutmut_13 # type: ignore # mutmut generated
mutants_x_pool_row__mutmut['x_pool_row__mutmut_14'] = x_pool_row__mutmut_14 # type: ignore # mutmut generated
mutants_x_pool_row__mutmut['x_pool_row__mutmut_15'] = x_pool_row__mutmut_15 # type: ignore # mutmut generated
mutants_x_pool_row__mutmut['x_pool_row__mutmut_16'] = x_pool_row__mutmut_16 # type: ignore # mutmut generated
mutants_x_pool_row__mutmut['x_pool_row__mutmut_17'] = x_pool_row__mutmut_17 # type: ignore # mutmut generated
mutants_x_pool_row__mutmut['x_pool_row__mutmut_18'] = x_pool_row__mutmut_18 # type: ignore # mutmut generated
mutants_x_pool_row__mutmut['x_pool_row__mutmut_19'] = x_pool_row__mutmut_19 # type: ignore # mutmut generated
mutants_x_pool_row__mutmut['x_pool_row__mutmut_20'] = x_pool_row__mutmut_20 # type: ignore # mutmut generated
mutants_x_pool_row__mutmut['x_pool_row__mutmut_21'] = x_pool_row__mutmut_21 # type: ignore # mutmut generated
mutants_x_pool_row__mutmut['x_pool_row__mutmut_22'] = x_pool_row__mutmut_22 # type: ignore # mutmut generated
mutants_x_pool_row__mutmut['x_pool_row__mutmut_23'] = x_pool_row__mutmut_23 # type: ignore # mutmut generated
mutants_x_pool_row__mutmut['x_pool_row__mutmut_24'] = x_pool_row__mutmut_24 # type: ignore # mutmut generated
mutants_x_pool_row__mutmut['x_pool_row__mutmut_25'] = x_pool_row__mutmut_25 # type: ignore # mutmut generated
mutants_x_pool_row__mutmut['x_pool_row__mutmut_26'] = x_pool_row__mutmut_26 # type: ignore # mutmut generated
mutants_x_pool_row__mutmut['x_pool_row__mutmut_27'] = x_pool_row__mutmut_27 # type: ignore # mutmut generated
mutants_x_pool_row__mutmut['x_pool_row__mutmut_28'] = x_pool_row__mutmut_28 # type: ignore # mutmut generated
mutants_x_pool_row__mutmut['x_pool_row__mutmut_29'] = x_pool_row__mutmut_29 # type: ignore # mutmut generated
mutants_x_pool_row__mutmut['x_pool_row__mutmut_30'] = x_pool_row__mutmut_30 # type: ignore # mutmut generated
mutants_x_pool_row__mutmut['x_pool_row__mutmut_31'] = x_pool_row__mutmut_31 # type: ignore # mutmut generated
mutants_x_pool_row__mutmut['x_pool_row__mutmut_32'] = x_pool_row__mutmut_32 # type: ignore # mutmut generated
mutants_x_pool_row__mutmut['x_pool_row__mutmut_33'] = x_pool_row__mutmut_33 # type: ignore # mutmut generated
mutants_x_pool_row__mutmut['x_pool_row__mutmut_34'] = x_pool_row__mutmut_34 # type: ignore # mutmut generated
mutants_x_pool_row__mutmut['x_pool_row__mutmut_35'] = x_pool_row__mutmut_35 # type: ignore # mutmut generated
mutants_x_pool_row__mutmut['x_pool_row__mutmut_36'] = x_pool_row__mutmut_36 # type: ignore # mutmut generated
mutants_x_pool_row__mutmut['x_pool_row__mutmut_37'] = x_pool_row__mutmut_37 # type: ignore # mutmut generated
mutants_x_pool_row__mutmut['x_pool_row__mutmut_38'] = x_pool_row__mutmut_38 # type: ignore # mutmut generated
mutants_x_pool_row__mutmut['x_pool_row__mutmut_39'] = x_pool_row__mutmut_39 # type: ignore # mutmut generated
mutants_x_pool_row__mutmut['x_pool_row__mutmut_40'] = x_pool_row__mutmut_40 # type: ignore # mutmut generated
mutants_x_pool_row__mutmut['x_pool_row__mutmut_41'] = x_pool_row__mutmut_41 # type: ignore # mutmut generated
mutants_x_pool_row__mutmut['x_pool_row__mutmut_42'] = x_pool_row__mutmut_42 # type: ignore # mutmut generated
mutants_x_pool_row__mutmut['x_pool_row__mutmut_43'] = x_pool_row__mutmut_43 # type: ignore # mutmut generated
mutants_x_pool_row__mutmut['x_pool_row__mutmut_44'] = x_pool_row__mutmut_44 # type: ignore # mutmut generated
mutants_x_pool_row__mutmut['x_pool_row__mutmut_45'] = x_pool_row__mutmut_45 # type: ignore # mutmut generated
mutants_x_pool_row__mutmut['x_pool_row__mutmut_46'] = x_pool_row__mutmut_46 # type: ignore # mutmut generated
mutants_x_pool_row__mutmut['x_pool_row__mutmut_47'] = x_pool_row__mutmut_47 # type: ignore # mutmut generated
mutants_x_pool_row__mutmut['x_pool_row__mutmut_48'] = x_pool_row__mutmut_48 # type: ignore # mutmut generated
mutants_x_pool_row__mutmut['x_pool_row__mutmut_49'] = x_pool_row__mutmut_49 # type: ignore # mutmut generated
mutants_x_pool_row__mutmut['x_pool_row__mutmut_50'] = x_pool_row__mutmut_50 # type: ignore # mutmut generated
mutants_x_pool_row__mutmut['x_pool_row__mutmut_51'] = x_pool_row__mutmut_51 # type: ignore # mutmut generated
mutants_x_pool_row__mutmut['x_pool_row__mutmut_52'] = x_pool_row__mutmut_52 # type: ignore # mutmut generated
mutants_x_pool_row__mutmut['x_pool_row__mutmut_53'] = x_pool_row__mutmut_53 # type: ignore # mutmut generated
mutants_x_pool_row__mutmut['x_pool_row__mutmut_54'] = x_pool_row__mutmut_54 # type: ignore # mutmut generated
mutants_x_pool_row__mutmut['x_pool_row__mutmut_55'] = x_pool_row__mutmut_55 # type: ignore # mutmut generated
mutants_x_pool_row__mutmut['x_pool_row__mutmut_56'] = x_pool_row__mutmut_56 # type: ignore # mutmut generated
mutants_x_pool_row__mutmut['x_pool_row__mutmut_57'] = x_pool_row__mutmut_57 # type: ignore # mutmut generated
mutants_x_pool_row__mutmut['x_pool_row__mutmut_58'] = x_pool_row__mutmut_58 # type: ignore # mutmut generated
mutants_x_pool_row__mutmut['x_pool_row__mutmut_59'] = x_pool_row__mutmut_59 # type: ignore # mutmut generated
mutants_x_pool_row__mutmut['x_pool_row__mutmut_60'] = x_pool_row__mutmut_60 # type: ignore # mutmut generated
mutants_x_pool_row__mutmut['x_pool_row__mutmut_61'] = x_pool_row__mutmut_61 # type: ignore # mutmut generated
mutants_x_pool_row__mutmut['x_pool_row__mutmut_62'] = x_pool_row__mutmut_62 # type: ignore # mutmut generated
mutants_x_pool_row__mutmut['x_pool_row__mutmut_63'] = x_pool_row__mutmut_63 # type: ignore # mutmut generated
mutants_x_pool_row__mutmut['x_pool_row__mutmut_64'] = x_pool_row__mutmut_64 # type: ignore # mutmut generated
mutants_x_pool_row__mutmut['x_pool_row__mutmut_65'] = x_pool_row__mutmut_65 # type: ignore # mutmut generated
mutants_x_pool_row__mutmut['x_pool_row__mutmut_66'] = x_pool_row__mutmut_66 # type: ignore # mutmut generated
mutants_x_pool_row__mutmut['x_pool_row__mutmut_67'] = x_pool_row__mutmut_67 # type: ignore # mutmut generated
mutants_x_pool_row__mutmut['x_pool_row__mutmut_68'] = x_pool_row__mutmut_68 # type: ignore # mutmut generated
mutants_x_pool_row__mutmut['x_pool_row__mutmut_69'] = x_pool_row__mutmut_69 # type: ignore # mutmut generated
mutants_x_pool_row__mutmut['x_pool_row__mutmut_70'] = x_pool_row__mutmut_70 # type: ignore # mutmut generated
mutants_x_pool_row__mutmut['x_pool_row__mutmut_71'] = x_pool_row__mutmut_71 # type: ignore # mutmut generated
mutants_x_pool_row__mutmut['x_pool_row__mutmut_72'] = x_pool_row__mutmut_72 # type: ignore # mutmut generated
mutants_x_pool_row__mutmut['x_pool_row__mutmut_73'] = x_pool_row__mutmut_73 # type: ignore # mutmut generated
mutants_x_pool_row__mutmut['x_pool_row__mutmut_74'] = x_pool_row__mutmut_74 # type: ignore # mutmut generated
mutants_x_pool_row__mutmut['x_pool_row__mutmut_75'] = x_pool_row__mutmut_75 # type: ignore # mutmut generated
mutants_x_pool_row__mutmut['x_pool_row__mutmut_76'] = x_pool_row__mutmut_76 # type: ignore # mutmut generated
mutants_x_pool_row__mutmut['x_pool_row__mutmut_77'] = x_pool_row__mutmut_77 # type: ignore # mutmut generated
mutants_x_pool_row__mutmut['x_pool_row__mutmut_78'] = x_pool_row__mutmut_78 # type: ignore # mutmut generated
mutants_x_pool_row__mutmut['x_pool_row__mutmut_79'] = x_pool_row__mutmut_79 # type: ignore # mutmut generated
mutants_x_pool_row__mutmut['x_pool_row__mutmut_80'] = x_pool_row__mutmut_80 # type: ignore # mutmut generated
mutants_x_pool_row__mutmut['x_pool_row__mutmut_81'] = x_pool_row__mutmut_81 # type: ignore # mutmut generated
mutants_x_pool_row__mutmut['x_pool_row__mutmut_82'] = x_pool_row__mutmut_82 # type: ignore # mutmut generated
mutants_x_pool_row__mutmut['x_pool_row__mutmut_83'] = x_pool_row__mutmut_83 # type: ignore # mutmut generated
mutants_x_pool_row__mutmut['x_pool_row__mutmut_84'] = x_pool_row__mutmut_84 # type: ignore # mutmut generated
mutants_x_pool_row__mutmut['x_pool_row__mutmut_85'] = x_pool_row__mutmut_85 # type: ignore # mutmut generated
mutants_x_pool_row__mutmut['x_pool_row__mutmut_86'] = x_pool_row__mutmut_86 # type: ignore # mutmut generated
mutants_x_main__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_main__mutmut)
def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--curated", type=Path, required=True)
    parser.add_argument("--destination", type=Path, default=dr.ROOT / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    rows, failed = [], []
    for meta in json.loads(args.curated.read_text())["kept"]:
        try:
            path, digest = dr.fetch_unpinned(
                meta["data_url"], args.destination / f"{meta['uci_id']}.csv"
            )
            rows.append(pool_row(meta, path, digest))
        except (OSError, ValueError, dr.RegistryError) as error:
            failed.append({"uci_id": meta["uci_id"], "error": str(error)})
        time.sleep(0.3)
    out = {"rows": rows, "failed": failed}
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"{len(rows)} recorded, {len(failed)} failed")
    return 0


def x_main__mutmut_orig(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--curated", type=Path, required=True)
    parser.add_argument("--destination", type=Path, default=dr.ROOT / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    rows, failed = [], []
    for meta in json.loads(args.curated.read_text())["kept"]:
        try:
            path, digest = dr.fetch_unpinned(
                meta["data_url"], args.destination / f"{meta['uci_id']}.csv"
            )
            rows.append(pool_row(meta, path, digest))
        except (OSError, ValueError, dr.RegistryError) as error:
            failed.append({"uci_id": meta["uci_id"], "error": str(error)})
        time.sleep(0.3)
    out = {"rows": rows, "failed": failed}
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"{len(rows)} recorded, {len(failed)} failed")
    return 0


def x_main__mutmut_1(argv: list[str] | None = None) -> int:
    parser = None
    parser.add_argument("--curated", type=Path, required=True)
    parser.add_argument("--destination", type=Path, default=dr.ROOT / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    rows, failed = [], []
    for meta in json.loads(args.curated.read_text())["kept"]:
        try:
            path, digest = dr.fetch_unpinned(
                meta["data_url"], args.destination / f"{meta['uci_id']}.csv"
            )
            rows.append(pool_row(meta, path, digest))
        except (OSError, ValueError, dr.RegistryError) as error:
            failed.append({"uci_id": meta["uci_id"], "error": str(error)})
        time.sleep(0.3)
    out = {"rows": rows, "failed": failed}
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"{len(rows)} recorded, {len(failed)} failed")
    return 0


def x_main__mutmut_2(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=None)
    parser.add_argument("--curated", type=Path, required=True)
    parser.add_argument("--destination", type=Path, default=dr.ROOT / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    rows, failed = [], []
    for meta in json.loads(args.curated.read_text())["kept"]:
        try:
            path, digest = dr.fetch_unpinned(
                meta["data_url"], args.destination / f"{meta['uci_id']}.csv"
            )
            rows.append(pool_row(meta, path, digest))
        except (OSError, ValueError, dr.RegistryError) as error:
            failed.append({"uci_id": meta["uci_id"], "error": str(error)})
        time.sleep(0.3)
    out = {"rows": rows, "failed": failed}
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"{len(rows)} recorded, {len(failed)} failed")
    return 0


def x_main__mutmut_3(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(None, type=Path, required=True)
    parser.add_argument("--destination", type=Path, default=dr.ROOT / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    rows, failed = [], []
    for meta in json.loads(args.curated.read_text())["kept"]:
        try:
            path, digest = dr.fetch_unpinned(
                meta["data_url"], args.destination / f"{meta['uci_id']}.csv"
            )
            rows.append(pool_row(meta, path, digest))
        except (OSError, ValueError, dr.RegistryError) as error:
            failed.append({"uci_id": meta["uci_id"], "error": str(error)})
        time.sleep(0.3)
    out = {"rows": rows, "failed": failed}
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"{len(rows)} recorded, {len(failed)} failed")
    return 0


def x_main__mutmut_4(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--curated", type=None, required=True)
    parser.add_argument("--destination", type=Path, default=dr.ROOT / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    rows, failed = [], []
    for meta in json.loads(args.curated.read_text())["kept"]:
        try:
            path, digest = dr.fetch_unpinned(
                meta["data_url"], args.destination / f"{meta['uci_id']}.csv"
            )
            rows.append(pool_row(meta, path, digest))
        except (OSError, ValueError, dr.RegistryError) as error:
            failed.append({"uci_id": meta["uci_id"], "error": str(error)})
        time.sleep(0.3)
    out = {"rows": rows, "failed": failed}
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"{len(rows)} recorded, {len(failed)} failed")
    return 0


def x_main__mutmut_5(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--curated", type=Path, required=None)
    parser.add_argument("--destination", type=Path, default=dr.ROOT / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    rows, failed = [], []
    for meta in json.loads(args.curated.read_text())["kept"]:
        try:
            path, digest = dr.fetch_unpinned(
                meta["data_url"], args.destination / f"{meta['uci_id']}.csv"
            )
            rows.append(pool_row(meta, path, digest))
        except (OSError, ValueError, dr.RegistryError) as error:
            failed.append({"uci_id": meta["uci_id"], "error": str(error)})
        time.sleep(0.3)
    out = {"rows": rows, "failed": failed}
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"{len(rows)} recorded, {len(failed)} failed")
    return 0


def x_main__mutmut_6(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(type=Path, required=True)
    parser.add_argument("--destination", type=Path, default=dr.ROOT / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    rows, failed = [], []
    for meta in json.loads(args.curated.read_text())["kept"]:
        try:
            path, digest = dr.fetch_unpinned(
                meta["data_url"], args.destination / f"{meta['uci_id']}.csv"
            )
            rows.append(pool_row(meta, path, digest))
        except (OSError, ValueError, dr.RegistryError) as error:
            failed.append({"uci_id": meta["uci_id"], "error": str(error)})
        time.sleep(0.3)
    out = {"rows": rows, "failed": failed}
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"{len(rows)} recorded, {len(failed)} failed")
    return 0


def x_main__mutmut_7(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--curated", required=True)
    parser.add_argument("--destination", type=Path, default=dr.ROOT / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    rows, failed = [], []
    for meta in json.loads(args.curated.read_text())["kept"]:
        try:
            path, digest = dr.fetch_unpinned(
                meta["data_url"], args.destination / f"{meta['uci_id']}.csv"
            )
            rows.append(pool_row(meta, path, digest))
        except (OSError, ValueError, dr.RegistryError) as error:
            failed.append({"uci_id": meta["uci_id"], "error": str(error)})
        time.sleep(0.3)
    out = {"rows": rows, "failed": failed}
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"{len(rows)} recorded, {len(failed)} failed")
    return 0


def x_main__mutmut_8(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--curated", type=Path, )
    parser.add_argument("--destination", type=Path, default=dr.ROOT / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    rows, failed = [], []
    for meta in json.loads(args.curated.read_text())["kept"]:
        try:
            path, digest = dr.fetch_unpinned(
                meta["data_url"], args.destination / f"{meta['uci_id']}.csv"
            )
            rows.append(pool_row(meta, path, digest))
        except (OSError, ValueError, dr.RegistryError) as error:
            failed.append({"uci_id": meta["uci_id"], "error": str(error)})
        time.sleep(0.3)
    out = {"rows": rows, "failed": failed}
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"{len(rows)} recorded, {len(failed)} failed")
    return 0


def x_main__mutmut_9(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("XX--curatedXX", type=Path, required=True)
    parser.add_argument("--destination", type=Path, default=dr.ROOT / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    rows, failed = [], []
    for meta in json.loads(args.curated.read_text())["kept"]:
        try:
            path, digest = dr.fetch_unpinned(
                meta["data_url"], args.destination / f"{meta['uci_id']}.csv"
            )
            rows.append(pool_row(meta, path, digest))
        except (OSError, ValueError, dr.RegistryError) as error:
            failed.append({"uci_id": meta["uci_id"], "error": str(error)})
        time.sleep(0.3)
    out = {"rows": rows, "failed": failed}
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"{len(rows)} recorded, {len(failed)} failed")
    return 0


def x_main__mutmut_10(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--CURATED", type=Path, required=True)
    parser.add_argument("--destination", type=Path, default=dr.ROOT / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    rows, failed = [], []
    for meta in json.loads(args.curated.read_text())["kept"]:
        try:
            path, digest = dr.fetch_unpinned(
                meta["data_url"], args.destination / f"{meta['uci_id']}.csv"
            )
            rows.append(pool_row(meta, path, digest))
        except (OSError, ValueError, dr.RegistryError) as error:
            failed.append({"uci_id": meta["uci_id"], "error": str(error)})
        time.sleep(0.3)
    out = {"rows": rows, "failed": failed}
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"{len(rows)} recorded, {len(failed)} failed")
    return 0


def x_main__mutmut_11(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--curated", type=Path, required=False)
    parser.add_argument("--destination", type=Path, default=dr.ROOT / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    rows, failed = [], []
    for meta in json.loads(args.curated.read_text())["kept"]:
        try:
            path, digest = dr.fetch_unpinned(
                meta["data_url"], args.destination / f"{meta['uci_id']}.csv"
            )
            rows.append(pool_row(meta, path, digest))
        except (OSError, ValueError, dr.RegistryError) as error:
            failed.append({"uci_id": meta["uci_id"], "error": str(error)})
        time.sleep(0.3)
    out = {"rows": rows, "failed": failed}
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"{len(rows)} recorded, {len(failed)} failed")
    return 0


def x_main__mutmut_12(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--curated", type=Path, required=True)
    parser.add_argument(None, type=Path, default=dr.ROOT / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    rows, failed = [], []
    for meta in json.loads(args.curated.read_text())["kept"]:
        try:
            path, digest = dr.fetch_unpinned(
                meta["data_url"], args.destination / f"{meta['uci_id']}.csv"
            )
            rows.append(pool_row(meta, path, digest))
        except (OSError, ValueError, dr.RegistryError) as error:
            failed.append({"uci_id": meta["uci_id"], "error": str(error)})
        time.sleep(0.3)
    out = {"rows": rows, "failed": failed}
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"{len(rows)} recorded, {len(failed)} failed")
    return 0


def x_main__mutmut_13(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--curated", type=Path, required=True)
    parser.add_argument("--destination", type=None, default=dr.ROOT / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    rows, failed = [], []
    for meta in json.loads(args.curated.read_text())["kept"]:
        try:
            path, digest = dr.fetch_unpinned(
                meta["data_url"], args.destination / f"{meta['uci_id']}.csv"
            )
            rows.append(pool_row(meta, path, digest))
        except (OSError, ValueError, dr.RegistryError) as error:
            failed.append({"uci_id": meta["uci_id"], "error": str(error)})
        time.sleep(0.3)
    out = {"rows": rows, "failed": failed}
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"{len(rows)} recorded, {len(failed)} failed")
    return 0


def x_main__mutmut_14(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--curated", type=Path, required=True)
    parser.add_argument("--destination", type=Path, default=None)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    rows, failed = [], []
    for meta in json.loads(args.curated.read_text())["kept"]:
        try:
            path, digest = dr.fetch_unpinned(
                meta["data_url"], args.destination / f"{meta['uci_id']}.csv"
            )
            rows.append(pool_row(meta, path, digest))
        except (OSError, ValueError, dr.RegistryError) as error:
            failed.append({"uci_id": meta["uci_id"], "error": str(error)})
        time.sleep(0.3)
    out = {"rows": rows, "failed": failed}
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"{len(rows)} recorded, {len(failed)} failed")
    return 0


def x_main__mutmut_15(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--curated", type=Path, required=True)
    parser.add_argument(type=Path, default=dr.ROOT / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    rows, failed = [], []
    for meta in json.loads(args.curated.read_text())["kept"]:
        try:
            path, digest = dr.fetch_unpinned(
                meta["data_url"], args.destination / f"{meta['uci_id']}.csv"
            )
            rows.append(pool_row(meta, path, digest))
        except (OSError, ValueError, dr.RegistryError) as error:
            failed.append({"uci_id": meta["uci_id"], "error": str(error)})
        time.sleep(0.3)
    out = {"rows": rows, "failed": failed}
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"{len(rows)} recorded, {len(failed)} failed")
    return 0


def x_main__mutmut_16(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--curated", type=Path, required=True)
    parser.add_argument("--destination", default=dr.ROOT / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    rows, failed = [], []
    for meta in json.loads(args.curated.read_text())["kept"]:
        try:
            path, digest = dr.fetch_unpinned(
                meta["data_url"], args.destination / f"{meta['uci_id']}.csv"
            )
            rows.append(pool_row(meta, path, digest))
        except (OSError, ValueError, dr.RegistryError) as error:
            failed.append({"uci_id": meta["uci_id"], "error": str(error)})
        time.sleep(0.3)
    out = {"rows": rows, "failed": failed}
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"{len(rows)} recorded, {len(failed)} failed")
    return 0


def x_main__mutmut_17(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--curated", type=Path, required=True)
    parser.add_argument("--destination", type=Path, )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    rows, failed = [], []
    for meta in json.loads(args.curated.read_text())["kept"]:
        try:
            path, digest = dr.fetch_unpinned(
                meta["data_url"], args.destination / f"{meta['uci_id']}.csv"
            )
            rows.append(pool_row(meta, path, digest))
        except (OSError, ValueError, dr.RegistryError) as error:
            failed.append({"uci_id": meta["uci_id"], "error": str(error)})
        time.sleep(0.3)
    out = {"rows": rows, "failed": failed}
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"{len(rows)} recorded, {len(failed)} failed")
    return 0


def x_main__mutmut_18(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--curated", type=Path, required=True)
    parser.add_argument("XX--destinationXX", type=Path, default=dr.ROOT / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    rows, failed = [], []
    for meta in json.loads(args.curated.read_text())["kept"]:
        try:
            path, digest = dr.fetch_unpinned(
                meta["data_url"], args.destination / f"{meta['uci_id']}.csv"
            )
            rows.append(pool_row(meta, path, digest))
        except (OSError, ValueError, dr.RegistryError) as error:
            failed.append({"uci_id": meta["uci_id"], "error": str(error)})
        time.sleep(0.3)
    out = {"rows": rows, "failed": failed}
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"{len(rows)} recorded, {len(failed)} failed")
    return 0


def x_main__mutmut_19(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--curated", type=Path, required=True)
    parser.add_argument("--DESTINATION", type=Path, default=dr.ROOT / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    rows, failed = [], []
    for meta in json.loads(args.curated.read_text())["kept"]:
        try:
            path, digest = dr.fetch_unpinned(
                meta["data_url"], args.destination / f"{meta['uci_id']}.csv"
            )
            rows.append(pool_row(meta, path, digest))
        except (OSError, ValueError, dr.RegistryError) as error:
            failed.append({"uci_id": meta["uci_id"], "error": str(error)})
        time.sleep(0.3)
    out = {"rows": rows, "failed": failed}
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"{len(rows)} recorded, {len(failed)} failed")
    return 0


def x_main__mutmut_20(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--curated", type=Path, required=True)
    parser.add_argument("--destination", type=Path, default=dr.ROOT / "data" * "pool")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    rows, failed = [], []
    for meta in json.loads(args.curated.read_text())["kept"]:
        try:
            path, digest = dr.fetch_unpinned(
                meta["data_url"], args.destination / f"{meta['uci_id']}.csv"
            )
            rows.append(pool_row(meta, path, digest))
        except (OSError, ValueError, dr.RegistryError) as error:
            failed.append({"uci_id": meta["uci_id"], "error": str(error)})
        time.sleep(0.3)
    out = {"rows": rows, "failed": failed}
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"{len(rows)} recorded, {len(failed)} failed")
    return 0


def x_main__mutmut_21(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--curated", type=Path, required=True)
    parser.add_argument("--destination", type=Path, default=dr.ROOT * "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    rows, failed = [], []
    for meta in json.loads(args.curated.read_text())["kept"]:
        try:
            path, digest = dr.fetch_unpinned(
                meta["data_url"], args.destination / f"{meta['uci_id']}.csv"
            )
            rows.append(pool_row(meta, path, digest))
        except (OSError, ValueError, dr.RegistryError) as error:
            failed.append({"uci_id": meta["uci_id"], "error": str(error)})
        time.sleep(0.3)
    out = {"rows": rows, "failed": failed}
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"{len(rows)} recorded, {len(failed)} failed")
    return 0


def x_main__mutmut_22(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--curated", type=Path, required=True)
    parser.add_argument("--destination", type=Path, default=dr.ROOT / "XXdataXX" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    rows, failed = [], []
    for meta in json.loads(args.curated.read_text())["kept"]:
        try:
            path, digest = dr.fetch_unpinned(
                meta["data_url"], args.destination / f"{meta['uci_id']}.csv"
            )
            rows.append(pool_row(meta, path, digest))
        except (OSError, ValueError, dr.RegistryError) as error:
            failed.append({"uci_id": meta["uci_id"], "error": str(error)})
        time.sleep(0.3)
    out = {"rows": rows, "failed": failed}
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"{len(rows)} recorded, {len(failed)} failed")
    return 0


def x_main__mutmut_23(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--curated", type=Path, required=True)
    parser.add_argument("--destination", type=Path, default=dr.ROOT / "DATA" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    rows, failed = [], []
    for meta in json.loads(args.curated.read_text())["kept"]:
        try:
            path, digest = dr.fetch_unpinned(
                meta["data_url"], args.destination / f"{meta['uci_id']}.csv"
            )
            rows.append(pool_row(meta, path, digest))
        except (OSError, ValueError, dr.RegistryError) as error:
            failed.append({"uci_id": meta["uci_id"], "error": str(error)})
        time.sleep(0.3)
    out = {"rows": rows, "failed": failed}
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"{len(rows)} recorded, {len(failed)} failed")
    return 0


def x_main__mutmut_24(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--curated", type=Path, required=True)
    parser.add_argument("--destination", type=Path, default=dr.ROOT / "data" / "XXpoolXX")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    rows, failed = [], []
    for meta in json.loads(args.curated.read_text())["kept"]:
        try:
            path, digest = dr.fetch_unpinned(
                meta["data_url"], args.destination / f"{meta['uci_id']}.csv"
            )
            rows.append(pool_row(meta, path, digest))
        except (OSError, ValueError, dr.RegistryError) as error:
            failed.append({"uci_id": meta["uci_id"], "error": str(error)})
        time.sleep(0.3)
    out = {"rows": rows, "failed": failed}
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"{len(rows)} recorded, {len(failed)} failed")
    return 0


def x_main__mutmut_25(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--curated", type=Path, required=True)
    parser.add_argument("--destination", type=Path, default=dr.ROOT / "data" / "POOL")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    rows, failed = [], []
    for meta in json.loads(args.curated.read_text())["kept"]:
        try:
            path, digest = dr.fetch_unpinned(
                meta["data_url"], args.destination / f"{meta['uci_id']}.csv"
            )
            rows.append(pool_row(meta, path, digest))
        except (OSError, ValueError, dr.RegistryError) as error:
            failed.append({"uci_id": meta["uci_id"], "error": str(error)})
        time.sleep(0.3)
    out = {"rows": rows, "failed": failed}
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"{len(rows)} recorded, {len(failed)} failed")
    return 0


def x_main__mutmut_26(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--curated", type=Path, required=True)
    parser.add_argument("--destination", type=Path, default=dr.ROOT / "data" / "pool")
    parser.add_argument(None, type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    rows, failed = [], []
    for meta in json.loads(args.curated.read_text())["kept"]:
        try:
            path, digest = dr.fetch_unpinned(
                meta["data_url"], args.destination / f"{meta['uci_id']}.csv"
            )
            rows.append(pool_row(meta, path, digest))
        except (OSError, ValueError, dr.RegistryError) as error:
            failed.append({"uci_id": meta["uci_id"], "error": str(error)})
        time.sleep(0.3)
    out = {"rows": rows, "failed": failed}
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"{len(rows)} recorded, {len(failed)} failed")
    return 0


def x_main__mutmut_27(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--curated", type=Path, required=True)
    parser.add_argument("--destination", type=Path, default=dr.ROOT / "data" / "pool")
    parser.add_argument("--output", type=None, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    rows, failed = [], []
    for meta in json.loads(args.curated.read_text())["kept"]:
        try:
            path, digest = dr.fetch_unpinned(
                meta["data_url"], args.destination / f"{meta['uci_id']}.csv"
            )
            rows.append(pool_row(meta, path, digest))
        except (OSError, ValueError, dr.RegistryError) as error:
            failed.append({"uci_id": meta["uci_id"], "error": str(error)})
        time.sleep(0.3)
    out = {"rows": rows, "failed": failed}
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"{len(rows)} recorded, {len(failed)} failed")
    return 0


def x_main__mutmut_28(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--curated", type=Path, required=True)
    parser.add_argument("--destination", type=Path, default=dr.ROOT / "data" / "pool")
    parser.add_argument("--output", type=Path, required=None)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    rows, failed = [], []
    for meta in json.loads(args.curated.read_text())["kept"]:
        try:
            path, digest = dr.fetch_unpinned(
                meta["data_url"], args.destination / f"{meta['uci_id']}.csv"
            )
            rows.append(pool_row(meta, path, digest))
        except (OSError, ValueError, dr.RegistryError) as error:
            failed.append({"uci_id": meta["uci_id"], "error": str(error)})
        time.sleep(0.3)
    out = {"rows": rows, "failed": failed}
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"{len(rows)} recorded, {len(failed)} failed")
    return 0


def x_main__mutmut_29(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--curated", type=Path, required=True)
    parser.add_argument("--destination", type=Path, default=dr.ROOT / "data" / "pool")
    parser.add_argument(type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    rows, failed = [], []
    for meta in json.loads(args.curated.read_text())["kept"]:
        try:
            path, digest = dr.fetch_unpinned(
                meta["data_url"], args.destination / f"{meta['uci_id']}.csv"
            )
            rows.append(pool_row(meta, path, digest))
        except (OSError, ValueError, dr.RegistryError) as error:
            failed.append({"uci_id": meta["uci_id"], "error": str(error)})
        time.sleep(0.3)
    out = {"rows": rows, "failed": failed}
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"{len(rows)} recorded, {len(failed)} failed")
    return 0


def x_main__mutmut_30(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--curated", type=Path, required=True)
    parser.add_argument("--destination", type=Path, default=dr.ROOT / "data" / "pool")
    parser.add_argument("--output", required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    rows, failed = [], []
    for meta in json.loads(args.curated.read_text())["kept"]:
        try:
            path, digest = dr.fetch_unpinned(
                meta["data_url"], args.destination / f"{meta['uci_id']}.csv"
            )
            rows.append(pool_row(meta, path, digest))
        except (OSError, ValueError, dr.RegistryError) as error:
            failed.append({"uci_id": meta["uci_id"], "error": str(error)})
        time.sleep(0.3)
    out = {"rows": rows, "failed": failed}
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"{len(rows)} recorded, {len(failed)} failed")
    return 0


def x_main__mutmut_31(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--curated", type=Path, required=True)
    parser.add_argument("--destination", type=Path, default=dr.ROOT / "data" / "pool")
    parser.add_argument("--output", type=Path, )
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    rows, failed = [], []
    for meta in json.loads(args.curated.read_text())["kept"]:
        try:
            path, digest = dr.fetch_unpinned(
                meta["data_url"], args.destination / f"{meta['uci_id']}.csv"
            )
            rows.append(pool_row(meta, path, digest))
        except (OSError, ValueError, dr.RegistryError) as error:
            failed.append({"uci_id": meta["uci_id"], "error": str(error)})
        time.sleep(0.3)
    out = {"rows": rows, "failed": failed}
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"{len(rows)} recorded, {len(failed)} failed")
    return 0


def x_main__mutmut_32(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--curated", type=Path, required=True)
    parser.add_argument("--destination", type=Path, default=dr.ROOT / "data" / "pool")
    parser.add_argument("XX--outputXX", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    rows, failed = [], []
    for meta in json.loads(args.curated.read_text())["kept"]:
        try:
            path, digest = dr.fetch_unpinned(
                meta["data_url"], args.destination / f"{meta['uci_id']}.csv"
            )
            rows.append(pool_row(meta, path, digest))
        except (OSError, ValueError, dr.RegistryError) as error:
            failed.append({"uci_id": meta["uci_id"], "error": str(error)})
        time.sleep(0.3)
    out = {"rows": rows, "failed": failed}
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"{len(rows)} recorded, {len(failed)} failed")
    return 0


def x_main__mutmut_33(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--curated", type=Path, required=True)
    parser.add_argument("--destination", type=Path, default=dr.ROOT / "data" / "pool")
    parser.add_argument("--OUTPUT", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    rows, failed = [], []
    for meta in json.loads(args.curated.read_text())["kept"]:
        try:
            path, digest = dr.fetch_unpinned(
                meta["data_url"], args.destination / f"{meta['uci_id']}.csv"
            )
            rows.append(pool_row(meta, path, digest))
        except (OSError, ValueError, dr.RegistryError) as error:
            failed.append({"uci_id": meta["uci_id"], "error": str(error)})
        time.sleep(0.3)
    out = {"rows": rows, "failed": failed}
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"{len(rows)} recorded, {len(failed)} failed")
    return 0


def x_main__mutmut_34(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--curated", type=Path, required=True)
    parser.add_argument("--destination", type=Path, default=dr.ROOT / "data" / "pool")
    parser.add_argument("--output", type=Path, required=False)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    rows, failed = [], []
    for meta in json.loads(args.curated.read_text())["kept"]:
        try:
            path, digest = dr.fetch_unpinned(
                meta["data_url"], args.destination / f"{meta['uci_id']}.csv"
            )
            rows.append(pool_row(meta, path, digest))
        except (OSError, ValueError, dr.RegistryError) as error:
            failed.append({"uci_id": meta["uci_id"], "error": str(error)})
        time.sleep(0.3)
    out = {"rows": rows, "failed": failed}
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"{len(rows)} recorded, {len(failed)} failed")
    return 0


def x_main__mutmut_35(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--curated", type=Path, required=True)
    parser.add_argument("--destination", type=Path, default=dr.ROOT / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    args = None
    from etl_benchmark.atomic import atomic_path

    rows, failed = [], []
    for meta in json.loads(args.curated.read_text())["kept"]:
        try:
            path, digest = dr.fetch_unpinned(
                meta["data_url"], args.destination / f"{meta['uci_id']}.csv"
            )
            rows.append(pool_row(meta, path, digest))
        except (OSError, ValueError, dr.RegistryError) as error:
            failed.append({"uci_id": meta["uci_id"], "error": str(error)})
        time.sleep(0.3)
    out = {"rows": rows, "failed": failed}
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"{len(rows)} recorded, {len(failed)} failed")
    return 0


def x_main__mutmut_36(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--curated", type=Path, required=True)
    parser.add_argument("--destination", type=Path, default=dr.ROOT / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(None)
    from etl_benchmark.atomic import atomic_path

    rows, failed = [], []
    for meta in json.loads(args.curated.read_text())["kept"]:
        try:
            path, digest = dr.fetch_unpinned(
                meta["data_url"], args.destination / f"{meta['uci_id']}.csv"
            )
            rows.append(pool_row(meta, path, digest))
        except (OSError, ValueError, dr.RegistryError) as error:
            failed.append({"uci_id": meta["uci_id"], "error": str(error)})
        time.sleep(0.3)
    out = {"rows": rows, "failed": failed}
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"{len(rows)} recorded, {len(failed)} failed")
    return 0


def x_main__mutmut_37(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--curated", type=Path, required=True)
    parser.add_argument("--destination", type=Path, default=dr.ROOT / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    rows, failed = None
    for meta in json.loads(args.curated.read_text())["kept"]:
        try:
            path, digest = dr.fetch_unpinned(
                meta["data_url"], args.destination / f"{meta['uci_id']}.csv"
            )
            rows.append(pool_row(meta, path, digest))
        except (OSError, ValueError, dr.RegistryError) as error:
            failed.append({"uci_id": meta["uci_id"], "error": str(error)})
        time.sleep(0.3)
    out = {"rows": rows, "failed": failed}
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"{len(rows)} recorded, {len(failed)} failed")
    return 0


def x_main__mutmut_38(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--curated", type=Path, required=True)
    parser.add_argument("--destination", type=Path, default=dr.ROOT / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    rows, failed = [], []
    for meta in json.loads(None)["kept"]:
        try:
            path, digest = dr.fetch_unpinned(
                meta["data_url"], args.destination / f"{meta['uci_id']}.csv"
            )
            rows.append(pool_row(meta, path, digest))
        except (OSError, ValueError, dr.RegistryError) as error:
            failed.append({"uci_id": meta["uci_id"], "error": str(error)})
        time.sleep(0.3)
    out = {"rows": rows, "failed": failed}
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"{len(rows)} recorded, {len(failed)} failed")
    return 0


def x_main__mutmut_39(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--curated", type=Path, required=True)
    parser.add_argument("--destination", type=Path, default=dr.ROOT / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    rows, failed = [], []
    for meta in json.loads(args.curated.read_text())["XXkeptXX"]:
        try:
            path, digest = dr.fetch_unpinned(
                meta["data_url"], args.destination / f"{meta['uci_id']}.csv"
            )
            rows.append(pool_row(meta, path, digest))
        except (OSError, ValueError, dr.RegistryError) as error:
            failed.append({"uci_id": meta["uci_id"], "error": str(error)})
        time.sleep(0.3)
    out = {"rows": rows, "failed": failed}
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"{len(rows)} recorded, {len(failed)} failed")
    return 0


def x_main__mutmut_40(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--curated", type=Path, required=True)
    parser.add_argument("--destination", type=Path, default=dr.ROOT / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    rows, failed = [], []
    for meta in json.loads(args.curated.read_text())["KEPT"]:
        try:
            path, digest = dr.fetch_unpinned(
                meta["data_url"], args.destination / f"{meta['uci_id']}.csv"
            )
            rows.append(pool_row(meta, path, digest))
        except (OSError, ValueError, dr.RegistryError) as error:
            failed.append({"uci_id": meta["uci_id"], "error": str(error)})
        time.sleep(0.3)
    out = {"rows": rows, "failed": failed}
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"{len(rows)} recorded, {len(failed)} failed")
    return 0


def x_main__mutmut_41(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--curated", type=Path, required=True)
    parser.add_argument("--destination", type=Path, default=dr.ROOT / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    rows, failed = [], []
    for meta in json.loads(args.curated.read_text())["kept"]:
        try:
            path, digest = None
            rows.append(pool_row(meta, path, digest))
        except (OSError, ValueError, dr.RegistryError) as error:
            failed.append({"uci_id": meta["uci_id"], "error": str(error)})
        time.sleep(0.3)
    out = {"rows": rows, "failed": failed}
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"{len(rows)} recorded, {len(failed)} failed")
    return 0


def x_main__mutmut_42(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--curated", type=Path, required=True)
    parser.add_argument("--destination", type=Path, default=dr.ROOT / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    rows, failed = [], []
    for meta in json.loads(args.curated.read_text())["kept"]:
        try:
            path, digest = dr.fetch_unpinned(
                None, args.destination / f"{meta['uci_id']}.csv"
            )
            rows.append(pool_row(meta, path, digest))
        except (OSError, ValueError, dr.RegistryError) as error:
            failed.append({"uci_id": meta["uci_id"], "error": str(error)})
        time.sleep(0.3)
    out = {"rows": rows, "failed": failed}
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"{len(rows)} recorded, {len(failed)} failed")
    return 0


def x_main__mutmut_43(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--curated", type=Path, required=True)
    parser.add_argument("--destination", type=Path, default=dr.ROOT / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    rows, failed = [], []
    for meta in json.loads(args.curated.read_text())["kept"]:
        try:
            path, digest = dr.fetch_unpinned(
                meta["data_url"], None
            )
            rows.append(pool_row(meta, path, digest))
        except (OSError, ValueError, dr.RegistryError) as error:
            failed.append({"uci_id": meta["uci_id"], "error": str(error)})
        time.sleep(0.3)
    out = {"rows": rows, "failed": failed}
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"{len(rows)} recorded, {len(failed)} failed")
    return 0


def x_main__mutmut_44(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--curated", type=Path, required=True)
    parser.add_argument("--destination", type=Path, default=dr.ROOT / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    rows, failed = [], []
    for meta in json.loads(args.curated.read_text())["kept"]:
        try:
            path, digest = dr.fetch_unpinned(
                args.destination / f"{meta['uci_id']}.csv"
            )
            rows.append(pool_row(meta, path, digest))
        except (OSError, ValueError, dr.RegistryError) as error:
            failed.append({"uci_id": meta["uci_id"], "error": str(error)})
        time.sleep(0.3)
    out = {"rows": rows, "failed": failed}
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"{len(rows)} recorded, {len(failed)} failed")
    return 0


def x_main__mutmut_45(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--curated", type=Path, required=True)
    parser.add_argument("--destination", type=Path, default=dr.ROOT / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    rows, failed = [], []
    for meta in json.loads(args.curated.read_text())["kept"]:
        try:
            path, digest = dr.fetch_unpinned(
                meta["data_url"], )
            rows.append(pool_row(meta, path, digest))
        except (OSError, ValueError, dr.RegistryError) as error:
            failed.append({"uci_id": meta["uci_id"], "error": str(error)})
        time.sleep(0.3)
    out = {"rows": rows, "failed": failed}
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"{len(rows)} recorded, {len(failed)} failed")
    return 0


def x_main__mutmut_46(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--curated", type=Path, required=True)
    parser.add_argument("--destination", type=Path, default=dr.ROOT / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    rows, failed = [], []
    for meta in json.loads(args.curated.read_text())["kept"]:
        try:
            path, digest = dr.fetch_unpinned(
                meta["XXdata_urlXX"], args.destination / f"{meta['uci_id']}.csv"
            )
            rows.append(pool_row(meta, path, digest))
        except (OSError, ValueError, dr.RegistryError) as error:
            failed.append({"uci_id": meta["uci_id"], "error": str(error)})
        time.sleep(0.3)
    out = {"rows": rows, "failed": failed}
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"{len(rows)} recorded, {len(failed)} failed")
    return 0


def x_main__mutmut_47(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--curated", type=Path, required=True)
    parser.add_argument("--destination", type=Path, default=dr.ROOT / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    rows, failed = [], []
    for meta in json.loads(args.curated.read_text())["kept"]:
        try:
            path, digest = dr.fetch_unpinned(
                meta["DATA_URL"], args.destination / f"{meta['uci_id']}.csv"
            )
            rows.append(pool_row(meta, path, digest))
        except (OSError, ValueError, dr.RegistryError) as error:
            failed.append({"uci_id": meta["uci_id"], "error": str(error)})
        time.sleep(0.3)
    out = {"rows": rows, "failed": failed}
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"{len(rows)} recorded, {len(failed)} failed")
    return 0


def x_main__mutmut_48(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--curated", type=Path, required=True)
    parser.add_argument("--destination", type=Path, default=dr.ROOT / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    rows, failed = [], []
    for meta in json.loads(args.curated.read_text())["kept"]:
        try:
            path, digest = dr.fetch_unpinned(
                meta["data_url"], args.destination * f"{meta['uci_id']}.csv"
            )
            rows.append(pool_row(meta, path, digest))
        except (OSError, ValueError, dr.RegistryError) as error:
            failed.append({"uci_id": meta["uci_id"], "error": str(error)})
        time.sleep(0.3)
    out = {"rows": rows, "failed": failed}
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"{len(rows)} recorded, {len(failed)} failed")
    return 0


def x_main__mutmut_49(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--curated", type=Path, required=True)
    parser.add_argument("--destination", type=Path, default=dr.ROOT / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    rows, failed = [], []
    for meta in json.loads(args.curated.read_text())["kept"]:
        try:
            path, digest = dr.fetch_unpinned(
                meta["data_url"], args.destination / f"{meta['XXuci_idXX']}.csv"
            )
            rows.append(pool_row(meta, path, digest))
        except (OSError, ValueError, dr.RegistryError) as error:
            failed.append({"uci_id": meta["uci_id"], "error": str(error)})
        time.sleep(0.3)
    out = {"rows": rows, "failed": failed}
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"{len(rows)} recorded, {len(failed)} failed")
    return 0


def x_main__mutmut_50(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--curated", type=Path, required=True)
    parser.add_argument("--destination", type=Path, default=dr.ROOT / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    rows, failed = [], []
    for meta in json.loads(args.curated.read_text())["kept"]:
        try:
            path, digest = dr.fetch_unpinned(
                meta["data_url"], args.destination / f"{meta['UCI_ID']}.csv"
            )
            rows.append(pool_row(meta, path, digest))
        except (OSError, ValueError, dr.RegistryError) as error:
            failed.append({"uci_id": meta["uci_id"], "error": str(error)})
        time.sleep(0.3)
    out = {"rows": rows, "failed": failed}
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"{len(rows)} recorded, {len(failed)} failed")
    return 0


def x_main__mutmut_51(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--curated", type=Path, required=True)
    parser.add_argument("--destination", type=Path, default=dr.ROOT / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    rows, failed = [], []
    for meta in json.loads(args.curated.read_text())["kept"]:
        try:
            path, digest = dr.fetch_unpinned(
                meta["data_url"], args.destination / f"{meta['uci_id']}.csv"
            )
            rows.append(None)
        except (OSError, ValueError, dr.RegistryError) as error:
            failed.append({"uci_id": meta["uci_id"], "error": str(error)})
        time.sleep(0.3)
    out = {"rows": rows, "failed": failed}
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"{len(rows)} recorded, {len(failed)} failed")
    return 0


def x_main__mutmut_52(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--curated", type=Path, required=True)
    parser.add_argument("--destination", type=Path, default=dr.ROOT / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    rows, failed = [], []
    for meta in json.loads(args.curated.read_text())["kept"]:
        try:
            path, digest = dr.fetch_unpinned(
                meta["data_url"], args.destination / f"{meta['uci_id']}.csv"
            )
            rows.append(pool_row(None, path, digest))
        except (OSError, ValueError, dr.RegistryError) as error:
            failed.append({"uci_id": meta["uci_id"], "error": str(error)})
        time.sleep(0.3)
    out = {"rows": rows, "failed": failed}
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"{len(rows)} recorded, {len(failed)} failed")
    return 0


def x_main__mutmut_53(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--curated", type=Path, required=True)
    parser.add_argument("--destination", type=Path, default=dr.ROOT / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    rows, failed = [], []
    for meta in json.loads(args.curated.read_text())["kept"]:
        try:
            path, digest = dr.fetch_unpinned(
                meta["data_url"], args.destination / f"{meta['uci_id']}.csv"
            )
            rows.append(pool_row(meta, None, digest))
        except (OSError, ValueError, dr.RegistryError) as error:
            failed.append({"uci_id": meta["uci_id"], "error": str(error)})
        time.sleep(0.3)
    out = {"rows": rows, "failed": failed}
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"{len(rows)} recorded, {len(failed)} failed")
    return 0


def x_main__mutmut_54(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--curated", type=Path, required=True)
    parser.add_argument("--destination", type=Path, default=dr.ROOT / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    rows, failed = [], []
    for meta in json.loads(args.curated.read_text())["kept"]:
        try:
            path, digest = dr.fetch_unpinned(
                meta["data_url"], args.destination / f"{meta['uci_id']}.csv"
            )
            rows.append(pool_row(meta, path, None))
        except (OSError, ValueError, dr.RegistryError) as error:
            failed.append({"uci_id": meta["uci_id"], "error": str(error)})
        time.sleep(0.3)
    out = {"rows": rows, "failed": failed}
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"{len(rows)} recorded, {len(failed)} failed")
    return 0


def x_main__mutmut_55(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--curated", type=Path, required=True)
    parser.add_argument("--destination", type=Path, default=dr.ROOT / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    rows, failed = [], []
    for meta in json.loads(args.curated.read_text())["kept"]:
        try:
            path, digest = dr.fetch_unpinned(
                meta["data_url"], args.destination / f"{meta['uci_id']}.csv"
            )
            rows.append(pool_row(path, digest))
        except (OSError, ValueError, dr.RegistryError) as error:
            failed.append({"uci_id": meta["uci_id"], "error": str(error)})
        time.sleep(0.3)
    out = {"rows": rows, "failed": failed}
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"{len(rows)} recorded, {len(failed)} failed")
    return 0


def x_main__mutmut_56(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--curated", type=Path, required=True)
    parser.add_argument("--destination", type=Path, default=dr.ROOT / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    rows, failed = [], []
    for meta in json.loads(args.curated.read_text())["kept"]:
        try:
            path, digest = dr.fetch_unpinned(
                meta["data_url"], args.destination / f"{meta['uci_id']}.csv"
            )
            rows.append(pool_row(meta, digest))
        except (OSError, ValueError, dr.RegistryError) as error:
            failed.append({"uci_id": meta["uci_id"], "error": str(error)})
        time.sleep(0.3)
    out = {"rows": rows, "failed": failed}
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"{len(rows)} recorded, {len(failed)} failed")
    return 0


def x_main__mutmut_57(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--curated", type=Path, required=True)
    parser.add_argument("--destination", type=Path, default=dr.ROOT / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    rows, failed = [], []
    for meta in json.loads(args.curated.read_text())["kept"]:
        try:
            path, digest = dr.fetch_unpinned(
                meta["data_url"], args.destination / f"{meta['uci_id']}.csv"
            )
            rows.append(pool_row(meta, path, ))
        except (OSError, ValueError, dr.RegistryError) as error:
            failed.append({"uci_id": meta["uci_id"], "error": str(error)})
        time.sleep(0.3)
    out = {"rows": rows, "failed": failed}
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"{len(rows)} recorded, {len(failed)} failed")
    return 0


def x_main__mutmut_58(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--curated", type=Path, required=True)
    parser.add_argument("--destination", type=Path, default=dr.ROOT / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    rows, failed = [], []
    for meta in json.loads(args.curated.read_text())["kept"]:
        try:
            path, digest = dr.fetch_unpinned(
                meta["data_url"], args.destination / f"{meta['uci_id']}.csv"
            )
            rows.append(pool_row(meta, path, digest))
        except (OSError, ValueError, dr.RegistryError) as error:
            failed.append(None)
        time.sleep(0.3)
    out = {"rows": rows, "failed": failed}
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"{len(rows)} recorded, {len(failed)} failed")
    return 0


def x_main__mutmut_59(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--curated", type=Path, required=True)
    parser.add_argument("--destination", type=Path, default=dr.ROOT / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    rows, failed = [], []
    for meta in json.loads(args.curated.read_text())["kept"]:
        try:
            path, digest = dr.fetch_unpinned(
                meta["data_url"], args.destination / f"{meta['uci_id']}.csv"
            )
            rows.append(pool_row(meta, path, digest))
        except (OSError, ValueError, dr.RegistryError) as error:
            failed.append({"XXuci_idXX": meta["uci_id"], "error": str(error)})
        time.sleep(0.3)
    out = {"rows": rows, "failed": failed}
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"{len(rows)} recorded, {len(failed)} failed")
    return 0


def x_main__mutmut_60(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--curated", type=Path, required=True)
    parser.add_argument("--destination", type=Path, default=dr.ROOT / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    rows, failed = [], []
    for meta in json.loads(args.curated.read_text())["kept"]:
        try:
            path, digest = dr.fetch_unpinned(
                meta["data_url"], args.destination / f"{meta['uci_id']}.csv"
            )
            rows.append(pool_row(meta, path, digest))
        except (OSError, ValueError, dr.RegistryError) as error:
            failed.append({"UCI_ID": meta["uci_id"], "error": str(error)})
        time.sleep(0.3)
    out = {"rows": rows, "failed": failed}
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"{len(rows)} recorded, {len(failed)} failed")
    return 0


def x_main__mutmut_61(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--curated", type=Path, required=True)
    parser.add_argument("--destination", type=Path, default=dr.ROOT / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    rows, failed = [], []
    for meta in json.loads(args.curated.read_text())["kept"]:
        try:
            path, digest = dr.fetch_unpinned(
                meta["data_url"], args.destination / f"{meta['uci_id']}.csv"
            )
            rows.append(pool_row(meta, path, digest))
        except (OSError, ValueError, dr.RegistryError) as error:
            failed.append({"uci_id": meta["XXuci_idXX"], "error": str(error)})
        time.sleep(0.3)
    out = {"rows": rows, "failed": failed}
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"{len(rows)} recorded, {len(failed)} failed")
    return 0


def x_main__mutmut_62(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--curated", type=Path, required=True)
    parser.add_argument("--destination", type=Path, default=dr.ROOT / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    rows, failed = [], []
    for meta in json.loads(args.curated.read_text())["kept"]:
        try:
            path, digest = dr.fetch_unpinned(
                meta["data_url"], args.destination / f"{meta['uci_id']}.csv"
            )
            rows.append(pool_row(meta, path, digest))
        except (OSError, ValueError, dr.RegistryError) as error:
            failed.append({"uci_id": meta["UCI_ID"], "error": str(error)})
        time.sleep(0.3)
    out = {"rows": rows, "failed": failed}
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"{len(rows)} recorded, {len(failed)} failed")
    return 0


def x_main__mutmut_63(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--curated", type=Path, required=True)
    parser.add_argument("--destination", type=Path, default=dr.ROOT / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    rows, failed = [], []
    for meta in json.loads(args.curated.read_text())["kept"]:
        try:
            path, digest = dr.fetch_unpinned(
                meta["data_url"], args.destination / f"{meta['uci_id']}.csv"
            )
            rows.append(pool_row(meta, path, digest))
        except (OSError, ValueError, dr.RegistryError) as error:
            failed.append({"uci_id": meta["uci_id"], "XXerrorXX": str(error)})
        time.sleep(0.3)
    out = {"rows": rows, "failed": failed}
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"{len(rows)} recorded, {len(failed)} failed")
    return 0


def x_main__mutmut_64(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--curated", type=Path, required=True)
    parser.add_argument("--destination", type=Path, default=dr.ROOT / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    rows, failed = [], []
    for meta in json.loads(args.curated.read_text())["kept"]:
        try:
            path, digest = dr.fetch_unpinned(
                meta["data_url"], args.destination / f"{meta['uci_id']}.csv"
            )
            rows.append(pool_row(meta, path, digest))
        except (OSError, ValueError, dr.RegistryError) as error:
            failed.append({"uci_id": meta["uci_id"], "ERROR": str(error)})
        time.sleep(0.3)
    out = {"rows": rows, "failed": failed}
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"{len(rows)} recorded, {len(failed)} failed")
    return 0


def x_main__mutmut_65(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--curated", type=Path, required=True)
    parser.add_argument("--destination", type=Path, default=dr.ROOT / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    rows, failed = [], []
    for meta in json.loads(args.curated.read_text())["kept"]:
        try:
            path, digest = dr.fetch_unpinned(
                meta["data_url"], args.destination / f"{meta['uci_id']}.csv"
            )
            rows.append(pool_row(meta, path, digest))
        except (OSError, ValueError, dr.RegistryError) as error:
            failed.append({"uci_id": meta["uci_id"], "error": str(None)})
        time.sleep(0.3)
    out = {"rows": rows, "failed": failed}
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"{len(rows)} recorded, {len(failed)} failed")
    return 0


def x_main__mutmut_66(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--curated", type=Path, required=True)
    parser.add_argument("--destination", type=Path, default=dr.ROOT / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    rows, failed = [], []
    for meta in json.loads(args.curated.read_text())["kept"]:
        try:
            path, digest = dr.fetch_unpinned(
                meta["data_url"], args.destination / f"{meta['uci_id']}.csv"
            )
            rows.append(pool_row(meta, path, digest))
        except (OSError, ValueError, dr.RegistryError) as error:
            failed.append({"uci_id": meta["uci_id"], "error": str(error)})
        time.sleep(None)
    out = {"rows": rows, "failed": failed}
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"{len(rows)} recorded, {len(failed)} failed")
    return 0


def x_main__mutmut_67(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--curated", type=Path, required=True)
    parser.add_argument("--destination", type=Path, default=dr.ROOT / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    rows, failed = [], []
    for meta in json.loads(args.curated.read_text())["kept"]:
        try:
            path, digest = dr.fetch_unpinned(
                meta["data_url"], args.destination / f"{meta['uci_id']}.csv"
            )
            rows.append(pool_row(meta, path, digest))
        except (OSError, ValueError, dr.RegistryError) as error:
            failed.append({"uci_id": meta["uci_id"], "error": str(error)})
        time.sleep(1.3)
    out = {"rows": rows, "failed": failed}
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"{len(rows)} recorded, {len(failed)} failed")
    return 0


def x_main__mutmut_68(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--curated", type=Path, required=True)
    parser.add_argument("--destination", type=Path, default=dr.ROOT / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    rows, failed = [], []
    for meta in json.loads(args.curated.read_text())["kept"]:
        try:
            path, digest = dr.fetch_unpinned(
                meta["data_url"], args.destination / f"{meta['uci_id']}.csv"
            )
            rows.append(pool_row(meta, path, digest))
        except (OSError, ValueError, dr.RegistryError) as error:
            failed.append({"uci_id": meta["uci_id"], "error": str(error)})
        time.sleep(0.3)
    out = None
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"{len(rows)} recorded, {len(failed)} failed")
    return 0


def x_main__mutmut_69(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--curated", type=Path, required=True)
    parser.add_argument("--destination", type=Path, default=dr.ROOT / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    rows, failed = [], []
    for meta in json.loads(args.curated.read_text())["kept"]:
        try:
            path, digest = dr.fetch_unpinned(
                meta["data_url"], args.destination / f"{meta['uci_id']}.csv"
            )
            rows.append(pool_row(meta, path, digest))
        except (OSError, ValueError, dr.RegistryError) as error:
            failed.append({"uci_id": meta["uci_id"], "error": str(error)})
        time.sleep(0.3)
    out = {"XXrowsXX": rows, "failed": failed}
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"{len(rows)} recorded, {len(failed)} failed")
    return 0


def x_main__mutmut_70(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--curated", type=Path, required=True)
    parser.add_argument("--destination", type=Path, default=dr.ROOT / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    rows, failed = [], []
    for meta in json.loads(args.curated.read_text())["kept"]:
        try:
            path, digest = dr.fetch_unpinned(
                meta["data_url"], args.destination / f"{meta['uci_id']}.csv"
            )
            rows.append(pool_row(meta, path, digest))
        except (OSError, ValueError, dr.RegistryError) as error:
            failed.append({"uci_id": meta["uci_id"], "error": str(error)})
        time.sleep(0.3)
    out = {"ROWS": rows, "failed": failed}
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"{len(rows)} recorded, {len(failed)} failed")
    return 0


def x_main__mutmut_71(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--curated", type=Path, required=True)
    parser.add_argument("--destination", type=Path, default=dr.ROOT / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    rows, failed = [], []
    for meta in json.loads(args.curated.read_text())["kept"]:
        try:
            path, digest = dr.fetch_unpinned(
                meta["data_url"], args.destination / f"{meta['uci_id']}.csv"
            )
            rows.append(pool_row(meta, path, digest))
        except (OSError, ValueError, dr.RegistryError) as error:
            failed.append({"uci_id": meta["uci_id"], "error": str(error)})
        time.sleep(0.3)
    out = {"rows": rows, "XXfailedXX": failed}
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"{len(rows)} recorded, {len(failed)} failed")
    return 0


def x_main__mutmut_72(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--curated", type=Path, required=True)
    parser.add_argument("--destination", type=Path, default=dr.ROOT / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    rows, failed = [], []
    for meta in json.loads(args.curated.read_text())["kept"]:
        try:
            path, digest = dr.fetch_unpinned(
                meta["data_url"], args.destination / f"{meta['uci_id']}.csv"
            )
            rows.append(pool_row(meta, path, digest))
        except (OSError, ValueError, dr.RegistryError) as error:
            failed.append({"uci_id": meta["uci_id"], "error": str(error)})
        time.sleep(0.3)
    out = {"rows": rows, "FAILED": failed}
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"{len(rows)} recorded, {len(failed)} failed")
    return 0


def x_main__mutmut_73(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--curated", type=Path, required=True)
    parser.add_argument("--destination", type=Path, default=dr.ROOT / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    rows, failed = [], []
    for meta in json.loads(args.curated.read_text())["kept"]:
        try:
            path, digest = dr.fetch_unpinned(
                meta["data_url"], args.destination / f"{meta['uci_id']}.csv"
            )
            rows.append(pool_row(meta, path, digest))
        except (OSError, ValueError, dr.RegistryError) as error:
            failed.append({"uci_id": meta["uci_id"], "error": str(error)})
        time.sleep(0.3)
    out = {"rows": rows, "failed": failed}
    with atomic_path(None) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"{len(rows)} recorded, {len(failed)} failed")
    return 0


def x_main__mutmut_74(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--curated", type=Path, required=True)
    parser.add_argument("--destination", type=Path, default=dr.ROOT / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    rows, failed = [], []
    for meta in json.loads(args.curated.read_text())["kept"]:
        try:
            path, digest = dr.fetch_unpinned(
                meta["data_url"], args.destination / f"{meta['uci_id']}.csv"
            )
            rows.append(pool_row(meta, path, digest))
        except (OSError, ValueError, dr.RegistryError) as error:
            failed.append({"uci_id": meta["uci_id"], "error": str(error)})
        time.sleep(0.3)
    out = {"rows": rows, "failed": failed}
    with atomic_path(args.output) as partial:
        partial.write_text(None)
    print(f"{len(rows)} recorded, {len(failed)} failed")
    return 0


def x_main__mutmut_75(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--curated", type=Path, required=True)
    parser.add_argument("--destination", type=Path, default=dr.ROOT / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    rows, failed = [], []
    for meta in json.loads(args.curated.read_text())["kept"]:
        try:
            path, digest = dr.fetch_unpinned(
                meta["data_url"], args.destination / f"{meta['uci_id']}.csv"
            )
            rows.append(pool_row(meta, path, digest))
        except (OSError, ValueError, dr.RegistryError) as error:
            failed.append({"uci_id": meta["uci_id"], "error": str(error)})
        time.sleep(0.3)
    out = {"rows": rows, "failed": failed}
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) - "\n")
    print(f"{len(rows)} recorded, {len(failed)} failed")
    return 0


def x_main__mutmut_76(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--curated", type=Path, required=True)
    parser.add_argument("--destination", type=Path, default=dr.ROOT / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    rows, failed = [], []
    for meta in json.loads(args.curated.read_text())["kept"]:
        try:
            path, digest = dr.fetch_unpinned(
                meta["data_url"], args.destination / f"{meta['uci_id']}.csv"
            )
            rows.append(pool_row(meta, path, digest))
        except (OSError, ValueError, dr.RegistryError) as error:
            failed.append({"uci_id": meta["uci_id"], "error": str(error)})
        time.sleep(0.3)
    out = {"rows": rows, "failed": failed}
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(None, indent=1, sort_keys=True) + "\n")
    print(f"{len(rows)} recorded, {len(failed)} failed")
    return 0


def x_main__mutmut_77(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--curated", type=Path, required=True)
    parser.add_argument("--destination", type=Path, default=dr.ROOT / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    rows, failed = [], []
    for meta in json.loads(args.curated.read_text())["kept"]:
        try:
            path, digest = dr.fetch_unpinned(
                meta["data_url"], args.destination / f"{meta['uci_id']}.csv"
            )
            rows.append(pool_row(meta, path, digest))
        except (OSError, ValueError, dr.RegistryError) as error:
            failed.append({"uci_id": meta["uci_id"], "error": str(error)})
        time.sleep(0.3)
    out = {"rows": rows, "failed": failed}
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=None, sort_keys=True) + "\n")
    print(f"{len(rows)} recorded, {len(failed)} failed")
    return 0


def x_main__mutmut_78(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--curated", type=Path, required=True)
    parser.add_argument("--destination", type=Path, default=dr.ROOT / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    rows, failed = [], []
    for meta in json.loads(args.curated.read_text())["kept"]:
        try:
            path, digest = dr.fetch_unpinned(
                meta["data_url"], args.destination / f"{meta['uci_id']}.csv"
            )
            rows.append(pool_row(meta, path, digest))
        except (OSError, ValueError, dr.RegistryError) as error:
            failed.append({"uci_id": meta["uci_id"], "error": str(error)})
        time.sleep(0.3)
    out = {"rows": rows, "failed": failed}
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=None) + "\n")
    print(f"{len(rows)} recorded, {len(failed)} failed")
    return 0


def x_main__mutmut_79(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--curated", type=Path, required=True)
    parser.add_argument("--destination", type=Path, default=dr.ROOT / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    rows, failed = [], []
    for meta in json.loads(args.curated.read_text())["kept"]:
        try:
            path, digest = dr.fetch_unpinned(
                meta["data_url"], args.destination / f"{meta['uci_id']}.csv"
            )
            rows.append(pool_row(meta, path, digest))
        except (OSError, ValueError, dr.RegistryError) as error:
            failed.append({"uci_id": meta["uci_id"], "error": str(error)})
        time.sleep(0.3)
    out = {"rows": rows, "failed": failed}
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(indent=1, sort_keys=True) + "\n")
    print(f"{len(rows)} recorded, {len(failed)} failed")
    return 0


def x_main__mutmut_80(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--curated", type=Path, required=True)
    parser.add_argument("--destination", type=Path, default=dr.ROOT / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    rows, failed = [], []
    for meta in json.loads(args.curated.read_text())["kept"]:
        try:
            path, digest = dr.fetch_unpinned(
                meta["data_url"], args.destination / f"{meta['uci_id']}.csv"
            )
            rows.append(pool_row(meta, path, digest))
        except (OSError, ValueError, dr.RegistryError) as error:
            failed.append({"uci_id": meta["uci_id"], "error": str(error)})
        time.sleep(0.3)
    out = {"rows": rows, "failed": failed}
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, sort_keys=True) + "\n")
    print(f"{len(rows)} recorded, {len(failed)} failed")
    return 0


def x_main__mutmut_81(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--curated", type=Path, required=True)
    parser.add_argument("--destination", type=Path, default=dr.ROOT / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    rows, failed = [], []
    for meta in json.loads(args.curated.read_text())["kept"]:
        try:
            path, digest = dr.fetch_unpinned(
                meta["data_url"], args.destination / f"{meta['uci_id']}.csv"
            )
            rows.append(pool_row(meta, path, digest))
        except (OSError, ValueError, dr.RegistryError) as error:
            failed.append({"uci_id": meta["uci_id"], "error": str(error)})
        time.sleep(0.3)
    out = {"rows": rows, "failed": failed}
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, ) + "\n")
    print(f"{len(rows)} recorded, {len(failed)} failed")
    return 0


def x_main__mutmut_82(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--curated", type=Path, required=True)
    parser.add_argument("--destination", type=Path, default=dr.ROOT / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    rows, failed = [], []
    for meta in json.loads(args.curated.read_text())["kept"]:
        try:
            path, digest = dr.fetch_unpinned(
                meta["data_url"], args.destination / f"{meta['uci_id']}.csv"
            )
            rows.append(pool_row(meta, path, digest))
        except (OSError, ValueError, dr.RegistryError) as error:
            failed.append({"uci_id": meta["uci_id"], "error": str(error)})
        time.sleep(0.3)
    out = {"rows": rows, "failed": failed}
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=2, sort_keys=True) + "\n")
    print(f"{len(rows)} recorded, {len(failed)} failed")
    return 0


def x_main__mutmut_83(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--curated", type=Path, required=True)
    parser.add_argument("--destination", type=Path, default=dr.ROOT / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    rows, failed = [], []
    for meta in json.loads(args.curated.read_text())["kept"]:
        try:
            path, digest = dr.fetch_unpinned(
                meta["data_url"], args.destination / f"{meta['uci_id']}.csv"
            )
            rows.append(pool_row(meta, path, digest))
        except (OSError, ValueError, dr.RegistryError) as error:
            failed.append({"uci_id": meta["uci_id"], "error": str(error)})
        time.sleep(0.3)
    out = {"rows": rows, "failed": failed}
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=False) + "\n")
    print(f"{len(rows)} recorded, {len(failed)} failed")
    return 0


def x_main__mutmut_84(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--curated", type=Path, required=True)
    parser.add_argument("--destination", type=Path, default=dr.ROOT / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    rows, failed = [], []
    for meta in json.loads(args.curated.read_text())["kept"]:
        try:
            path, digest = dr.fetch_unpinned(
                meta["data_url"], args.destination / f"{meta['uci_id']}.csv"
            )
            rows.append(pool_row(meta, path, digest))
        except (OSError, ValueError, dr.RegistryError) as error:
            failed.append({"uci_id": meta["uci_id"], "error": str(error)})
        time.sleep(0.3)
    out = {"rows": rows, "failed": failed}
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "XX\nXX")
    print(f"{len(rows)} recorded, {len(failed)} failed")
    return 0


def x_main__mutmut_85(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--curated", type=Path, required=True)
    parser.add_argument("--destination", type=Path, default=dr.ROOT / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    rows, failed = [], []
    for meta in json.loads(args.curated.read_text())["kept"]:
        try:
            path, digest = dr.fetch_unpinned(
                meta["data_url"], args.destination / f"{meta['uci_id']}.csv"
            )
            rows.append(pool_row(meta, path, digest))
        except (OSError, ValueError, dr.RegistryError) as error:
            failed.append({"uci_id": meta["uci_id"], "error": str(error)})
        time.sleep(0.3)
    out = {"rows": rows, "failed": failed}
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(None)
    return 0


def x_main__mutmut_86(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--curated", type=Path, required=True)
    parser.add_argument("--destination", type=Path, default=dr.ROOT / "data" / "pool")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    from etl_benchmark.atomic import atomic_path

    rows, failed = [], []
    for meta in json.loads(args.curated.read_text())["kept"]:
        try:
            path, digest = dr.fetch_unpinned(
                meta["data_url"], args.destination / f"{meta['uci_id']}.csv"
            )
            rows.append(pool_row(meta, path, digest))
        except (OSError, ValueError, dr.RegistryError) as error:
            failed.append({"uci_id": meta["uci_id"], "error": str(error)})
        time.sleep(0.3)
    out = {"rows": rows, "failed": failed}
    with atomic_path(args.output) as partial:
        partial.write_text(json.dumps(out, indent=1, sort_keys=True) + "\n")
    print(f"{len(rows)} recorded, {len(failed)} failed")
    return 1

mutants_x_main__mutmut['_mutmut_orig'] = x_main__mutmut_orig # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_1'] = x_main__mutmut_1 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_2'] = x_main__mutmut_2 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_3'] = x_main__mutmut_3 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_4'] = x_main__mutmut_4 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_5'] = x_main__mutmut_5 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_6'] = x_main__mutmut_6 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_7'] = x_main__mutmut_7 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_8'] = x_main__mutmut_8 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_9'] = x_main__mutmut_9 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_10'] = x_main__mutmut_10 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_11'] = x_main__mutmut_11 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_12'] = x_main__mutmut_12 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_13'] = x_main__mutmut_13 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_14'] = x_main__mutmut_14 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_15'] = x_main__mutmut_15 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_16'] = x_main__mutmut_16 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_17'] = x_main__mutmut_17 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_18'] = x_main__mutmut_18 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_19'] = x_main__mutmut_19 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_20'] = x_main__mutmut_20 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_21'] = x_main__mutmut_21 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_22'] = x_main__mutmut_22 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_23'] = x_main__mutmut_23 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_24'] = x_main__mutmut_24 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_25'] = x_main__mutmut_25 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_26'] = x_main__mutmut_26 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_27'] = x_main__mutmut_27 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_28'] = x_main__mutmut_28 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_29'] = x_main__mutmut_29 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_30'] = x_main__mutmut_30 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_31'] = x_main__mutmut_31 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_32'] = x_main__mutmut_32 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_33'] = x_main__mutmut_33 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_34'] = x_main__mutmut_34 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_35'] = x_main__mutmut_35 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_36'] = x_main__mutmut_36 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_37'] = x_main__mutmut_37 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_38'] = x_main__mutmut_38 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_39'] = x_main__mutmut_39 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_40'] = x_main__mutmut_40 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_41'] = x_main__mutmut_41 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_42'] = x_main__mutmut_42 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_43'] = x_main__mutmut_43 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_44'] = x_main__mutmut_44 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_45'] = x_main__mutmut_45 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_46'] = x_main__mutmut_46 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_47'] = x_main__mutmut_47 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_48'] = x_main__mutmut_48 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_49'] = x_main__mutmut_49 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_50'] = x_main__mutmut_50 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_51'] = x_main__mutmut_51 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_52'] = x_main__mutmut_52 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_53'] = x_main__mutmut_53 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_54'] = x_main__mutmut_54 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_55'] = x_main__mutmut_55 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_56'] = x_main__mutmut_56 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_57'] = x_main__mutmut_57 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_58'] = x_main__mutmut_58 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_59'] = x_main__mutmut_59 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_60'] = x_main__mutmut_60 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_61'] = x_main__mutmut_61 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_62'] = x_main__mutmut_62 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_63'] = x_main__mutmut_63 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_64'] = x_main__mutmut_64 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_65'] = x_main__mutmut_65 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_66'] = x_main__mutmut_66 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_67'] = x_main__mutmut_67 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_68'] = x_main__mutmut_68 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_69'] = x_main__mutmut_69 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_70'] = x_main__mutmut_70 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_71'] = x_main__mutmut_71 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_72'] = x_main__mutmut_72 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_73'] = x_main__mutmut_73 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_74'] = x_main__mutmut_74 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_75'] = x_main__mutmut_75 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_76'] = x_main__mutmut_76 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_77'] = x_main__mutmut_77 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_78'] = x_main__mutmut_78 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_79'] = x_main__mutmut_79 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_80'] = x_main__mutmut_80 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_81'] = x_main__mutmut_81 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_82'] = x_main__mutmut_82 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_83'] = x_main__mutmut_83 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_84'] = x_main__mutmut_84 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_85'] = x_main__mutmut_85 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_86'] = x_main__mutmut_86 # type: ignore # mutmut generated


if __name__ == "__main__":
    raise SystemExit(main())
