"""Rules against learned detectors at comparable alert volume (T167; exploratory).

A rule has no score to threshold, so it keeps its own decision contract and its own alert volume.
For each rule, learned detector, problem and seed, the budget cell whose realized held-out alert
rate is closest (in ratio) to the rule's is taken from the archived alert-budget cells, and the pair
is kept only if the two alert rates differ by less than ``TOLERANCE``. The learned thresholds stay
training-calibrated; only the choice of which budget cell to compare uses the realized alert rates
(never a label). The matching is therefore an evaluation-time construct, not a deployment
procedure, and an exact match is not claimed. Differences (learned minus rule) are averaged over
the eligible seeds of a problem, then compared with a bootstrap that resamples original sources.
"""

from __future__ import annotations

import argparse
import json
import math
import sys
from pathlib import Path
from typing import Any

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from source_clustered import bootstrap, holm, source_id  # noqa: E402

RULES = ("zscore", "iqr", "great_expectations")
TOLERANCE = 1.5  # the larger alert rate may be at most this many times the smaller one
MIN_SEEDS = 3  # eligible seeds a problem needs to enter a comparison
METRICS = ("precision", "recall")
DRAWS = 10_000


from mutmut.mutation.trampoline import wrap_in_trampoline as _mutmut_mutated, MutantDict
mutants_x_match_cell__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_match_cell__mutmut)
def match_cell(budgets: dict[str, Any], rule_rate: float) -> tuple[str, float] | None:
    """The feasible budget cell closest to ``rule_rate`` and its ratio, or None beyond tolerance."""
    if not rule_rate > 0:
        return None
    best: tuple[float, str, float] | None = None
    for key, cell in budgets.items():
        if "infeasible" in cell or not cell["test_alert_rate"] > 0:
            continue
        ratio = cell["test_alert_rate"] / rule_rate
        distance = abs(math.log(ratio))
        if best is None or (distance, float(key)) < (best[0], float(best[1])):
            best = (distance, key, ratio)
    if best is None or best[0] > math.log(TOLERANCE):
        return None
    return best[1], best[2]


def x_match_cell__mutmut_orig(budgets: dict[str, Any], rule_rate: float) -> tuple[str, float] | None:
    """The feasible budget cell closest to ``rule_rate`` and its ratio, or None beyond tolerance."""
    if not rule_rate > 0:
        return None
    best: tuple[float, str, float] | None = None
    for key, cell in budgets.items():
        if "infeasible" in cell or not cell["test_alert_rate"] > 0:
            continue
        ratio = cell["test_alert_rate"] / rule_rate
        distance = abs(math.log(ratio))
        if best is None or (distance, float(key)) < (best[0], float(best[1])):
            best = (distance, key, ratio)
    if best is None or best[0] > math.log(TOLERANCE):
        return None
    return best[1], best[2]


def x_match_cell__mutmut_1(budgets: dict[str, Any], rule_rate: float) -> tuple[str, float] | None:
    """The feasible budget cell closest to ``rule_rate`` and its ratio, or None beyond tolerance."""
    if rule_rate > 0:
        return None
    best: tuple[float, str, float] | None = None
    for key, cell in budgets.items():
        if "infeasible" in cell or not cell["test_alert_rate"] > 0:
            continue
        ratio = cell["test_alert_rate"] / rule_rate
        distance = abs(math.log(ratio))
        if best is None or (distance, float(key)) < (best[0], float(best[1])):
            best = (distance, key, ratio)
    if best is None or best[0] > math.log(TOLERANCE):
        return None
    return best[1], best[2]


def x_match_cell__mutmut_2(budgets: dict[str, Any], rule_rate: float) -> tuple[str, float] | None:
    """The feasible budget cell closest to ``rule_rate`` and its ratio, or None beyond tolerance."""
    if not rule_rate >= 0:
        return None
    best: tuple[float, str, float] | None = None
    for key, cell in budgets.items():
        if "infeasible" in cell or not cell["test_alert_rate"] > 0:
            continue
        ratio = cell["test_alert_rate"] / rule_rate
        distance = abs(math.log(ratio))
        if best is None or (distance, float(key)) < (best[0], float(best[1])):
            best = (distance, key, ratio)
    if best is None or best[0] > math.log(TOLERANCE):
        return None
    return best[1], best[2]


def x_match_cell__mutmut_3(budgets: dict[str, Any], rule_rate: float) -> tuple[str, float] | None:
    """The feasible budget cell closest to ``rule_rate`` and its ratio, or None beyond tolerance."""
    if not rule_rate > 1:
        return None
    best: tuple[float, str, float] | None = None
    for key, cell in budgets.items():
        if "infeasible" in cell or not cell["test_alert_rate"] > 0:
            continue
        ratio = cell["test_alert_rate"] / rule_rate
        distance = abs(math.log(ratio))
        if best is None or (distance, float(key)) < (best[0], float(best[1])):
            best = (distance, key, ratio)
    if best is None or best[0] > math.log(TOLERANCE):
        return None
    return best[1], best[2]


def x_match_cell__mutmut_4(budgets: dict[str, Any], rule_rate: float) -> tuple[str, float] | None:
    """The feasible budget cell closest to ``rule_rate`` and its ratio, or None beyond tolerance."""
    if not rule_rate > 0:
        return None
    best: tuple[float, str, float] | None = ""
    for key, cell in budgets.items():
        if "infeasible" in cell or not cell["test_alert_rate"] > 0:
            continue
        ratio = cell["test_alert_rate"] / rule_rate
        distance = abs(math.log(ratio))
        if best is None or (distance, float(key)) < (best[0], float(best[1])):
            best = (distance, key, ratio)
    if best is None or best[0] > math.log(TOLERANCE):
        return None
    return best[1], best[2]


def x_match_cell__mutmut_5(budgets: dict[str, Any], rule_rate: float) -> tuple[str, float] | None:
    """The feasible budget cell closest to ``rule_rate`` and its ratio, or None beyond tolerance."""
    if not rule_rate > 0:
        return None
    best: tuple[float, str, float] | None = None
    for key, cell in budgets.items():
        if "infeasible" in cell and not cell["test_alert_rate"] > 0:
            continue
        ratio = cell["test_alert_rate"] / rule_rate
        distance = abs(math.log(ratio))
        if best is None or (distance, float(key)) < (best[0], float(best[1])):
            best = (distance, key, ratio)
    if best is None or best[0] > math.log(TOLERANCE):
        return None
    return best[1], best[2]


def x_match_cell__mutmut_6(budgets: dict[str, Any], rule_rate: float) -> tuple[str, float] | None:
    """The feasible budget cell closest to ``rule_rate`` and its ratio, or None beyond tolerance."""
    if not rule_rate > 0:
        return None
    best: tuple[float, str, float] | None = None
    for key, cell in budgets.items():
        if "XXinfeasibleXX" in cell or not cell["test_alert_rate"] > 0:
            continue
        ratio = cell["test_alert_rate"] / rule_rate
        distance = abs(math.log(ratio))
        if best is None or (distance, float(key)) < (best[0], float(best[1])):
            best = (distance, key, ratio)
    if best is None or best[0] > math.log(TOLERANCE):
        return None
    return best[1], best[2]


def x_match_cell__mutmut_7(budgets: dict[str, Any], rule_rate: float) -> tuple[str, float] | None:
    """The feasible budget cell closest to ``rule_rate`` and its ratio, or None beyond tolerance."""
    if not rule_rate > 0:
        return None
    best: tuple[float, str, float] | None = None
    for key, cell in budgets.items():
        if "INFEASIBLE" in cell or not cell["test_alert_rate"] > 0:
            continue
        ratio = cell["test_alert_rate"] / rule_rate
        distance = abs(math.log(ratio))
        if best is None or (distance, float(key)) < (best[0], float(best[1])):
            best = (distance, key, ratio)
    if best is None or best[0] > math.log(TOLERANCE):
        return None
    return best[1], best[2]


def x_match_cell__mutmut_8(budgets: dict[str, Any], rule_rate: float) -> tuple[str, float] | None:
    """The feasible budget cell closest to ``rule_rate`` and its ratio, or None beyond tolerance."""
    if not rule_rate > 0:
        return None
    best: tuple[float, str, float] | None = None
    for key, cell in budgets.items():
        if "infeasible" not in cell or not cell["test_alert_rate"] > 0:
            continue
        ratio = cell["test_alert_rate"] / rule_rate
        distance = abs(math.log(ratio))
        if best is None or (distance, float(key)) < (best[0], float(best[1])):
            best = (distance, key, ratio)
    if best is None or best[0] > math.log(TOLERANCE):
        return None
    return best[1], best[2]


def x_match_cell__mutmut_9(budgets: dict[str, Any], rule_rate: float) -> tuple[str, float] | None:
    """The feasible budget cell closest to ``rule_rate`` and its ratio, or None beyond tolerance."""
    if not rule_rate > 0:
        return None
    best: tuple[float, str, float] | None = None
    for key, cell in budgets.items():
        if "infeasible" in cell or cell["test_alert_rate"] > 0:
            continue
        ratio = cell["test_alert_rate"] / rule_rate
        distance = abs(math.log(ratio))
        if best is None or (distance, float(key)) < (best[0], float(best[1])):
            best = (distance, key, ratio)
    if best is None or best[0] > math.log(TOLERANCE):
        return None
    return best[1], best[2]


def x_match_cell__mutmut_10(budgets: dict[str, Any], rule_rate: float) -> tuple[str, float] | None:
    """The feasible budget cell closest to ``rule_rate`` and its ratio, or None beyond tolerance."""
    if not rule_rate > 0:
        return None
    best: tuple[float, str, float] | None = None
    for key, cell in budgets.items():
        if "infeasible" in cell or not cell["XXtest_alert_rateXX"] > 0:
            continue
        ratio = cell["test_alert_rate"] / rule_rate
        distance = abs(math.log(ratio))
        if best is None or (distance, float(key)) < (best[0], float(best[1])):
            best = (distance, key, ratio)
    if best is None or best[0] > math.log(TOLERANCE):
        return None
    return best[1], best[2]


def x_match_cell__mutmut_11(budgets: dict[str, Any], rule_rate: float) -> tuple[str, float] | None:
    """The feasible budget cell closest to ``rule_rate`` and its ratio, or None beyond tolerance."""
    if not rule_rate > 0:
        return None
    best: tuple[float, str, float] | None = None
    for key, cell in budgets.items():
        if "infeasible" in cell or not cell["TEST_ALERT_RATE"] > 0:
            continue
        ratio = cell["test_alert_rate"] / rule_rate
        distance = abs(math.log(ratio))
        if best is None or (distance, float(key)) < (best[0], float(best[1])):
            best = (distance, key, ratio)
    if best is None or best[0] > math.log(TOLERANCE):
        return None
    return best[1], best[2]


def x_match_cell__mutmut_12(budgets: dict[str, Any], rule_rate: float) -> tuple[str, float] | None:
    """The feasible budget cell closest to ``rule_rate`` and its ratio, or None beyond tolerance."""
    if not rule_rate > 0:
        return None
    best: tuple[float, str, float] | None = None
    for key, cell in budgets.items():
        if "infeasible" in cell or not cell["test_alert_rate"] >= 0:
            continue
        ratio = cell["test_alert_rate"] / rule_rate
        distance = abs(math.log(ratio))
        if best is None or (distance, float(key)) < (best[0], float(best[1])):
            best = (distance, key, ratio)
    if best is None or best[0] > math.log(TOLERANCE):
        return None
    return best[1], best[2]


def x_match_cell__mutmut_13(budgets: dict[str, Any], rule_rate: float) -> tuple[str, float] | None:
    """The feasible budget cell closest to ``rule_rate`` and its ratio, or None beyond tolerance."""
    if not rule_rate > 0:
        return None
    best: tuple[float, str, float] | None = None
    for key, cell in budgets.items():
        if "infeasible" in cell or not cell["test_alert_rate"] > 1:
            continue
        ratio = cell["test_alert_rate"] / rule_rate
        distance = abs(math.log(ratio))
        if best is None or (distance, float(key)) < (best[0], float(best[1])):
            best = (distance, key, ratio)
    if best is None or best[0] > math.log(TOLERANCE):
        return None
    return best[1], best[2]


def x_match_cell__mutmut_14(budgets: dict[str, Any], rule_rate: float) -> tuple[str, float] | None:
    """The feasible budget cell closest to ``rule_rate`` and its ratio, or None beyond tolerance."""
    if not rule_rate > 0:
        return None
    best: tuple[float, str, float] | None = None
    for key, cell in budgets.items():
        if "infeasible" in cell or not cell["test_alert_rate"] > 0:
            break
        ratio = cell["test_alert_rate"] / rule_rate
        distance = abs(math.log(ratio))
        if best is None or (distance, float(key)) < (best[0], float(best[1])):
            best = (distance, key, ratio)
    if best is None or best[0] > math.log(TOLERANCE):
        return None
    return best[1], best[2]


def x_match_cell__mutmut_15(budgets: dict[str, Any], rule_rate: float) -> tuple[str, float] | None:
    """The feasible budget cell closest to ``rule_rate`` and its ratio, or None beyond tolerance."""
    if not rule_rate > 0:
        return None
    best: tuple[float, str, float] | None = None
    for key, cell in budgets.items():
        if "infeasible" in cell or not cell["test_alert_rate"] > 0:
            continue
        ratio = None
        distance = abs(math.log(ratio))
        if best is None or (distance, float(key)) < (best[0], float(best[1])):
            best = (distance, key, ratio)
    if best is None or best[0] > math.log(TOLERANCE):
        return None
    return best[1], best[2]


def x_match_cell__mutmut_16(budgets: dict[str, Any], rule_rate: float) -> tuple[str, float] | None:
    """The feasible budget cell closest to ``rule_rate`` and its ratio, or None beyond tolerance."""
    if not rule_rate > 0:
        return None
    best: tuple[float, str, float] | None = None
    for key, cell in budgets.items():
        if "infeasible" in cell or not cell["test_alert_rate"] > 0:
            continue
        ratio = cell["test_alert_rate"] * rule_rate
        distance = abs(math.log(ratio))
        if best is None or (distance, float(key)) < (best[0], float(best[1])):
            best = (distance, key, ratio)
    if best is None or best[0] > math.log(TOLERANCE):
        return None
    return best[1], best[2]


def x_match_cell__mutmut_17(budgets: dict[str, Any], rule_rate: float) -> tuple[str, float] | None:
    """The feasible budget cell closest to ``rule_rate`` and its ratio, or None beyond tolerance."""
    if not rule_rate > 0:
        return None
    best: tuple[float, str, float] | None = None
    for key, cell in budgets.items():
        if "infeasible" in cell or not cell["test_alert_rate"] > 0:
            continue
        ratio = cell["XXtest_alert_rateXX"] / rule_rate
        distance = abs(math.log(ratio))
        if best is None or (distance, float(key)) < (best[0], float(best[1])):
            best = (distance, key, ratio)
    if best is None or best[0] > math.log(TOLERANCE):
        return None
    return best[1], best[2]


def x_match_cell__mutmut_18(budgets: dict[str, Any], rule_rate: float) -> tuple[str, float] | None:
    """The feasible budget cell closest to ``rule_rate`` and its ratio, or None beyond tolerance."""
    if not rule_rate > 0:
        return None
    best: tuple[float, str, float] | None = None
    for key, cell in budgets.items():
        if "infeasible" in cell or not cell["test_alert_rate"] > 0:
            continue
        ratio = cell["TEST_ALERT_RATE"] / rule_rate
        distance = abs(math.log(ratio))
        if best is None or (distance, float(key)) < (best[0], float(best[1])):
            best = (distance, key, ratio)
    if best is None or best[0] > math.log(TOLERANCE):
        return None
    return best[1], best[2]


def x_match_cell__mutmut_19(budgets: dict[str, Any], rule_rate: float) -> tuple[str, float] | None:
    """The feasible budget cell closest to ``rule_rate`` and its ratio, or None beyond tolerance."""
    if not rule_rate > 0:
        return None
    best: tuple[float, str, float] | None = None
    for key, cell in budgets.items():
        if "infeasible" in cell or not cell["test_alert_rate"] > 0:
            continue
        ratio = cell["test_alert_rate"] / rule_rate
        distance = None
        if best is None or (distance, float(key)) < (best[0], float(best[1])):
            best = (distance, key, ratio)
    if best is None or best[0] > math.log(TOLERANCE):
        return None
    return best[1], best[2]


def x_match_cell__mutmut_20(budgets: dict[str, Any], rule_rate: float) -> tuple[str, float] | None:
    """The feasible budget cell closest to ``rule_rate`` and its ratio, or None beyond tolerance."""
    if not rule_rate > 0:
        return None
    best: tuple[float, str, float] | None = None
    for key, cell in budgets.items():
        if "infeasible" in cell or not cell["test_alert_rate"] > 0:
            continue
        ratio = cell["test_alert_rate"] / rule_rate
        distance = abs(None)
        if best is None or (distance, float(key)) < (best[0], float(best[1])):
            best = (distance, key, ratio)
    if best is None or best[0] > math.log(TOLERANCE):
        return None
    return best[1], best[2]


def x_match_cell__mutmut_21(budgets: dict[str, Any], rule_rate: float) -> tuple[str, float] | None:
    """The feasible budget cell closest to ``rule_rate`` and its ratio, or None beyond tolerance."""
    if not rule_rate > 0:
        return None
    best: tuple[float, str, float] | None = None
    for key, cell in budgets.items():
        if "infeasible" in cell or not cell["test_alert_rate"] > 0:
            continue
        ratio = cell["test_alert_rate"] / rule_rate
        distance = abs(math.log(None))
        if best is None or (distance, float(key)) < (best[0], float(best[1])):
            best = (distance, key, ratio)
    if best is None or best[0] > math.log(TOLERANCE):
        return None
    return best[1], best[2]


def x_match_cell__mutmut_22(budgets: dict[str, Any], rule_rate: float) -> tuple[str, float] | None:
    """The feasible budget cell closest to ``rule_rate`` and its ratio, or None beyond tolerance."""
    if not rule_rate > 0:
        return None
    best: tuple[float, str, float] | None = None
    for key, cell in budgets.items():
        if "infeasible" in cell or not cell["test_alert_rate"] > 0:
            continue
        ratio = cell["test_alert_rate"] / rule_rate
        distance = abs(math.log(ratio))
        if best is None and (distance, float(key)) < (best[0], float(best[1])):
            best = (distance, key, ratio)
    if best is None or best[0] > math.log(TOLERANCE):
        return None
    return best[1], best[2]


def x_match_cell__mutmut_23(budgets: dict[str, Any], rule_rate: float) -> tuple[str, float] | None:
    """The feasible budget cell closest to ``rule_rate`` and its ratio, or None beyond tolerance."""
    if not rule_rate > 0:
        return None
    best: tuple[float, str, float] | None = None
    for key, cell in budgets.items():
        if "infeasible" in cell or not cell["test_alert_rate"] > 0:
            continue
        ratio = cell["test_alert_rate"] / rule_rate
        distance = abs(math.log(ratio))
        if best is not None or (distance, float(key)) < (best[0], float(best[1])):
            best = (distance, key, ratio)
    if best is None or best[0] > math.log(TOLERANCE):
        return None
    return best[1], best[2]


def x_match_cell__mutmut_24(budgets: dict[str, Any], rule_rate: float) -> tuple[str, float] | None:
    """The feasible budget cell closest to ``rule_rate`` and its ratio, or None beyond tolerance."""
    if not rule_rate > 0:
        return None
    best: tuple[float, str, float] | None = None
    for key, cell in budgets.items():
        if "infeasible" in cell or not cell["test_alert_rate"] > 0:
            continue
        ratio = cell["test_alert_rate"] / rule_rate
        distance = abs(math.log(ratio))
        if best is None or (distance, float(None)) < (best[0], float(best[1])):
            best = (distance, key, ratio)
    if best is None or best[0] > math.log(TOLERANCE):
        return None
    return best[1], best[2]


def x_match_cell__mutmut_25(budgets: dict[str, Any], rule_rate: float) -> tuple[str, float] | None:
    """The feasible budget cell closest to ``rule_rate`` and its ratio, or None beyond tolerance."""
    if not rule_rate > 0:
        return None
    best: tuple[float, str, float] | None = None
    for key, cell in budgets.items():
        if "infeasible" in cell or not cell["test_alert_rate"] > 0:
            continue
        ratio = cell["test_alert_rate"] / rule_rate
        distance = abs(math.log(ratio))
        if best is None or (distance, float(key)) <= (best[0], float(best[1])):
            best = (distance, key, ratio)
    if best is None or best[0] > math.log(TOLERANCE):
        return None
    return best[1], best[2]


def x_match_cell__mutmut_26(budgets: dict[str, Any], rule_rate: float) -> tuple[str, float] | None:
    """The feasible budget cell closest to ``rule_rate`` and its ratio, or None beyond tolerance."""
    if not rule_rate > 0:
        return None
    best: tuple[float, str, float] | None = None
    for key, cell in budgets.items():
        if "infeasible" in cell or not cell["test_alert_rate"] > 0:
            continue
        ratio = cell["test_alert_rate"] / rule_rate
        distance = abs(math.log(ratio))
        if best is None or (distance, float(key)) < (best[1], float(best[1])):
            best = (distance, key, ratio)
    if best is None or best[0] > math.log(TOLERANCE):
        return None
    return best[1], best[2]


def x_match_cell__mutmut_27(budgets: dict[str, Any], rule_rate: float) -> tuple[str, float] | None:
    """The feasible budget cell closest to ``rule_rate`` and its ratio, or None beyond tolerance."""
    if not rule_rate > 0:
        return None
    best: tuple[float, str, float] | None = None
    for key, cell in budgets.items():
        if "infeasible" in cell or not cell["test_alert_rate"] > 0:
            continue
        ratio = cell["test_alert_rate"] / rule_rate
        distance = abs(math.log(ratio))
        if best is None or (distance, float(key)) < (best[0], float(None)):
            best = (distance, key, ratio)
    if best is None or best[0] > math.log(TOLERANCE):
        return None
    return best[1], best[2]


def x_match_cell__mutmut_28(budgets: dict[str, Any], rule_rate: float) -> tuple[str, float] | None:
    """The feasible budget cell closest to ``rule_rate`` and its ratio, or None beyond tolerance."""
    if not rule_rate > 0:
        return None
    best: tuple[float, str, float] | None = None
    for key, cell in budgets.items():
        if "infeasible" in cell or not cell["test_alert_rate"] > 0:
            continue
        ratio = cell["test_alert_rate"] / rule_rate
        distance = abs(math.log(ratio))
        if best is None or (distance, float(key)) < (best[0], float(best[2])):
            best = (distance, key, ratio)
    if best is None or best[0] > math.log(TOLERANCE):
        return None
    return best[1], best[2]


def x_match_cell__mutmut_29(budgets: dict[str, Any], rule_rate: float) -> tuple[str, float] | None:
    """The feasible budget cell closest to ``rule_rate`` and its ratio, or None beyond tolerance."""
    if not rule_rate > 0:
        return None
    best: tuple[float, str, float] | None = None
    for key, cell in budgets.items():
        if "infeasible" in cell or not cell["test_alert_rate"] > 0:
            continue
        ratio = cell["test_alert_rate"] / rule_rate
        distance = abs(math.log(ratio))
        if best is None or (distance, float(key)) < (best[0], float(best[1])):
            best = None
    if best is None or best[0] > math.log(TOLERANCE):
        return None
    return best[1], best[2]


def x_match_cell__mutmut_30(budgets: dict[str, Any], rule_rate: float) -> tuple[str, float] | None:
    """The feasible budget cell closest to ``rule_rate`` and its ratio, or None beyond tolerance."""
    if not rule_rate > 0:
        return None
    best: tuple[float, str, float] | None = None
    for key, cell in budgets.items():
        if "infeasible" in cell or not cell["test_alert_rate"] > 0:
            continue
        ratio = cell["test_alert_rate"] / rule_rate
        distance = abs(math.log(ratio))
        if best is None or (distance, float(key)) < (best[0], float(best[1])):
            best = (distance, key, ratio)
    if best is None and best[0] > math.log(TOLERANCE):
        return None
    return best[1], best[2]


def x_match_cell__mutmut_31(budgets: dict[str, Any], rule_rate: float) -> tuple[str, float] | None:
    """The feasible budget cell closest to ``rule_rate`` and its ratio, or None beyond tolerance."""
    if not rule_rate > 0:
        return None
    best: tuple[float, str, float] | None = None
    for key, cell in budgets.items():
        if "infeasible" in cell or not cell["test_alert_rate"] > 0:
            continue
        ratio = cell["test_alert_rate"] / rule_rate
        distance = abs(math.log(ratio))
        if best is None or (distance, float(key)) < (best[0], float(best[1])):
            best = (distance, key, ratio)
    if best is not None or best[0] > math.log(TOLERANCE):
        return None
    return best[1], best[2]


def x_match_cell__mutmut_32(budgets: dict[str, Any], rule_rate: float) -> tuple[str, float] | None:
    """The feasible budget cell closest to ``rule_rate`` and its ratio, or None beyond tolerance."""
    if not rule_rate > 0:
        return None
    best: tuple[float, str, float] | None = None
    for key, cell in budgets.items():
        if "infeasible" in cell or not cell["test_alert_rate"] > 0:
            continue
        ratio = cell["test_alert_rate"] / rule_rate
        distance = abs(math.log(ratio))
        if best is None or (distance, float(key)) < (best[0], float(best[1])):
            best = (distance, key, ratio)
    if best is None or best[1] > math.log(TOLERANCE):
        return None
    return best[1], best[2]


def x_match_cell__mutmut_33(budgets: dict[str, Any], rule_rate: float) -> tuple[str, float] | None:
    """The feasible budget cell closest to ``rule_rate`` and its ratio, or None beyond tolerance."""
    if not rule_rate > 0:
        return None
    best: tuple[float, str, float] | None = None
    for key, cell in budgets.items():
        if "infeasible" in cell or not cell["test_alert_rate"] > 0:
            continue
        ratio = cell["test_alert_rate"] / rule_rate
        distance = abs(math.log(ratio))
        if best is None or (distance, float(key)) < (best[0], float(best[1])):
            best = (distance, key, ratio)
    if best is None or best[0] >= math.log(TOLERANCE):
        return None
    return best[1], best[2]


def x_match_cell__mutmut_34(budgets: dict[str, Any], rule_rate: float) -> tuple[str, float] | None:
    """The feasible budget cell closest to ``rule_rate`` and its ratio, or None beyond tolerance."""
    if not rule_rate > 0:
        return None
    best: tuple[float, str, float] | None = None
    for key, cell in budgets.items():
        if "infeasible" in cell or not cell["test_alert_rate"] > 0:
            continue
        ratio = cell["test_alert_rate"] / rule_rate
        distance = abs(math.log(ratio))
        if best is None or (distance, float(key)) < (best[0], float(best[1])):
            best = (distance, key, ratio)
    if best is None or best[0] > math.log(None):
        return None
    return best[1], best[2]


def x_match_cell__mutmut_35(budgets: dict[str, Any], rule_rate: float) -> tuple[str, float] | None:
    """The feasible budget cell closest to ``rule_rate`` and its ratio, or None beyond tolerance."""
    if not rule_rate > 0:
        return None
    best: tuple[float, str, float] | None = None
    for key, cell in budgets.items():
        if "infeasible" in cell or not cell["test_alert_rate"] > 0:
            continue
        ratio = cell["test_alert_rate"] / rule_rate
        distance = abs(math.log(ratio))
        if best is None or (distance, float(key)) < (best[0], float(best[1])):
            best = (distance, key, ratio)
    if best is None or best[0] > math.log(TOLERANCE):
        return None
    return best[2], best[2]


def x_match_cell__mutmut_36(budgets: dict[str, Any], rule_rate: float) -> tuple[str, float] | None:
    """The feasible budget cell closest to ``rule_rate`` and its ratio, or None beyond tolerance."""
    if not rule_rate > 0:
        return None
    best: tuple[float, str, float] | None = None
    for key, cell in budgets.items():
        if "infeasible" in cell or not cell["test_alert_rate"] > 0:
            continue
        ratio = cell["test_alert_rate"] / rule_rate
        distance = abs(math.log(ratio))
        if best is None or (distance, float(key)) < (best[0], float(best[1])):
            best = (distance, key, ratio)
    if best is None or best[0] > math.log(TOLERANCE):
        return None
    return best[1], best[3]

mutants_x_match_cell__mutmut['_mutmut_orig'] = x_match_cell__mutmut_orig # type: ignore # mutmut generated
mutants_x_match_cell__mutmut['x_match_cell__mutmut_1'] = x_match_cell__mutmut_1 # type: ignore # mutmut generated
mutants_x_match_cell__mutmut['x_match_cell__mutmut_2'] = x_match_cell__mutmut_2 # type: ignore # mutmut generated
mutants_x_match_cell__mutmut['x_match_cell__mutmut_3'] = x_match_cell__mutmut_3 # type: ignore # mutmut generated
mutants_x_match_cell__mutmut['x_match_cell__mutmut_4'] = x_match_cell__mutmut_4 # type: ignore # mutmut generated
mutants_x_match_cell__mutmut['x_match_cell__mutmut_5'] = x_match_cell__mutmut_5 # type: ignore # mutmut generated
mutants_x_match_cell__mutmut['x_match_cell__mutmut_6'] = x_match_cell__mutmut_6 # type: ignore # mutmut generated
mutants_x_match_cell__mutmut['x_match_cell__mutmut_7'] = x_match_cell__mutmut_7 # type: ignore # mutmut generated
mutants_x_match_cell__mutmut['x_match_cell__mutmut_8'] = x_match_cell__mutmut_8 # type: ignore # mutmut generated
mutants_x_match_cell__mutmut['x_match_cell__mutmut_9'] = x_match_cell__mutmut_9 # type: ignore # mutmut generated
mutants_x_match_cell__mutmut['x_match_cell__mutmut_10'] = x_match_cell__mutmut_10 # type: ignore # mutmut generated
mutants_x_match_cell__mutmut['x_match_cell__mutmut_11'] = x_match_cell__mutmut_11 # type: ignore # mutmut generated
mutants_x_match_cell__mutmut['x_match_cell__mutmut_12'] = x_match_cell__mutmut_12 # type: ignore # mutmut generated
mutants_x_match_cell__mutmut['x_match_cell__mutmut_13'] = x_match_cell__mutmut_13 # type: ignore # mutmut generated
mutants_x_match_cell__mutmut['x_match_cell__mutmut_14'] = x_match_cell__mutmut_14 # type: ignore # mutmut generated
mutants_x_match_cell__mutmut['x_match_cell__mutmut_15'] = x_match_cell__mutmut_15 # type: ignore # mutmut generated
mutants_x_match_cell__mutmut['x_match_cell__mutmut_16'] = x_match_cell__mutmut_16 # type: ignore # mutmut generated
mutants_x_match_cell__mutmut['x_match_cell__mutmut_17'] = x_match_cell__mutmut_17 # type: ignore # mutmut generated
mutants_x_match_cell__mutmut['x_match_cell__mutmut_18'] = x_match_cell__mutmut_18 # type: ignore # mutmut generated
mutants_x_match_cell__mutmut['x_match_cell__mutmut_19'] = x_match_cell__mutmut_19 # type: ignore # mutmut generated
mutants_x_match_cell__mutmut['x_match_cell__mutmut_20'] = x_match_cell__mutmut_20 # type: ignore # mutmut generated
mutants_x_match_cell__mutmut['x_match_cell__mutmut_21'] = x_match_cell__mutmut_21 # type: ignore # mutmut generated
mutants_x_match_cell__mutmut['x_match_cell__mutmut_22'] = x_match_cell__mutmut_22 # type: ignore # mutmut generated
mutants_x_match_cell__mutmut['x_match_cell__mutmut_23'] = x_match_cell__mutmut_23 # type: ignore # mutmut generated
mutants_x_match_cell__mutmut['x_match_cell__mutmut_24'] = x_match_cell__mutmut_24 # type: ignore # mutmut generated
mutants_x_match_cell__mutmut['x_match_cell__mutmut_25'] = x_match_cell__mutmut_25 # type: ignore # mutmut generated
mutants_x_match_cell__mutmut['x_match_cell__mutmut_26'] = x_match_cell__mutmut_26 # type: ignore # mutmut generated
mutants_x_match_cell__mutmut['x_match_cell__mutmut_27'] = x_match_cell__mutmut_27 # type: ignore # mutmut generated
mutants_x_match_cell__mutmut['x_match_cell__mutmut_28'] = x_match_cell__mutmut_28 # type: ignore # mutmut generated
mutants_x_match_cell__mutmut['x_match_cell__mutmut_29'] = x_match_cell__mutmut_29 # type: ignore # mutmut generated
mutants_x_match_cell__mutmut['x_match_cell__mutmut_30'] = x_match_cell__mutmut_30 # type: ignore # mutmut generated
mutants_x_match_cell__mutmut['x_match_cell__mutmut_31'] = x_match_cell__mutmut_31 # type: ignore # mutmut generated
mutants_x_match_cell__mutmut['x_match_cell__mutmut_32'] = x_match_cell__mutmut_32 # type: ignore # mutmut generated
mutants_x_match_cell__mutmut['x_match_cell__mutmut_33'] = x_match_cell__mutmut_33 # type: ignore # mutmut generated
mutants_x_match_cell__mutmut['x_match_cell__mutmut_34'] = x_match_cell__mutmut_34 # type: ignore # mutmut generated
mutants_x_match_cell__mutmut['x_match_cell__mutmut_35'] = x_match_cell__mutmut_35 # type: ignore # mutmut generated
mutants_x_match_cell__mutmut['x_match_cell__mutmut_36'] = x_match_cell__mutmut_36 # type: ignore # mutmut generated
mutants_x_pair_problem__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_pair_problem__mutmut)
def pair_problem(run: dict[str, Any], rule: str, method: str) -> dict[str, Any]:
    """Seed-paired matched differences for one problem, with the reason of every exclusion."""
    rules = {s["seed"]: s["rule"] for s in run["runs"].get(rule, [])}
    learned = {s["seed"]: s["budgets"] for s in run["runs"].get(method, []) if "budgets" in s}
    out: dict[str, Any] = {"rows": [], "unpaired": 0, "no_alerts": 0, "no_match": 0}
    for seed, decision in rules.items():
        if seed not in learned:
            out["unpaired"] += 1
            continue
        found = match_cell(learned[seed], decision["test_alert_rate"])
        if found is None:
            out["no_alerts" if not decision["test_alert_rate"] > 0 else "no_match"] += 1
            continue
        key, ratio = found
        cell = learned[seed][key]
        out["rows"].append(
            {"budget": float(key), "ratio": ratio}
            | {m: cell[m] - decision[m] for m in METRICS}
        )  # fmt: skip
    return out


def x_pair_problem__mutmut_orig(run: dict[str, Any], rule: str, method: str) -> dict[str, Any]:
    """Seed-paired matched differences for one problem, with the reason of every exclusion."""
    rules = {s["seed"]: s["rule"] for s in run["runs"].get(rule, [])}
    learned = {s["seed"]: s["budgets"] for s in run["runs"].get(method, []) if "budgets" in s}
    out: dict[str, Any] = {"rows": [], "unpaired": 0, "no_alerts": 0, "no_match": 0}
    for seed, decision in rules.items():
        if seed not in learned:
            out["unpaired"] += 1
            continue
        found = match_cell(learned[seed], decision["test_alert_rate"])
        if found is None:
            out["no_alerts" if not decision["test_alert_rate"] > 0 else "no_match"] += 1
            continue
        key, ratio = found
        cell = learned[seed][key]
        out["rows"].append(
            {"budget": float(key), "ratio": ratio}
            | {m: cell[m] - decision[m] for m in METRICS}
        )  # fmt: skip
    return out


def x_pair_problem__mutmut_1(run: dict[str, Any], rule: str, method: str) -> dict[str, Any]:
    """Seed-paired matched differences for one problem, with the reason of every exclusion."""
    rules = None
    learned = {s["seed"]: s["budgets"] for s in run["runs"].get(method, []) if "budgets" in s}
    out: dict[str, Any] = {"rows": [], "unpaired": 0, "no_alerts": 0, "no_match": 0}
    for seed, decision in rules.items():
        if seed not in learned:
            out["unpaired"] += 1
            continue
        found = match_cell(learned[seed], decision["test_alert_rate"])
        if found is None:
            out["no_alerts" if not decision["test_alert_rate"] > 0 else "no_match"] += 1
            continue
        key, ratio = found
        cell = learned[seed][key]
        out["rows"].append(
            {"budget": float(key), "ratio": ratio}
            | {m: cell[m] - decision[m] for m in METRICS}
        )  # fmt: skip
    return out


def x_pair_problem__mutmut_2(run: dict[str, Any], rule: str, method: str) -> dict[str, Any]:
    """Seed-paired matched differences for one problem, with the reason of every exclusion."""
    rules = {s["XXseedXX"]: s["rule"] for s in run["runs"].get(rule, [])}
    learned = {s["seed"]: s["budgets"] for s in run["runs"].get(method, []) if "budgets" in s}
    out: dict[str, Any] = {"rows": [], "unpaired": 0, "no_alerts": 0, "no_match": 0}
    for seed, decision in rules.items():
        if seed not in learned:
            out["unpaired"] += 1
            continue
        found = match_cell(learned[seed], decision["test_alert_rate"])
        if found is None:
            out["no_alerts" if not decision["test_alert_rate"] > 0 else "no_match"] += 1
            continue
        key, ratio = found
        cell = learned[seed][key]
        out["rows"].append(
            {"budget": float(key), "ratio": ratio}
            | {m: cell[m] - decision[m] for m in METRICS}
        )  # fmt: skip
    return out


def x_pair_problem__mutmut_3(run: dict[str, Any], rule: str, method: str) -> dict[str, Any]:
    """Seed-paired matched differences for one problem, with the reason of every exclusion."""
    rules = {s["SEED"]: s["rule"] for s in run["runs"].get(rule, [])}
    learned = {s["seed"]: s["budgets"] for s in run["runs"].get(method, []) if "budgets" in s}
    out: dict[str, Any] = {"rows": [], "unpaired": 0, "no_alerts": 0, "no_match": 0}
    for seed, decision in rules.items():
        if seed not in learned:
            out["unpaired"] += 1
            continue
        found = match_cell(learned[seed], decision["test_alert_rate"])
        if found is None:
            out["no_alerts" if not decision["test_alert_rate"] > 0 else "no_match"] += 1
            continue
        key, ratio = found
        cell = learned[seed][key]
        out["rows"].append(
            {"budget": float(key), "ratio": ratio}
            | {m: cell[m] - decision[m] for m in METRICS}
        )  # fmt: skip
    return out


def x_pair_problem__mutmut_4(run: dict[str, Any], rule: str, method: str) -> dict[str, Any]:
    """Seed-paired matched differences for one problem, with the reason of every exclusion."""
    rules = {s["seed"]: s["XXruleXX"] for s in run["runs"].get(rule, [])}
    learned = {s["seed"]: s["budgets"] for s in run["runs"].get(method, []) if "budgets" in s}
    out: dict[str, Any] = {"rows": [], "unpaired": 0, "no_alerts": 0, "no_match": 0}
    for seed, decision in rules.items():
        if seed not in learned:
            out["unpaired"] += 1
            continue
        found = match_cell(learned[seed], decision["test_alert_rate"])
        if found is None:
            out["no_alerts" if not decision["test_alert_rate"] > 0 else "no_match"] += 1
            continue
        key, ratio = found
        cell = learned[seed][key]
        out["rows"].append(
            {"budget": float(key), "ratio": ratio}
            | {m: cell[m] - decision[m] for m in METRICS}
        )  # fmt: skip
    return out


def x_pair_problem__mutmut_5(run: dict[str, Any], rule: str, method: str) -> dict[str, Any]:
    """Seed-paired matched differences for one problem, with the reason of every exclusion."""
    rules = {s["seed"]: s["RULE"] for s in run["runs"].get(rule, [])}
    learned = {s["seed"]: s["budgets"] for s in run["runs"].get(method, []) if "budgets" in s}
    out: dict[str, Any] = {"rows": [], "unpaired": 0, "no_alerts": 0, "no_match": 0}
    for seed, decision in rules.items():
        if seed not in learned:
            out["unpaired"] += 1
            continue
        found = match_cell(learned[seed], decision["test_alert_rate"])
        if found is None:
            out["no_alerts" if not decision["test_alert_rate"] > 0 else "no_match"] += 1
            continue
        key, ratio = found
        cell = learned[seed][key]
        out["rows"].append(
            {"budget": float(key), "ratio": ratio}
            | {m: cell[m] - decision[m] for m in METRICS}
        )  # fmt: skip
    return out


def x_pair_problem__mutmut_6(run: dict[str, Any], rule: str, method: str) -> dict[str, Any]:
    """Seed-paired matched differences for one problem, with the reason of every exclusion."""
    rules = {s["seed"]: s["rule"] for s in run["runs"].get(None, [])}
    learned = {s["seed"]: s["budgets"] for s in run["runs"].get(method, []) if "budgets" in s}
    out: dict[str, Any] = {"rows": [], "unpaired": 0, "no_alerts": 0, "no_match": 0}
    for seed, decision in rules.items():
        if seed not in learned:
            out["unpaired"] += 1
            continue
        found = match_cell(learned[seed], decision["test_alert_rate"])
        if found is None:
            out["no_alerts" if not decision["test_alert_rate"] > 0 else "no_match"] += 1
            continue
        key, ratio = found
        cell = learned[seed][key]
        out["rows"].append(
            {"budget": float(key), "ratio": ratio}
            | {m: cell[m] - decision[m] for m in METRICS}
        )  # fmt: skip
    return out


def x_pair_problem__mutmut_7(run: dict[str, Any], rule: str, method: str) -> dict[str, Any]:
    """Seed-paired matched differences for one problem, with the reason of every exclusion."""
    rules = {s["seed"]: s["rule"] for s in run["runs"].get(rule, None)}
    learned = {s["seed"]: s["budgets"] for s in run["runs"].get(method, []) if "budgets" in s}
    out: dict[str, Any] = {"rows": [], "unpaired": 0, "no_alerts": 0, "no_match": 0}
    for seed, decision in rules.items():
        if seed not in learned:
            out["unpaired"] += 1
            continue
        found = match_cell(learned[seed], decision["test_alert_rate"])
        if found is None:
            out["no_alerts" if not decision["test_alert_rate"] > 0 else "no_match"] += 1
            continue
        key, ratio = found
        cell = learned[seed][key]
        out["rows"].append(
            {"budget": float(key), "ratio": ratio}
            | {m: cell[m] - decision[m] for m in METRICS}
        )  # fmt: skip
    return out


def x_pair_problem__mutmut_8(run: dict[str, Any], rule: str, method: str) -> dict[str, Any]:
    """Seed-paired matched differences for one problem, with the reason of every exclusion."""
    rules = {s["seed"]: s["rule"] for s in run["runs"].get([])}
    learned = {s["seed"]: s["budgets"] for s in run["runs"].get(method, []) if "budgets" in s}
    out: dict[str, Any] = {"rows": [], "unpaired": 0, "no_alerts": 0, "no_match": 0}
    for seed, decision in rules.items():
        if seed not in learned:
            out["unpaired"] += 1
            continue
        found = match_cell(learned[seed], decision["test_alert_rate"])
        if found is None:
            out["no_alerts" if not decision["test_alert_rate"] > 0 else "no_match"] += 1
            continue
        key, ratio = found
        cell = learned[seed][key]
        out["rows"].append(
            {"budget": float(key), "ratio": ratio}
            | {m: cell[m] - decision[m] for m in METRICS}
        )  # fmt: skip
    return out


def x_pair_problem__mutmut_9(run: dict[str, Any], rule: str, method: str) -> dict[str, Any]:
    """Seed-paired matched differences for one problem, with the reason of every exclusion."""
    rules = {s["seed"]: s["rule"] for s in run["runs"].get(rule, )}
    learned = {s["seed"]: s["budgets"] for s in run["runs"].get(method, []) if "budgets" in s}
    out: dict[str, Any] = {"rows": [], "unpaired": 0, "no_alerts": 0, "no_match": 0}
    for seed, decision in rules.items():
        if seed not in learned:
            out["unpaired"] += 1
            continue
        found = match_cell(learned[seed], decision["test_alert_rate"])
        if found is None:
            out["no_alerts" if not decision["test_alert_rate"] > 0 else "no_match"] += 1
            continue
        key, ratio = found
        cell = learned[seed][key]
        out["rows"].append(
            {"budget": float(key), "ratio": ratio}
            | {m: cell[m] - decision[m] for m in METRICS}
        )  # fmt: skip
    return out


def x_pair_problem__mutmut_10(run: dict[str, Any], rule: str, method: str) -> dict[str, Any]:
    """Seed-paired matched differences for one problem, with the reason of every exclusion."""
    rules = {s["seed"]: s["rule"] for s in run["XXrunsXX"].get(rule, [])}
    learned = {s["seed"]: s["budgets"] for s in run["runs"].get(method, []) if "budgets" in s}
    out: dict[str, Any] = {"rows": [], "unpaired": 0, "no_alerts": 0, "no_match": 0}
    for seed, decision in rules.items():
        if seed not in learned:
            out["unpaired"] += 1
            continue
        found = match_cell(learned[seed], decision["test_alert_rate"])
        if found is None:
            out["no_alerts" if not decision["test_alert_rate"] > 0 else "no_match"] += 1
            continue
        key, ratio = found
        cell = learned[seed][key]
        out["rows"].append(
            {"budget": float(key), "ratio": ratio}
            | {m: cell[m] - decision[m] for m in METRICS}
        )  # fmt: skip
    return out


def x_pair_problem__mutmut_11(run: dict[str, Any], rule: str, method: str) -> dict[str, Any]:
    """Seed-paired matched differences for one problem, with the reason of every exclusion."""
    rules = {s["seed"]: s["rule"] for s in run["RUNS"].get(rule, [])}
    learned = {s["seed"]: s["budgets"] for s in run["runs"].get(method, []) if "budgets" in s}
    out: dict[str, Any] = {"rows": [], "unpaired": 0, "no_alerts": 0, "no_match": 0}
    for seed, decision in rules.items():
        if seed not in learned:
            out["unpaired"] += 1
            continue
        found = match_cell(learned[seed], decision["test_alert_rate"])
        if found is None:
            out["no_alerts" if not decision["test_alert_rate"] > 0 else "no_match"] += 1
            continue
        key, ratio = found
        cell = learned[seed][key]
        out["rows"].append(
            {"budget": float(key), "ratio": ratio}
            | {m: cell[m] - decision[m] for m in METRICS}
        )  # fmt: skip
    return out


def x_pair_problem__mutmut_12(run: dict[str, Any], rule: str, method: str) -> dict[str, Any]:
    """Seed-paired matched differences for one problem, with the reason of every exclusion."""
    rules = {s["seed"]: s["rule"] for s in run["runs"].get(rule, [])}
    learned = None
    out: dict[str, Any] = {"rows": [], "unpaired": 0, "no_alerts": 0, "no_match": 0}
    for seed, decision in rules.items():
        if seed not in learned:
            out["unpaired"] += 1
            continue
        found = match_cell(learned[seed], decision["test_alert_rate"])
        if found is None:
            out["no_alerts" if not decision["test_alert_rate"] > 0 else "no_match"] += 1
            continue
        key, ratio = found
        cell = learned[seed][key]
        out["rows"].append(
            {"budget": float(key), "ratio": ratio}
            | {m: cell[m] - decision[m] for m in METRICS}
        )  # fmt: skip
    return out


def x_pair_problem__mutmut_13(run: dict[str, Any], rule: str, method: str) -> dict[str, Any]:
    """Seed-paired matched differences for one problem, with the reason of every exclusion."""
    rules = {s["seed"]: s["rule"] for s in run["runs"].get(rule, [])}
    learned = {s["XXseedXX"]: s["budgets"] for s in run["runs"].get(method, []) if "budgets" in s}
    out: dict[str, Any] = {"rows": [], "unpaired": 0, "no_alerts": 0, "no_match": 0}
    for seed, decision in rules.items():
        if seed not in learned:
            out["unpaired"] += 1
            continue
        found = match_cell(learned[seed], decision["test_alert_rate"])
        if found is None:
            out["no_alerts" if not decision["test_alert_rate"] > 0 else "no_match"] += 1
            continue
        key, ratio = found
        cell = learned[seed][key]
        out["rows"].append(
            {"budget": float(key), "ratio": ratio}
            | {m: cell[m] - decision[m] for m in METRICS}
        )  # fmt: skip
    return out


def x_pair_problem__mutmut_14(run: dict[str, Any], rule: str, method: str) -> dict[str, Any]:
    """Seed-paired matched differences for one problem, with the reason of every exclusion."""
    rules = {s["seed"]: s["rule"] for s in run["runs"].get(rule, [])}
    learned = {s["SEED"]: s["budgets"] for s in run["runs"].get(method, []) if "budgets" in s}
    out: dict[str, Any] = {"rows": [], "unpaired": 0, "no_alerts": 0, "no_match": 0}
    for seed, decision in rules.items():
        if seed not in learned:
            out["unpaired"] += 1
            continue
        found = match_cell(learned[seed], decision["test_alert_rate"])
        if found is None:
            out["no_alerts" if not decision["test_alert_rate"] > 0 else "no_match"] += 1
            continue
        key, ratio = found
        cell = learned[seed][key]
        out["rows"].append(
            {"budget": float(key), "ratio": ratio}
            | {m: cell[m] - decision[m] for m in METRICS}
        )  # fmt: skip
    return out


def x_pair_problem__mutmut_15(run: dict[str, Any], rule: str, method: str) -> dict[str, Any]:
    """Seed-paired matched differences for one problem, with the reason of every exclusion."""
    rules = {s["seed"]: s["rule"] for s in run["runs"].get(rule, [])}
    learned = {s["seed"]: s["XXbudgetsXX"] for s in run["runs"].get(method, []) if "budgets" in s}
    out: dict[str, Any] = {"rows": [], "unpaired": 0, "no_alerts": 0, "no_match": 0}
    for seed, decision in rules.items():
        if seed not in learned:
            out["unpaired"] += 1
            continue
        found = match_cell(learned[seed], decision["test_alert_rate"])
        if found is None:
            out["no_alerts" if not decision["test_alert_rate"] > 0 else "no_match"] += 1
            continue
        key, ratio = found
        cell = learned[seed][key]
        out["rows"].append(
            {"budget": float(key), "ratio": ratio}
            | {m: cell[m] - decision[m] for m in METRICS}
        )  # fmt: skip
    return out


def x_pair_problem__mutmut_16(run: dict[str, Any], rule: str, method: str) -> dict[str, Any]:
    """Seed-paired matched differences for one problem, with the reason of every exclusion."""
    rules = {s["seed"]: s["rule"] for s in run["runs"].get(rule, [])}
    learned = {s["seed"]: s["BUDGETS"] for s in run["runs"].get(method, []) if "budgets" in s}
    out: dict[str, Any] = {"rows": [], "unpaired": 0, "no_alerts": 0, "no_match": 0}
    for seed, decision in rules.items():
        if seed not in learned:
            out["unpaired"] += 1
            continue
        found = match_cell(learned[seed], decision["test_alert_rate"])
        if found is None:
            out["no_alerts" if not decision["test_alert_rate"] > 0 else "no_match"] += 1
            continue
        key, ratio = found
        cell = learned[seed][key]
        out["rows"].append(
            {"budget": float(key), "ratio": ratio}
            | {m: cell[m] - decision[m] for m in METRICS}
        )  # fmt: skip
    return out


def x_pair_problem__mutmut_17(run: dict[str, Any], rule: str, method: str) -> dict[str, Any]:
    """Seed-paired matched differences for one problem, with the reason of every exclusion."""
    rules = {s["seed"]: s["rule"] for s in run["runs"].get(rule, [])}
    learned = {s["seed"]: s["budgets"] for s in run["runs"].get(None, []) if "budgets" in s}
    out: dict[str, Any] = {"rows": [], "unpaired": 0, "no_alerts": 0, "no_match": 0}
    for seed, decision in rules.items():
        if seed not in learned:
            out["unpaired"] += 1
            continue
        found = match_cell(learned[seed], decision["test_alert_rate"])
        if found is None:
            out["no_alerts" if not decision["test_alert_rate"] > 0 else "no_match"] += 1
            continue
        key, ratio = found
        cell = learned[seed][key]
        out["rows"].append(
            {"budget": float(key), "ratio": ratio}
            | {m: cell[m] - decision[m] for m in METRICS}
        )  # fmt: skip
    return out


def x_pair_problem__mutmut_18(run: dict[str, Any], rule: str, method: str) -> dict[str, Any]:
    """Seed-paired matched differences for one problem, with the reason of every exclusion."""
    rules = {s["seed"]: s["rule"] for s in run["runs"].get(rule, [])}
    learned = {s["seed"]: s["budgets"] for s in run["runs"].get(method, None) if "budgets" in s}
    out: dict[str, Any] = {"rows": [], "unpaired": 0, "no_alerts": 0, "no_match": 0}
    for seed, decision in rules.items():
        if seed not in learned:
            out["unpaired"] += 1
            continue
        found = match_cell(learned[seed], decision["test_alert_rate"])
        if found is None:
            out["no_alerts" if not decision["test_alert_rate"] > 0 else "no_match"] += 1
            continue
        key, ratio = found
        cell = learned[seed][key]
        out["rows"].append(
            {"budget": float(key), "ratio": ratio}
            | {m: cell[m] - decision[m] for m in METRICS}
        )  # fmt: skip
    return out


def x_pair_problem__mutmut_19(run: dict[str, Any], rule: str, method: str) -> dict[str, Any]:
    """Seed-paired matched differences for one problem, with the reason of every exclusion."""
    rules = {s["seed"]: s["rule"] for s in run["runs"].get(rule, [])}
    learned = {s["seed"]: s["budgets"] for s in run["runs"].get([]) if "budgets" in s}
    out: dict[str, Any] = {"rows": [], "unpaired": 0, "no_alerts": 0, "no_match": 0}
    for seed, decision in rules.items():
        if seed not in learned:
            out["unpaired"] += 1
            continue
        found = match_cell(learned[seed], decision["test_alert_rate"])
        if found is None:
            out["no_alerts" if not decision["test_alert_rate"] > 0 else "no_match"] += 1
            continue
        key, ratio = found
        cell = learned[seed][key]
        out["rows"].append(
            {"budget": float(key), "ratio": ratio}
            | {m: cell[m] - decision[m] for m in METRICS}
        )  # fmt: skip
    return out


def x_pair_problem__mutmut_20(run: dict[str, Any], rule: str, method: str) -> dict[str, Any]:
    """Seed-paired matched differences for one problem, with the reason of every exclusion."""
    rules = {s["seed"]: s["rule"] for s in run["runs"].get(rule, [])}
    learned = {s["seed"]: s["budgets"] for s in run["runs"].get(method, ) if "budgets" in s}
    out: dict[str, Any] = {"rows": [], "unpaired": 0, "no_alerts": 0, "no_match": 0}
    for seed, decision in rules.items():
        if seed not in learned:
            out["unpaired"] += 1
            continue
        found = match_cell(learned[seed], decision["test_alert_rate"])
        if found is None:
            out["no_alerts" if not decision["test_alert_rate"] > 0 else "no_match"] += 1
            continue
        key, ratio = found
        cell = learned[seed][key]
        out["rows"].append(
            {"budget": float(key), "ratio": ratio}
            | {m: cell[m] - decision[m] for m in METRICS}
        )  # fmt: skip
    return out


def x_pair_problem__mutmut_21(run: dict[str, Any], rule: str, method: str) -> dict[str, Any]:
    """Seed-paired matched differences for one problem, with the reason of every exclusion."""
    rules = {s["seed"]: s["rule"] for s in run["runs"].get(rule, [])}
    learned = {s["seed"]: s["budgets"] for s in run["XXrunsXX"].get(method, []) if "budgets" in s}
    out: dict[str, Any] = {"rows": [], "unpaired": 0, "no_alerts": 0, "no_match": 0}
    for seed, decision in rules.items():
        if seed not in learned:
            out["unpaired"] += 1
            continue
        found = match_cell(learned[seed], decision["test_alert_rate"])
        if found is None:
            out["no_alerts" if not decision["test_alert_rate"] > 0 else "no_match"] += 1
            continue
        key, ratio = found
        cell = learned[seed][key]
        out["rows"].append(
            {"budget": float(key), "ratio": ratio}
            | {m: cell[m] - decision[m] for m in METRICS}
        )  # fmt: skip
    return out


def x_pair_problem__mutmut_22(run: dict[str, Any], rule: str, method: str) -> dict[str, Any]:
    """Seed-paired matched differences for one problem, with the reason of every exclusion."""
    rules = {s["seed"]: s["rule"] for s in run["runs"].get(rule, [])}
    learned = {s["seed"]: s["budgets"] for s in run["RUNS"].get(method, []) if "budgets" in s}
    out: dict[str, Any] = {"rows": [], "unpaired": 0, "no_alerts": 0, "no_match": 0}
    for seed, decision in rules.items():
        if seed not in learned:
            out["unpaired"] += 1
            continue
        found = match_cell(learned[seed], decision["test_alert_rate"])
        if found is None:
            out["no_alerts" if not decision["test_alert_rate"] > 0 else "no_match"] += 1
            continue
        key, ratio = found
        cell = learned[seed][key]
        out["rows"].append(
            {"budget": float(key), "ratio": ratio}
            | {m: cell[m] - decision[m] for m in METRICS}
        )  # fmt: skip
    return out


def x_pair_problem__mutmut_23(run: dict[str, Any], rule: str, method: str) -> dict[str, Any]:
    """Seed-paired matched differences for one problem, with the reason of every exclusion."""
    rules = {s["seed"]: s["rule"] for s in run["runs"].get(rule, [])}
    learned = {s["seed"]: s["budgets"] for s in run["runs"].get(method, []) if "XXbudgetsXX" in s}
    out: dict[str, Any] = {"rows": [], "unpaired": 0, "no_alerts": 0, "no_match": 0}
    for seed, decision in rules.items():
        if seed not in learned:
            out["unpaired"] += 1
            continue
        found = match_cell(learned[seed], decision["test_alert_rate"])
        if found is None:
            out["no_alerts" if not decision["test_alert_rate"] > 0 else "no_match"] += 1
            continue
        key, ratio = found
        cell = learned[seed][key]
        out["rows"].append(
            {"budget": float(key), "ratio": ratio}
            | {m: cell[m] - decision[m] for m in METRICS}
        )  # fmt: skip
    return out


def x_pair_problem__mutmut_24(run: dict[str, Any], rule: str, method: str) -> dict[str, Any]:
    """Seed-paired matched differences for one problem, with the reason of every exclusion."""
    rules = {s["seed"]: s["rule"] for s in run["runs"].get(rule, [])}
    learned = {s["seed"]: s["budgets"] for s in run["runs"].get(method, []) if "BUDGETS" in s}
    out: dict[str, Any] = {"rows": [], "unpaired": 0, "no_alerts": 0, "no_match": 0}
    for seed, decision in rules.items():
        if seed not in learned:
            out["unpaired"] += 1
            continue
        found = match_cell(learned[seed], decision["test_alert_rate"])
        if found is None:
            out["no_alerts" if not decision["test_alert_rate"] > 0 else "no_match"] += 1
            continue
        key, ratio = found
        cell = learned[seed][key]
        out["rows"].append(
            {"budget": float(key), "ratio": ratio}
            | {m: cell[m] - decision[m] for m in METRICS}
        )  # fmt: skip
    return out


def x_pair_problem__mutmut_25(run: dict[str, Any], rule: str, method: str) -> dict[str, Any]:
    """Seed-paired matched differences for one problem, with the reason of every exclusion."""
    rules = {s["seed"]: s["rule"] for s in run["runs"].get(rule, [])}
    learned = {s["seed"]: s["budgets"] for s in run["runs"].get(method, []) if "budgets" not in s}
    out: dict[str, Any] = {"rows": [], "unpaired": 0, "no_alerts": 0, "no_match": 0}
    for seed, decision in rules.items():
        if seed not in learned:
            out["unpaired"] += 1
            continue
        found = match_cell(learned[seed], decision["test_alert_rate"])
        if found is None:
            out["no_alerts" if not decision["test_alert_rate"] > 0 else "no_match"] += 1
            continue
        key, ratio = found
        cell = learned[seed][key]
        out["rows"].append(
            {"budget": float(key), "ratio": ratio}
            | {m: cell[m] - decision[m] for m in METRICS}
        )  # fmt: skip
    return out


def x_pair_problem__mutmut_26(run: dict[str, Any], rule: str, method: str) -> dict[str, Any]:
    """Seed-paired matched differences for one problem, with the reason of every exclusion."""
    rules = {s["seed"]: s["rule"] for s in run["runs"].get(rule, [])}
    learned = {s["seed"]: s["budgets"] for s in run["runs"].get(method, []) if "budgets" in s}
    out: dict[str, Any] = None
    for seed, decision in rules.items():
        if seed not in learned:
            out["unpaired"] += 1
            continue
        found = match_cell(learned[seed], decision["test_alert_rate"])
        if found is None:
            out["no_alerts" if not decision["test_alert_rate"] > 0 else "no_match"] += 1
            continue
        key, ratio = found
        cell = learned[seed][key]
        out["rows"].append(
            {"budget": float(key), "ratio": ratio}
            | {m: cell[m] - decision[m] for m in METRICS}
        )  # fmt: skip
    return out


def x_pair_problem__mutmut_27(run: dict[str, Any], rule: str, method: str) -> dict[str, Any]:
    """Seed-paired matched differences for one problem, with the reason of every exclusion."""
    rules = {s["seed"]: s["rule"] for s in run["runs"].get(rule, [])}
    learned = {s["seed"]: s["budgets"] for s in run["runs"].get(method, []) if "budgets" in s}
    out: dict[str, Any] = {"XXrowsXX": [], "unpaired": 0, "no_alerts": 0, "no_match": 0}
    for seed, decision in rules.items():
        if seed not in learned:
            out["unpaired"] += 1
            continue
        found = match_cell(learned[seed], decision["test_alert_rate"])
        if found is None:
            out["no_alerts" if not decision["test_alert_rate"] > 0 else "no_match"] += 1
            continue
        key, ratio = found
        cell = learned[seed][key]
        out["rows"].append(
            {"budget": float(key), "ratio": ratio}
            | {m: cell[m] - decision[m] for m in METRICS}
        )  # fmt: skip
    return out


def x_pair_problem__mutmut_28(run: dict[str, Any], rule: str, method: str) -> dict[str, Any]:
    """Seed-paired matched differences for one problem, with the reason of every exclusion."""
    rules = {s["seed"]: s["rule"] for s in run["runs"].get(rule, [])}
    learned = {s["seed"]: s["budgets"] for s in run["runs"].get(method, []) if "budgets" in s}
    out: dict[str, Any] = {"ROWS": [], "unpaired": 0, "no_alerts": 0, "no_match": 0}
    for seed, decision in rules.items():
        if seed not in learned:
            out["unpaired"] += 1
            continue
        found = match_cell(learned[seed], decision["test_alert_rate"])
        if found is None:
            out["no_alerts" if not decision["test_alert_rate"] > 0 else "no_match"] += 1
            continue
        key, ratio = found
        cell = learned[seed][key]
        out["rows"].append(
            {"budget": float(key), "ratio": ratio}
            | {m: cell[m] - decision[m] for m in METRICS}
        )  # fmt: skip
    return out


def x_pair_problem__mutmut_29(run: dict[str, Any], rule: str, method: str) -> dict[str, Any]:
    """Seed-paired matched differences for one problem, with the reason of every exclusion."""
    rules = {s["seed"]: s["rule"] for s in run["runs"].get(rule, [])}
    learned = {s["seed"]: s["budgets"] for s in run["runs"].get(method, []) if "budgets" in s}
    out: dict[str, Any] = {"rows": [], "XXunpairedXX": 0, "no_alerts": 0, "no_match": 0}
    for seed, decision in rules.items():
        if seed not in learned:
            out["unpaired"] += 1
            continue
        found = match_cell(learned[seed], decision["test_alert_rate"])
        if found is None:
            out["no_alerts" if not decision["test_alert_rate"] > 0 else "no_match"] += 1
            continue
        key, ratio = found
        cell = learned[seed][key]
        out["rows"].append(
            {"budget": float(key), "ratio": ratio}
            | {m: cell[m] - decision[m] for m in METRICS}
        )  # fmt: skip
    return out


def x_pair_problem__mutmut_30(run: dict[str, Any], rule: str, method: str) -> dict[str, Any]:
    """Seed-paired matched differences for one problem, with the reason of every exclusion."""
    rules = {s["seed"]: s["rule"] for s in run["runs"].get(rule, [])}
    learned = {s["seed"]: s["budgets"] for s in run["runs"].get(method, []) if "budgets" in s}
    out: dict[str, Any] = {"rows": [], "UNPAIRED": 0, "no_alerts": 0, "no_match": 0}
    for seed, decision in rules.items():
        if seed not in learned:
            out["unpaired"] += 1
            continue
        found = match_cell(learned[seed], decision["test_alert_rate"])
        if found is None:
            out["no_alerts" if not decision["test_alert_rate"] > 0 else "no_match"] += 1
            continue
        key, ratio = found
        cell = learned[seed][key]
        out["rows"].append(
            {"budget": float(key), "ratio": ratio}
            | {m: cell[m] - decision[m] for m in METRICS}
        )  # fmt: skip
    return out


def x_pair_problem__mutmut_31(run: dict[str, Any], rule: str, method: str) -> dict[str, Any]:
    """Seed-paired matched differences for one problem, with the reason of every exclusion."""
    rules = {s["seed"]: s["rule"] for s in run["runs"].get(rule, [])}
    learned = {s["seed"]: s["budgets"] for s in run["runs"].get(method, []) if "budgets" in s}
    out: dict[str, Any] = {"rows": [], "unpaired": 1, "no_alerts": 0, "no_match": 0}
    for seed, decision in rules.items():
        if seed not in learned:
            out["unpaired"] += 1
            continue
        found = match_cell(learned[seed], decision["test_alert_rate"])
        if found is None:
            out["no_alerts" if not decision["test_alert_rate"] > 0 else "no_match"] += 1
            continue
        key, ratio = found
        cell = learned[seed][key]
        out["rows"].append(
            {"budget": float(key), "ratio": ratio}
            | {m: cell[m] - decision[m] for m in METRICS}
        )  # fmt: skip
    return out


def x_pair_problem__mutmut_32(run: dict[str, Any], rule: str, method: str) -> dict[str, Any]:
    """Seed-paired matched differences for one problem, with the reason of every exclusion."""
    rules = {s["seed"]: s["rule"] for s in run["runs"].get(rule, [])}
    learned = {s["seed"]: s["budgets"] for s in run["runs"].get(method, []) if "budgets" in s}
    out: dict[str, Any] = {"rows": [], "unpaired": 0, "XXno_alertsXX": 0, "no_match": 0}
    for seed, decision in rules.items():
        if seed not in learned:
            out["unpaired"] += 1
            continue
        found = match_cell(learned[seed], decision["test_alert_rate"])
        if found is None:
            out["no_alerts" if not decision["test_alert_rate"] > 0 else "no_match"] += 1
            continue
        key, ratio = found
        cell = learned[seed][key]
        out["rows"].append(
            {"budget": float(key), "ratio": ratio}
            | {m: cell[m] - decision[m] for m in METRICS}
        )  # fmt: skip
    return out


def x_pair_problem__mutmut_33(run: dict[str, Any], rule: str, method: str) -> dict[str, Any]:
    """Seed-paired matched differences for one problem, with the reason of every exclusion."""
    rules = {s["seed"]: s["rule"] for s in run["runs"].get(rule, [])}
    learned = {s["seed"]: s["budgets"] for s in run["runs"].get(method, []) if "budgets" in s}
    out: dict[str, Any] = {"rows": [], "unpaired": 0, "NO_ALERTS": 0, "no_match": 0}
    for seed, decision in rules.items():
        if seed not in learned:
            out["unpaired"] += 1
            continue
        found = match_cell(learned[seed], decision["test_alert_rate"])
        if found is None:
            out["no_alerts" if not decision["test_alert_rate"] > 0 else "no_match"] += 1
            continue
        key, ratio = found
        cell = learned[seed][key]
        out["rows"].append(
            {"budget": float(key), "ratio": ratio}
            | {m: cell[m] - decision[m] for m in METRICS}
        )  # fmt: skip
    return out


def x_pair_problem__mutmut_34(run: dict[str, Any], rule: str, method: str) -> dict[str, Any]:
    """Seed-paired matched differences for one problem, with the reason of every exclusion."""
    rules = {s["seed"]: s["rule"] for s in run["runs"].get(rule, [])}
    learned = {s["seed"]: s["budgets"] for s in run["runs"].get(method, []) if "budgets" in s}
    out: dict[str, Any] = {"rows": [], "unpaired": 0, "no_alerts": 1, "no_match": 0}
    for seed, decision in rules.items():
        if seed not in learned:
            out["unpaired"] += 1
            continue
        found = match_cell(learned[seed], decision["test_alert_rate"])
        if found is None:
            out["no_alerts" if not decision["test_alert_rate"] > 0 else "no_match"] += 1
            continue
        key, ratio = found
        cell = learned[seed][key]
        out["rows"].append(
            {"budget": float(key), "ratio": ratio}
            | {m: cell[m] - decision[m] for m in METRICS}
        )  # fmt: skip
    return out


def x_pair_problem__mutmut_35(run: dict[str, Any], rule: str, method: str) -> dict[str, Any]:
    """Seed-paired matched differences for one problem, with the reason of every exclusion."""
    rules = {s["seed"]: s["rule"] for s in run["runs"].get(rule, [])}
    learned = {s["seed"]: s["budgets"] for s in run["runs"].get(method, []) if "budgets" in s}
    out: dict[str, Any] = {"rows": [], "unpaired": 0, "no_alerts": 0, "XXno_matchXX": 0}
    for seed, decision in rules.items():
        if seed not in learned:
            out["unpaired"] += 1
            continue
        found = match_cell(learned[seed], decision["test_alert_rate"])
        if found is None:
            out["no_alerts" if not decision["test_alert_rate"] > 0 else "no_match"] += 1
            continue
        key, ratio = found
        cell = learned[seed][key]
        out["rows"].append(
            {"budget": float(key), "ratio": ratio}
            | {m: cell[m] - decision[m] for m in METRICS}
        )  # fmt: skip
    return out


def x_pair_problem__mutmut_36(run: dict[str, Any], rule: str, method: str) -> dict[str, Any]:
    """Seed-paired matched differences for one problem, with the reason of every exclusion."""
    rules = {s["seed"]: s["rule"] for s in run["runs"].get(rule, [])}
    learned = {s["seed"]: s["budgets"] for s in run["runs"].get(method, []) if "budgets" in s}
    out: dict[str, Any] = {"rows": [], "unpaired": 0, "no_alerts": 0, "NO_MATCH": 0}
    for seed, decision in rules.items():
        if seed not in learned:
            out["unpaired"] += 1
            continue
        found = match_cell(learned[seed], decision["test_alert_rate"])
        if found is None:
            out["no_alerts" if not decision["test_alert_rate"] > 0 else "no_match"] += 1
            continue
        key, ratio = found
        cell = learned[seed][key]
        out["rows"].append(
            {"budget": float(key), "ratio": ratio}
            | {m: cell[m] - decision[m] for m in METRICS}
        )  # fmt: skip
    return out


def x_pair_problem__mutmut_37(run: dict[str, Any], rule: str, method: str) -> dict[str, Any]:
    """Seed-paired matched differences for one problem, with the reason of every exclusion."""
    rules = {s["seed"]: s["rule"] for s in run["runs"].get(rule, [])}
    learned = {s["seed"]: s["budgets"] for s in run["runs"].get(method, []) if "budgets" in s}
    out: dict[str, Any] = {"rows": [], "unpaired": 0, "no_alerts": 0, "no_match": 1}
    for seed, decision in rules.items():
        if seed not in learned:
            out["unpaired"] += 1
            continue
        found = match_cell(learned[seed], decision["test_alert_rate"])
        if found is None:
            out["no_alerts" if not decision["test_alert_rate"] > 0 else "no_match"] += 1
            continue
        key, ratio = found
        cell = learned[seed][key]
        out["rows"].append(
            {"budget": float(key), "ratio": ratio}
            | {m: cell[m] - decision[m] for m in METRICS}
        )  # fmt: skip
    return out


def x_pair_problem__mutmut_38(run: dict[str, Any], rule: str, method: str) -> dict[str, Any]:
    """Seed-paired matched differences for one problem, with the reason of every exclusion."""
    rules = {s["seed"]: s["rule"] for s in run["runs"].get(rule, [])}
    learned = {s["seed"]: s["budgets"] for s in run["runs"].get(method, []) if "budgets" in s}
    out: dict[str, Any] = {"rows": [], "unpaired": 0, "no_alerts": 0, "no_match": 0}
    for seed, decision in rules.items():
        if seed in learned:
            out["unpaired"] += 1
            continue
        found = match_cell(learned[seed], decision["test_alert_rate"])
        if found is None:
            out["no_alerts" if not decision["test_alert_rate"] > 0 else "no_match"] += 1
            continue
        key, ratio = found
        cell = learned[seed][key]
        out["rows"].append(
            {"budget": float(key), "ratio": ratio}
            | {m: cell[m] - decision[m] for m in METRICS}
        )  # fmt: skip
    return out


def x_pair_problem__mutmut_39(run: dict[str, Any], rule: str, method: str) -> dict[str, Any]:
    """Seed-paired matched differences for one problem, with the reason of every exclusion."""
    rules = {s["seed"]: s["rule"] for s in run["runs"].get(rule, [])}
    learned = {s["seed"]: s["budgets"] for s in run["runs"].get(method, []) if "budgets" in s}
    out: dict[str, Any] = {"rows": [], "unpaired": 0, "no_alerts": 0, "no_match": 0}
    for seed, decision in rules.items():
        if seed not in learned:
            out["unpaired"] = 1
            continue
        found = match_cell(learned[seed], decision["test_alert_rate"])
        if found is None:
            out["no_alerts" if not decision["test_alert_rate"] > 0 else "no_match"] += 1
            continue
        key, ratio = found
        cell = learned[seed][key]
        out["rows"].append(
            {"budget": float(key), "ratio": ratio}
            | {m: cell[m] - decision[m] for m in METRICS}
        )  # fmt: skip
    return out


def x_pair_problem__mutmut_40(run: dict[str, Any], rule: str, method: str) -> dict[str, Any]:
    """Seed-paired matched differences for one problem, with the reason of every exclusion."""
    rules = {s["seed"]: s["rule"] for s in run["runs"].get(rule, [])}
    learned = {s["seed"]: s["budgets"] for s in run["runs"].get(method, []) if "budgets" in s}
    out: dict[str, Any] = {"rows": [], "unpaired": 0, "no_alerts": 0, "no_match": 0}
    for seed, decision in rules.items():
        if seed not in learned:
            out["unpaired"] -= 1
            continue
        found = match_cell(learned[seed], decision["test_alert_rate"])
        if found is None:
            out["no_alerts" if not decision["test_alert_rate"] > 0 else "no_match"] += 1
            continue
        key, ratio = found
        cell = learned[seed][key]
        out["rows"].append(
            {"budget": float(key), "ratio": ratio}
            | {m: cell[m] - decision[m] for m in METRICS}
        )  # fmt: skip
    return out


def x_pair_problem__mutmut_41(run: dict[str, Any], rule: str, method: str) -> dict[str, Any]:
    """Seed-paired matched differences for one problem, with the reason of every exclusion."""
    rules = {s["seed"]: s["rule"] for s in run["runs"].get(rule, [])}
    learned = {s["seed"]: s["budgets"] for s in run["runs"].get(method, []) if "budgets" in s}
    out: dict[str, Any] = {"rows": [], "unpaired": 0, "no_alerts": 0, "no_match": 0}
    for seed, decision in rules.items():
        if seed not in learned:
            out["XXunpairedXX"] += 1
            continue
        found = match_cell(learned[seed], decision["test_alert_rate"])
        if found is None:
            out["no_alerts" if not decision["test_alert_rate"] > 0 else "no_match"] += 1
            continue
        key, ratio = found
        cell = learned[seed][key]
        out["rows"].append(
            {"budget": float(key), "ratio": ratio}
            | {m: cell[m] - decision[m] for m in METRICS}
        )  # fmt: skip
    return out


def x_pair_problem__mutmut_42(run: dict[str, Any], rule: str, method: str) -> dict[str, Any]:
    """Seed-paired matched differences for one problem, with the reason of every exclusion."""
    rules = {s["seed"]: s["rule"] for s in run["runs"].get(rule, [])}
    learned = {s["seed"]: s["budgets"] for s in run["runs"].get(method, []) if "budgets" in s}
    out: dict[str, Any] = {"rows": [], "unpaired": 0, "no_alerts": 0, "no_match": 0}
    for seed, decision in rules.items():
        if seed not in learned:
            out["UNPAIRED"] += 1
            continue
        found = match_cell(learned[seed], decision["test_alert_rate"])
        if found is None:
            out["no_alerts" if not decision["test_alert_rate"] > 0 else "no_match"] += 1
            continue
        key, ratio = found
        cell = learned[seed][key]
        out["rows"].append(
            {"budget": float(key), "ratio": ratio}
            | {m: cell[m] - decision[m] for m in METRICS}
        )  # fmt: skip
    return out


def x_pair_problem__mutmut_43(run: dict[str, Any], rule: str, method: str) -> dict[str, Any]:
    """Seed-paired matched differences for one problem, with the reason of every exclusion."""
    rules = {s["seed"]: s["rule"] for s in run["runs"].get(rule, [])}
    learned = {s["seed"]: s["budgets"] for s in run["runs"].get(method, []) if "budgets" in s}
    out: dict[str, Any] = {"rows": [], "unpaired": 0, "no_alerts": 0, "no_match": 0}
    for seed, decision in rules.items():
        if seed not in learned:
            out["unpaired"] += 2
            continue
        found = match_cell(learned[seed], decision["test_alert_rate"])
        if found is None:
            out["no_alerts" if not decision["test_alert_rate"] > 0 else "no_match"] += 1
            continue
        key, ratio = found
        cell = learned[seed][key]
        out["rows"].append(
            {"budget": float(key), "ratio": ratio}
            | {m: cell[m] - decision[m] for m in METRICS}
        )  # fmt: skip
    return out


def x_pair_problem__mutmut_44(run: dict[str, Any], rule: str, method: str) -> dict[str, Any]:
    """Seed-paired matched differences for one problem, with the reason of every exclusion."""
    rules = {s["seed"]: s["rule"] for s in run["runs"].get(rule, [])}
    learned = {s["seed"]: s["budgets"] for s in run["runs"].get(method, []) if "budgets" in s}
    out: dict[str, Any] = {"rows": [], "unpaired": 0, "no_alerts": 0, "no_match": 0}
    for seed, decision in rules.items():
        if seed not in learned:
            out["unpaired"] += 1
            break
        found = match_cell(learned[seed], decision["test_alert_rate"])
        if found is None:
            out["no_alerts" if not decision["test_alert_rate"] > 0 else "no_match"] += 1
            continue
        key, ratio = found
        cell = learned[seed][key]
        out["rows"].append(
            {"budget": float(key), "ratio": ratio}
            | {m: cell[m] - decision[m] for m in METRICS}
        )  # fmt: skip
    return out


def x_pair_problem__mutmut_45(run: dict[str, Any], rule: str, method: str) -> dict[str, Any]:
    """Seed-paired matched differences for one problem, with the reason of every exclusion."""
    rules = {s["seed"]: s["rule"] for s in run["runs"].get(rule, [])}
    learned = {s["seed"]: s["budgets"] for s in run["runs"].get(method, []) if "budgets" in s}
    out: dict[str, Any] = {"rows": [], "unpaired": 0, "no_alerts": 0, "no_match": 0}
    for seed, decision in rules.items():
        if seed not in learned:
            out["unpaired"] += 1
            continue
        found = None
        if found is None:
            out["no_alerts" if not decision["test_alert_rate"] > 0 else "no_match"] += 1
            continue
        key, ratio = found
        cell = learned[seed][key]
        out["rows"].append(
            {"budget": float(key), "ratio": ratio}
            | {m: cell[m] - decision[m] for m in METRICS}
        )  # fmt: skip
    return out


def x_pair_problem__mutmut_46(run: dict[str, Any], rule: str, method: str) -> dict[str, Any]:
    """Seed-paired matched differences for one problem, with the reason of every exclusion."""
    rules = {s["seed"]: s["rule"] for s in run["runs"].get(rule, [])}
    learned = {s["seed"]: s["budgets"] for s in run["runs"].get(method, []) if "budgets" in s}
    out: dict[str, Any] = {"rows": [], "unpaired": 0, "no_alerts": 0, "no_match": 0}
    for seed, decision in rules.items():
        if seed not in learned:
            out["unpaired"] += 1
            continue
        found = match_cell(None, decision["test_alert_rate"])
        if found is None:
            out["no_alerts" if not decision["test_alert_rate"] > 0 else "no_match"] += 1
            continue
        key, ratio = found
        cell = learned[seed][key]
        out["rows"].append(
            {"budget": float(key), "ratio": ratio}
            | {m: cell[m] - decision[m] for m in METRICS}
        )  # fmt: skip
    return out


def x_pair_problem__mutmut_47(run: dict[str, Any], rule: str, method: str) -> dict[str, Any]:
    """Seed-paired matched differences for one problem, with the reason of every exclusion."""
    rules = {s["seed"]: s["rule"] for s in run["runs"].get(rule, [])}
    learned = {s["seed"]: s["budgets"] for s in run["runs"].get(method, []) if "budgets" in s}
    out: dict[str, Any] = {"rows": [], "unpaired": 0, "no_alerts": 0, "no_match": 0}
    for seed, decision in rules.items():
        if seed not in learned:
            out["unpaired"] += 1
            continue
        found = match_cell(learned[seed], None)
        if found is None:
            out["no_alerts" if not decision["test_alert_rate"] > 0 else "no_match"] += 1
            continue
        key, ratio = found
        cell = learned[seed][key]
        out["rows"].append(
            {"budget": float(key), "ratio": ratio}
            | {m: cell[m] - decision[m] for m in METRICS}
        )  # fmt: skip
    return out


def x_pair_problem__mutmut_48(run: dict[str, Any], rule: str, method: str) -> dict[str, Any]:
    """Seed-paired matched differences for one problem, with the reason of every exclusion."""
    rules = {s["seed"]: s["rule"] for s in run["runs"].get(rule, [])}
    learned = {s["seed"]: s["budgets"] for s in run["runs"].get(method, []) if "budgets" in s}
    out: dict[str, Any] = {"rows": [], "unpaired": 0, "no_alerts": 0, "no_match": 0}
    for seed, decision in rules.items():
        if seed not in learned:
            out["unpaired"] += 1
            continue
        found = match_cell(decision["test_alert_rate"])
        if found is None:
            out["no_alerts" if not decision["test_alert_rate"] > 0 else "no_match"] += 1
            continue
        key, ratio = found
        cell = learned[seed][key]
        out["rows"].append(
            {"budget": float(key), "ratio": ratio}
            | {m: cell[m] - decision[m] for m in METRICS}
        )  # fmt: skip
    return out


def x_pair_problem__mutmut_49(run: dict[str, Any], rule: str, method: str) -> dict[str, Any]:
    """Seed-paired matched differences for one problem, with the reason of every exclusion."""
    rules = {s["seed"]: s["rule"] for s in run["runs"].get(rule, [])}
    learned = {s["seed"]: s["budgets"] for s in run["runs"].get(method, []) if "budgets" in s}
    out: dict[str, Any] = {"rows": [], "unpaired": 0, "no_alerts": 0, "no_match": 0}
    for seed, decision in rules.items():
        if seed not in learned:
            out["unpaired"] += 1
            continue
        found = match_cell(learned[seed], )
        if found is None:
            out["no_alerts" if not decision["test_alert_rate"] > 0 else "no_match"] += 1
            continue
        key, ratio = found
        cell = learned[seed][key]
        out["rows"].append(
            {"budget": float(key), "ratio": ratio}
            | {m: cell[m] - decision[m] for m in METRICS}
        )  # fmt: skip
    return out


def x_pair_problem__mutmut_50(run: dict[str, Any], rule: str, method: str) -> dict[str, Any]:
    """Seed-paired matched differences for one problem, with the reason of every exclusion."""
    rules = {s["seed"]: s["rule"] for s in run["runs"].get(rule, [])}
    learned = {s["seed"]: s["budgets"] for s in run["runs"].get(method, []) if "budgets" in s}
    out: dict[str, Any] = {"rows": [], "unpaired": 0, "no_alerts": 0, "no_match": 0}
    for seed, decision in rules.items():
        if seed not in learned:
            out["unpaired"] += 1
            continue
        found = match_cell(learned[seed], decision["XXtest_alert_rateXX"])
        if found is None:
            out["no_alerts" if not decision["test_alert_rate"] > 0 else "no_match"] += 1
            continue
        key, ratio = found
        cell = learned[seed][key]
        out["rows"].append(
            {"budget": float(key), "ratio": ratio}
            | {m: cell[m] - decision[m] for m in METRICS}
        )  # fmt: skip
    return out


def x_pair_problem__mutmut_51(run: dict[str, Any], rule: str, method: str) -> dict[str, Any]:
    """Seed-paired matched differences for one problem, with the reason of every exclusion."""
    rules = {s["seed"]: s["rule"] for s in run["runs"].get(rule, [])}
    learned = {s["seed"]: s["budgets"] for s in run["runs"].get(method, []) if "budgets" in s}
    out: dict[str, Any] = {"rows": [], "unpaired": 0, "no_alerts": 0, "no_match": 0}
    for seed, decision in rules.items():
        if seed not in learned:
            out["unpaired"] += 1
            continue
        found = match_cell(learned[seed], decision["TEST_ALERT_RATE"])
        if found is None:
            out["no_alerts" if not decision["test_alert_rate"] > 0 else "no_match"] += 1
            continue
        key, ratio = found
        cell = learned[seed][key]
        out["rows"].append(
            {"budget": float(key), "ratio": ratio}
            | {m: cell[m] - decision[m] for m in METRICS}
        )  # fmt: skip
    return out


def x_pair_problem__mutmut_52(run: dict[str, Any], rule: str, method: str) -> dict[str, Any]:
    """Seed-paired matched differences for one problem, with the reason of every exclusion."""
    rules = {s["seed"]: s["rule"] for s in run["runs"].get(rule, [])}
    learned = {s["seed"]: s["budgets"] for s in run["runs"].get(method, []) if "budgets" in s}
    out: dict[str, Any] = {"rows": [], "unpaired": 0, "no_alerts": 0, "no_match": 0}
    for seed, decision in rules.items():
        if seed not in learned:
            out["unpaired"] += 1
            continue
        found = match_cell(learned[seed], decision["test_alert_rate"])
        if found is not None:
            out["no_alerts" if not decision["test_alert_rate"] > 0 else "no_match"] += 1
            continue
        key, ratio = found
        cell = learned[seed][key]
        out["rows"].append(
            {"budget": float(key), "ratio": ratio}
            | {m: cell[m] - decision[m] for m in METRICS}
        )  # fmt: skip
    return out


def x_pair_problem__mutmut_53(run: dict[str, Any], rule: str, method: str) -> dict[str, Any]:
    """Seed-paired matched differences for one problem, with the reason of every exclusion."""
    rules = {s["seed"]: s["rule"] for s in run["runs"].get(rule, [])}
    learned = {s["seed"]: s["budgets"] for s in run["runs"].get(method, []) if "budgets" in s}
    out: dict[str, Any] = {"rows": [], "unpaired": 0, "no_alerts": 0, "no_match": 0}
    for seed, decision in rules.items():
        if seed not in learned:
            out["unpaired"] += 1
            continue
        found = match_cell(learned[seed], decision["test_alert_rate"])
        if found is None:
            out["no_alerts" if not decision["test_alert_rate"] > 0 else "no_match"] = 1
            continue
        key, ratio = found
        cell = learned[seed][key]
        out["rows"].append(
            {"budget": float(key), "ratio": ratio}
            | {m: cell[m] - decision[m] for m in METRICS}
        )  # fmt: skip
    return out


def x_pair_problem__mutmut_54(run: dict[str, Any], rule: str, method: str) -> dict[str, Any]:
    """Seed-paired matched differences for one problem, with the reason of every exclusion."""
    rules = {s["seed"]: s["rule"] for s in run["runs"].get(rule, [])}
    learned = {s["seed"]: s["budgets"] for s in run["runs"].get(method, []) if "budgets" in s}
    out: dict[str, Any] = {"rows": [], "unpaired": 0, "no_alerts": 0, "no_match": 0}
    for seed, decision in rules.items():
        if seed not in learned:
            out["unpaired"] += 1
            continue
        found = match_cell(learned[seed], decision["test_alert_rate"])
        if found is None:
            out["no_alerts" if not decision["test_alert_rate"] > 0 else "no_match"] -= 1
            continue
        key, ratio = found
        cell = learned[seed][key]
        out["rows"].append(
            {"budget": float(key), "ratio": ratio}
            | {m: cell[m] - decision[m] for m in METRICS}
        )  # fmt: skip
    return out


def x_pair_problem__mutmut_55(run: dict[str, Any], rule: str, method: str) -> dict[str, Any]:
    """Seed-paired matched differences for one problem, with the reason of every exclusion."""
    rules = {s["seed"]: s["rule"] for s in run["runs"].get(rule, [])}
    learned = {s["seed"]: s["budgets"] for s in run["runs"].get(method, []) if "budgets" in s}
    out: dict[str, Any] = {"rows": [], "unpaired": 0, "no_alerts": 0, "no_match": 0}
    for seed, decision in rules.items():
        if seed not in learned:
            out["unpaired"] += 1
            continue
        found = match_cell(learned[seed], decision["test_alert_rate"])
        if found is None:
            out["no_alerts" if (not decision["test_alert_rate"] > 0) and False else "no_match"] += 1
            continue
        key, ratio = found
        cell = learned[seed][key]
        out["rows"].append(
            {"budget": float(key), "ratio": ratio}
            | {m: cell[m] - decision[m] for m in METRICS}
        )  # fmt: skip
    return out


def x_pair_problem__mutmut_56(run: dict[str, Any], rule: str, method: str) -> dict[str, Any]:
    """Seed-paired matched differences for one problem, with the reason of every exclusion."""
    rules = {s["seed"]: s["rule"] for s in run["runs"].get(rule, [])}
    learned = {s["seed"]: s["budgets"] for s in run["runs"].get(method, []) if "budgets" in s}
    out: dict[str, Any] = {"rows": [], "unpaired": 0, "no_alerts": 0, "no_match": 0}
    for seed, decision in rules.items():
        if seed not in learned:
            out["unpaired"] += 1
            continue
        found = match_cell(learned[seed], decision["test_alert_rate"])
        if found is None:
            out["no_alerts" if (not decision["test_alert_rate"] > 0) or True else "no_match"] += 1
            continue
        key, ratio = found
        cell = learned[seed][key]
        out["rows"].append(
            {"budget": float(key), "ratio": ratio}
            | {m: cell[m] - decision[m] for m in METRICS}
        )  # fmt: skip
    return out


def x_pair_problem__mutmut_57(run: dict[str, Any], rule: str, method: str) -> dict[str, Any]:
    """Seed-paired matched differences for one problem, with the reason of every exclusion."""
    rules = {s["seed"]: s["rule"] for s in run["runs"].get(rule, [])}
    learned = {s["seed"]: s["budgets"] for s in run["runs"].get(method, []) if "budgets" in s}
    out: dict[str, Any] = {"rows": [], "unpaired": 0, "no_alerts": 0, "no_match": 0}
    for seed, decision in rules.items():
        if seed not in learned:
            out["unpaired"] += 1
            continue
        found = match_cell(learned[seed], decision["test_alert_rate"])
        if found is None:
            out["XXno_alertsXX" if not decision["test_alert_rate"] > 0 else "no_match"] += 1
            continue
        key, ratio = found
        cell = learned[seed][key]
        out["rows"].append(
            {"budget": float(key), "ratio": ratio}
            | {m: cell[m] - decision[m] for m in METRICS}
        )  # fmt: skip
    return out


def x_pair_problem__mutmut_58(run: dict[str, Any], rule: str, method: str) -> dict[str, Any]:
    """Seed-paired matched differences for one problem, with the reason of every exclusion."""
    rules = {s["seed"]: s["rule"] for s in run["runs"].get(rule, [])}
    learned = {s["seed"]: s["budgets"] for s in run["runs"].get(method, []) if "budgets" in s}
    out: dict[str, Any] = {"rows": [], "unpaired": 0, "no_alerts": 0, "no_match": 0}
    for seed, decision in rules.items():
        if seed not in learned:
            out["unpaired"] += 1
            continue
        found = match_cell(learned[seed], decision["test_alert_rate"])
        if found is None:
            out["NO_ALERTS" if not decision["test_alert_rate"] > 0 else "no_match"] += 1
            continue
        key, ratio = found
        cell = learned[seed][key]
        out["rows"].append(
            {"budget": float(key), "ratio": ratio}
            | {m: cell[m] - decision[m] for m in METRICS}
        )  # fmt: skip
    return out


def x_pair_problem__mutmut_59(run: dict[str, Any], rule: str, method: str) -> dict[str, Any]:
    """Seed-paired matched differences for one problem, with the reason of every exclusion."""
    rules = {s["seed"]: s["rule"] for s in run["runs"].get(rule, [])}
    learned = {s["seed"]: s["budgets"] for s in run["runs"].get(method, []) if "budgets" in s}
    out: dict[str, Any] = {"rows": [], "unpaired": 0, "no_alerts": 0, "no_match": 0}
    for seed, decision in rules.items():
        if seed not in learned:
            out["unpaired"] += 1
            continue
        found = match_cell(learned[seed], decision["test_alert_rate"])
        if found is None:
            out["no_alerts" if decision["test_alert_rate"] > 0 else "no_match"] += 1
            continue
        key, ratio = found
        cell = learned[seed][key]
        out["rows"].append(
            {"budget": float(key), "ratio": ratio}
            | {m: cell[m] - decision[m] for m in METRICS}
        )  # fmt: skip
    return out


def x_pair_problem__mutmut_60(run: dict[str, Any], rule: str, method: str) -> dict[str, Any]:
    """Seed-paired matched differences for one problem, with the reason of every exclusion."""
    rules = {s["seed"]: s["rule"] for s in run["runs"].get(rule, [])}
    learned = {s["seed"]: s["budgets"] for s in run["runs"].get(method, []) if "budgets" in s}
    out: dict[str, Any] = {"rows": [], "unpaired": 0, "no_alerts": 0, "no_match": 0}
    for seed, decision in rules.items():
        if seed not in learned:
            out["unpaired"] += 1
            continue
        found = match_cell(learned[seed], decision["test_alert_rate"])
        if found is None:
            out["no_alerts" if not decision["XXtest_alert_rateXX"] > 0 else "no_match"] += 1
            continue
        key, ratio = found
        cell = learned[seed][key]
        out["rows"].append(
            {"budget": float(key), "ratio": ratio}
            | {m: cell[m] - decision[m] for m in METRICS}
        )  # fmt: skip
    return out


def x_pair_problem__mutmut_61(run: dict[str, Any], rule: str, method: str) -> dict[str, Any]:
    """Seed-paired matched differences for one problem, with the reason of every exclusion."""
    rules = {s["seed"]: s["rule"] for s in run["runs"].get(rule, [])}
    learned = {s["seed"]: s["budgets"] for s in run["runs"].get(method, []) if "budgets" in s}
    out: dict[str, Any] = {"rows": [], "unpaired": 0, "no_alerts": 0, "no_match": 0}
    for seed, decision in rules.items():
        if seed not in learned:
            out["unpaired"] += 1
            continue
        found = match_cell(learned[seed], decision["test_alert_rate"])
        if found is None:
            out["no_alerts" if not decision["TEST_ALERT_RATE"] > 0 else "no_match"] += 1
            continue
        key, ratio = found
        cell = learned[seed][key]
        out["rows"].append(
            {"budget": float(key), "ratio": ratio}
            | {m: cell[m] - decision[m] for m in METRICS}
        )  # fmt: skip
    return out


def x_pair_problem__mutmut_62(run: dict[str, Any], rule: str, method: str) -> dict[str, Any]:
    """Seed-paired matched differences for one problem, with the reason of every exclusion."""
    rules = {s["seed"]: s["rule"] for s in run["runs"].get(rule, [])}
    learned = {s["seed"]: s["budgets"] for s in run["runs"].get(method, []) if "budgets" in s}
    out: dict[str, Any] = {"rows": [], "unpaired": 0, "no_alerts": 0, "no_match": 0}
    for seed, decision in rules.items():
        if seed not in learned:
            out["unpaired"] += 1
            continue
        found = match_cell(learned[seed], decision["test_alert_rate"])
        if found is None:
            out["no_alerts" if not decision["test_alert_rate"] >= 0 else "no_match"] += 1
            continue
        key, ratio = found
        cell = learned[seed][key]
        out["rows"].append(
            {"budget": float(key), "ratio": ratio}
            | {m: cell[m] - decision[m] for m in METRICS}
        )  # fmt: skip
    return out


def x_pair_problem__mutmut_63(run: dict[str, Any], rule: str, method: str) -> dict[str, Any]:
    """Seed-paired matched differences for one problem, with the reason of every exclusion."""
    rules = {s["seed"]: s["rule"] for s in run["runs"].get(rule, [])}
    learned = {s["seed"]: s["budgets"] for s in run["runs"].get(method, []) if "budgets" in s}
    out: dict[str, Any] = {"rows": [], "unpaired": 0, "no_alerts": 0, "no_match": 0}
    for seed, decision in rules.items():
        if seed not in learned:
            out["unpaired"] += 1
            continue
        found = match_cell(learned[seed], decision["test_alert_rate"])
        if found is None:
            out["no_alerts" if not decision["test_alert_rate"] > 1 else "no_match"] += 1
            continue
        key, ratio = found
        cell = learned[seed][key]
        out["rows"].append(
            {"budget": float(key), "ratio": ratio}
            | {m: cell[m] - decision[m] for m in METRICS}
        )  # fmt: skip
    return out


def x_pair_problem__mutmut_64(run: dict[str, Any], rule: str, method: str) -> dict[str, Any]:
    """Seed-paired matched differences for one problem, with the reason of every exclusion."""
    rules = {s["seed"]: s["rule"] for s in run["runs"].get(rule, [])}
    learned = {s["seed"]: s["budgets"] for s in run["runs"].get(method, []) if "budgets" in s}
    out: dict[str, Any] = {"rows": [], "unpaired": 0, "no_alerts": 0, "no_match": 0}
    for seed, decision in rules.items():
        if seed not in learned:
            out["unpaired"] += 1
            continue
        found = match_cell(learned[seed], decision["test_alert_rate"])
        if found is None:
            out["no_alerts" if not decision["test_alert_rate"] > 0 else "XXno_matchXX"] += 1
            continue
        key, ratio = found
        cell = learned[seed][key]
        out["rows"].append(
            {"budget": float(key), "ratio": ratio}
            | {m: cell[m] - decision[m] for m in METRICS}
        )  # fmt: skip
    return out


def x_pair_problem__mutmut_65(run: dict[str, Any], rule: str, method: str) -> dict[str, Any]:
    """Seed-paired matched differences for one problem, with the reason of every exclusion."""
    rules = {s["seed"]: s["rule"] for s in run["runs"].get(rule, [])}
    learned = {s["seed"]: s["budgets"] for s in run["runs"].get(method, []) if "budgets" in s}
    out: dict[str, Any] = {"rows": [], "unpaired": 0, "no_alerts": 0, "no_match": 0}
    for seed, decision in rules.items():
        if seed not in learned:
            out["unpaired"] += 1
            continue
        found = match_cell(learned[seed], decision["test_alert_rate"])
        if found is None:
            out["no_alerts" if not decision["test_alert_rate"] > 0 else "NO_MATCH"] += 1
            continue
        key, ratio = found
        cell = learned[seed][key]
        out["rows"].append(
            {"budget": float(key), "ratio": ratio}
            | {m: cell[m] - decision[m] for m in METRICS}
        )  # fmt: skip
    return out


def x_pair_problem__mutmut_66(run: dict[str, Any], rule: str, method: str) -> dict[str, Any]:
    """Seed-paired matched differences for one problem, with the reason of every exclusion."""
    rules = {s["seed"]: s["rule"] for s in run["runs"].get(rule, [])}
    learned = {s["seed"]: s["budgets"] for s in run["runs"].get(method, []) if "budgets" in s}
    out: dict[str, Any] = {"rows": [], "unpaired": 0, "no_alerts": 0, "no_match": 0}
    for seed, decision in rules.items():
        if seed not in learned:
            out["unpaired"] += 1
            continue
        found = match_cell(learned[seed], decision["test_alert_rate"])
        if found is None:
            out["no_alerts" if not decision["test_alert_rate"] > 0 else "no_match"] += 2
            continue
        key, ratio = found
        cell = learned[seed][key]
        out["rows"].append(
            {"budget": float(key), "ratio": ratio}
            | {m: cell[m] - decision[m] for m in METRICS}
        )  # fmt: skip
    return out


def x_pair_problem__mutmut_67(run: dict[str, Any], rule: str, method: str) -> dict[str, Any]:
    """Seed-paired matched differences for one problem, with the reason of every exclusion."""
    rules = {s["seed"]: s["rule"] for s in run["runs"].get(rule, [])}
    learned = {s["seed"]: s["budgets"] for s in run["runs"].get(method, []) if "budgets" in s}
    out: dict[str, Any] = {"rows": [], "unpaired": 0, "no_alerts": 0, "no_match": 0}
    for seed, decision in rules.items():
        if seed not in learned:
            out["unpaired"] += 1
            continue
        found = match_cell(learned[seed], decision["test_alert_rate"])
        if found is None:
            out["no_alerts" if not decision["test_alert_rate"] > 0 else "no_match"] += 1
            break
        key, ratio = found
        cell = learned[seed][key]
        out["rows"].append(
            {"budget": float(key), "ratio": ratio}
            | {m: cell[m] - decision[m] for m in METRICS}
        )  # fmt: skip
    return out


def x_pair_problem__mutmut_68(run: dict[str, Any], rule: str, method: str) -> dict[str, Any]:
    """Seed-paired matched differences for one problem, with the reason of every exclusion."""
    rules = {s["seed"]: s["rule"] for s in run["runs"].get(rule, [])}
    learned = {s["seed"]: s["budgets"] for s in run["runs"].get(method, []) if "budgets" in s}
    out: dict[str, Any] = {"rows": [], "unpaired": 0, "no_alerts": 0, "no_match": 0}
    for seed, decision in rules.items():
        if seed not in learned:
            out["unpaired"] += 1
            continue
        found = match_cell(learned[seed], decision["test_alert_rate"])
        if found is None:
            out["no_alerts" if not decision["test_alert_rate"] > 0 else "no_match"] += 1
            continue
        key, ratio = None
        cell = learned[seed][key]
        out["rows"].append(
            {"budget": float(key), "ratio": ratio}
            | {m: cell[m] - decision[m] for m in METRICS}
        )  # fmt: skip
    return out


def x_pair_problem__mutmut_69(run: dict[str, Any], rule: str, method: str) -> dict[str, Any]:
    """Seed-paired matched differences for one problem, with the reason of every exclusion."""
    rules = {s["seed"]: s["rule"] for s in run["runs"].get(rule, [])}
    learned = {s["seed"]: s["budgets"] for s in run["runs"].get(method, []) if "budgets" in s}
    out: dict[str, Any] = {"rows": [], "unpaired": 0, "no_alerts": 0, "no_match": 0}
    for seed, decision in rules.items():
        if seed not in learned:
            out["unpaired"] += 1
            continue
        found = match_cell(learned[seed], decision["test_alert_rate"])
        if found is None:
            out["no_alerts" if not decision["test_alert_rate"] > 0 else "no_match"] += 1
            continue
        key, ratio = found
        cell = None
        out["rows"].append(
            {"budget": float(key), "ratio": ratio}
            | {m: cell[m] - decision[m] for m in METRICS}
        )  # fmt: skip
    return out


def x_pair_problem__mutmut_70(run: dict[str, Any], rule: str, method: str) -> dict[str, Any]:
    """Seed-paired matched differences for one problem, with the reason of every exclusion."""
    rules = {s["seed"]: s["rule"] for s in run["runs"].get(rule, [])}
    learned = {s["seed"]: s["budgets"] for s in run["runs"].get(method, []) if "budgets" in s}
    out: dict[str, Any] = {"rows": [], "unpaired": 0, "no_alerts": 0, "no_match": 0}
    for seed, decision in rules.items():
        if seed not in learned:
            out["unpaired"] += 1
            continue
        found = match_cell(learned[seed], decision["test_alert_rate"])
        if found is None:
            out["no_alerts" if not decision["test_alert_rate"] > 0 else "no_match"] += 1
            continue
        key, ratio = found
        cell = learned[seed][key]
        out["rows"].append(
            None
        )  # fmt: skip
    return out


def x_pair_problem__mutmut_71(run: dict[str, Any], rule: str, method: str) -> dict[str, Any]:
    """Seed-paired matched differences for one problem, with the reason of every exclusion."""
    rules = {s["seed"]: s["rule"] for s in run["runs"].get(rule, [])}
    learned = {s["seed"]: s["budgets"] for s in run["runs"].get(method, []) if "budgets" in s}
    out: dict[str, Any] = {"rows": [], "unpaired": 0, "no_alerts": 0, "no_match": 0}
    for seed, decision in rules.items():
        if seed not in learned:
            out["unpaired"] += 1
            continue
        found = match_cell(learned[seed], decision["test_alert_rate"])
        if found is None:
            out["no_alerts" if not decision["test_alert_rate"] > 0 else "no_match"] += 1
            continue
        key, ratio = found
        cell = learned[seed][key]
        out["XXrowsXX"].append(
            {"budget": float(key), "ratio": ratio}
            | {m: cell[m] - decision[m] for m in METRICS}
        )  # fmt: skip
    return out


def x_pair_problem__mutmut_72(run: dict[str, Any], rule: str, method: str) -> dict[str, Any]:
    """Seed-paired matched differences for one problem, with the reason of every exclusion."""
    rules = {s["seed"]: s["rule"] for s in run["runs"].get(rule, [])}
    learned = {s["seed"]: s["budgets"] for s in run["runs"].get(method, []) if "budgets" in s}
    out: dict[str, Any] = {"rows": [], "unpaired": 0, "no_alerts": 0, "no_match": 0}
    for seed, decision in rules.items():
        if seed not in learned:
            out["unpaired"] += 1
            continue
        found = match_cell(learned[seed], decision["test_alert_rate"])
        if found is None:
            out["no_alerts" if not decision["test_alert_rate"] > 0 else "no_match"] += 1
            continue
        key, ratio = found
        cell = learned[seed][key]
        out["ROWS"].append(
            {"budget": float(key), "ratio": ratio}
            | {m: cell[m] - decision[m] for m in METRICS}
        )  # fmt: skip
    return out


def x_pair_problem__mutmut_73(run: dict[str, Any], rule: str, method: str) -> dict[str, Any]:
    """Seed-paired matched differences for one problem, with the reason of every exclusion."""
    rules = {s["seed"]: s["rule"] for s in run["runs"].get(rule, [])}
    learned = {s["seed"]: s["budgets"] for s in run["runs"].get(method, []) if "budgets" in s}
    out: dict[str, Any] = {"rows": [], "unpaired": 0, "no_alerts": 0, "no_match": 0}
    for seed, decision in rules.items():
        if seed not in learned:
            out["unpaired"] += 1
            continue
        found = match_cell(learned[seed], decision["test_alert_rate"])
        if found is None:
            out["no_alerts" if not decision["test_alert_rate"] > 0 else "no_match"] += 1
            continue
        key, ratio = found
        cell = learned[seed][key]
        out["rows"].append(
            {"budget": float(key), "ratio": ratio} & {m: cell[m] - decision[m] for m in METRICS}
        )  # fmt: skip
    return out


def x_pair_problem__mutmut_74(run: dict[str, Any], rule: str, method: str) -> dict[str, Any]:
    """Seed-paired matched differences for one problem, with the reason of every exclusion."""
    rules = {s["seed"]: s["rule"] for s in run["runs"].get(rule, [])}
    learned = {s["seed"]: s["budgets"] for s in run["runs"].get(method, []) if "budgets" in s}
    out: dict[str, Any] = {"rows": [], "unpaired": 0, "no_alerts": 0, "no_match": 0}
    for seed, decision in rules.items():
        if seed not in learned:
            out["unpaired"] += 1
            continue
        found = match_cell(learned[seed], decision["test_alert_rate"])
        if found is None:
            out["no_alerts" if not decision["test_alert_rate"] > 0 else "no_match"] += 1
            continue
        key, ratio = found
        cell = learned[seed][key]
        out["rows"].append(
            {"XXbudgetXX": float(key), "ratio": ratio}
            | {m: cell[m] - decision[m] for m in METRICS}
        )  # fmt: skip
    return out


def x_pair_problem__mutmut_75(run: dict[str, Any], rule: str, method: str) -> dict[str, Any]:
    """Seed-paired matched differences for one problem, with the reason of every exclusion."""
    rules = {s["seed"]: s["rule"] for s in run["runs"].get(rule, [])}
    learned = {s["seed"]: s["budgets"] for s in run["runs"].get(method, []) if "budgets" in s}
    out: dict[str, Any] = {"rows": [], "unpaired": 0, "no_alerts": 0, "no_match": 0}
    for seed, decision in rules.items():
        if seed not in learned:
            out["unpaired"] += 1
            continue
        found = match_cell(learned[seed], decision["test_alert_rate"])
        if found is None:
            out["no_alerts" if not decision["test_alert_rate"] > 0 else "no_match"] += 1
            continue
        key, ratio = found
        cell = learned[seed][key]
        out["rows"].append(
            {"BUDGET": float(key), "ratio": ratio}
            | {m: cell[m] - decision[m] for m in METRICS}
        )  # fmt: skip
    return out


def x_pair_problem__mutmut_76(run: dict[str, Any], rule: str, method: str) -> dict[str, Any]:
    """Seed-paired matched differences for one problem, with the reason of every exclusion."""
    rules = {s["seed"]: s["rule"] for s in run["runs"].get(rule, [])}
    learned = {s["seed"]: s["budgets"] for s in run["runs"].get(method, []) if "budgets" in s}
    out: dict[str, Any] = {"rows": [], "unpaired": 0, "no_alerts": 0, "no_match": 0}
    for seed, decision in rules.items():
        if seed not in learned:
            out["unpaired"] += 1
            continue
        found = match_cell(learned[seed], decision["test_alert_rate"])
        if found is None:
            out["no_alerts" if not decision["test_alert_rate"] > 0 else "no_match"] += 1
            continue
        key, ratio = found
        cell = learned[seed][key]
        out["rows"].append(
            {"budget": float(None), "ratio": ratio}
            | {m: cell[m] - decision[m] for m in METRICS}
        )  # fmt: skip
    return out


def x_pair_problem__mutmut_77(run: dict[str, Any], rule: str, method: str) -> dict[str, Any]:
    """Seed-paired matched differences for one problem, with the reason of every exclusion."""
    rules = {s["seed"]: s["rule"] for s in run["runs"].get(rule, [])}
    learned = {s["seed"]: s["budgets"] for s in run["runs"].get(method, []) if "budgets" in s}
    out: dict[str, Any] = {"rows": [], "unpaired": 0, "no_alerts": 0, "no_match": 0}
    for seed, decision in rules.items():
        if seed not in learned:
            out["unpaired"] += 1
            continue
        found = match_cell(learned[seed], decision["test_alert_rate"])
        if found is None:
            out["no_alerts" if not decision["test_alert_rate"] > 0 else "no_match"] += 1
            continue
        key, ratio = found
        cell = learned[seed][key]
        out["rows"].append(
            {"budget": float(key), "XXratioXX": ratio}
            | {m: cell[m] - decision[m] for m in METRICS}
        )  # fmt: skip
    return out


def x_pair_problem__mutmut_78(run: dict[str, Any], rule: str, method: str) -> dict[str, Any]:
    """Seed-paired matched differences for one problem, with the reason of every exclusion."""
    rules = {s["seed"]: s["rule"] for s in run["runs"].get(rule, [])}
    learned = {s["seed"]: s["budgets"] for s in run["runs"].get(method, []) if "budgets" in s}
    out: dict[str, Any] = {"rows": [], "unpaired": 0, "no_alerts": 0, "no_match": 0}
    for seed, decision in rules.items():
        if seed not in learned:
            out["unpaired"] += 1
            continue
        found = match_cell(learned[seed], decision["test_alert_rate"])
        if found is None:
            out["no_alerts" if not decision["test_alert_rate"] > 0 else "no_match"] += 1
            continue
        key, ratio = found
        cell = learned[seed][key]
        out["rows"].append(
            {"budget": float(key), "RATIO": ratio}
            | {m: cell[m] - decision[m] for m in METRICS}
        )  # fmt: skip
    return out


def x_pair_problem__mutmut_79(run: dict[str, Any], rule: str, method: str) -> dict[str, Any]:
    """Seed-paired matched differences for one problem, with the reason of every exclusion."""
    rules = {s["seed"]: s["rule"] for s in run["runs"].get(rule, [])}
    learned = {s["seed"]: s["budgets"] for s in run["runs"].get(method, []) if "budgets" in s}
    out: dict[str, Any] = {"rows": [], "unpaired": 0, "no_alerts": 0, "no_match": 0}
    for seed, decision in rules.items():
        if seed not in learned:
            out["unpaired"] += 1
            continue
        found = match_cell(learned[seed], decision["test_alert_rate"])
        if found is None:
            out["no_alerts" if not decision["test_alert_rate"] > 0 else "no_match"] += 1
            continue
        key, ratio = found
        cell = learned[seed][key]
        out["rows"].append(
            {"budget": float(key), "ratio": ratio}
            | {m: cell[m] + decision[m] for m in METRICS}
        )  # fmt: skip
    return out

mutants_x_pair_problem__mutmut['_mutmut_orig'] = x_pair_problem__mutmut_orig # type: ignore # mutmut generated
mutants_x_pair_problem__mutmut['x_pair_problem__mutmut_1'] = x_pair_problem__mutmut_1 # type: ignore # mutmut generated
mutants_x_pair_problem__mutmut['x_pair_problem__mutmut_2'] = x_pair_problem__mutmut_2 # type: ignore # mutmut generated
mutants_x_pair_problem__mutmut['x_pair_problem__mutmut_3'] = x_pair_problem__mutmut_3 # type: ignore # mutmut generated
mutants_x_pair_problem__mutmut['x_pair_problem__mutmut_4'] = x_pair_problem__mutmut_4 # type: ignore # mutmut generated
mutants_x_pair_problem__mutmut['x_pair_problem__mutmut_5'] = x_pair_problem__mutmut_5 # type: ignore # mutmut generated
mutants_x_pair_problem__mutmut['x_pair_problem__mutmut_6'] = x_pair_problem__mutmut_6 # type: ignore # mutmut generated
mutants_x_pair_problem__mutmut['x_pair_problem__mutmut_7'] = x_pair_problem__mutmut_7 # type: ignore # mutmut generated
mutants_x_pair_problem__mutmut['x_pair_problem__mutmut_8'] = x_pair_problem__mutmut_8 # type: ignore # mutmut generated
mutants_x_pair_problem__mutmut['x_pair_problem__mutmut_9'] = x_pair_problem__mutmut_9 # type: ignore # mutmut generated
mutants_x_pair_problem__mutmut['x_pair_problem__mutmut_10'] = x_pair_problem__mutmut_10 # type: ignore # mutmut generated
mutants_x_pair_problem__mutmut['x_pair_problem__mutmut_11'] = x_pair_problem__mutmut_11 # type: ignore # mutmut generated
mutants_x_pair_problem__mutmut['x_pair_problem__mutmut_12'] = x_pair_problem__mutmut_12 # type: ignore # mutmut generated
mutants_x_pair_problem__mutmut['x_pair_problem__mutmut_13'] = x_pair_problem__mutmut_13 # type: ignore # mutmut generated
mutants_x_pair_problem__mutmut['x_pair_problem__mutmut_14'] = x_pair_problem__mutmut_14 # type: ignore # mutmut generated
mutants_x_pair_problem__mutmut['x_pair_problem__mutmut_15'] = x_pair_problem__mutmut_15 # type: ignore # mutmut generated
mutants_x_pair_problem__mutmut['x_pair_problem__mutmut_16'] = x_pair_problem__mutmut_16 # type: ignore # mutmut generated
mutants_x_pair_problem__mutmut['x_pair_problem__mutmut_17'] = x_pair_problem__mutmut_17 # type: ignore # mutmut generated
mutants_x_pair_problem__mutmut['x_pair_problem__mutmut_18'] = x_pair_problem__mutmut_18 # type: ignore # mutmut generated
mutants_x_pair_problem__mutmut['x_pair_problem__mutmut_19'] = x_pair_problem__mutmut_19 # type: ignore # mutmut generated
mutants_x_pair_problem__mutmut['x_pair_problem__mutmut_20'] = x_pair_problem__mutmut_20 # type: ignore # mutmut generated
mutants_x_pair_problem__mutmut['x_pair_problem__mutmut_21'] = x_pair_problem__mutmut_21 # type: ignore # mutmut generated
mutants_x_pair_problem__mutmut['x_pair_problem__mutmut_22'] = x_pair_problem__mutmut_22 # type: ignore # mutmut generated
mutants_x_pair_problem__mutmut['x_pair_problem__mutmut_23'] = x_pair_problem__mutmut_23 # type: ignore # mutmut generated
mutants_x_pair_problem__mutmut['x_pair_problem__mutmut_24'] = x_pair_problem__mutmut_24 # type: ignore # mutmut generated
mutants_x_pair_problem__mutmut['x_pair_problem__mutmut_25'] = x_pair_problem__mutmut_25 # type: ignore # mutmut generated
mutants_x_pair_problem__mutmut['x_pair_problem__mutmut_26'] = x_pair_problem__mutmut_26 # type: ignore # mutmut generated
mutants_x_pair_problem__mutmut['x_pair_problem__mutmut_27'] = x_pair_problem__mutmut_27 # type: ignore # mutmut generated
mutants_x_pair_problem__mutmut['x_pair_problem__mutmut_28'] = x_pair_problem__mutmut_28 # type: ignore # mutmut generated
mutants_x_pair_problem__mutmut['x_pair_problem__mutmut_29'] = x_pair_problem__mutmut_29 # type: ignore # mutmut generated
mutants_x_pair_problem__mutmut['x_pair_problem__mutmut_30'] = x_pair_problem__mutmut_30 # type: ignore # mutmut generated
mutants_x_pair_problem__mutmut['x_pair_problem__mutmut_31'] = x_pair_problem__mutmut_31 # type: ignore # mutmut generated
mutants_x_pair_problem__mutmut['x_pair_problem__mutmut_32'] = x_pair_problem__mutmut_32 # type: ignore # mutmut generated
mutants_x_pair_problem__mutmut['x_pair_problem__mutmut_33'] = x_pair_problem__mutmut_33 # type: ignore # mutmut generated
mutants_x_pair_problem__mutmut['x_pair_problem__mutmut_34'] = x_pair_problem__mutmut_34 # type: ignore # mutmut generated
mutants_x_pair_problem__mutmut['x_pair_problem__mutmut_35'] = x_pair_problem__mutmut_35 # type: ignore # mutmut generated
mutants_x_pair_problem__mutmut['x_pair_problem__mutmut_36'] = x_pair_problem__mutmut_36 # type: ignore # mutmut generated
mutants_x_pair_problem__mutmut['x_pair_problem__mutmut_37'] = x_pair_problem__mutmut_37 # type: ignore # mutmut generated
mutants_x_pair_problem__mutmut['x_pair_problem__mutmut_38'] = x_pair_problem__mutmut_38 # type: ignore # mutmut generated
mutants_x_pair_problem__mutmut['x_pair_problem__mutmut_39'] = x_pair_problem__mutmut_39 # type: ignore # mutmut generated
mutants_x_pair_problem__mutmut['x_pair_problem__mutmut_40'] = x_pair_problem__mutmut_40 # type: ignore # mutmut generated
mutants_x_pair_problem__mutmut['x_pair_problem__mutmut_41'] = x_pair_problem__mutmut_41 # type: ignore # mutmut generated
mutants_x_pair_problem__mutmut['x_pair_problem__mutmut_42'] = x_pair_problem__mutmut_42 # type: ignore # mutmut generated
mutants_x_pair_problem__mutmut['x_pair_problem__mutmut_43'] = x_pair_problem__mutmut_43 # type: ignore # mutmut generated
mutants_x_pair_problem__mutmut['x_pair_problem__mutmut_44'] = x_pair_problem__mutmut_44 # type: ignore # mutmut generated
mutants_x_pair_problem__mutmut['x_pair_problem__mutmut_45'] = x_pair_problem__mutmut_45 # type: ignore # mutmut generated
mutants_x_pair_problem__mutmut['x_pair_problem__mutmut_46'] = x_pair_problem__mutmut_46 # type: ignore # mutmut generated
mutants_x_pair_problem__mutmut['x_pair_problem__mutmut_47'] = x_pair_problem__mutmut_47 # type: ignore # mutmut generated
mutants_x_pair_problem__mutmut['x_pair_problem__mutmut_48'] = x_pair_problem__mutmut_48 # type: ignore # mutmut generated
mutants_x_pair_problem__mutmut['x_pair_problem__mutmut_49'] = x_pair_problem__mutmut_49 # type: ignore # mutmut generated
mutants_x_pair_problem__mutmut['x_pair_problem__mutmut_50'] = x_pair_problem__mutmut_50 # type: ignore # mutmut generated
mutants_x_pair_problem__mutmut['x_pair_problem__mutmut_51'] = x_pair_problem__mutmut_51 # type: ignore # mutmut generated
mutants_x_pair_problem__mutmut['x_pair_problem__mutmut_52'] = x_pair_problem__mutmut_52 # type: ignore # mutmut generated
mutants_x_pair_problem__mutmut['x_pair_problem__mutmut_53'] = x_pair_problem__mutmut_53 # type: ignore # mutmut generated
mutants_x_pair_problem__mutmut['x_pair_problem__mutmut_54'] = x_pair_problem__mutmut_54 # type: ignore # mutmut generated
mutants_x_pair_problem__mutmut['x_pair_problem__mutmut_55'] = x_pair_problem__mutmut_55 # type: ignore # mutmut generated
mutants_x_pair_problem__mutmut['x_pair_problem__mutmut_56'] = x_pair_problem__mutmut_56 # type: ignore # mutmut generated
mutants_x_pair_problem__mutmut['x_pair_problem__mutmut_57'] = x_pair_problem__mutmut_57 # type: ignore # mutmut generated
mutants_x_pair_problem__mutmut['x_pair_problem__mutmut_58'] = x_pair_problem__mutmut_58 # type: ignore # mutmut generated
mutants_x_pair_problem__mutmut['x_pair_problem__mutmut_59'] = x_pair_problem__mutmut_59 # type: ignore # mutmut generated
mutants_x_pair_problem__mutmut['x_pair_problem__mutmut_60'] = x_pair_problem__mutmut_60 # type: ignore # mutmut generated
mutants_x_pair_problem__mutmut['x_pair_problem__mutmut_61'] = x_pair_problem__mutmut_61 # type: ignore # mutmut generated
mutants_x_pair_problem__mutmut['x_pair_problem__mutmut_62'] = x_pair_problem__mutmut_62 # type: ignore # mutmut generated
mutants_x_pair_problem__mutmut['x_pair_problem__mutmut_63'] = x_pair_problem__mutmut_63 # type: ignore # mutmut generated
mutants_x_pair_problem__mutmut['x_pair_problem__mutmut_64'] = x_pair_problem__mutmut_64 # type: ignore # mutmut generated
mutants_x_pair_problem__mutmut['x_pair_problem__mutmut_65'] = x_pair_problem__mutmut_65 # type: ignore # mutmut generated
mutants_x_pair_problem__mutmut['x_pair_problem__mutmut_66'] = x_pair_problem__mutmut_66 # type: ignore # mutmut generated
mutants_x_pair_problem__mutmut['x_pair_problem__mutmut_67'] = x_pair_problem__mutmut_67 # type: ignore # mutmut generated
mutants_x_pair_problem__mutmut['x_pair_problem__mutmut_68'] = x_pair_problem__mutmut_68 # type: ignore # mutmut generated
mutants_x_pair_problem__mutmut['x_pair_problem__mutmut_69'] = x_pair_problem__mutmut_69 # type: ignore # mutmut generated
mutants_x_pair_problem__mutmut['x_pair_problem__mutmut_70'] = x_pair_problem__mutmut_70 # type: ignore # mutmut generated
mutants_x_pair_problem__mutmut['x_pair_problem__mutmut_71'] = x_pair_problem__mutmut_71 # type: ignore # mutmut generated
mutants_x_pair_problem__mutmut['x_pair_problem__mutmut_72'] = x_pair_problem__mutmut_72 # type: ignore # mutmut generated
mutants_x_pair_problem__mutmut['x_pair_problem__mutmut_73'] = x_pair_problem__mutmut_73 # type: ignore # mutmut generated
mutants_x_pair_problem__mutmut['x_pair_problem__mutmut_74'] = x_pair_problem__mutmut_74 # type: ignore # mutmut generated
mutants_x_pair_problem__mutmut['x_pair_problem__mutmut_75'] = x_pair_problem__mutmut_75 # type: ignore # mutmut generated
mutants_x_pair_problem__mutmut['x_pair_problem__mutmut_76'] = x_pair_problem__mutmut_76 # type: ignore # mutmut generated
mutants_x_pair_problem__mutmut['x_pair_problem__mutmut_77'] = x_pair_problem__mutmut_77 # type: ignore # mutmut generated
mutants_x_pair_problem__mutmut['x_pair_problem__mutmut_78'] = x_pair_problem__mutmut_78 # type: ignore # mutmut generated
mutants_x_pair_problem__mutmut['x_pair_problem__mutmut_79'] = x_pair_problem__mutmut_79 # type: ignore # mutmut generated
mutants_x_compare__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_compare__mutmut)
def compare(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_orig(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_1(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = None
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_2(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = None
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_3(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = None
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_4(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = None
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_5(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"XXunpairedXX": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_6(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"UNPAIRED": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_7(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 1, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_8(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "XXno_alertsXX": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_9(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "NO_ALERTS": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_10(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 1, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_11(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "XXno_matchXX": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_12(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "NO_MATCH": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_13(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 1, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_14(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "XXfew_seedsXX": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_15(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "FEW_SEEDS": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_16(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 1}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_17(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = None
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_18(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 1
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_19(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = None
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_20(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(None, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_21(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, None, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_22(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, None)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_23(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_24(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_25(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, )
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_26(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("XXunpairedXX", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_27(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("UNPAIRED", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_28(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "XXno_alertsXX", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_29(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "NO_ALERTS", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_30(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "XXno_matchXX"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_31(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "NO_MATCH"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_32(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] = paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_33(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] -= paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_34(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = None
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_35(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["XXrowsXX"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_36(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["ROWS"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_37(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) <= MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_38(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] = len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_39(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] -= len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_40(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["XXfew_seedsXX"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_41(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["FEW_SEEDS"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_42(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            break
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_43(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(None)
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_44(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["XXproblemXX"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_45(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["PROBLEM"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_46(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(None)
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_47(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(None))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_48(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["XXproblemXX"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_49(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["PROBLEM"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_50(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs = len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_51(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs -= len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_52(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios = [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_53(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios -= [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_54(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["XXratioXX"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_55(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["RATIO"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_56(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(None)
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_57(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(None))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_58(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean(None)))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_59(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = None  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_60(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "XXruleXX": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_61(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "RULE": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_62(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "XXmethodXX": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_63(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "METHOD": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_64(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "XXproblemsXX": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_65(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "PROBLEMS": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_66(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "XXseed_runsXX": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_67(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "SEED_RUNS": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_68(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "XXexcluded_seed_runsXX": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_69(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "EXCLUDED_SEED_RUNS": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_70(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "XXmedian_alert_ratioXX": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_71(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "MEDIAN_ALERT_RATIO": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_72(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if (ratios) and False else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_73(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if (ratios) or True else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_74(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(None) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_75(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(None)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_76(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "XXalert_ratio_quartilesXX": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_77(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "ALERT_RATIO_QUARTILES": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_78(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if (ratios) and False
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_79(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if (ratios) or True
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_80(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(None) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_81(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(None, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_82(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, None)]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_83(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile([0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_84(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, )]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_85(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [1.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_86(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 1.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_87(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = None
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_88(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(None)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_89(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = None
    return entry


def x_compare__mutmut_90(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(None, clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_91(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), None, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_92(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=None, draws=draws)
    return entry


def x_compare__mutmut_93(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, draws=None)
    return entry


def x_compare__mutmut_94(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_95(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_96(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, draws=draws)
    return entry


def x_compare__mutmut_97(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=True, )
    return entry


def x_compare__mutmut_98(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(None), clusters, by_cluster=True, draws=draws)
    return entry


def x_compare__mutmut_99(runs: list[dict[str, Any]], rule: str, method: str, draws: int = DRAWS) -> dict:
    problems, sources = [], []
    diffs: dict[str, list[float]] = {m: [] for m in METRICS}
    ratios: list[float] = []
    excluded = {"unpaired": 0, "no_alerts": 0, "no_match": 0, "few_seeds": 0}
    seed_runs = 0
    for run in runs:
        paired = pair_problem(run, rule, method)
        for reason in ("unpaired", "no_alerts", "no_match"):
            excluded[reason] += paired[reason]
        rows = paired["rows"]
        if len(rows) < MIN_SEEDS:
            excluded["few_seeds"] += len(rows)
            continue
        problems.append(run["problem"])
        sources.append(source_id(run["problem"]))
        seed_runs += len(rows)
        ratios += [r["ratio"] for r in rows]
        for m in METRICS:
            diffs[m].append(float(np.mean([r[m] for r in rows])))
    entry: dict[str, Any] = {
        "rule": rule, "method": method, "problems": len(problems), "seed_runs": seed_runs,
        "excluded_seed_runs": excluded,
        "median_alert_ratio": float(np.median(ratios)) if ratios else None,
        "alert_ratio_quartiles": [float(q) for q in np.quantile(ratios, [0.25, 0.75])]
        if ratios
        else None,
    }  # fmt: skip
    if problems:
        clusters = np.array(sources)
        for m in METRICS:
            entry[m] = bootstrap(np.array(diffs[m]), clusters, by_cluster=False, draws=draws)
    return entry

mutants_x_compare__mutmut['_mutmut_orig'] = x_compare__mutmut_orig # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_1'] = x_compare__mutmut_1 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_2'] = x_compare__mutmut_2 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_3'] = x_compare__mutmut_3 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_4'] = x_compare__mutmut_4 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_5'] = x_compare__mutmut_5 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_6'] = x_compare__mutmut_6 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_7'] = x_compare__mutmut_7 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_8'] = x_compare__mutmut_8 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_9'] = x_compare__mutmut_9 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_10'] = x_compare__mutmut_10 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_11'] = x_compare__mutmut_11 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_12'] = x_compare__mutmut_12 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_13'] = x_compare__mutmut_13 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_14'] = x_compare__mutmut_14 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_15'] = x_compare__mutmut_15 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_16'] = x_compare__mutmut_16 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_17'] = x_compare__mutmut_17 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_18'] = x_compare__mutmut_18 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_19'] = x_compare__mutmut_19 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_20'] = x_compare__mutmut_20 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_21'] = x_compare__mutmut_21 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_22'] = x_compare__mutmut_22 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_23'] = x_compare__mutmut_23 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_24'] = x_compare__mutmut_24 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_25'] = x_compare__mutmut_25 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_26'] = x_compare__mutmut_26 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_27'] = x_compare__mutmut_27 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_28'] = x_compare__mutmut_28 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_29'] = x_compare__mutmut_29 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_30'] = x_compare__mutmut_30 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_31'] = x_compare__mutmut_31 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_32'] = x_compare__mutmut_32 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_33'] = x_compare__mutmut_33 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_34'] = x_compare__mutmut_34 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_35'] = x_compare__mutmut_35 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_36'] = x_compare__mutmut_36 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_37'] = x_compare__mutmut_37 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_38'] = x_compare__mutmut_38 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_39'] = x_compare__mutmut_39 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_40'] = x_compare__mutmut_40 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_41'] = x_compare__mutmut_41 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_42'] = x_compare__mutmut_42 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_43'] = x_compare__mutmut_43 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_44'] = x_compare__mutmut_44 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_45'] = x_compare__mutmut_45 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_46'] = x_compare__mutmut_46 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_47'] = x_compare__mutmut_47 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_48'] = x_compare__mutmut_48 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_49'] = x_compare__mutmut_49 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_50'] = x_compare__mutmut_50 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_51'] = x_compare__mutmut_51 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_52'] = x_compare__mutmut_52 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_53'] = x_compare__mutmut_53 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_54'] = x_compare__mutmut_54 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_55'] = x_compare__mutmut_55 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_56'] = x_compare__mutmut_56 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_57'] = x_compare__mutmut_57 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_58'] = x_compare__mutmut_58 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_59'] = x_compare__mutmut_59 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_60'] = x_compare__mutmut_60 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_61'] = x_compare__mutmut_61 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_62'] = x_compare__mutmut_62 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_63'] = x_compare__mutmut_63 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_64'] = x_compare__mutmut_64 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_65'] = x_compare__mutmut_65 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_66'] = x_compare__mutmut_66 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_67'] = x_compare__mutmut_67 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_68'] = x_compare__mutmut_68 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_69'] = x_compare__mutmut_69 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_70'] = x_compare__mutmut_70 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_71'] = x_compare__mutmut_71 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_72'] = x_compare__mutmut_72 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_73'] = x_compare__mutmut_73 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_74'] = x_compare__mutmut_74 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_75'] = x_compare__mutmut_75 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_76'] = x_compare__mutmut_76 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_77'] = x_compare__mutmut_77 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_78'] = x_compare__mutmut_78 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_79'] = x_compare__mutmut_79 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_80'] = x_compare__mutmut_80 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_81'] = x_compare__mutmut_81 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_82'] = x_compare__mutmut_82 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_83'] = x_compare__mutmut_83 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_84'] = x_compare__mutmut_84 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_85'] = x_compare__mutmut_85 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_86'] = x_compare__mutmut_86 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_87'] = x_compare__mutmut_87 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_88'] = x_compare__mutmut_88 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_89'] = x_compare__mutmut_89 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_90'] = x_compare__mutmut_90 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_91'] = x_compare__mutmut_91 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_92'] = x_compare__mutmut_92 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_93'] = x_compare__mutmut_93 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_94'] = x_compare__mutmut_94 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_95'] = x_compare__mutmut_95 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_96'] = x_compare__mutmut_96 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_97'] = x_compare__mutmut_97 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_98'] = x_compare__mutmut_98 # type: ignore # mutmut generated
mutants_x_compare__mutmut['x_compare__mutmut_99'] = x_compare__mutmut_99 # type: ignore # mutmut generated
mutants_x_analyse__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_analyse__mutmut)
def analyse(runs: list[dict[str, Any]], draws: int = DRAWS) -> dict[str, Any]:
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if m not in RULES and seeds}
    )
    entries = [compare(runs, rule, m, draws) for rule in RULES for m in methods]
    for metric in METRICS:
        scored = [e for e in entries if metric in e]
        adjusted = holm([e[metric]["p_two_sided"] for e in scored]) if scored else []
        for e, value in zip(scored, adjusted, strict=True):
            e[metric]["holm_p"] = value
    return {
        "tolerance": TOLERANCE, "min_seeds": MIN_SEEDS, "draws": draws,
        "problems_read": len(runs), "comparisons": entries,
    }  # fmt: skip


def x_analyse__mutmut_orig(runs: list[dict[str, Any]], draws: int = DRAWS) -> dict[str, Any]:
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if m not in RULES and seeds}
    )
    entries = [compare(runs, rule, m, draws) for rule in RULES for m in methods]
    for metric in METRICS:
        scored = [e for e in entries if metric in e]
        adjusted = holm([e[metric]["p_two_sided"] for e in scored]) if scored else []
        for e, value in zip(scored, adjusted, strict=True):
            e[metric]["holm_p"] = value
    return {
        "tolerance": TOLERANCE, "min_seeds": MIN_SEEDS, "draws": draws,
        "problems_read": len(runs), "comparisons": entries,
    }  # fmt: skip


def x_analyse__mutmut_1(runs: list[dict[str, Any]], draws: int = DRAWS) -> dict[str, Any]:
    methods = None
    entries = [compare(runs, rule, m, draws) for rule in RULES for m in methods]
    for metric in METRICS:
        scored = [e for e in entries if metric in e]
        adjusted = holm([e[metric]["p_two_sided"] for e in scored]) if scored else []
        for e, value in zip(scored, adjusted, strict=True):
            e[metric]["holm_p"] = value
    return {
        "tolerance": TOLERANCE, "min_seeds": MIN_SEEDS, "draws": draws,
        "problems_read": len(runs), "comparisons": entries,
    }  # fmt: skip


def x_analyse__mutmut_2(runs: list[dict[str, Any]], draws: int = DRAWS) -> dict[str, Any]:
    methods = sorted(
        None
    )
    entries = [compare(runs, rule, m, draws) for rule in RULES for m in methods]
    for metric in METRICS:
        scored = [e for e in entries if metric in e]
        adjusted = holm([e[metric]["p_two_sided"] for e in scored]) if scored else []
        for e, value in zip(scored, adjusted, strict=True):
            e[metric]["holm_p"] = value
    return {
        "tolerance": TOLERANCE, "min_seeds": MIN_SEEDS, "draws": draws,
        "problems_read": len(runs), "comparisons": entries,
    }  # fmt: skip


def x_analyse__mutmut_3(runs: list[dict[str, Any]], draws: int = DRAWS) -> dict[str, Any]:
    methods = sorted(
        {m for r in runs for m, seeds in r["XXrunsXX"].items() if m not in RULES and seeds}
    )
    entries = [compare(runs, rule, m, draws) for rule in RULES for m in methods]
    for metric in METRICS:
        scored = [e for e in entries if metric in e]
        adjusted = holm([e[metric]["p_two_sided"] for e in scored]) if scored else []
        for e, value in zip(scored, adjusted, strict=True):
            e[metric]["holm_p"] = value
    return {
        "tolerance": TOLERANCE, "min_seeds": MIN_SEEDS, "draws": draws,
        "problems_read": len(runs), "comparisons": entries,
    }  # fmt: skip


def x_analyse__mutmut_4(runs: list[dict[str, Any]], draws: int = DRAWS) -> dict[str, Any]:
    methods = sorted(
        {m for r in runs for m, seeds in r["RUNS"].items() if m not in RULES and seeds}
    )
    entries = [compare(runs, rule, m, draws) for rule in RULES for m in methods]
    for metric in METRICS:
        scored = [e for e in entries if metric in e]
        adjusted = holm([e[metric]["p_two_sided"] for e in scored]) if scored else []
        for e, value in zip(scored, adjusted, strict=True):
            e[metric]["holm_p"] = value
    return {
        "tolerance": TOLERANCE, "min_seeds": MIN_SEEDS, "draws": draws,
        "problems_read": len(runs), "comparisons": entries,
    }  # fmt: skip


def x_analyse__mutmut_5(runs: list[dict[str, Any]], draws: int = DRAWS) -> dict[str, Any]:
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if m not in RULES or seeds}
    )
    entries = [compare(runs, rule, m, draws) for rule in RULES for m in methods]
    for metric in METRICS:
        scored = [e for e in entries if metric in e]
        adjusted = holm([e[metric]["p_two_sided"] for e in scored]) if scored else []
        for e, value in zip(scored, adjusted, strict=True):
            e[metric]["holm_p"] = value
    return {
        "tolerance": TOLERANCE, "min_seeds": MIN_SEEDS, "draws": draws,
        "problems_read": len(runs), "comparisons": entries,
    }  # fmt: skip


def x_analyse__mutmut_6(runs: list[dict[str, Any]], draws: int = DRAWS) -> dict[str, Any]:
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if m in RULES and seeds}
    )
    entries = [compare(runs, rule, m, draws) for rule in RULES for m in methods]
    for metric in METRICS:
        scored = [e for e in entries if metric in e]
        adjusted = holm([e[metric]["p_two_sided"] for e in scored]) if scored else []
        for e, value in zip(scored, adjusted, strict=True):
            e[metric]["holm_p"] = value
    return {
        "tolerance": TOLERANCE, "min_seeds": MIN_SEEDS, "draws": draws,
        "problems_read": len(runs), "comparisons": entries,
    }  # fmt: skip


def x_analyse__mutmut_7(runs: list[dict[str, Any]], draws: int = DRAWS) -> dict[str, Any]:
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if m not in RULES and seeds}
    )
    entries = None
    for metric in METRICS:
        scored = [e for e in entries if metric in e]
        adjusted = holm([e[metric]["p_two_sided"] for e in scored]) if scored else []
        for e, value in zip(scored, adjusted, strict=True):
            e[metric]["holm_p"] = value
    return {
        "tolerance": TOLERANCE, "min_seeds": MIN_SEEDS, "draws": draws,
        "problems_read": len(runs), "comparisons": entries,
    }  # fmt: skip


def x_analyse__mutmut_8(runs: list[dict[str, Any]], draws: int = DRAWS) -> dict[str, Any]:
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if m not in RULES and seeds}
    )
    entries = [compare(None, rule, m, draws) for rule in RULES for m in methods]
    for metric in METRICS:
        scored = [e for e in entries if metric in e]
        adjusted = holm([e[metric]["p_two_sided"] for e in scored]) if scored else []
        for e, value in zip(scored, adjusted, strict=True):
            e[metric]["holm_p"] = value
    return {
        "tolerance": TOLERANCE, "min_seeds": MIN_SEEDS, "draws": draws,
        "problems_read": len(runs), "comparisons": entries,
    }  # fmt: skip


def x_analyse__mutmut_9(runs: list[dict[str, Any]], draws: int = DRAWS) -> dict[str, Any]:
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if m not in RULES and seeds}
    )
    entries = [compare(runs, None, m, draws) for rule in RULES for m in methods]
    for metric in METRICS:
        scored = [e for e in entries if metric in e]
        adjusted = holm([e[metric]["p_two_sided"] for e in scored]) if scored else []
        for e, value in zip(scored, adjusted, strict=True):
            e[metric]["holm_p"] = value
    return {
        "tolerance": TOLERANCE, "min_seeds": MIN_SEEDS, "draws": draws,
        "problems_read": len(runs), "comparisons": entries,
    }  # fmt: skip


def x_analyse__mutmut_10(runs: list[dict[str, Any]], draws: int = DRAWS) -> dict[str, Any]:
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if m not in RULES and seeds}
    )
    entries = [compare(runs, rule, None, draws) for rule in RULES for m in methods]
    for metric in METRICS:
        scored = [e for e in entries if metric in e]
        adjusted = holm([e[metric]["p_two_sided"] for e in scored]) if scored else []
        for e, value in zip(scored, adjusted, strict=True):
            e[metric]["holm_p"] = value
    return {
        "tolerance": TOLERANCE, "min_seeds": MIN_SEEDS, "draws": draws,
        "problems_read": len(runs), "comparisons": entries,
    }  # fmt: skip


def x_analyse__mutmut_11(runs: list[dict[str, Any]], draws: int = DRAWS) -> dict[str, Any]:
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if m not in RULES and seeds}
    )
    entries = [compare(runs, rule, m, None) for rule in RULES for m in methods]
    for metric in METRICS:
        scored = [e for e in entries if metric in e]
        adjusted = holm([e[metric]["p_two_sided"] for e in scored]) if scored else []
        for e, value in zip(scored, adjusted, strict=True):
            e[metric]["holm_p"] = value
    return {
        "tolerance": TOLERANCE, "min_seeds": MIN_SEEDS, "draws": draws,
        "problems_read": len(runs), "comparisons": entries,
    }  # fmt: skip


def x_analyse__mutmut_12(runs: list[dict[str, Any]], draws: int = DRAWS) -> dict[str, Any]:
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if m not in RULES and seeds}
    )
    entries = [compare(rule, m, draws) for rule in RULES for m in methods]
    for metric in METRICS:
        scored = [e for e in entries if metric in e]
        adjusted = holm([e[metric]["p_two_sided"] for e in scored]) if scored else []
        for e, value in zip(scored, adjusted, strict=True):
            e[metric]["holm_p"] = value
    return {
        "tolerance": TOLERANCE, "min_seeds": MIN_SEEDS, "draws": draws,
        "problems_read": len(runs), "comparisons": entries,
    }  # fmt: skip


def x_analyse__mutmut_13(runs: list[dict[str, Any]], draws: int = DRAWS) -> dict[str, Any]:
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if m not in RULES and seeds}
    )
    entries = [compare(runs, m, draws) for rule in RULES for m in methods]
    for metric in METRICS:
        scored = [e for e in entries if metric in e]
        adjusted = holm([e[metric]["p_two_sided"] for e in scored]) if scored else []
        for e, value in zip(scored, adjusted, strict=True):
            e[metric]["holm_p"] = value
    return {
        "tolerance": TOLERANCE, "min_seeds": MIN_SEEDS, "draws": draws,
        "problems_read": len(runs), "comparisons": entries,
    }  # fmt: skip


def x_analyse__mutmut_14(runs: list[dict[str, Any]], draws: int = DRAWS) -> dict[str, Any]:
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if m not in RULES and seeds}
    )
    entries = [compare(runs, rule, draws) for rule in RULES for m in methods]
    for metric in METRICS:
        scored = [e for e in entries if metric in e]
        adjusted = holm([e[metric]["p_two_sided"] for e in scored]) if scored else []
        for e, value in zip(scored, adjusted, strict=True):
            e[metric]["holm_p"] = value
    return {
        "tolerance": TOLERANCE, "min_seeds": MIN_SEEDS, "draws": draws,
        "problems_read": len(runs), "comparisons": entries,
    }  # fmt: skip


def x_analyse__mutmut_15(runs: list[dict[str, Any]], draws: int = DRAWS) -> dict[str, Any]:
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if m not in RULES and seeds}
    )
    entries = [compare(runs, rule, m, ) for rule in RULES for m in methods]
    for metric in METRICS:
        scored = [e for e in entries if metric in e]
        adjusted = holm([e[metric]["p_two_sided"] for e in scored]) if scored else []
        for e, value in zip(scored, adjusted, strict=True):
            e[metric]["holm_p"] = value
    return {
        "tolerance": TOLERANCE, "min_seeds": MIN_SEEDS, "draws": draws,
        "problems_read": len(runs), "comparisons": entries,
    }  # fmt: skip


def x_analyse__mutmut_16(runs: list[dict[str, Any]], draws: int = DRAWS) -> dict[str, Any]:
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if m not in RULES and seeds}
    )
    entries = [compare(runs, rule, m, draws) for rule in RULES for m in methods]
    for metric in METRICS:
        scored = None
        adjusted = holm([e[metric]["p_two_sided"] for e in scored]) if scored else []
        for e, value in zip(scored, adjusted, strict=True):
            e[metric]["holm_p"] = value
    return {
        "tolerance": TOLERANCE, "min_seeds": MIN_SEEDS, "draws": draws,
        "problems_read": len(runs), "comparisons": entries,
    }  # fmt: skip


def x_analyse__mutmut_17(runs: list[dict[str, Any]], draws: int = DRAWS) -> dict[str, Any]:
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if m not in RULES and seeds}
    )
    entries = [compare(runs, rule, m, draws) for rule in RULES for m in methods]
    for metric in METRICS:
        scored = [e for e in entries if metric not in e]
        adjusted = holm([e[metric]["p_two_sided"] for e in scored]) if scored else []
        for e, value in zip(scored, adjusted, strict=True):
            e[metric]["holm_p"] = value
    return {
        "tolerance": TOLERANCE, "min_seeds": MIN_SEEDS, "draws": draws,
        "problems_read": len(runs), "comparisons": entries,
    }  # fmt: skip


def x_analyse__mutmut_18(runs: list[dict[str, Any]], draws: int = DRAWS) -> dict[str, Any]:
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if m not in RULES and seeds}
    )
    entries = [compare(runs, rule, m, draws) for rule in RULES for m in methods]
    for metric in METRICS:
        scored = [e for e in entries if metric in e]
        adjusted = None
        for e, value in zip(scored, adjusted, strict=True):
            e[metric]["holm_p"] = value
    return {
        "tolerance": TOLERANCE, "min_seeds": MIN_SEEDS, "draws": draws,
        "problems_read": len(runs), "comparisons": entries,
    }  # fmt: skip


def x_analyse__mutmut_19(runs: list[dict[str, Any]], draws: int = DRAWS) -> dict[str, Any]:
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if m not in RULES and seeds}
    )
    entries = [compare(runs, rule, m, draws) for rule in RULES for m in methods]
    for metric in METRICS:
        scored = [e for e in entries if metric in e]
        adjusted = holm([e[metric]["p_two_sided"] for e in scored]) if (scored) and False else []
        for e, value in zip(scored, adjusted, strict=True):
            e[metric]["holm_p"] = value
    return {
        "tolerance": TOLERANCE, "min_seeds": MIN_SEEDS, "draws": draws,
        "problems_read": len(runs), "comparisons": entries,
    }  # fmt: skip


def x_analyse__mutmut_20(runs: list[dict[str, Any]], draws: int = DRAWS) -> dict[str, Any]:
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if m not in RULES and seeds}
    )
    entries = [compare(runs, rule, m, draws) for rule in RULES for m in methods]
    for metric in METRICS:
        scored = [e for e in entries if metric in e]
        adjusted = holm([e[metric]["p_two_sided"] for e in scored]) if (scored) or True else []
        for e, value in zip(scored, adjusted, strict=True):
            e[metric]["holm_p"] = value
    return {
        "tolerance": TOLERANCE, "min_seeds": MIN_SEEDS, "draws": draws,
        "problems_read": len(runs), "comparisons": entries,
    }  # fmt: skip


def x_analyse__mutmut_21(runs: list[dict[str, Any]], draws: int = DRAWS) -> dict[str, Any]:
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if m not in RULES and seeds}
    )
    entries = [compare(runs, rule, m, draws) for rule in RULES for m in methods]
    for metric in METRICS:
        scored = [e for e in entries if metric in e]
        adjusted = holm(None) if scored else []
        for e, value in zip(scored, adjusted, strict=True):
            e[metric]["holm_p"] = value
    return {
        "tolerance": TOLERANCE, "min_seeds": MIN_SEEDS, "draws": draws,
        "problems_read": len(runs), "comparisons": entries,
    }  # fmt: skip


def x_analyse__mutmut_22(runs: list[dict[str, Any]], draws: int = DRAWS) -> dict[str, Any]:
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if m not in RULES and seeds}
    )
    entries = [compare(runs, rule, m, draws) for rule in RULES for m in methods]
    for metric in METRICS:
        scored = [e for e in entries if metric in e]
        adjusted = holm([e[metric]["XXp_two_sidedXX"] for e in scored]) if scored else []
        for e, value in zip(scored, adjusted, strict=True):
            e[metric]["holm_p"] = value
    return {
        "tolerance": TOLERANCE, "min_seeds": MIN_SEEDS, "draws": draws,
        "problems_read": len(runs), "comparisons": entries,
    }  # fmt: skip


def x_analyse__mutmut_23(runs: list[dict[str, Any]], draws: int = DRAWS) -> dict[str, Any]:
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if m not in RULES and seeds}
    )
    entries = [compare(runs, rule, m, draws) for rule in RULES for m in methods]
    for metric in METRICS:
        scored = [e for e in entries if metric in e]
        adjusted = holm([e[metric]["P_TWO_SIDED"] for e in scored]) if scored else []
        for e, value in zip(scored, adjusted, strict=True):
            e[metric]["holm_p"] = value
    return {
        "tolerance": TOLERANCE, "min_seeds": MIN_SEEDS, "draws": draws,
        "problems_read": len(runs), "comparisons": entries,
    }  # fmt: skip


def x_analyse__mutmut_24(runs: list[dict[str, Any]], draws: int = DRAWS) -> dict[str, Any]:
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if m not in RULES and seeds}
    )
    entries = [compare(runs, rule, m, draws) for rule in RULES for m in methods]
    for metric in METRICS:
        scored = [e for e in entries if metric in e]
        adjusted = holm([e[metric]["p_two_sided"] for e in scored]) if scored else []
        for e, value in zip(None, adjusted, strict=True):
            e[metric]["holm_p"] = value
    return {
        "tolerance": TOLERANCE, "min_seeds": MIN_SEEDS, "draws": draws,
        "problems_read": len(runs), "comparisons": entries,
    }  # fmt: skip


def x_analyse__mutmut_25(runs: list[dict[str, Any]], draws: int = DRAWS) -> dict[str, Any]:
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if m not in RULES and seeds}
    )
    entries = [compare(runs, rule, m, draws) for rule in RULES for m in methods]
    for metric in METRICS:
        scored = [e for e in entries if metric in e]
        adjusted = holm([e[metric]["p_two_sided"] for e in scored]) if scored else []
        for e, value in zip(scored, None, strict=True):
            e[metric]["holm_p"] = value
    return {
        "tolerance": TOLERANCE, "min_seeds": MIN_SEEDS, "draws": draws,
        "problems_read": len(runs), "comparisons": entries,
    }  # fmt: skip


def x_analyse__mutmut_26(runs: list[dict[str, Any]], draws: int = DRAWS) -> dict[str, Any]:
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if m not in RULES and seeds}
    )
    entries = [compare(runs, rule, m, draws) for rule in RULES for m in methods]
    for metric in METRICS:
        scored = [e for e in entries if metric in e]
        adjusted = holm([e[metric]["p_two_sided"] for e in scored]) if scored else []
        for e, value in zip(scored, adjusted, strict=None):
            e[metric]["holm_p"] = value
    return {
        "tolerance": TOLERANCE, "min_seeds": MIN_SEEDS, "draws": draws,
        "problems_read": len(runs), "comparisons": entries,
    }  # fmt: skip


def x_analyse__mutmut_27(runs: list[dict[str, Any]], draws: int = DRAWS) -> dict[str, Any]:
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if m not in RULES and seeds}
    )
    entries = [compare(runs, rule, m, draws) for rule in RULES for m in methods]
    for metric in METRICS:
        scored = [e for e in entries if metric in e]
        adjusted = holm([e[metric]["p_two_sided"] for e in scored]) if scored else []
        for e, value in zip(adjusted, strict=True):
            e[metric]["holm_p"] = value
    return {
        "tolerance": TOLERANCE, "min_seeds": MIN_SEEDS, "draws": draws,
        "problems_read": len(runs), "comparisons": entries,
    }  # fmt: skip


def x_analyse__mutmut_28(runs: list[dict[str, Any]], draws: int = DRAWS) -> dict[str, Any]:
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if m not in RULES and seeds}
    )
    entries = [compare(runs, rule, m, draws) for rule in RULES for m in methods]
    for metric in METRICS:
        scored = [e for e in entries if metric in e]
        adjusted = holm([e[metric]["p_two_sided"] for e in scored]) if scored else []
        for e, value in zip(scored, strict=True):
            e[metric]["holm_p"] = value
    return {
        "tolerance": TOLERANCE, "min_seeds": MIN_SEEDS, "draws": draws,
        "problems_read": len(runs), "comparisons": entries,
    }  # fmt: skip


def x_analyse__mutmut_29(runs: list[dict[str, Any]], draws: int = DRAWS) -> dict[str, Any]:
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if m not in RULES and seeds}
    )
    entries = [compare(runs, rule, m, draws) for rule in RULES for m in methods]
    for metric in METRICS:
        scored = [e for e in entries if metric in e]
        adjusted = holm([e[metric]["p_two_sided"] for e in scored]) if scored else []
        for e, value in zip(scored, adjusted, ):
            e[metric]["holm_p"] = value
    return {
        "tolerance": TOLERANCE, "min_seeds": MIN_SEEDS, "draws": draws,
        "problems_read": len(runs), "comparisons": entries,
    }  # fmt: skip


def x_analyse__mutmut_30(runs: list[dict[str, Any]], draws: int = DRAWS) -> dict[str, Any]:
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if m not in RULES and seeds}
    )
    entries = [compare(runs, rule, m, draws) for rule in RULES for m in methods]
    for metric in METRICS:
        scored = [e for e in entries if metric in e]
        adjusted = holm([e[metric]["p_two_sided"] for e in scored]) if scored else []
        for e, value in zip(scored, adjusted, strict=False):
            e[metric]["holm_p"] = value
    return {
        "tolerance": TOLERANCE, "min_seeds": MIN_SEEDS, "draws": draws,
        "problems_read": len(runs), "comparisons": entries,
    }  # fmt: skip


def x_analyse__mutmut_31(runs: list[dict[str, Any]], draws: int = DRAWS) -> dict[str, Any]:
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if m not in RULES and seeds}
    )
    entries = [compare(runs, rule, m, draws) for rule in RULES for m in methods]
    for metric in METRICS:
        scored = [e for e in entries if metric in e]
        adjusted = holm([e[metric]["p_two_sided"] for e in scored]) if scored else []
        for e, value in zip(scored, adjusted, strict=True):
            e[metric]["holm_p"] = None
    return {
        "tolerance": TOLERANCE, "min_seeds": MIN_SEEDS, "draws": draws,
        "problems_read": len(runs), "comparisons": entries,
    }  # fmt: skip


def x_analyse__mutmut_32(runs: list[dict[str, Any]], draws: int = DRAWS) -> dict[str, Any]:
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if m not in RULES and seeds}
    )
    entries = [compare(runs, rule, m, draws) for rule in RULES for m in methods]
    for metric in METRICS:
        scored = [e for e in entries if metric in e]
        adjusted = holm([e[metric]["p_two_sided"] for e in scored]) if scored else []
        for e, value in zip(scored, adjusted, strict=True):
            e[metric]["XXholm_pXX"] = value
    return {
        "tolerance": TOLERANCE, "min_seeds": MIN_SEEDS, "draws": draws,
        "problems_read": len(runs), "comparisons": entries,
    }  # fmt: skip


def x_analyse__mutmut_33(runs: list[dict[str, Any]], draws: int = DRAWS) -> dict[str, Any]:
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if m not in RULES and seeds}
    )
    entries = [compare(runs, rule, m, draws) for rule in RULES for m in methods]
    for metric in METRICS:
        scored = [e for e in entries if metric in e]
        adjusted = holm([e[metric]["p_two_sided"] for e in scored]) if scored else []
        for e, value in zip(scored, adjusted, strict=True):
            e[metric]["HOLM_P"] = value
    return {
        "tolerance": TOLERANCE, "min_seeds": MIN_SEEDS, "draws": draws,
        "problems_read": len(runs), "comparisons": entries,
    }  # fmt: skip


def x_analyse__mutmut_34(runs: list[dict[str, Any]], draws: int = DRAWS) -> dict[str, Any]:
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if m not in RULES and seeds}
    )
    entries = [compare(runs, rule, m, draws) for rule in RULES for m in methods]
    for metric in METRICS:
        scored = [e for e in entries if metric in e]
        adjusted = holm([e[metric]["p_two_sided"] for e in scored]) if scored else []
        for e, value in zip(scored, adjusted, strict=True):
            e[metric]["holm_p"] = value
    return {
        "XXtoleranceXX": TOLERANCE, "min_seeds": MIN_SEEDS, "draws": draws,
        "problems_read": len(runs), "comparisons": entries,
    }  # fmt: skip


def x_analyse__mutmut_35(runs: list[dict[str, Any]], draws: int = DRAWS) -> dict[str, Any]:
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if m not in RULES and seeds}
    )
    entries = [compare(runs, rule, m, draws) for rule in RULES for m in methods]
    for metric in METRICS:
        scored = [e for e in entries if metric in e]
        adjusted = holm([e[metric]["p_two_sided"] for e in scored]) if scored else []
        for e, value in zip(scored, adjusted, strict=True):
            e[metric]["holm_p"] = value
    return {
        "TOLERANCE": TOLERANCE, "min_seeds": MIN_SEEDS, "draws": draws,
        "problems_read": len(runs), "comparisons": entries,
    }  # fmt: skip


def x_analyse__mutmut_36(runs: list[dict[str, Any]], draws: int = DRAWS) -> dict[str, Any]:
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if m not in RULES and seeds}
    )
    entries = [compare(runs, rule, m, draws) for rule in RULES for m in methods]
    for metric in METRICS:
        scored = [e for e in entries if metric in e]
        adjusted = holm([e[metric]["p_two_sided"] for e in scored]) if scored else []
        for e, value in zip(scored, adjusted, strict=True):
            e[metric]["holm_p"] = value
    return {
        "tolerance": TOLERANCE, "XXmin_seedsXX": MIN_SEEDS, "draws": draws,
        "problems_read": len(runs), "comparisons": entries,
    }  # fmt: skip


def x_analyse__mutmut_37(runs: list[dict[str, Any]], draws: int = DRAWS) -> dict[str, Any]:
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if m not in RULES and seeds}
    )
    entries = [compare(runs, rule, m, draws) for rule in RULES for m in methods]
    for metric in METRICS:
        scored = [e for e in entries if metric in e]
        adjusted = holm([e[metric]["p_two_sided"] for e in scored]) if scored else []
        for e, value in zip(scored, adjusted, strict=True):
            e[metric]["holm_p"] = value
    return {
        "tolerance": TOLERANCE, "MIN_SEEDS": MIN_SEEDS, "draws": draws,
        "problems_read": len(runs), "comparisons": entries,
    }  # fmt: skip


def x_analyse__mutmut_38(runs: list[dict[str, Any]], draws: int = DRAWS) -> dict[str, Any]:
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if m not in RULES and seeds}
    )
    entries = [compare(runs, rule, m, draws) for rule in RULES for m in methods]
    for metric in METRICS:
        scored = [e for e in entries if metric in e]
        adjusted = holm([e[metric]["p_two_sided"] for e in scored]) if scored else []
        for e, value in zip(scored, adjusted, strict=True):
            e[metric]["holm_p"] = value
    return {
        "tolerance": TOLERANCE, "min_seeds": MIN_SEEDS, "XXdrawsXX": draws,
        "problems_read": len(runs), "comparisons": entries,
    }  # fmt: skip


def x_analyse__mutmut_39(runs: list[dict[str, Any]], draws: int = DRAWS) -> dict[str, Any]:
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if m not in RULES and seeds}
    )
    entries = [compare(runs, rule, m, draws) for rule in RULES for m in methods]
    for metric in METRICS:
        scored = [e for e in entries if metric in e]
        adjusted = holm([e[metric]["p_two_sided"] for e in scored]) if scored else []
        for e, value in zip(scored, adjusted, strict=True):
            e[metric]["holm_p"] = value
    return {
        "tolerance": TOLERANCE, "min_seeds": MIN_SEEDS, "DRAWS": draws,
        "problems_read": len(runs), "comparisons": entries,
    }  # fmt: skip


def x_analyse__mutmut_40(runs: list[dict[str, Any]], draws: int = DRAWS) -> dict[str, Any]:
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if m not in RULES and seeds}
    )
    entries = [compare(runs, rule, m, draws) for rule in RULES for m in methods]
    for metric in METRICS:
        scored = [e for e in entries if metric in e]
        adjusted = holm([e[metric]["p_two_sided"] for e in scored]) if scored else []
        for e, value in zip(scored, adjusted, strict=True):
            e[metric]["holm_p"] = value
    return {
        "tolerance": TOLERANCE, "min_seeds": MIN_SEEDS, "draws": draws,
        "XXproblems_readXX": len(runs), "comparisons": entries,
    }  # fmt: skip


def x_analyse__mutmut_41(runs: list[dict[str, Any]], draws: int = DRAWS) -> dict[str, Any]:
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if m not in RULES and seeds}
    )
    entries = [compare(runs, rule, m, draws) for rule in RULES for m in methods]
    for metric in METRICS:
        scored = [e for e in entries if metric in e]
        adjusted = holm([e[metric]["p_two_sided"] for e in scored]) if scored else []
        for e, value in zip(scored, adjusted, strict=True):
            e[metric]["holm_p"] = value
    return {
        "tolerance": TOLERANCE, "min_seeds": MIN_SEEDS, "draws": draws,
        "PROBLEMS_READ": len(runs), "comparisons": entries,
    }  # fmt: skip


def x_analyse__mutmut_42(runs: list[dict[str, Any]], draws: int = DRAWS) -> dict[str, Any]:
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if m not in RULES and seeds}
    )
    entries = [compare(runs, rule, m, draws) for rule in RULES for m in methods]
    for metric in METRICS:
        scored = [e for e in entries if metric in e]
        adjusted = holm([e[metric]["p_two_sided"] for e in scored]) if scored else []
        for e, value in zip(scored, adjusted, strict=True):
            e[metric]["holm_p"] = value
    return {
        "tolerance": TOLERANCE, "min_seeds": MIN_SEEDS, "draws": draws,
        "problems_read": len(runs), "XXcomparisonsXX": entries,
    }  # fmt: skip


def x_analyse__mutmut_43(runs: list[dict[str, Any]], draws: int = DRAWS) -> dict[str, Any]:
    methods = sorted(
        {m for r in runs for m, seeds in r["runs"].items() if m not in RULES and seeds}
    )
    entries = [compare(runs, rule, m, draws) for rule in RULES for m in methods]
    for metric in METRICS:
        scored = [e for e in entries if metric in e]
        adjusted = holm([e[metric]["p_two_sided"] for e in scored]) if scored else []
        for e, value in zip(scored, adjusted, strict=True):
            e[metric]["holm_p"] = value
    return {
        "tolerance": TOLERANCE, "min_seeds": MIN_SEEDS, "draws": draws,
        "problems_read": len(runs), "COMPARISONS": entries,
    }  # fmt: skip

mutants_x_analyse__mutmut['_mutmut_orig'] = x_analyse__mutmut_orig # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_1'] = x_analyse__mutmut_1 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_2'] = x_analyse__mutmut_2 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_3'] = x_analyse__mutmut_3 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_4'] = x_analyse__mutmut_4 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_5'] = x_analyse__mutmut_5 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_6'] = x_analyse__mutmut_6 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_7'] = x_analyse__mutmut_7 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_8'] = x_analyse__mutmut_8 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_9'] = x_analyse__mutmut_9 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_10'] = x_analyse__mutmut_10 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_11'] = x_analyse__mutmut_11 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_12'] = x_analyse__mutmut_12 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_13'] = x_analyse__mutmut_13 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_14'] = x_analyse__mutmut_14 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_15'] = x_analyse__mutmut_15 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_16'] = x_analyse__mutmut_16 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_17'] = x_analyse__mutmut_17 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_18'] = x_analyse__mutmut_18 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_19'] = x_analyse__mutmut_19 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_20'] = x_analyse__mutmut_20 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_21'] = x_analyse__mutmut_21 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_22'] = x_analyse__mutmut_22 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_23'] = x_analyse__mutmut_23 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_24'] = x_analyse__mutmut_24 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_25'] = x_analyse__mutmut_25 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_26'] = x_analyse__mutmut_26 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_27'] = x_analyse__mutmut_27 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_28'] = x_analyse__mutmut_28 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_29'] = x_analyse__mutmut_29 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_30'] = x_analyse__mutmut_30 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_31'] = x_analyse__mutmut_31 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_32'] = x_analyse__mutmut_32 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_33'] = x_analyse__mutmut_33 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_34'] = x_analyse__mutmut_34 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_35'] = x_analyse__mutmut_35 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_36'] = x_analyse__mutmut_36 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_37'] = x_analyse__mutmut_37 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_38'] = x_analyse__mutmut_38 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_39'] = x_analyse__mutmut_39 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_40'] = x_analyse__mutmut_40 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_41'] = x_analyse__mutmut_41 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_42'] = x_analyse__mutmut_42 # type: ignore # mutmut generated
mutants_x_analyse__mutmut['x_analyse__mutmut_43'] = x_analyse__mutmut_43 # type: ignore # mutmut generated
mutants_x_load__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_load__mutmut)
def load(*folders: Path) -> list[dict[str, Any]]:
    """Merge the classical and neural problem files by problem."""
    merged: dict[str, dict[str, Any]] = {}
    for folder in folders:
        for path in sorted(folder.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            base = merged.setdefault(run["problem"], {"problem": run["problem"], "runs": {}})
            base["runs"].update(run["runs"])
    return list(merged.values())


def x_load__mutmut_orig(*folders: Path) -> list[dict[str, Any]]:
    """Merge the classical and neural problem files by problem."""
    merged: dict[str, dict[str, Any]] = {}
    for folder in folders:
        for path in sorted(folder.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            base = merged.setdefault(run["problem"], {"problem": run["problem"], "runs": {}})
            base["runs"].update(run["runs"])
    return list(merged.values())


def x_load__mutmut_1(*folders: Path) -> list[dict[str, Any]]:
    """Merge the classical and neural problem files by problem."""
    merged: dict[str, dict[str, Any]] = None
    for folder in folders:
        for path in sorted(folder.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            base = merged.setdefault(run["problem"], {"problem": run["problem"], "runs": {}})
            base["runs"].update(run["runs"])
    return list(merged.values())


def x_load__mutmut_2(*folders: Path) -> list[dict[str, Any]]:
    """Merge the classical and neural problem files by problem."""
    merged: dict[str, dict[str, Any]] = {}
    for folder in folders:
        for path in sorted(None):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            base = merged.setdefault(run["problem"], {"problem": run["problem"], "runs": {}})
            base["runs"].update(run["runs"])
    return list(merged.values())


def x_load__mutmut_3(*folders: Path) -> list[dict[str, Any]]:
    """Merge the classical and neural problem files by problem."""
    merged: dict[str, dict[str, Any]] = {}
    for folder in folders:
        for path in sorted(folder.glob(None)):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            base = merged.setdefault(run["problem"], {"problem": run["problem"], "runs": {}})
            base["runs"].update(run["runs"])
    return list(merged.values())


def x_load__mutmut_4(*folders: Path) -> list[dict[str, Any]]:
    """Merge the classical and neural problem files by problem."""
    merged: dict[str, dict[str, Any]] = {}
    for folder in folders:
        for path in sorted(folder.glob("XX*.jsonXX")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            base = merged.setdefault(run["problem"], {"problem": run["problem"], "runs": {}})
            base["runs"].update(run["runs"])
    return list(merged.values())


def x_load__mutmut_5(*folders: Path) -> list[dict[str, Any]]:
    """Merge the classical and neural problem files by problem."""
    merged: dict[str, dict[str, Any]] = {}
    for folder in folders:
        for path in sorted(folder.glob("*.JSON")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            base = merged.setdefault(run["problem"], {"problem": run["problem"], "runs": {}})
            base["runs"].update(run["runs"])
    return list(merged.values())


def x_load__mutmut_6(*folders: Path) -> list[dict[str, Any]]:
    """Merge the classical and neural problem files by problem."""
    merged: dict[str, dict[str, Any]] = {}
    for folder in folders:
        for path in sorted(folder.glob("*.json")):
            run = None
            if "failed" in run:
                continue
            base = merged.setdefault(run["problem"], {"problem": run["problem"], "runs": {}})
            base["runs"].update(run["runs"])
    return list(merged.values())


def x_load__mutmut_7(*folders: Path) -> list[dict[str, Any]]:
    """Merge the classical and neural problem files by problem."""
    merged: dict[str, dict[str, Any]] = {}
    for folder in folders:
        for path in sorted(folder.glob("*.json")):
            run = json.loads(None)
            if "failed" in run:
                continue
            base = merged.setdefault(run["problem"], {"problem": run["problem"], "runs": {}})
            base["runs"].update(run["runs"])
    return list(merged.values())


def x_load__mutmut_8(*folders: Path) -> list[dict[str, Any]]:
    """Merge the classical and neural problem files by problem."""
    merged: dict[str, dict[str, Any]] = {}
    for folder in folders:
        for path in sorted(folder.glob("*.json")):
            run = json.loads(path.read_text())
            if "XXfailedXX" in run:
                continue
            base = merged.setdefault(run["problem"], {"problem": run["problem"], "runs": {}})
            base["runs"].update(run["runs"])
    return list(merged.values())


def x_load__mutmut_9(*folders: Path) -> list[dict[str, Any]]:
    """Merge the classical and neural problem files by problem."""
    merged: dict[str, dict[str, Any]] = {}
    for folder in folders:
        for path in sorted(folder.glob("*.json")):
            run = json.loads(path.read_text())
            if "FAILED" in run:
                continue
            base = merged.setdefault(run["problem"], {"problem": run["problem"], "runs": {}})
            base["runs"].update(run["runs"])
    return list(merged.values())


def x_load__mutmut_10(*folders: Path) -> list[dict[str, Any]]:
    """Merge the classical and neural problem files by problem."""
    merged: dict[str, dict[str, Any]] = {}
    for folder in folders:
        for path in sorted(folder.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" not in run:
                continue
            base = merged.setdefault(run["problem"], {"problem": run["problem"], "runs": {}})
            base["runs"].update(run["runs"])
    return list(merged.values())


def x_load__mutmut_11(*folders: Path) -> list[dict[str, Any]]:
    """Merge the classical and neural problem files by problem."""
    merged: dict[str, dict[str, Any]] = {}
    for folder in folders:
        for path in sorted(folder.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                break
            base = merged.setdefault(run["problem"], {"problem": run["problem"], "runs": {}})
            base["runs"].update(run["runs"])
    return list(merged.values())


def x_load__mutmut_12(*folders: Path) -> list[dict[str, Any]]:
    """Merge the classical and neural problem files by problem."""
    merged: dict[str, dict[str, Any]] = {}
    for folder in folders:
        for path in sorted(folder.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            base = None
            base["runs"].update(run["runs"])
    return list(merged.values())


def x_load__mutmut_13(*folders: Path) -> list[dict[str, Any]]:
    """Merge the classical and neural problem files by problem."""
    merged: dict[str, dict[str, Any]] = {}
    for folder in folders:
        for path in sorted(folder.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            base = merged.setdefault(None, {"problem": run["problem"], "runs": {}})
            base["runs"].update(run["runs"])
    return list(merged.values())


def x_load__mutmut_14(*folders: Path) -> list[dict[str, Any]]:
    """Merge the classical and neural problem files by problem."""
    merged: dict[str, dict[str, Any]] = {}
    for folder in folders:
        for path in sorted(folder.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            base = merged.setdefault(run["problem"], None)
            base["runs"].update(run["runs"])
    return list(merged.values())


def x_load__mutmut_15(*folders: Path) -> list[dict[str, Any]]:
    """Merge the classical and neural problem files by problem."""
    merged: dict[str, dict[str, Any]] = {}
    for folder in folders:
        for path in sorted(folder.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            base = merged.setdefault({"problem": run["problem"], "runs": {}})
            base["runs"].update(run["runs"])
    return list(merged.values())


def x_load__mutmut_16(*folders: Path) -> list[dict[str, Any]]:
    """Merge the classical and neural problem files by problem."""
    merged: dict[str, dict[str, Any]] = {}
    for folder in folders:
        for path in sorted(folder.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            base = merged.setdefault(run["problem"], )
            base["runs"].update(run["runs"])
    return list(merged.values())


def x_load__mutmut_17(*folders: Path) -> list[dict[str, Any]]:
    """Merge the classical and neural problem files by problem."""
    merged: dict[str, dict[str, Any]] = {}
    for folder in folders:
        for path in sorted(folder.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            base = merged.setdefault(run["XXproblemXX"], {"problem": run["problem"], "runs": {}})
            base["runs"].update(run["runs"])
    return list(merged.values())


def x_load__mutmut_18(*folders: Path) -> list[dict[str, Any]]:
    """Merge the classical and neural problem files by problem."""
    merged: dict[str, dict[str, Any]] = {}
    for folder in folders:
        for path in sorted(folder.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            base = merged.setdefault(run["PROBLEM"], {"problem": run["problem"], "runs": {}})
            base["runs"].update(run["runs"])
    return list(merged.values())


def x_load__mutmut_19(*folders: Path) -> list[dict[str, Any]]:
    """Merge the classical and neural problem files by problem."""
    merged: dict[str, dict[str, Any]] = {}
    for folder in folders:
        for path in sorted(folder.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            base = merged.setdefault(run["problem"], {"XXproblemXX": run["problem"], "runs": {}})
            base["runs"].update(run["runs"])
    return list(merged.values())


def x_load__mutmut_20(*folders: Path) -> list[dict[str, Any]]:
    """Merge the classical and neural problem files by problem."""
    merged: dict[str, dict[str, Any]] = {}
    for folder in folders:
        for path in sorted(folder.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            base = merged.setdefault(run["problem"], {"PROBLEM": run["problem"], "runs": {}})
            base["runs"].update(run["runs"])
    return list(merged.values())


def x_load__mutmut_21(*folders: Path) -> list[dict[str, Any]]:
    """Merge the classical and neural problem files by problem."""
    merged: dict[str, dict[str, Any]] = {}
    for folder in folders:
        for path in sorted(folder.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            base = merged.setdefault(run["problem"], {"problem": run["XXproblemXX"], "runs": {}})
            base["runs"].update(run["runs"])
    return list(merged.values())


def x_load__mutmut_22(*folders: Path) -> list[dict[str, Any]]:
    """Merge the classical and neural problem files by problem."""
    merged: dict[str, dict[str, Any]] = {}
    for folder in folders:
        for path in sorted(folder.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            base = merged.setdefault(run["problem"], {"problem": run["PROBLEM"], "runs": {}})
            base["runs"].update(run["runs"])
    return list(merged.values())


def x_load__mutmut_23(*folders: Path) -> list[dict[str, Any]]:
    """Merge the classical and neural problem files by problem."""
    merged: dict[str, dict[str, Any]] = {}
    for folder in folders:
        for path in sorted(folder.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            base = merged.setdefault(run["problem"], {"problem": run["problem"], "XXrunsXX": {}})
            base["runs"].update(run["runs"])
    return list(merged.values())


def x_load__mutmut_24(*folders: Path) -> list[dict[str, Any]]:
    """Merge the classical and neural problem files by problem."""
    merged: dict[str, dict[str, Any]] = {}
    for folder in folders:
        for path in sorted(folder.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            base = merged.setdefault(run["problem"], {"problem": run["problem"], "RUNS": {}})
            base["runs"].update(run["runs"])
    return list(merged.values())


def x_load__mutmut_25(*folders: Path) -> list[dict[str, Any]]:
    """Merge the classical and neural problem files by problem."""
    merged: dict[str, dict[str, Any]] = {}
    for folder in folders:
        for path in sorted(folder.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            base = merged.setdefault(run["problem"], {"problem": run["problem"], "runs": {}})
            base["runs"].update(None)
    return list(merged.values())


def x_load__mutmut_26(*folders: Path) -> list[dict[str, Any]]:
    """Merge the classical and neural problem files by problem."""
    merged: dict[str, dict[str, Any]] = {}
    for folder in folders:
        for path in sorted(folder.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            base = merged.setdefault(run["problem"], {"problem": run["problem"], "runs": {}})
            base["XXrunsXX"].update(run["runs"])
    return list(merged.values())


def x_load__mutmut_27(*folders: Path) -> list[dict[str, Any]]:
    """Merge the classical and neural problem files by problem."""
    merged: dict[str, dict[str, Any]] = {}
    for folder in folders:
        for path in sorted(folder.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            base = merged.setdefault(run["problem"], {"problem": run["problem"], "runs": {}})
            base["RUNS"].update(run["runs"])
    return list(merged.values())


def x_load__mutmut_28(*folders: Path) -> list[dict[str, Any]]:
    """Merge the classical and neural problem files by problem."""
    merged: dict[str, dict[str, Any]] = {}
    for folder in folders:
        for path in sorted(folder.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            base = merged.setdefault(run["problem"], {"problem": run["problem"], "runs": {}})
            base["runs"].update(run["XXrunsXX"])
    return list(merged.values())


def x_load__mutmut_29(*folders: Path) -> list[dict[str, Any]]:
    """Merge the classical and neural problem files by problem."""
    merged: dict[str, dict[str, Any]] = {}
    for folder in folders:
        for path in sorted(folder.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            base = merged.setdefault(run["problem"], {"problem": run["problem"], "runs": {}})
            base["runs"].update(run["RUNS"])
    return list(merged.values())


def x_load__mutmut_30(*folders: Path) -> list[dict[str, Any]]:
    """Merge the classical and neural problem files by problem."""
    merged: dict[str, dict[str, Any]] = {}
    for folder in folders:
        for path in sorted(folder.glob("*.json")):
            run = json.loads(path.read_text())
            if "failed" in run:
                continue
            base = merged.setdefault(run["problem"], {"problem": run["problem"], "runs": {}})
            base["runs"].update(run["runs"])
    return list(None)

mutants_x_load__mutmut['_mutmut_orig'] = x_load__mutmut_orig # type: ignore # mutmut generated
mutants_x_load__mutmut['x_load__mutmut_1'] = x_load__mutmut_1 # type: ignore # mutmut generated
mutants_x_load__mutmut['x_load__mutmut_2'] = x_load__mutmut_2 # type: ignore # mutmut generated
mutants_x_load__mutmut['x_load__mutmut_3'] = x_load__mutmut_3 # type: ignore # mutmut generated
mutants_x_load__mutmut['x_load__mutmut_4'] = x_load__mutmut_4 # type: ignore # mutmut generated
mutants_x_load__mutmut['x_load__mutmut_5'] = x_load__mutmut_5 # type: ignore # mutmut generated
mutants_x_load__mutmut['x_load__mutmut_6'] = x_load__mutmut_6 # type: ignore # mutmut generated
mutants_x_load__mutmut['x_load__mutmut_7'] = x_load__mutmut_7 # type: ignore # mutmut generated
mutants_x_load__mutmut['x_load__mutmut_8'] = x_load__mutmut_8 # type: ignore # mutmut generated
mutants_x_load__mutmut['x_load__mutmut_9'] = x_load__mutmut_9 # type: ignore # mutmut generated
mutants_x_load__mutmut['x_load__mutmut_10'] = x_load__mutmut_10 # type: ignore # mutmut generated
mutants_x_load__mutmut['x_load__mutmut_11'] = x_load__mutmut_11 # type: ignore # mutmut generated
mutants_x_load__mutmut['x_load__mutmut_12'] = x_load__mutmut_12 # type: ignore # mutmut generated
mutants_x_load__mutmut['x_load__mutmut_13'] = x_load__mutmut_13 # type: ignore # mutmut generated
mutants_x_load__mutmut['x_load__mutmut_14'] = x_load__mutmut_14 # type: ignore # mutmut generated
mutants_x_load__mutmut['x_load__mutmut_15'] = x_load__mutmut_15 # type: ignore # mutmut generated
mutants_x_load__mutmut['x_load__mutmut_16'] = x_load__mutmut_16 # type: ignore # mutmut generated
mutants_x_load__mutmut['x_load__mutmut_17'] = x_load__mutmut_17 # type: ignore # mutmut generated
mutants_x_load__mutmut['x_load__mutmut_18'] = x_load__mutmut_18 # type: ignore # mutmut generated
mutants_x_load__mutmut['x_load__mutmut_19'] = x_load__mutmut_19 # type: ignore # mutmut generated
mutants_x_load__mutmut['x_load__mutmut_20'] = x_load__mutmut_20 # type: ignore # mutmut generated
mutants_x_load__mutmut['x_load__mutmut_21'] = x_load__mutmut_21 # type: ignore # mutmut generated
mutants_x_load__mutmut['x_load__mutmut_22'] = x_load__mutmut_22 # type: ignore # mutmut generated
mutants_x_load__mutmut['x_load__mutmut_23'] = x_load__mutmut_23 # type: ignore # mutmut generated
mutants_x_load__mutmut['x_load__mutmut_24'] = x_load__mutmut_24 # type: ignore # mutmut generated
mutants_x_load__mutmut['x_load__mutmut_25'] = x_load__mutmut_25 # type: ignore # mutmut generated
mutants_x_load__mutmut['x_load__mutmut_26'] = x_load__mutmut_26 # type: ignore # mutmut generated
mutants_x_load__mutmut['x_load__mutmut_27'] = x_load__mutmut_27 # type: ignore # mutmut generated
mutants_x_load__mutmut['x_load__mutmut_28'] = x_load__mutmut_28 # type: ignore # mutmut generated
mutants_x_load__mutmut['x_load__mutmut_29'] = x_load__mutmut_29 # type: ignore # mutmut generated
mutants_x_load__mutmut['x_load__mutmut_30'] = x_load__mutmut_30 # type: ignore # mutmut generated
mutants_x_main__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_main__mutmut)
def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", nargs="+", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.write_text(
        json.dumps(analyse(load(*args.folders)), indent=1, sort_keys=True) + "\n"
    )
    return 0


def x_main__mutmut_orig(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", nargs="+", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.write_text(
        json.dumps(analyse(load(*args.folders)), indent=1, sort_keys=True) + "\n"
    )
    return 0


def x_main__mutmut_1(argv: list[str] | None = None) -> int:
    parser = None
    parser.add_argument("folders", nargs="+", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.write_text(
        json.dumps(analyse(load(*args.folders)), indent=1, sort_keys=True) + "\n"
    )
    return 0


def x_main__mutmut_2(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=None)
    parser.add_argument("folders", nargs="+", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.write_text(
        json.dumps(analyse(load(*args.folders)), indent=1, sort_keys=True) + "\n"
    )
    return 0


def x_main__mutmut_3(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(None, nargs="+", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.write_text(
        json.dumps(analyse(load(*args.folders)), indent=1, sort_keys=True) + "\n"
    )
    return 0


def x_main__mutmut_4(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", nargs=None, type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.write_text(
        json.dumps(analyse(load(*args.folders)), indent=1, sort_keys=True) + "\n"
    )
    return 0


def x_main__mutmut_5(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", nargs="+", type=None)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.write_text(
        json.dumps(analyse(load(*args.folders)), indent=1, sort_keys=True) + "\n"
    )
    return 0


def x_main__mutmut_6(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(nargs="+", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.write_text(
        json.dumps(analyse(load(*args.folders)), indent=1, sort_keys=True) + "\n"
    )
    return 0


def x_main__mutmut_7(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.write_text(
        json.dumps(analyse(load(*args.folders)), indent=1, sort_keys=True) + "\n"
    )
    return 0


def x_main__mutmut_8(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", nargs="+", )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.write_text(
        json.dumps(analyse(load(*args.folders)), indent=1, sort_keys=True) + "\n"
    )
    return 0


def x_main__mutmut_9(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("XXfoldersXX", nargs="+", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.write_text(
        json.dumps(analyse(load(*args.folders)), indent=1, sort_keys=True) + "\n"
    )
    return 0


def x_main__mutmut_10(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("FOLDERS", nargs="+", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.write_text(
        json.dumps(analyse(load(*args.folders)), indent=1, sort_keys=True) + "\n"
    )
    return 0


def x_main__mutmut_11(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", nargs="XX+XX", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.write_text(
        json.dumps(analyse(load(*args.folders)), indent=1, sort_keys=True) + "\n"
    )
    return 0


def x_main__mutmut_12(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", nargs="+", type=Path)
    parser.add_argument(None, type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.write_text(
        json.dumps(analyse(load(*args.folders)), indent=1, sort_keys=True) + "\n"
    )
    return 0


def x_main__mutmut_13(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", nargs="+", type=Path)
    parser.add_argument("--output", type=None, required=True)
    args = parser.parse_args(argv)
    args.output.write_text(
        json.dumps(analyse(load(*args.folders)), indent=1, sort_keys=True) + "\n"
    )
    return 0


def x_main__mutmut_14(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", nargs="+", type=Path)
    parser.add_argument("--output", type=Path, required=None)
    args = parser.parse_args(argv)
    args.output.write_text(
        json.dumps(analyse(load(*args.folders)), indent=1, sort_keys=True) + "\n"
    )
    return 0


def x_main__mutmut_15(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", nargs="+", type=Path)
    parser.add_argument(type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.write_text(
        json.dumps(analyse(load(*args.folders)), indent=1, sort_keys=True) + "\n"
    )
    return 0


def x_main__mutmut_16(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", nargs="+", type=Path)
    parser.add_argument("--output", required=True)
    args = parser.parse_args(argv)
    args.output.write_text(
        json.dumps(analyse(load(*args.folders)), indent=1, sort_keys=True) + "\n"
    )
    return 0


def x_main__mutmut_17(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", nargs="+", type=Path)
    parser.add_argument("--output", type=Path, )
    args = parser.parse_args(argv)
    args.output.write_text(
        json.dumps(analyse(load(*args.folders)), indent=1, sort_keys=True) + "\n"
    )
    return 0


def x_main__mutmut_18(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", nargs="+", type=Path)
    parser.add_argument("XX--outputXX", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.write_text(
        json.dumps(analyse(load(*args.folders)), indent=1, sort_keys=True) + "\n"
    )
    return 0


def x_main__mutmut_19(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", nargs="+", type=Path)
    parser.add_argument("--OUTPUT", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.write_text(
        json.dumps(analyse(load(*args.folders)), indent=1, sort_keys=True) + "\n"
    )
    return 0


def x_main__mutmut_20(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", nargs="+", type=Path)
    parser.add_argument("--output", type=Path, required=False)
    args = parser.parse_args(argv)
    args.output.write_text(
        json.dumps(analyse(load(*args.folders)), indent=1, sort_keys=True) + "\n"
    )
    return 0


def x_main__mutmut_21(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", nargs="+", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = None
    args.output.write_text(
        json.dumps(analyse(load(*args.folders)), indent=1, sort_keys=True) + "\n"
    )
    return 0


def x_main__mutmut_22(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", nargs="+", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(None)
    args.output.write_text(
        json.dumps(analyse(load(*args.folders)), indent=1, sort_keys=True) + "\n"
    )
    return 0


def x_main__mutmut_23(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", nargs="+", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.write_text(
        None
    )
    return 0


def x_main__mutmut_24(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", nargs="+", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.write_text(
        json.dumps(analyse(load(*args.folders)), indent=1, sort_keys=True) - "\n"
    )
    return 0


def x_main__mutmut_25(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", nargs="+", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.write_text(
        json.dumps(None, indent=1, sort_keys=True) + "\n"
    )
    return 0


def x_main__mutmut_26(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", nargs="+", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.write_text(
        json.dumps(analyse(load(*args.folders)), indent=None, sort_keys=True) + "\n"
    )
    return 0


def x_main__mutmut_27(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", nargs="+", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.write_text(
        json.dumps(analyse(load(*args.folders)), indent=1, sort_keys=None) + "\n"
    )
    return 0


def x_main__mutmut_28(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", nargs="+", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.write_text(
        json.dumps(indent=1, sort_keys=True) + "\n"
    )
    return 0


def x_main__mutmut_29(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", nargs="+", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.write_text(
        json.dumps(analyse(load(*args.folders)), sort_keys=True) + "\n"
    )
    return 0


def x_main__mutmut_30(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", nargs="+", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.write_text(
        json.dumps(analyse(load(*args.folders)), indent=1, ) + "\n"
    )
    return 0


def x_main__mutmut_31(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", nargs="+", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.write_text(
        json.dumps(analyse(None), indent=1, sort_keys=True) + "\n"
    )
    return 0


def x_main__mutmut_32(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", nargs="+", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.write_text(
        json.dumps(analyse(load(*args.folders)), indent=2, sort_keys=True) + "\n"
    )
    return 0


def x_main__mutmut_33(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", nargs="+", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.write_text(
        json.dumps(analyse(load(*args.folders)), indent=1, sort_keys=False) + "\n"
    )
    return 0


def x_main__mutmut_34(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", nargs="+", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.write_text(
        json.dumps(analyse(load(*args.folders)), indent=1, sort_keys=True) + "XX\nXX"
    )
    return 0


def x_main__mutmut_35(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folders", nargs="+", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    args.output.write_text(
        json.dumps(analyse(load(*args.folders)), indent=1, sort_keys=True) + "\n"
    )
    return 1

mutants_x_main__mutmut['_mutmut_orig'] = x_main__mutmut_orig # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_1'] = x_main__mutmut_1 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_2'] = x_main__mutmut_2 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_3'] = x_main__mutmut_3 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_4'] = x_main__mutmut_4 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_5'] = x_main__mutmut_5 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_6'] = x_main__mutmut_6 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_7'] = x_main__mutmut_7 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_8'] = x_main__mutmut_8 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_9'] = x_main__mutmut_9 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_10'] = x_main__mutmut_10 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_11'] = x_main__mutmut_11 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_12'] = x_main__mutmut_12 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_13'] = x_main__mutmut_13 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_14'] = x_main__mutmut_14 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_15'] = x_main__mutmut_15 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_16'] = x_main__mutmut_16 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_17'] = x_main__mutmut_17 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_18'] = x_main__mutmut_18 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_19'] = x_main__mutmut_19 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_20'] = x_main__mutmut_20 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_21'] = x_main__mutmut_21 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_22'] = x_main__mutmut_22 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_23'] = x_main__mutmut_23 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_24'] = x_main__mutmut_24 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_25'] = x_main__mutmut_25 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_26'] = x_main__mutmut_26 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_27'] = x_main__mutmut_27 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_28'] = x_main__mutmut_28 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_29'] = x_main__mutmut_29 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_30'] = x_main__mutmut_30 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_31'] = x_main__mutmut_31 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_32'] = x_main__mutmut_32 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_33'] = x_main__mutmut_33 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_34'] = x_main__mutmut_34 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_35'] = x_main__mutmut_35 # type: ignore # mutmut generated


if __name__ == "__main__":
    raise SystemExit(main())
