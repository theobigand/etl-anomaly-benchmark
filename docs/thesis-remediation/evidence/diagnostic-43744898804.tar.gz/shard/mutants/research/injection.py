"""Typed anomaly injection on a numeric carrier table.

The six types of the synthetic benchmark are adapted to arbitrary numeric columns. The carrier is
the clean (normal-class) part of a real dataset reduced to its continuous columns; the protocol
and the magnitudes are those written in verification/typed_injection.md before any result.
"""

from __future__ import annotations

from typing import Any

import numpy as np
import pandas as pd

from etl_benchmark import synthetic

ANOMALY_TYPES: list[str] = list(synthetic.ANOMALY_TYPES)
MIN_DISTINCT, MIN_COLUMNS, MIN_ROWS, MAX_ROWS = 10, 4, 3000, 20_000
RATE, SEVERITY = 0.03, 1.0
META = ("t", "group_id", "anomaly", "anomaly_type")
_BASE = pd.Timestamp("2020-01-01")
_SENTINEL, _SCALE = -999.0, 1000.0


from mutmut.mutation.trampoline import wrap_in_trampoline as _mutmut_mutated, MutantDict


class NotEligible(Exception):
    """The table cannot carry the typed injection under the pre-registered rule."""
mutants_x_continuous_columns__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_continuous_columns__mutmut)
def continuous_columns(frame: pd.DataFrame) -> list[str]:
    return [
        c
        for c in frame.columns
        if pd.api.types.is_numeric_dtype(frame[c])
        and not pd.api.types.is_bool_dtype(frame[c])
        and frame[c].nunique() >= MIN_DISTINCT
    ]


def x_continuous_columns__mutmut_orig(frame: pd.DataFrame) -> list[str]:
    return [
        c
        for c in frame.columns
        if pd.api.types.is_numeric_dtype(frame[c])
        and not pd.api.types.is_bool_dtype(frame[c])
        and frame[c].nunique() >= MIN_DISTINCT
    ]


def x_continuous_columns__mutmut_1(frame: pd.DataFrame) -> list[str]:
    return [
        c
        for c in frame.columns
        if pd.api.types.is_numeric_dtype(frame[c])
        and not pd.api.types.is_bool_dtype(frame[c]) or frame[c].nunique() >= MIN_DISTINCT
    ]


def x_continuous_columns__mutmut_2(frame: pd.DataFrame) -> list[str]:
    return [
        c
        for c in frame.columns
        if pd.api.types.is_numeric_dtype(frame[c]) or not pd.api.types.is_bool_dtype(frame[c])
        and frame[c].nunique() >= MIN_DISTINCT
    ]


def x_continuous_columns__mutmut_3(frame: pd.DataFrame) -> list[str]:
    return [
        c
        for c in frame.columns
        if pd.api.types.is_numeric_dtype(None)
        and not pd.api.types.is_bool_dtype(frame[c])
        and frame[c].nunique() >= MIN_DISTINCT
    ]


def x_continuous_columns__mutmut_4(frame: pd.DataFrame) -> list[str]:
    return [
        c
        for c in frame.columns
        if pd.api.types.is_numeric_dtype(frame[c])
        and pd.api.types.is_bool_dtype(frame[c])
        and frame[c].nunique() >= MIN_DISTINCT
    ]


def x_continuous_columns__mutmut_5(frame: pd.DataFrame) -> list[str]:
    return [
        c
        for c in frame.columns
        if pd.api.types.is_numeric_dtype(frame[c])
        and not pd.api.types.is_bool_dtype(None)
        and frame[c].nunique() >= MIN_DISTINCT
    ]


def x_continuous_columns__mutmut_6(frame: pd.DataFrame) -> list[str]:
    return [
        c
        for c in frame.columns
        if pd.api.types.is_numeric_dtype(frame[c])
        and not pd.api.types.is_bool_dtype(frame[c])
        and frame[c].nunique() > MIN_DISTINCT
    ]

mutants_x_continuous_columns__mutmut['_mutmut_orig'] = x_continuous_columns__mutmut_orig # type: ignore # mutmut generated
mutants_x_continuous_columns__mutmut['x_continuous_columns__mutmut_1'] = x_continuous_columns__mutmut_1 # type: ignore # mutmut generated
mutants_x_continuous_columns__mutmut['x_continuous_columns__mutmut_2'] = x_continuous_columns__mutmut_2 # type: ignore # mutmut generated
mutants_x_continuous_columns__mutmut['x_continuous_columns__mutmut_3'] = x_continuous_columns__mutmut_3 # type: ignore # mutmut generated
mutants_x_continuous_columns__mutmut['x_continuous_columns__mutmut_4'] = x_continuous_columns__mutmut_4 # type: ignore # mutmut generated
mutants_x_continuous_columns__mutmut['x_continuous_columns__mutmut_5'] = x_continuous_columns__mutmut_5 # type: ignore # mutmut generated
mutants_x_continuous_columns__mutmut['x_continuous_columns__mutmut_6'] = x_continuous_columns__mutmut_6 # type: ignore # mutmut generated
mutants_x_FEATURES_OF__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_FEATURES_OF__mutmut)
def FEATURES_OF(frame: pd.DataFrame) -> list[str]:  # noqa: N802 - reads like a constant table
    return [c for c in frame.columns if c not in META]


def x_FEATURES_OF__mutmut_orig(frame: pd.DataFrame) -> list[str]:  # noqa: N802 - reads like a constant table
    return [c for c in frame.columns if c not in META]


def x_FEATURES_OF__mutmut_1(frame: pd.DataFrame) -> list[str]:  # noqa: N802 - reads like a constant table
    return [c for c in frame.columns if c in META]

mutants_x_FEATURES_OF__mutmut['_mutmut_orig'] = x_FEATURES_OF__mutmut_orig # type: ignore # mutmut generated
mutants_x_FEATURES_OF__mutmut['x_FEATURES_OF__mutmut_1'] = x_FEATURES_OF__mutmut_1 # type: ignore # mutmut generated
mutants_x_prepare__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_prepare__mutmut)
def prepare(frame: pd.DataFrame, seed: int, cap: int = MAX_ROWS) -> tuple[pd.DataFrame, dict]:
    columns = continuous_columns(frame)
    if len(columns) < MIN_COLUMNS:
        raise NotEligible(f"only {len(columns)} continuous columns")
    table = frame[columns].astype(float)
    report: dict[str, Any] = {"rows_in": len(table), "columns": columns}
    complete = table.dropna()
    report["rows_incomplete_dropped"] = len(table) - len(complete)
    unique = complete.drop_duplicates()
    report["duplicates_dropped"] = len(complete) - len(unique)
    if len(unique) < MIN_ROWS:
        raise NotEligible(f"only {len(unique)} rows after cleaning")
    if len(unique) > cap:
        unique = unique.sample(n=cap, random_state=seed)
    report["rows_out"] = len(unique)
    return unique.reset_index(drop=True), report


def x_prepare__mutmut_orig(frame: pd.DataFrame, seed: int, cap: int = MAX_ROWS) -> tuple[pd.DataFrame, dict]:
    columns = continuous_columns(frame)
    if len(columns) < MIN_COLUMNS:
        raise NotEligible(f"only {len(columns)} continuous columns")
    table = frame[columns].astype(float)
    report: dict[str, Any] = {"rows_in": len(table), "columns": columns}
    complete = table.dropna()
    report["rows_incomplete_dropped"] = len(table) - len(complete)
    unique = complete.drop_duplicates()
    report["duplicates_dropped"] = len(complete) - len(unique)
    if len(unique) < MIN_ROWS:
        raise NotEligible(f"only {len(unique)} rows after cleaning")
    if len(unique) > cap:
        unique = unique.sample(n=cap, random_state=seed)
    report["rows_out"] = len(unique)
    return unique.reset_index(drop=True), report


def x_prepare__mutmut_1(frame: pd.DataFrame, seed: int, cap: int = MAX_ROWS) -> tuple[pd.DataFrame, dict]:
    columns = None
    if len(columns) < MIN_COLUMNS:
        raise NotEligible(f"only {len(columns)} continuous columns")
    table = frame[columns].astype(float)
    report: dict[str, Any] = {"rows_in": len(table), "columns": columns}
    complete = table.dropna()
    report["rows_incomplete_dropped"] = len(table) - len(complete)
    unique = complete.drop_duplicates()
    report["duplicates_dropped"] = len(complete) - len(unique)
    if len(unique) < MIN_ROWS:
        raise NotEligible(f"only {len(unique)} rows after cleaning")
    if len(unique) > cap:
        unique = unique.sample(n=cap, random_state=seed)
    report["rows_out"] = len(unique)
    return unique.reset_index(drop=True), report


def x_prepare__mutmut_2(frame: pd.DataFrame, seed: int, cap: int = MAX_ROWS) -> tuple[pd.DataFrame, dict]:
    columns = continuous_columns(None)
    if len(columns) < MIN_COLUMNS:
        raise NotEligible(f"only {len(columns)} continuous columns")
    table = frame[columns].astype(float)
    report: dict[str, Any] = {"rows_in": len(table), "columns": columns}
    complete = table.dropna()
    report["rows_incomplete_dropped"] = len(table) - len(complete)
    unique = complete.drop_duplicates()
    report["duplicates_dropped"] = len(complete) - len(unique)
    if len(unique) < MIN_ROWS:
        raise NotEligible(f"only {len(unique)} rows after cleaning")
    if len(unique) > cap:
        unique = unique.sample(n=cap, random_state=seed)
    report["rows_out"] = len(unique)
    return unique.reset_index(drop=True), report


def x_prepare__mutmut_3(frame: pd.DataFrame, seed: int, cap: int = MAX_ROWS) -> tuple[pd.DataFrame, dict]:
    columns = continuous_columns(frame)
    if len(columns) <= MIN_COLUMNS:
        raise NotEligible(f"only {len(columns)} continuous columns")
    table = frame[columns].astype(float)
    report: dict[str, Any] = {"rows_in": len(table), "columns": columns}
    complete = table.dropna()
    report["rows_incomplete_dropped"] = len(table) - len(complete)
    unique = complete.drop_duplicates()
    report["duplicates_dropped"] = len(complete) - len(unique)
    if len(unique) < MIN_ROWS:
        raise NotEligible(f"only {len(unique)} rows after cleaning")
    if len(unique) > cap:
        unique = unique.sample(n=cap, random_state=seed)
    report["rows_out"] = len(unique)
    return unique.reset_index(drop=True), report


def x_prepare__mutmut_4(frame: pd.DataFrame, seed: int, cap: int = MAX_ROWS) -> tuple[pd.DataFrame, dict]:
    columns = continuous_columns(frame)
    if len(columns) < MIN_COLUMNS:
        raise NotEligible(None)
    table = frame[columns].astype(float)
    report: dict[str, Any] = {"rows_in": len(table), "columns": columns}
    complete = table.dropna()
    report["rows_incomplete_dropped"] = len(table) - len(complete)
    unique = complete.drop_duplicates()
    report["duplicates_dropped"] = len(complete) - len(unique)
    if len(unique) < MIN_ROWS:
        raise NotEligible(f"only {len(unique)} rows after cleaning")
    if len(unique) > cap:
        unique = unique.sample(n=cap, random_state=seed)
    report["rows_out"] = len(unique)
    return unique.reset_index(drop=True), report


def x_prepare__mutmut_5(frame: pd.DataFrame, seed: int, cap: int = MAX_ROWS) -> tuple[pd.DataFrame, dict]:
    columns = continuous_columns(frame)
    if len(columns) < MIN_COLUMNS:
        raise NotEligible(f"only {len(columns)} continuous columns")
    table = None
    report: dict[str, Any] = {"rows_in": len(table), "columns": columns}
    complete = table.dropna()
    report["rows_incomplete_dropped"] = len(table) - len(complete)
    unique = complete.drop_duplicates()
    report["duplicates_dropped"] = len(complete) - len(unique)
    if len(unique) < MIN_ROWS:
        raise NotEligible(f"only {len(unique)} rows after cleaning")
    if len(unique) > cap:
        unique = unique.sample(n=cap, random_state=seed)
    report["rows_out"] = len(unique)
    return unique.reset_index(drop=True), report


def x_prepare__mutmut_6(frame: pd.DataFrame, seed: int, cap: int = MAX_ROWS) -> tuple[pd.DataFrame, dict]:
    columns = continuous_columns(frame)
    if len(columns) < MIN_COLUMNS:
        raise NotEligible(f"only {len(columns)} continuous columns")
    table = frame[columns].astype(None)
    report: dict[str, Any] = {"rows_in": len(table), "columns": columns}
    complete = table.dropna()
    report["rows_incomplete_dropped"] = len(table) - len(complete)
    unique = complete.drop_duplicates()
    report["duplicates_dropped"] = len(complete) - len(unique)
    if len(unique) < MIN_ROWS:
        raise NotEligible(f"only {len(unique)} rows after cleaning")
    if len(unique) > cap:
        unique = unique.sample(n=cap, random_state=seed)
    report["rows_out"] = len(unique)
    return unique.reset_index(drop=True), report


def x_prepare__mutmut_7(frame: pd.DataFrame, seed: int, cap: int = MAX_ROWS) -> tuple[pd.DataFrame, dict]:
    columns = continuous_columns(frame)
    if len(columns) < MIN_COLUMNS:
        raise NotEligible(f"only {len(columns)} continuous columns")
    table = frame[columns].astype(float)
    report: dict[str, Any] = None
    complete = table.dropna()
    report["rows_incomplete_dropped"] = len(table) - len(complete)
    unique = complete.drop_duplicates()
    report["duplicates_dropped"] = len(complete) - len(unique)
    if len(unique) < MIN_ROWS:
        raise NotEligible(f"only {len(unique)} rows after cleaning")
    if len(unique) > cap:
        unique = unique.sample(n=cap, random_state=seed)
    report["rows_out"] = len(unique)
    return unique.reset_index(drop=True), report


def x_prepare__mutmut_8(frame: pd.DataFrame, seed: int, cap: int = MAX_ROWS) -> tuple[pd.DataFrame, dict]:
    columns = continuous_columns(frame)
    if len(columns) < MIN_COLUMNS:
        raise NotEligible(f"only {len(columns)} continuous columns")
    table = frame[columns].astype(float)
    report: dict[str, Any] = {"XXrows_inXX": len(table), "columns": columns}
    complete = table.dropna()
    report["rows_incomplete_dropped"] = len(table) - len(complete)
    unique = complete.drop_duplicates()
    report["duplicates_dropped"] = len(complete) - len(unique)
    if len(unique) < MIN_ROWS:
        raise NotEligible(f"only {len(unique)} rows after cleaning")
    if len(unique) > cap:
        unique = unique.sample(n=cap, random_state=seed)
    report["rows_out"] = len(unique)
    return unique.reset_index(drop=True), report


def x_prepare__mutmut_9(frame: pd.DataFrame, seed: int, cap: int = MAX_ROWS) -> tuple[pd.DataFrame, dict]:
    columns = continuous_columns(frame)
    if len(columns) < MIN_COLUMNS:
        raise NotEligible(f"only {len(columns)} continuous columns")
    table = frame[columns].astype(float)
    report: dict[str, Any] = {"ROWS_IN": len(table), "columns": columns}
    complete = table.dropna()
    report["rows_incomplete_dropped"] = len(table) - len(complete)
    unique = complete.drop_duplicates()
    report["duplicates_dropped"] = len(complete) - len(unique)
    if len(unique) < MIN_ROWS:
        raise NotEligible(f"only {len(unique)} rows after cleaning")
    if len(unique) > cap:
        unique = unique.sample(n=cap, random_state=seed)
    report["rows_out"] = len(unique)
    return unique.reset_index(drop=True), report


def x_prepare__mutmut_10(frame: pd.DataFrame, seed: int, cap: int = MAX_ROWS) -> tuple[pd.DataFrame, dict]:
    columns = continuous_columns(frame)
    if len(columns) < MIN_COLUMNS:
        raise NotEligible(f"only {len(columns)} continuous columns")
    table = frame[columns].astype(float)
    report: dict[str, Any] = {"rows_in": len(table), "XXcolumnsXX": columns}
    complete = table.dropna()
    report["rows_incomplete_dropped"] = len(table) - len(complete)
    unique = complete.drop_duplicates()
    report["duplicates_dropped"] = len(complete) - len(unique)
    if len(unique) < MIN_ROWS:
        raise NotEligible(f"only {len(unique)} rows after cleaning")
    if len(unique) > cap:
        unique = unique.sample(n=cap, random_state=seed)
    report["rows_out"] = len(unique)
    return unique.reset_index(drop=True), report


def x_prepare__mutmut_11(frame: pd.DataFrame, seed: int, cap: int = MAX_ROWS) -> tuple[pd.DataFrame, dict]:
    columns = continuous_columns(frame)
    if len(columns) < MIN_COLUMNS:
        raise NotEligible(f"only {len(columns)} continuous columns")
    table = frame[columns].astype(float)
    report: dict[str, Any] = {"rows_in": len(table), "COLUMNS": columns}
    complete = table.dropna()
    report["rows_incomplete_dropped"] = len(table) - len(complete)
    unique = complete.drop_duplicates()
    report["duplicates_dropped"] = len(complete) - len(unique)
    if len(unique) < MIN_ROWS:
        raise NotEligible(f"only {len(unique)} rows after cleaning")
    if len(unique) > cap:
        unique = unique.sample(n=cap, random_state=seed)
    report["rows_out"] = len(unique)
    return unique.reset_index(drop=True), report


def x_prepare__mutmut_12(frame: pd.DataFrame, seed: int, cap: int = MAX_ROWS) -> tuple[pd.DataFrame, dict]:
    columns = continuous_columns(frame)
    if len(columns) < MIN_COLUMNS:
        raise NotEligible(f"only {len(columns)} continuous columns")
    table = frame[columns].astype(float)
    report: dict[str, Any] = {"rows_in": len(table), "columns": columns}
    complete = None
    report["rows_incomplete_dropped"] = len(table) - len(complete)
    unique = complete.drop_duplicates()
    report["duplicates_dropped"] = len(complete) - len(unique)
    if len(unique) < MIN_ROWS:
        raise NotEligible(f"only {len(unique)} rows after cleaning")
    if len(unique) > cap:
        unique = unique.sample(n=cap, random_state=seed)
    report["rows_out"] = len(unique)
    return unique.reset_index(drop=True), report


def x_prepare__mutmut_13(frame: pd.DataFrame, seed: int, cap: int = MAX_ROWS) -> tuple[pd.DataFrame, dict]:
    columns = continuous_columns(frame)
    if len(columns) < MIN_COLUMNS:
        raise NotEligible(f"only {len(columns)} continuous columns")
    table = frame[columns].astype(float)
    report: dict[str, Any] = {"rows_in": len(table), "columns": columns}
    complete = table.dropna()
    report["rows_incomplete_dropped"] = None
    unique = complete.drop_duplicates()
    report["duplicates_dropped"] = len(complete) - len(unique)
    if len(unique) < MIN_ROWS:
        raise NotEligible(f"only {len(unique)} rows after cleaning")
    if len(unique) > cap:
        unique = unique.sample(n=cap, random_state=seed)
    report["rows_out"] = len(unique)
    return unique.reset_index(drop=True), report


def x_prepare__mutmut_14(frame: pd.DataFrame, seed: int, cap: int = MAX_ROWS) -> tuple[pd.DataFrame, dict]:
    columns = continuous_columns(frame)
    if len(columns) < MIN_COLUMNS:
        raise NotEligible(f"only {len(columns)} continuous columns")
    table = frame[columns].astype(float)
    report: dict[str, Any] = {"rows_in": len(table), "columns": columns}
    complete = table.dropna()
    report["XXrows_incomplete_droppedXX"] = len(table) - len(complete)
    unique = complete.drop_duplicates()
    report["duplicates_dropped"] = len(complete) - len(unique)
    if len(unique) < MIN_ROWS:
        raise NotEligible(f"only {len(unique)} rows after cleaning")
    if len(unique) > cap:
        unique = unique.sample(n=cap, random_state=seed)
    report["rows_out"] = len(unique)
    return unique.reset_index(drop=True), report


def x_prepare__mutmut_15(frame: pd.DataFrame, seed: int, cap: int = MAX_ROWS) -> tuple[pd.DataFrame, dict]:
    columns = continuous_columns(frame)
    if len(columns) < MIN_COLUMNS:
        raise NotEligible(f"only {len(columns)} continuous columns")
    table = frame[columns].astype(float)
    report: dict[str, Any] = {"rows_in": len(table), "columns": columns}
    complete = table.dropna()
    report["ROWS_INCOMPLETE_DROPPED"] = len(table) - len(complete)
    unique = complete.drop_duplicates()
    report["duplicates_dropped"] = len(complete) - len(unique)
    if len(unique) < MIN_ROWS:
        raise NotEligible(f"only {len(unique)} rows after cleaning")
    if len(unique) > cap:
        unique = unique.sample(n=cap, random_state=seed)
    report["rows_out"] = len(unique)
    return unique.reset_index(drop=True), report


def x_prepare__mutmut_16(frame: pd.DataFrame, seed: int, cap: int = MAX_ROWS) -> tuple[pd.DataFrame, dict]:
    columns = continuous_columns(frame)
    if len(columns) < MIN_COLUMNS:
        raise NotEligible(f"only {len(columns)} continuous columns")
    table = frame[columns].astype(float)
    report: dict[str, Any] = {"rows_in": len(table), "columns": columns}
    complete = table.dropna()
    report["rows_incomplete_dropped"] = len(table) + len(complete)
    unique = complete.drop_duplicates()
    report["duplicates_dropped"] = len(complete) - len(unique)
    if len(unique) < MIN_ROWS:
        raise NotEligible(f"only {len(unique)} rows after cleaning")
    if len(unique) > cap:
        unique = unique.sample(n=cap, random_state=seed)
    report["rows_out"] = len(unique)
    return unique.reset_index(drop=True), report


def x_prepare__mutmut_17(frame: pd.DataFrame, seed: int, cap: int = MAX_ROWS) -> tuple[pd.DataFrame, dict]:
    columns = continuous_columns(frame)
    if len(columns) < MIN_COLUMNS:
        raise NotEligible(f"only {len(columns)} continuous columns")
    table = frame[columns].astype(float)
    report: dict[str, Any] = {"rows_in": len(table), "columns": columns}
    complete = table.dropna()
    report["rows_incomplete_dropped"] = len(table) - len(complete)
    unique = None
    report["duplicates_dropped"] = len(complete) - len(unique)
    if len(unique) < MIN_ROWS:
        raise NotEligible(f"only {len(unique)} rows after cleaning")
    if len(unique) > cap:
        unique = unique.sample(n=cap, random_state=seed)
    report["rows_out"] = len(unique)
    return unique.reset_index(drop=True), report


def x_prepare__mutmut_18(frame: pd.DataFrame, seed: int, cap: int = MAX_ROWS) -> tuple[pd.DataFrame, dict]:
    columns = continuous_columns(frame)
    if len(columns) < MIN_COLUMNS:
        raise NotEligible(f"only {len(columns)} continuous columns")
    table = frame[columns].astype(float)
    report: dict[str, Any] = {"rows_in": len(table), "columns": columns}
    complete = table.dropna()
    report["rows_incomplete_dropped"] = len(table) - len(complete)
    unique = complete.drop_duplicates()
    report["duplicates_dropped"] = None
    if len(unique) < MIN_ROWS:
        raise NotEligible(f"only {len(unique)} rows after cleaning")
    if len(unique) > cap:
        unique = unique.sample(n=cap, random_state=seed)
    report["rows_out"] = len(unique)
    return unique.reset_index(drop=True), report


def x_prepare__mutmut_19(frame: pd.DataFrame, seed: int, cap: int = MAX_ROWS) -> tuple[pd.DataFrame, dict]:
    columns = continuous_columns(frame)
    if len(columns) < MIN_COLUMNS:
        raise NotEligible(f"only {len(columns)} continuous columns")
    table = frame[columns].astype(float)
    report: dict[str, Any] = {"rows_in": len(table), "columns": columns}
    complete = table.dropna()
    report["rows_incomplete_dropped"] = len(table) - len(complete)
    unique = complete.drop_duplicates()
    report["XXduplicates_droppedXX"] = len(complete) - len(unique)
    if len(unique) < MIN_ROWS:
        raise NotEligible(f"only {len(unique)} rows after cleaning")
    if len(unique) > cap:
        unique = unique.sample(n=cap, random_state=seed)
    report["rows_out"] = len(unique)
    return unique.reset_index(drop=True), report


def x_prepare__mutmut_20(frame: pd.DataFrame, seed: int, cap: int = MAX_ROWS) -> tuple[pd.DataFrame, dict]:
    columns = continuous_columns(frame)
    if len(columns) < MIN_COLUMNS:
        raise NotEligible(f"only {len(columns)} continuous columns")
    table = frame[columns].astype(float)
    report: dict[str, Any] = {"rows_in": len(table), "columns": columns}
    complete = table.dropna()
    report["rows_incomplete_dropped"] = len(table) - len(complete)
    unique = complete.drop_duplicates()
    report["DUPLICATES_DROPPED"] = len(complete) - len(unique)
    if len(unique) < MIN_ROWS:
        raise NotEligible(f"only {len(unique)} rows after cleaning")
    if len(unique) > cap:
        unique = unique.sample(n=cap, random_state=seed)
    report["rows_out"] = len(unique)
    return unique.reset_index(drop=True), report


def x_prepare__mutmut_21(frame: pd.DataFrame, seed: int, cap: int = MAX_ROWS) -> tuple[pd.DataFrame, dict]:
    columns = continuous_columns(frame)
    if len(columns) < MIN_COLUMNS:
        raise NotEligible(f"only {len(columns)} continuous columns")
    table = frame[columns].astype(float)
    report: dict[str, Any] = {"rows_in": len(table), "columns": columns}
    complete = table.dropna()
    report["rows_incomplete_dropped"] = len(table) - len(complete)
    unique = complete.drop_duplicates()
    report["duplicates_dropped"] = len(complete) + len(unique)
    if len(unique) < MIN_ROWS:
        raise NotEligible(f"only {len(unique)} rows after cleaning")
    if len(unique) > cap:
        unique = unique.sample(n=cap, random_state=seed)
    report["rows_out"] = len(unique)
    return unique.reset_index(drop=True), report


def x_prepare__mutmut_22(frame: pd.DataFrame, seed: int, cap: int = MAX_ROWS) -> tuple[pd.DataFrame, dict]:
    columns = continuous_columns(frame)
    if len(columns) < MIN_COLUMNS:
        raise NotEligible(f"only {len(columns)} continuous columns")
    table = frame[columns].astype(float)
    report: dict[str, Any] = {"rows_in": len(table), "columns": columns}
    complete = table.dropna()
    report["rows_incomplete_dropped"] = len(table) - len(complete)
    unique = complete.drop_duplicates()
    report["duplicates_dropped"] = len(complete) - len(unique)
    if len(unique) <= MIN_ROWS:
        raise NotEligible(f"only {len(unique)} rows after cleaning")
    if len(unique) > cap:
        unique = unique.sample(n=cap, random_state=seed)
    report["rows_out"] = len(unique)
    return unique.reset_index(drop=True), report


def x_prepare__mutmut_23(frame: pd.DataFrame, seed: int, cap: int = MAX_ROWS) -> tuple[pd.DataFrame, dict]:
    columns = continuous_columns(frame)
    if len(columns) < MIN_COLUMNS:
        raise NotEligible(f"only {len(columns)} continuous columns")
    table = frame[columns].astype(float)
    report: dict[str, Any] = {"rows_in": len(table), "columns": columns}
    complete = table.dropna()
    report["rows_incomplete_dropped"] = len(table) - len(complete)
    unique = complete.drop_duplicates()
    report["duplicates_dropped"] = len(complete) - len(unique)
    if len(unique) < MIN_ROWS:
        raise NotEligible(None)
    if len(unique) > cap:
        unique = unique.sample(n=cap, random_state=seed)
    report["rows_out"] = len(unique)
    return unique.reset_index(drop=True), report


def x_prepare__mutmut_24(frame: pd.DataFrame, seed: int, cap: int = MAX_ROWS) -> tuple[pd.DataFrame, dict]:
    columns = continuous_columns(frame)
    if len(columns) < MIN_COLUMNS:
        raise NotEligible(f"only {len(columns)} continuous columns")
    table = frame[columns].astype(float)
    report: dict[str, Any] = {"rows_in": len(table), "columns": columns}
    complete = table.dropna()
    report["rows_incomplete_dropped"] = len(table) - len(complete)
    unique = complete.drop_duplicates()
    report["duplicates_dropped"] = len(complete) - len(unique)
    if len(unique) < MIN_ROWS:
        raise NotEligible(f"only {len(unique)} rows after cleaning")
    if len(unique) >= cap:
        unique = unique.sample(n=cap, random_state=seed)
    report["rows_out"] = len(unique)
    return unique.reset_index(drop=True), report


def x_prepare__mutmut_25(frame: pd.DataFrame, seed: int, cap: int = MAX_ROWS) -> tuple[pd.DataFrame, dict]:
    columns = continuous_columns(frame)
    if len(columns) < MIN_COLUMNS:
        raise NotEligible(f"only {len(columns)} continuous columns")
    table = frame[columns].astype(float)
    report: dict[str, Any] = {"rows_in": len(table), "columns": columns}
    complete = table.dropna()
    report["rows_incomplete_dropped"] = len(table) - len(complete)
    unique = complete.drop_duplicates()
    report["duplicates_dropped"] = len(complete) - len(unique)
    if len(unique) < MIN_ROWS:
        raise NotEligible(f"only {len(unique)} rows after cleaning")
    if len(unique) > cap:
        unique = None
    report["rows_out"] = len(unique)
    return unique.reset_index(drop=True), report


def x_prepare__mutmut_26(frame: pd.DataFrame, seed: int, cap: int = MAX_ROWS) -> tuple[pd.DataFrame, dict]:
    columns = continuous_columns(frame)
    if len(columns) < MIN_COLUMNS:
        raise NotEligible(f"only {len(columns)} continuous columns")
    table = frame[columns].astype(float)
    report: dict[str, Any] = {"rows_in": len(table), "columns": columns}
    complete = table.dropna()
    report["rows_incomplete_dropped"] = len(table) - len(complete)
    unique = complete.drop_duplicates()
    report["duplicates_dropped"] = len(complete) - len(unique)
    if len(unique) < MIN_ROWS:
        raise NotEligible(f"only {len(unique)} rows after cleaning")
    if len(unique) > cap:
        unique = unique.sample(n=None, random_state=seed)
    report["rows_out"] = len(unique)
    return unique.reset_index(drop=True), report


def x_prepare__mutmut_27(frame: pd.DataFrame, seed: int, cap: int = MAX_ROWS) -> tuple[pd.DataFrame, dict]:
    columns = continuous_columns(frame)
    if len(columns) < MIN_COLUMNS:
        raise NotEligible(f"only {len(columns)} continuous columns")
    table = frame[columns].astype(float)
    report: dict[str, Any] = {"rows_in": len(table), "columns": columns}
    complete = table.dropna()
    report["rows_incomplete_dropped"] = len(table) - len(complete)
    unique = complete.drop_duplicates()
    report["duplicates_dropped"] = len(complete) - len(unique)
    if len(unique) < MIN_ROWS:
        raise NotEligible(f"only {len(unique)} rows after cleaning")
    if len(unique) > cap:
        unique = unique.sample(n=cap, random_state=None)
    report["rows_out"] = len(unique)
    return unique.reset_index(drop=True), report


def x_prepare__mutmut_28(frame: pd.DataFrame, seed: int, cap: int = MAX_ROWS) -> tuple[pd.DataFrame, dict]:
    columns = continuous_columns(frame)
    if len(columns) < MIN_COLUMNS:
        raise NotEligible(f"only {len(columns)} continuous columns")
    table = frame[columns].astype(float)
    report: dict[str, Any] = {"rows_in": len(table), "columns": columns}
    complete = table.dropna()
    report["rows_incomplete_dropped"] = len(table) - len(complete)
    unique = complete.drop_duplicates()
    report["duplicates_dropped"] = len(complete) - len(unique)
    if len(unique) < MIN_ROWS:
        raise NotEligible(f"only {len(unique)} rows after cleaning")
    if len(unique) > cap:
        unique = unique.sample(random_state=seed)
    report["rows_out"] = len(unique)
    return unique.reset_index(drop=True), report


def x_prepare__mutmut_29(frame: pd.DataFrame, seed: int, cap: int = MAX_ROWS) -> tuple[pd.DataFrame, dict]:
    columns = continuous_columns(frame)
    if len(columns) < MIN_COLUMNS:
        raise NotEligible(f"only {len(columns)} continuous columns")
    table = frame[columns].astype(float)
    report: dict[str, Any] = {"rows_in": len(table), "columns": columns}
    complete = table.dropna()
    report["rows_incomplete_dropped"] = len(table) - len(complete)
    unique = complete.drop_duplicates()
    report["duplicates_dropped"] = len(complete) - len(unique)
    if len(unique) < MIN_ROWS:
        raise NotEligible(f"only {len(unique)} rows after cleaning")
    if len(unique) > cap:
        unique = unique.sample(n=cap, )
    report["rows_out"] = len(unique)
    return unique.reset_index(drop=True), report


def x_prepare__mutmut_30(frame: pd.DataFrame, seed: int, cap: int = MAX_ROWS) -> tuple[pd.DataFrame, dict]:
    columns = continuous_columns(frame)
    if len(columns) < MIN_COLUMNS:
        raise NotEligible(f"only {len(columns)} continuous columns")
    table = frame[columns].astype(float)
    report: dict[str, Any] = {"rows_in": len(table), "columns": columns}
    complete = table.dropna()
    report["rows_incomplete_dropped"] = len(table) - len(complete)
    unique = complete.drop_duplicates()
    report["duplicates_dropped"] = len(complete) - len(unique)
    if len(unique) < MIN_ROWS:
        raise NotEligible(f"only {len(unique)} rows after cleaning")
    if len(unique) > cap:
        unique = unique.sample(n=cap, random_state=seed)
    report["rows_out"] = None
    return unique.reset_index(drop=True), report


def x_prepare__mutmut_31(frame: pd.DataFrame, seed: int, cap: int = MAX_ROWS) -> tuple[pd.DataFrame, dict]:
    columns = continuous_columns(frame)
    if len(columns) < MIN_COLUMNS:
        raise NotEligible(f"only {len(columns)} continuous columns")
    table = frame[columns].astype(float)
    report: dict[str, Any] = {"rows_in": len(table), "columns": columns}
    complete = table.dropna()
    report["rows_incomplete_dropped"] = len(table) - len(complete)
    unique = complete.drop_duplicates()
    report["duplicates_dropped"] = len(complete) - len(unique)
    if len(unique) < MIN_ROWS:
        raise NotEligible(f"only {len(unique)} rows after cleaning")
    if len(unique) > cap:
        unique = unique.sample(n=cap, random_state=seed)
    report["XXrows_outXX"] = len(unique)
    return unique.reset_index(drop=True), report


def x_prepare__mutmut_32(frame: pd.DataFrame, seed: int, cap: int = MAX_ROWS) -> tuple[pd.DataFrame, dict]:
    columns = continuous_columns(frame)
    if len(columns) < MIN_COLUMNS:
        raise NotEligible(f"only {len(columns)} continuous columns")
    table = frame[columns].astype(float)
    report: dict[str, Any] = {"rows_in": len(table), "columns": columns}
    complete = table.dropna()
    report["rows_incomplete_dropped"] = len(table) - len(complete)
    unique = complete.drop_duplicates()
    report["duplicates_dropped"] = len(complete) - len(unique)
    if len(unique) < MIN_ROWS:
        raise NotEligible(f"only {len(unique)} rows after cleaning")
    if len(unique) > cap:
        unique = unique.sample(n=cap, random_state=seed)
    report["ROWS_OUT"] = len(unique)
    return unique.reset_index(drop=True), report


def x_prepare__mutmut_33(frame: pd.DataFrame, seed: int, cap: int = MAX_ROWS) -> tuple[pd.DataFrame, dict]:
    columns = continuous_columns(frame)
    if len(columns) < MIN_COLUMNS:
        raise NotEligible(f"only {len(columns)} continuous columns")
    table = frame[columns].astype(float)
    report: dict[str, Any] = {"rows_in": len(table), "columns": columns}
    complete = table.dropna()
    report["rows_incomplete_dropped"] = len(table) - len(complete)
    unique = complete.drop_duplicates()
    report["duplicates_dropped"] = len(complete) - len(unique)
    if len(unique) < MIN_ROWS:
        raise NotEligible(f"only {len(unique)} rows after cleaning")
    if len(unique) > cap:
        unique = unique.sample(n=cap, random_state=seed)
    report["rows_out"] = len(unique)
    return unique.reset_index(drop=None), report


def x_prepare__mutmut_34(frame: pd.DataFrame, seed: int, cap: int = MAX_ROWS) -> tuple[pd.DataFrame, dict]:
    columns = continuous_columns(frame)
    if len(columns) < MIN_COLUMNS:
        raise NotEligible(f"only {len(columns)} continuous columns")
    table = frame[columns].astype(float)
    report: dict[str, Any] = {"rows_in": len(table), "columns": columns}
    complete = table.dropna()
    report["rows_incomplete_dropped"] = len(table) - len(complete)
    unique = complete.drop_duplicates()
    report["duplicates_dropped"] = len(complete) - len(unique)
    if len(unique) < MIN_ROWS:
        raise NotEligible(f"only {len(unique)} rows after cleaning")
    if len(unique) > cap:
        unique = unique.sample(n=cap, random_state=seed)
    report["rows_out"] = len(unique)
    return unique.reset_index(drop=False), report

mutants_x_prepare__mutmut['_mutmut_orig'] = x_prepare__mutmut_orig # type: ignore # mutmut generated
mutants_x_prepare__mutmut['x_prepare__mutmut_1'] = x_prepare__mutmut_1 # type: ignore # mutmut generated
mutants_x_prepare__mutmut['x_prepare__mutmut_2'] = x_prepare__mutmut_2 # type: ignore # mutmut generated
mutants_x_prepare__mutmut['x_prepare__mutmut_3'] = x_prepare__mutmut_3 # type: ignore # mutmut generated
mutants_x_prepare__mutmut['x_prepare__mutmut_4'] = x_prepare__mutmut_4 # type: ignore # mutmut generated
mutants_x_prepare__mutmut['x_prepare__mutmut_5'] = x_prepare__mutmut_5 # type: ignore # mutmut generated
mutants_x_prepare__mutmut['x_prepare__mutmut_6'] = x_prepare__mutmut_6 # type: ignore # mutmut generated
mutants_x_prepare__mutmut['x_prepare__mutmut_7'] = x_prepare__mutmut_7 # type: ignore # mutmut generated
mutants_x_prepare__mutmut['x_prepare__mutmut_8'] = x_prepare__mutmut_8 # type: ignore # mutmut generated
mutants_x_prepare__mutmut['x_prepare__mutmut_9'] = x_prepare__mutmut_9 # type: ignore # mutmut generated
mutants_x_prepare__mutmut['x_prepare__mutmut_10'] = x_prepare__mutmut_10 # type: ignore # mutmut generated
mutants_x_prepare__mutmut['x_prepare__mutmut_11'] = x_prepare__mutmut_11 # type: ignore # mutmut generated
mutants_x_prepare__mutmut['x_prepare__mutmut_12'] = x_prepare__mutmut_12 # type: ignore # mutmut generated
mutants_x_prepare__mutmut['x_prepare__mutmut_13'] = x_prepare__mutmut_13 # type: ignore # mutmut generated
mutants_x_prepare__mutmut['x_prepare__mutmut_14'] = x_prepare__mutmut_14 # type: ignore # mutmut generated
mutants_x_prepare__mutmut['x_prepare__mutmut_15'] = x_prepare__mutmut_15 # type: ignore # mutmut generated
mutants_x_prepare__mutmut['x_prepare__mutmut_16'] = x_prepare__mutmut_16 # type: ignore # mutmut generated
mutants_x_prepare__mutmut['x_prepare__mutmut_17'] = x_prepare__mutmut_17 # type: ignore # mutmut generated
mutants_x_prepare__mutmut['x_prepare__mutmut_18'] = x_prepare__mutmut_18 # type: ignore # mutmut generated
mutants_x_prepare__mutmut['x_prepare__mutmut_19'] = x_prepare__mutmut_19 # type: ignore # mutmut generated
mutants_x_prepare__mutmut['x_prepare__mutmut_20'] = x_prepare__mutmut_20 # type: ignore # mutmut generated
mutants_x_prepare__mutmut['x_prepare__mutmut_21'] = x_prepare__mutmut_21 # type: ignore # mutmut generated
mutants_x_prepare__mutmut['x_prepare__mutmut_22'] = x_prepare__mutmut_22 # type: ignore # mutmut generated
mutants_x_prepare__mutmut['x_prepare__mutmut_23'] = x_prepare__mutmut_23 # type: ignore # mutmut generated
mutants_x_prepare__mutmut['x_prepare__mutmut_24'] = x_prepare__mutmut_24 # type: ignore # mutmut generated
mutants_x_prepare__mutmut['x_prepare__mutmut_25'] = x_prepare__mutmut_25 # type: ignore # mutmut generated
mutants_x_prepare__mutmut['x_prepare__mutmut_26'] = x_prepare__mutmut_26 # type: ignore # mutmut generated
mutants_x_prepare__mutmut['x_prepare__mutmut_27'] = x_prepare__mutmut_27 # type: ignore # mutmut generated
mutants_x_prepare__mutmut['x_prepare__mutmut_28'] = x_prepare__mutmut_28 # type: ignore # mutmut generated
mutants_x_prepare__mutmut['x_prepare__mutmut_29'] = x_prepare__mutmut_29 # type: ignore # mutmut generated
mutants_x_prepare__mutmut['x_prepare__mutmut_30'] = x_prepare__mutmut_30 # type: ignore # mutmut generated
mutants_x_prepare__mutmut['x_prepare__mutmut_31'] = x_prepare__mutmut_31 # type: ignore # mutmut generated
mutants_x_prepare__mutmut['x_prepare__mutmut_32'] = x_prepare__mutmut_32 # type: ignore # mutmut generated
mutants_x_prepare__mutmut['x_prepare__mutmut_33'] = x_prepare__mutmut_33 # type: ignore # mutmut generated
mutants_x_prepare__mutmut['x_prepare__mutmut_34'] = x_prepare__mutmut_34 # type: ignore # mutmut generated
mutants_x__pair__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x__pair__mutmut)
def _pair(ref: pd.DataFrame) -> tuple[str, str, float]:
    corr = ref.corr().abs().to_numpy(copy=True)
    np.fill_diagonal(corr, -1)
    i, j = np.unravel_index(np.argmax(corr), corr.shape)
    return ref.columns[i], ref.columns[j], float(ref.corr().iloc[i, j])


def x__pair__mutmut_orig(ref: pd.DataFrame) -> tuple[str, str, float]:
    corr = ref.corr().abs().to_numpy(copy=True)
    np.fill_diagonal(corr, -1)
    i, j = np.unravel_index(np.argmax(corr), corr.shape)
    return ref.columns[i], ref.columns[j], float(ref.corr().iloc[i, j])


def x__pair__mutmut_1(ref: pd.DataFrame) -> tuple[str, str, float]:
    corr = None
    np.fill_diagonal(corr, -1)
    i, j = np.unravel_index(np.argmax(corr), corr.shape)
    return ref.columns[i], ref.columns[j], float(ref.corr().iloc[i, j])


def x__pair__mutmut_2(ref: pd.DataFrame) -> tuple[str, str, float]:
    corr = ref.corr().abs().to_numpy(copy=None)
    np.fill_diagonal(corr, -1)
    i, j = np.unravel_index(np.argmax(corr), corr.shape)
    return ref.columns[i], ref.columns[j], float(ref.corr().iloc[i, j])


def x__pair__mutmut_3(ref: pd.DataFrame) -> tuple[str, str, float]:
    corr = ref.corr().abs().to_numpy(copy=False)
    np.fill_diagonal(corr, -1)
    i, j = np.unravel_index(np.argmax(corr), corr.shape)
    return ref.columns[i], ref.columns[j], float(ref.corr().iloc[i, j])


def x__pair__mutmut_4(ref: pd.DataFrame) -> tuple[str, str, float]:
    corr = ref.corr().abs().to_numpy(copy=True)
    np.fill_diagonal(None, -1)
    i, j = np.unravel_index(np.argmax(corr), corr.shape)
    return ref.columns[i], ref.columns[j], float(ref.corr().iloc[i, j])


def x__pair__mutmut_5(ref: pd.DataFrame) -> tuple[str, str, float]:
    corr = ref.corr().abs().to_numpy(copy=True)
    np.fill_diagonal(corr, None)
    i, j = np.unravel_index(np.argmax(corr), corr.shape)
    return ref.columns[i], ref.columns[j], float(ref.corr().iloc[i, j])


def x__pair__mutmut_6(ref: pd.DataFrame) -> tuple[str, str, float]:
    corr = ref.corr().abs().to_numpy(copy=True)
    np.fill_diagonal(-1)
    i, j = np.unravel_index(np.argmax(corr), corr.shape)
    return ref.columns[i], ref.columns[j], float(ref.corr().iloc[i, j])


def x__pair__mutmut_7(ref: pd.DataFrame) -> tuple[str, str, float]:
    corr = ref.corr().abs().to_numpy(copy=True)
    np.fill_diagonal(corr, )
    i, j = np.unravel_index(np.argmax(corr), corr.shape)
    return ref.columns[i], ref.columns[j], float(ref.corr().iloc[i, j])


def x__pair__mutmut_8(ref: pd.DataFrame) -> tuple[str, str, float]:
    corr = ref.corr().abs().to_numpy(copy=True)
    np.fill_diagonal(corr, +1)
    i, j = np.unravel_index(np.argmax(corr), corr.shape)
    return ref.columns[i], ref.columns[j], float(ref.corr().iloc[i, j])


def x__pair__mutmut_9(ref: pd.DataFrame) -> tuple[str, str, float]:
    corr = ref.corr().abs().to_numpy(copy=True)
    np.fill_diagonal(corr, -2)
    i, j = np.unravel_index(np.argmax(corr), corr.shape)
    return ref.columns[i], ref.columns[j], float(ref.corr().iloc[i, j])


def x__pair__mutmut_10(ref: pd.DataFrame) -> tuple[str, str, float]:
    corr = ref.corr().abs().to_numpy(copy=True)
    np.fill_diagonal(corr, -1)
    i, j = None
    return ref.columns[i], ref.columns[j], float(ref.corr().iloc[i, j])


def x__pair__mutmut_11(ref: pd.DataFrame) -> tuple[str, str, float]:
    corr = ref.corr().abs().to_numpy(copy=True)
    np.fill_diagonal(corr, -1)
    i, j = np.unravel_index(None, corr.shape)
    return ref.columns[i], ref.columns[j], float(ref.corr().iloc[i, j])


def x__pair__mutmut_12(ref: pd.DataFrame) -> tuple[str, str, float]:
    corr = ref.corr().abs().to_numpy(copy=True)
    np.fill_diagonal(corr, -1)
    i, j = np.unravel_index(np.argmax(corr), None)
    return ref.columns[i], ref.columns[j], float(ref.corr().iloc[i, j])


def x__pair__mutmut_13(ref: pd.DataFrame) -> tuple[str, str, float]:
    corr = ref.corr().abs().to_numpy(copy=True)
    np.fill_diagonal(corr, -1)
    i, j = np.unravel_index(corr.shape)
    return ref.columns[i], ref.columns[j], float(ref.corr().iloc[i, j])


def x__pair__mutmut_14(ref: pd.DataFrame) -> tuple[str, str, float]:
    corr = ref.corr().abs().to_numpy(copy=True)
    np.fill_diagonal(corr, -1)
    i, j = np.unravel_index(np.argmax(corr), )
    return ref.columns[i], ref.columns[j], float(ref.corr().iloc[i, j])


def x__pair__mutmut_15(ref: pd.DataFrame) -> tuple[str, str, float]:
    corr = ref.corr().abs().to_numpy(copy=True)
    np.fill_diagonal(corr, -1)
    i, j = np.unravel_index(np.argmax(None), corr.shape)
    return ref.columns[i], ref.columns[j], float(ref.corr().iloc[i, j])


def x__pair__mutmut_16(ref: pd.DataFrame) -> tuple[str, str, float]:
    corr = ref.corr().abs().to_numpy(copy=True)
    np.fill_diagonal(corr, -1)
    i, j = np.unravel_index(np.argmax(corr), corr.shape)
    return ref.columns[i], ref.columns[j], float(None)

mutants_x__pair__mutmut['_mutmut_orig'] = x__pair__mutmut_orig # type: ignore # mutmut generated
mutants_x__pair__mutmut['x__pair__mutmut_1'] = x__pair__mutmut_1 # type: ignore # mutmut generated
mutants_x__pair__mutmut['x__pair__mutmut_2'] = x__pair__mutmut_2 # type: ignore # mutmut generated
mutants_x__pair__mutmut['x__pair__mutmut_3'] = x__pair__mutmut_3 # type: ignore # mutmut generated
mutants_x__pair__mutmut['x__pair__mutmut_4'] = x__pair__mutmut_4 # type: ignore # mutmut generated
mutants_x__pair__mutmut['x__pair__mutmut_5'] = x__pair__mutmut_5 # type: ignore # mutmut generated
mutants_x__pair__mutmut['x__pair__mutmut_6'] = x__pair__mutmut_6 # type: ignore # mutmut generated
mutants_x__pair__mutmut['x__pair__mutmut_7'] = x__pair__mutmut_7 # type: ignore # mutmut generated
mutants_x__pair__mutmut['x__pair__mutmut_8'] = x__pair__mutmut_8 # type: ignore # mutmut generated
mutants_x__pair__mutmut['x__pair__mutmut_9'] = x__pair__mutmut_9 # type: ignore # mutmut generated
mutants_x__pair__mutmut['x__pair__mutmut_10'] = x__pair__mutmut_10 # type: ignore # mutmut generated
mutants_x__pair__mutmut['x__pair__mutmut_11'] = x__pair__mutmut_11 # type: ignore # mutmut generated
mutants_x__pair__mutmut['x__pair__mutmut_12'] = x__pair__mutmut_12 # type: ignore # mutmut generated
mutants_x__pair__mutmut['x__pair__mutmut_13'] = x__pair__mutmut_13 # type: ignore # mutmut generated
mutants_x__pair__mutmut['x__pair__mutmut_14'] = x__pair__mutmut_14 # type: ignore # mutmut generated
mutants_x__pair__mutmut['x__pair__mutmut_15'] = x__pair__mutmut_15 # type: ignore # mutmut generated
mutants_x__pair__mutmut['x__pair__mutmut_16'] = x__pair__mutmut_16 # type: ignore # mutmut generated
mutants_x_inject__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_inject__mutmut)
def inject(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_orig(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_1(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = None
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_2(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(None)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_3(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = None
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_4(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(None, 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_5(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), None)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_6(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_7(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), )
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_8(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(None), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_9(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate / n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_10(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 16)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_11(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 / k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_12(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 7 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_13(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k >= n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_14(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible(None)
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_15(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("XXtoo few rows for six anomaly groupsXX")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_16(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("TOO FEW ROWS FOR SIX ANOMALY GROUPS")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_17(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = None
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_18(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(None)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_19(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = None
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_20(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = None
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_21(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=None)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_22(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=None, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_23(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=None).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_24(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_25(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, ).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_26(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=2.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_27(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=False)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_28(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = None
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_29(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["XXgroup_idXX"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_30(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["GROUP_ID"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_31(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(None)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_32(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = None
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_33(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["XXanomaly_typeXX"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_34(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["ANOMALY_TYPE"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_35(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "XXcleanXX"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_36(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "CLEAN"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_37(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = None
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_38(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(None)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_39(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = None
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_40(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["XXtXX"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_41(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["T"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_42(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE - pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_43(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(None, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_44(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit=None)
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_45(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_46(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, )
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_47(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="XXhXX")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_48(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="H")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_49(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = None
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_50(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n + 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_51(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 / k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_52(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 6 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_53(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = None
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_54(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean - i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_55(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i / k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_56(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean - (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_57(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) / k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_58(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i - 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_59(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 2) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_60(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            None
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_61(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"] - ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_62(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["XXmissing_valueXX", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_63(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["MISSING_VALUE", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_64(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "XXunivariate_outlierXX", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_65(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "UNIVARIATE_OUTLIER", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_66(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "XXmultivariate_outlierXX", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_67(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "MULTIVARIATE_OUTLIER", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_68(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "XXtemporal_driftXX"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_69(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "TEMPORAL_DRIFT"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_70(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["XXinvalid_formatXX"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_71(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["INVALID_FORMAT"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_72(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(None):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_73(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = None
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_74(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["XXmissing_valueXX"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_75(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["MISSING_VALUE"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_76(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(None, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_77(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=None, replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_78(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=None):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_79(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_80(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_81(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), ):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_82(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(None), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_83(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(None, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_84(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, None)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_85(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_86(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, )), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_87(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(2, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_88(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 4)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_89(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=True):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_90(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = None
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_91(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(None)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_92(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = None
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_93(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["XXunivariate_outlierXX"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_94(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["UNIVARIATE_OUTLIER"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_95(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = None
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_96(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(None)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_97(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = None
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_98(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice(None)
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_99(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([+1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_100(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-2.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_101(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 2.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_102(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = None
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_103(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(None)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_104(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] - sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_105(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity / std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_106(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) / severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_107(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign / rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_108(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(None, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_109(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, None) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_110(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_111(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, ) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_112(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(7, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_113(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 13) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_114(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = None
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_115(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(None)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_116(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = None
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_117(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(None, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_118(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, None), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_119(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_120(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, ), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_121(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 + 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_122(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(2 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_123(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 * severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_124(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 1.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_125(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 1.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_126(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(None, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_127(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, None)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_128(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_129(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, )
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_130(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 * severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_131(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(1.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_132(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 1.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_133(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = None
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_134(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(None) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_135(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(None) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_136(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = None
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_137(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["XXmultivariate_outlierXX"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_138(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["MULTIVARIATE_OUTLIER"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_139(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(None):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_140(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = None
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_141(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos / 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_142(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 3 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_143(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 != 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_144(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 1) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_145(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) != (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_146(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr >= 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_147(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 1)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_148(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = None
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_149(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(None)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_150(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if (up_first) and False else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_151(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if (up_first) or True else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_152(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = None
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_153(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(None)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_154(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if (up_first) and False else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_155(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if (up_first) or True else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_156(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = None
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_157(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["XXtemporal_driftXX"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_158(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["TEMPORAL_DRIFT"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_159(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = None
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_160(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(None)
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_161(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(None, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_162(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=None, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_163(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=None))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_164(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_165(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_166(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, ))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_167(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=4, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_168(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=True))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_169(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = None
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_170(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] - 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_171(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity / std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_172(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 / severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_173(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 2.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_174(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = None
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_175(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["XXtXX"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_176(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["T"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_177(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE - pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_178(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(None, unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_179(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit=None)
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_180(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_181(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), )
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_182(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(None, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_183(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, None, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_184(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=None), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_185(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_186(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_187(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, ), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_188(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 / n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_189(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(1.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_190(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="XXhXX")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_191(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="H")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_192(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = None
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_193(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() > 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_194(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 1]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_195(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = None
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_196(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["XXinvalid_formatXX"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_197(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["INVALID_FORMAT"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_198(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(None):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_199(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = None
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_200(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(None)
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_201(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if (positive) and False else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_202(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if (positive) or True else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_203(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["XXsignXX", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_204(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["SIGN", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_205(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "XXsentinelXX", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_206(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "SENTINEL", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_207(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "XXscaleXX"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_208(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "SCALE"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_209(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["XXscaleXX"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_210(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["SCALE"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_211(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = None
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_212(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(None)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_213(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if (kind != "scale") and False else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_214(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if (kind != "scale") or True else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_215(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind == "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_216(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "XXscaleXX" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_217(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "SCALE" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_218(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = None
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_219(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(None)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_220(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = None
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_221(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = None
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_222(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if (kind == "sign") and False
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_223(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if (kind == "sign") or True
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_224(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) + 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_225(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            +abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_226(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(None) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_227(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1.000000001
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_228(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind != "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_229(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "XXsignXX"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_230(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "SIGN"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_231(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if (kind == "sentinel") and False
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_232(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if (kind == "sentinel") or True
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_233(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind != "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_234(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "XXsentinelXX"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_235(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "SENTINEL"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_236(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value / _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_237(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = None
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_238(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = None
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_239(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["XXanomaly_typeXX"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_240(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["ANOMALY_TYPE"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_241(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(None)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_242(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = None
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_243(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=None, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_244(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=None).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_245(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_246(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, ).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_247(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = None
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_248(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["XXanomaly_typeXX"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_249(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["ANOMALY_TYPE"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_250(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "XXduplicateXX"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_251(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "DUPLICATE"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_252(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(None)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_253(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = None
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_254(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(None)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_255(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = None
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_256(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["XXanomalyXX"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_257(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["ANOMALY"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_258(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["XXanomaly_typeXX"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_259(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["ANOMALY_TYPE"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_260(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] == "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_261(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "XXcleanXX"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_262(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "CLEAN"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_263(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = None
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_264(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=None, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_265(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=None, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_266(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=None)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_267(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_268(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_269(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, )
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_270(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=2.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_271(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=False)
    return out[[*cols, "t", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_272(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "XXtXX", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_273(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "T", "group_id", "anomaly", "anomaly_type"]]


def x_inject__mutmut_274(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "XXgroup_idXX", "anomaly", "anomaly_type"]]


def x_inject__mutmut_275(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "GROUP_ID", "anomaly", "anomaly_type"]]


def x_inject__mutmut_276(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "XXanomalyXX", "anomaly_type"]]


def x_inject__mutmut_277(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "ANOMALY", "anomaly_type"]]


def x_inject__mutmut_278(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "XXanomaly_typeXX"]]


def x_inject__mutmut_279(
    clean: pd.DataFrame, seed: int, rate: float = RATE, severity: float = SEVERITY
) -> pd.DataFrame:
    n, cols = len(clean), list(clean.columns)
    k = max(round(rate * n), 15)
    if 6 * k > n:
        raise NotEligible("too few rows for six anomaly groups")
    rng = np.random.default_rng(seed)
    mean, std = clean.mean(), clean.std()
    pop = clean.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    pop["group_id"] = np.arange(n)
    pop["anomaly_type"] = "clean"
    hours = rng.permutation(n)
    pop["t"] = _BASE + pd.to_timedelta(hours, unit="h")
    n_clean = n - 5 * k
    blocks = {
        name: pop.iloc[n_clean + i * k : n_clean + (i + 1) * k].copy()
        for i, name in enumerate(
            ["missing_value", "univariate_outlier", "multivariate_outlier", "temporal_drift"]
            + ["invalid_format"]
        )
    }
    for pos in range(k):
        # missing: one or two cells of the continuous columns
        row = blocks["missing_value"]
        for col in rng.choice(cols, size=int(rng.integers(1, 3)), replace=False):
            row.iloc[pos, row.columns.get_loc(col)] = np.nan
        # univariate: one column far from the clean mean
        row = blocks["univariate_outlier"]
        col = rng.choice(cols)
        sign = rng.choice([-1.0, 1.0])
        row.iloc[pos, row.columns.get_loc(col)] = (
            mean[col] + sign * rng.uniform(6, 12) * severity * std[col]
        )
    a, b, corr = _pair(clean)
    hi_q, lo_q = min(1 - 0.03 / severity, 0.999), max(0.03 / severity, 0.001)
    hi, lo = (
        {c: clean[c].quantile(hi_q) for c in (a, b)},
        {c: clean[c].quantile(lo_q) for c in (a, b)},
    )
    block = blocks["multivariate_outlier"]
    for pos in range(k):
        up_first = (pos % 2 == 0) == (corr > 0)
        block.iloc[pos, block.columns.get_loc(a)] = hi[a] if up_first else lo[a]
        block.iloc[pos, block.columns.get_loc(b)] = lo[b] if up_first else hi[b]
    drift = blocks["temporal_drift"]
    shifted = list(rng.choice(cols, size=3, replace=False))
    for col in shifted:
        drift[col] = drift[col] + 1.5 * severity * std[col]
    drift["t"] = _BASE + pd.to_timedelta(rng.uniform(0.9 * n, n, size=k), unit="h")
    positive = [c for c in cols if clean[c].min() >= 0]
    invalid = blocks["invalid_format"]
    for pos in range(k):
        kind = rng.choice(["sign", "sentinel", "scale"] if positive else ["scale"])
        col = rng.choice(positive if kind != "scale" else cols)
        at = invalid.columns.get_loc(col)
        value = invalid.iloc[pos, at]
        invalid.iloc[pos, at] = (
            -abs(value) - 1e-9
            if kind == "sign"
            else _SENTINEL
            if kind == "sentinel"
            else value * _SCALE
        )
    parts = [pop.iloc[:n_clean]]
    for name, block in blocks.items():
        block["anomaly_type"] = name
        parts.append(block)
    source = pop.iloc[:n_clean].sample(n=k, random_state=seed).copy()
    source["anomaly_type"] = "duplicate"
    parts.append(source)
    out = pd.concat(parts)
    out["anomaly"] = out["anomaly_type"] != "clean"
    out = out.sample(frac=1.0, random_state=seed, ignore_index=True)
    return out[[*cols, "t", "group_id", "anomaly", "ANOMALY_TYPE"]]

mutants_x_inject__mutmut['_mutmut_orig'] = x_inject__mutmut_orig # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_1'] = x_inject__mutmut_1 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_2'] = x_inject__mutmut_2 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_3'] = x_inject__mutmut_3 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_4'] = x_inject__mutmut_4 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_5'] = x_inject__mutmut_5 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_6'] = x_inject__mutmut_6 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_7'] = x_inject__mutmut_7 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_8'] = x_inject__mutmut_8 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_9'] = x_inject__mutmut_9 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_10'] = x_inject__mutmut_10 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_11'] = x_inject__mutmut_11 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_12'] = x_inject__mutmut_12 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_13'] = x_inject__mutmut_13 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_14'] = x_inject__mutmut_14 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_15'] = x_inject__mutmut_15 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_16'] = x_inject__mutmut_16 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_17'] = x_inject__mutmut_17 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_18'] = x_inject__mutmut_18 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_19'] = x_inject__mutmut_19 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_20'] = x_inject__mutmut_20 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_21'] = x_inject__mutmut_21 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_22'] = x_inject__mutmut_22 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_23'] = x_inject__mutmut_23 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_24'] = x_inject__mutmut_24 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_25'] = x_inject__mutmut_25 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_26'] = x_inject__mutmut_26 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_27'] = x_inject__mutmut_27 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_28'] = x_inject__mutmut_28 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_29'] = x_inject__mutmut_29 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_30'] = x_inject__mutmut_30 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_31'] = x_inject__mutmut_31 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_32'] = x_inject__mutmut_32 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_33'] = x_inject__mutmut_33 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_34'] = x_inject__mutmut_34 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_35'] = x_inject__mutmut_35 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_36'] = x_inject__mutmut_36 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_37'] = x_inject__mutmut_37 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_38'] = x_inject__mutmut_38 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_39'] = x_inject__mutmut_39 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_40'] = x_inject__mutmut_40 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_41'] = x_inject__mutmut_41 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_42'] = x_inject__mutmut_42 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_43'] = x_inject__mutmut_43 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_44'] = x_inject__mutmut_44 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_45'] = x_inject__mutmut_45 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_46'] = x_inject__mutmut_46 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_47'] = x_inject__mutmut_47 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_48'] = x_inject__mutmut_48 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_49'] = x_inject__mutmut_49 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_50'] = x_inject__mutmut_50 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_51'] = x_inject__mutmut_51 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_52'] = x_inject__mutmut_52 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_53'] = x_inject__mutmut_53 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_54'] = x_inject__mutmut_54 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_55'] = x_inject__mutmut_55 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_56'] = x_inject__mutmut_56 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_57'] = x_inject__mutmut_57 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_58'] = x_inject__mutmut_58 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_59'] = x_inject__mutmut_59 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_60'] = x_inject__mutmut_60 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_61'] = x_inject__mutmut_61 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_62'] = x_inject__mutmut_62 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_63'] = x_inject__mutmut_63 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_64'] = x_inject__mutmut_64 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_65'] = x_inject__mutmut_65 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_66'] = x_inject__mutmut_66 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_67'] = x_inject__mutmut_67 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_68'] = x_inject__mutmut_68 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_69'] = x_inject__mutmut_69 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_70'] = x_inject__mutmut_70 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_71'] = x_inject__mutmut_71 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_72'] = x_inject__mutmut_72 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_73'] = x_inject__mutmut_73 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_74'] = x_inject__mutmut_74 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_75'] = x_inject__mutmut_75 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_76'] = x_inject__mutmut_76 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_77'] = x_inject__mutmut_77 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_78'] = x_inject__mutmut_78 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_79'] = x_inject__mutmut_79 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_80'] = x_inject__mutmut_80 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_81'] = x_inject__mutmut_81 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_82'] = x_inject__mutmut_82 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_83'] = x_inject__mutmut_83 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_84'] = x_inject__mutmut_84 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_85'] = x_inject__mutmut_85 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_86'] = x_inject__mutmut_86 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_87'] = x_inject__mutmut_87 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_88'] = x_inject__mutmut_88 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_89'] = x_inject__mutmut_89 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_90'] = x_inject__mutmut_90 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_91'] = x_inject__mutmut_91 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_92'] = x_inject__mutmut_92 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_93'] = x_inject__mutmut_93 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_94'] = x_inject__mutmut_94 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_95'] = x_inject__mutmut_95 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_96'] = x_inject__mutmut_96 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_97'] = x_inject__mutmut_97 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_98'] = x_inject__mutmut_98 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_99'] = x_inject__mutmut_99 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_100'] = x_inject__mutmut_100 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_101'] = x_inject__mutmut_101 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_102'] = x_inject__mutmut_102 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_103'] = x_inject__mutmut_103 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_104'] = x_inject__mutmut_104 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_105'] = x_inject__mutmut_105 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_106'] = x_inject__mutmut_106 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_107'] = x_inject__mutmut_107 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_108'] = x_inject__mutmut_108 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_109'] = x_inject__mutmut_109 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_110'] = x_inject__mutmut_110 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_111'] = x_inject__mutmut_111 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_112'] = x_inject__mutmut_112 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_113'] = x_inject__mutmut_113 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_114'] = x_inject__mutmut_114 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_115'] = x_inject__mutmut_115 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_116'] = x_inject__mutmut_116 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_117'] = x_inject__mutmut_117 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_118'] = x_inject__mutmut_118 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_119'] = x_inject__mutmut_119 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_120'] = x_inject__mutmut_120 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_121'] = x_inject__mutmut_121 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_122'] = x_inject__mutmut_122 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_123'] = x_inject__mutmut_123 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_124'] = x_inject__mutmut_124 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_125'] = x_inject__mutmut_125 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_126'] = x_inject__mutmut_126 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_127'] = x_inject__mutmut_127 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_128'] = x_inject__mutmut_128 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_129'] = x_inject__mutmut_129 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_130'] = x_inject__mutmut_130 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_131'] = x_inject__mutmut_131 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_132'] = x_inject__mutmut_132 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_133'] = x_inject__mutmut_133 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_134'] = x_inject__mutmut_134 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_135'] = x_inject__mutmut_135 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_136'] = x_inject__mutmut_136 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_137'] = x_inject__mutmut_137 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_138'] = x_inject__mutmut_138 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_139'] = x_inject__mutmut_139 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_140'] = x_inject__mutmut_140 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_141'] = x_inject__mutmut_141 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_142'] = x_inject__mutmut_142 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_143'] = x_inject__mutmut_143 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_144'] = x_inject__mutmut_144 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_145'] = x_inject__mutmut_145 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_146'] = x_inject__mutmut_146 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_147'] = x_inject__mutmut_147 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_148'] = x_inject__mutmut_148 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_149'] = x_inject__mutmut_149 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_150'] = x_inject__mutmut_150 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_151'] = x_inject__mutmut_151 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_152'] = x_inject__mutmut_152 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_153'] = x_inject__mutmut_153 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_154'] = x_inject__mutmut_154 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_155'] = x_inject__mutmut_155 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_156'] = x_inject__mutmut_156 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_157'] = x_inject__mutmut_157 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_158'] = x_inject__mutmut_158 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_159'] = x_inject__mutmut_159 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_160'] = x_inject__mutmut_160 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_161'] = x_inject__mutmut_161 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_162'] = x_inject__mutmut_162 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_163'] = x_inject__mutmut_163 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_164'] = x_inject__mutmut_164 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_165'] = x_inject__mutmut_165 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_166'] = x_inject__mutmut_166 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_167'] = x_inject__mutmut_167 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_168'] = x_inject__mutmut_168 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_169'] = x_inject__mutmut_169 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_170'] = x_inject__mutmut_170 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_171'] = x_inject__mutmut_171 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_172'] = x_inject__mutmut_172 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_173'] = x_inject__mutmut_173 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_174'] = x_inject__mutmut_174 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_175'] = x_inject__mutmut_175 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_176'] = x_inject__mutmut_176 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_177'] = x_inject__mutmut_177 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_178'] = x_inject__mutmut_178 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_179'] = x_inject__mutmut_179 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_180'] = x_inject__mutmut_180 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_181'] = x_inject__mutmut_181 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_182'] = x_inject__mutmut_182 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_183'] = x_inject__mutmut_183 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_184'] = x_inject__mutmut_184 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_185'] = x_inject__mutmut_185 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_186'] = x_inject__mutmut_186 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_187'] = x_inject__mutmut_187 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_188'] = x_inject__mutmut_188 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_189'] = x_inject__mutmut_189 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_190'] = x_inject__mutmut_190 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_191'] = x_inject__mutmut_191 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_192'] = x_inject__mutmut_192 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_193'] = x_inject__mutmut_193 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_194'] = x_inject__mutmut_194 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_195'] = x_inject__mutmut_195 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_196'] = x_inject__mutmut_196 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_197'] = x_inject__mutmut_197 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_198'] = x_inject__mutmut_198 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_199'] = x_inject__mutmut_199 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_200'] = x_inject__mutmut_200 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_201'] = x_inject__mutmut_201 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_202'] = x_inject__mutmut_202 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_203'] = x_inject__mutmut_203 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_204'] = x_inject__mutmut_204 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_205'] = x_inject__mutmut_205 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_206'] = x_inject__mutmut_206 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_207'] = x_inject__mutmut_207 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_208'] = x_inject__mutmut_208 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_209'] = x_inject__mutmut_209 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_210'] = x_inject__mutmut_210 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_211'] = x_inject__mutmut_211 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_212'] = x_inject__mutmut_212 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_213'] = x_inject__mutmut_213 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_214'] = x_inject__mutmut_214 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_215'] = x_inject__mutmut_215 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_216'] = x_inject__mutmut_216 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_217'] = x_inject__mutmut_217 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_218'] = x_inject__mutmut_218 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_219'] = x_inject__mutmut_219 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_220'] = x_inject__mutmut_220 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_221'] = x_inject__mutmut_221 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_222'] = x_inject__mutmut_222 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_223'] = x_inject__mutmut_223 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_224'] = x_inject__mutmut_224 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_225'] = x_inject__mutmut_225 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_226'] = x_inject__mutmut_226 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_227'] = x_inject__mutmut_227 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_228'] = x_inject__mutmut_228 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_229'] = x_inject__mutmut_229 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_230'] = x_inject__mutmut_230 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_231'] = x_inject__mutmut_231 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_232'] = x_inject__mutmut_232 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_233'] = x_inject__mutmut_233 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_234'] = x_inject__mutmut_234 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_235'] = x_inject__mutmut_235 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_236'] = x_inject__mutmut_236 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_237'] = x_inject__mutmut_237 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_238'] = x_inject__mutmut_238 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_239'] = x_inject__mutmut_239 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_240'] = x_inject__mutmut_240 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_241'] = x_inject__mutmut_241 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_242'] = x_inject__mutmut_242 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_243'] = x_inject__mutmut_243 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_244'] = x_inject__mutmut_244 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_245'] = x_inject__mutmut_245 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_246'] = x_inject__mutmut_246 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_247'] = x_inject__mutmut_247 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_248'] = x_inject__mutmut_248 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_249'] = x_inject__mutmut_249 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_250'] = x_inject__mutmut_250 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_251'] = x_inject__mutmut_251 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_252'] = x_inject__mutmut_252 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_253'] = x_inject__mutmut_253 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_254'] = x_inject__mutmut_254 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_255'] = x_inject__mutmut_255 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_256'] = x_inject__mutmut_256 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_257'] = x_inject__mutmut_257 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_258'] = x_inject__mutmut_258 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_259'] = x_inject__mutmut_259 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_260'] = x_inject__mutmut_260 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_261'] = x_inject__mutmut_261 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_262'] = x_inject__mutmut_262 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_263'] = x_inject__mutmut_263 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_264'] = x_inject__mutmut_264 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_265'] = x_inject__mutmut_265 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_266'] = x_inject__mutmut_266 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_267'] = x_inject__mutmut_267 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_268'] = x_inject__mutmut_268 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_269'] = x_inject__mutmut_269 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_270'] = x_inject__mutmut_270 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_271'] = x_inject__mutmut_271 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_272'] = x_inject__mutmut_272 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_273'] = x_inject__mutmut_273 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_274'] = x_inject__mutmut_274 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_275'] = x_inject__mutmut_275 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_276'] = x_inject__mutmut_276 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_277'] = x_inject__mutmut_277 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_278'] = x_inject__mutmut_278 # type: ignore # mutmut generated
mutants_x_inject__mutmut['x_inject__mutmut_279'] = x_inject__mutmut_279 # type: ignore # mutmut generated
