"""Per-type recall of every detector on a carrier with typed injection (issue #65).

Same protocol as the synthetic benchmark: identity-grouped 70/15/15 split stratified on the group
type, detectors fitted on train with the train anomaly prevalence as contamination, recall per type
on test against the clean rows only.
"""

from __future__ import annotations

import os

os.environ.setdefault("TQDM_DISABLE", "1")

import injection as inj  # noqa: E402
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402
from deep_support import build, capped  # noqa: E402
from sklearn.metrics import precision_score, recall_score  # noqa: E402

from etl_benchmark import config  # noqa: E402
from etl_benchmark.pipeline import detect  # noqa: E402
from etl_benchmark.quality import TemporalDriftDetector  # noqa: E402
from etl_benchmark.registry import ALL_NAMES, DEEP_NAMES  # noqa: E402
from etl_benchmark.split import stratified_split  # noqa: E402

DETECTORS = [n for n in ALL_NAMES if n != "drift"] + ["drift"]
KNOWN = [*ALL_NAMES, *DEEP_NAMES]


from mutmut.mutation.trampoline import wrap_in_trampoline as _mutmut_mutated, MutantDict
mutants_x_split__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_split__mutmut)
def split(df: pd.DataFrame, seed: int) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    groups = (
        df.groupby("group_id", sort=False)["anomaly_type"]
        .agg(lambda types: "duplicate" if "duplicate" in types.values else types.iloc[0])
        .reset_index(name="stratum")
    )
    parts = stratified_split(groups, "stratum", config.SPLIT_RATIOS, seed)
    return tuple(df[df["group_id"].isin(p["group_id"])].reset_index(drop=True) for p in parts)


def x_split__mutmut_orig(df: pd.DataFrame, seed: int) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    groups = (
        df.groupby("group_id", sort=False)["anomaly_type"]
        .agg(lambda types: "duplicate" if "duplicate" in types.values else types.iloc[0])
        .reset_index(name="stratum")
    )
    parts = stratified_split(groups, "stratum", config.SPLIT_RATIOS, seed)
    return tuple(df[df["group_id"].isin(p["group_id"])].reset_index(drop=True) for p in parts)


def x_split__mutmut_1(df: pd.DataFrame, seed: int) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    groups = None
    parts = stratified_split(groups, "stratum", config.SPLIT_RATIOS, seed)
    return tuple(df[df["group_id"].isin(p["group_id"])].reset_index(drop=True) for p in parts)


def x_split__mutmut_2(df: pd.DataFrame, seed: int) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    groups = (
        df.groupby("group_id", sort=False)["anomaly_type"]
        .agg(lambda types: "duplicate" if "duplicate" in types.values else types.iloc[0])
        .reset_index(name=None)
    )
    parts = stratified_split(groups, "stratum", config.SPLIT_RATIOS, seed)
    return tuple(df[df["group_id"].isin(p["group_id"])].reset_index(drop=True) for p in parts)


def x_split__mutmut_3(df: pd.DataFrame, seed: int) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    groups = (
        df.groupby("group_id", sort=False)["anomaly_type"]
        .agg(None)
        .reset_index(name="stratum")
    )
    parts = stratified_split(groups, "stratum", config.SPLIT_RATIOS, seed)
    return tuple(df[df["group_id"].isin(p["group_id"])].reset_index(drop=True) for p in parts)


def x_split__mutmut_4(df: pd.DataFrame, seed: int) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    groups = (
        df.groupby(None, sort=False)["anomaly_type"]
        .agg(lambda types: "duplicate" if "duplicate" in types.values else types.iloc[0])
        .reset_index(name="stratum")
    )
    parts = stratified_split(groups, "stratum", config.SPLIT_RATIOS, seed)
    return tuple(df[df["group_id"].isin(p["group_id"])].reset_index(drop=True) for p in parts)


def x_split__mutmut_5(df: pd.DataFrame, seed: int) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    groups = (
        df.groupby("group_id", sort=None)["anomaly_type"]
        .agg(lambda types: "duplicate" if "duplicate" in types.values else types.iloc[0])
        .reset_index(name="stratum")
    )
    parts = stratified_split(groups, "stratum", config.SPLIT_RATIOS, seed)
    return tuple(df[df["group_id"].isin(p["group_id"])].reset_index(drop=True) for p in parts)


def x_split__mutmut_6(df: pd.DataFrame, seed: int) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    groups = (
        df.groupby(sort=False)["anomaly_type"]
        .agg(lambda types: "duplicate" if "duplicate" in types.values else types.iloc[0])
        .reset_index(name="stratum")
    )
    parts = stratified_split(groups, "stratum", config.SPLIT_RATIOS, seed)
    return tuple(df[df["group_id"].isin(p["group_id"])].reset_index(drop=True) for p in parts)


def x_split__mutmut_7(df: pd.DataFrame, seed: int) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    groups = (
        df.groupby("group_id", )["anomaly_type"]
        .agg(lambda types: "duplicate" if "duplicate" in types.values else types.iloc[0])
        .reset_index(name="stratum")
    )
    parts = stratified_split(groups, "stratum", config.SPLIT_RATIOS, seed)
    return tuple(df[df["group_id"].isin(p["group_id"])].reset_index(drop=True) for p in parts)


def x_split__mutmut_8(df: pd.DataFrame, seed: int) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    groups = (
        df.groupby("XXgroup_idXX", sort=False)["anomaly_type"]
        .agg(lambda types: "duplicate" if "duplicate" in types.values else types.iloc[0])
        .reset_index(name="stratum")
    )
    parts = stratified_split(groups, "stratum", config.SPLIT_RATIOS, seed)
    return tuple(df[df["group_id"].isin(p["group_id"])].reset_index(drop=True) for p in parts)


def x_split__mutmut_9(df: pd.DataFrame, seed: int) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    groups = (
        df.groupby("GROUP_ID", sort=False)["anomaly_type"]
        .agg(lambda types: "duplicate" if "duplicate" in types.values else types.iloc[0])
        .reset_index(name="stratum")
    )
    parts = stratified_split(groups, "stratum", config.SPLIT_RATIOS, seed)
    return tuple(df[df["group_id"].isin(p["group_id"])].reset_index(drop=True) for p in parts)


def x_split__mutmut_10(df: pd.DataFrame, seed: int) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    groups = (
        df.groupby("group_id", sort=True)["anomaly_type"]
        .agg(lambda types: "duplicate" if "duplicate" in types.values else types.iloc[0])
        .reset_index(name="stratum")
    )
    parts = stratified_split(groups, "stratum", config.SPLIT_RATIOS, seed)
    return tuple(df[df["group_id"].isin(p["group_id"])].reset_index(drop=True) for p in parts)


def x_split__mutmut_11(df: pd.DataFrame, seed: int) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    groups = (
        df.groupby("group_id", sort=False)["XXanomaly_typeXX"]
        .agg(lambda types: "duplicate" if "duplicate" in types.values else types.iloc[0])
        .reset_index(name="stratum")
    )
    parts = stratified_split(groups, "stratum", config.SPLIT_RATIOS, seed)
    return tuple(df[df["group_id"].isin(p["group_id"])].reset_index(drop=True) for p in parts)


def x_split__mutmut_12(df: pd.DataFrame, seed: int) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    groups = (
        df.groupby("group_id", sort=False)["ANOMALY_TYPE"]
        .agg(lambda types: "duplicate" if "duplicate" in types.values else types.iloc[0])
        .reset_index(name="stratum")
    )
    parts = stratified_split(groups, "stratum", config.SPLIT_RATIOS, seed)
    return tuple(df[df["group_id"].isin(p["group_id"])].reset_index(drop=True) for p in parts)


def x_split__mutmut_13(df: pd.DataFrame, seed: int) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    groups = (
        df.groupby("group_id", sort=False)["anomaly_type"]
        .agg(lambda types: None)
        .reset_index(name="stratum")
    )
    parts = stratified_split(groups, "stratum", config.SPLIT_RATIOS, seed)
    return tuple(df[df["group_id"].isin(p["group_id"])].reset_index(drop=True) for p in parts)


def x_split__mutmut_14(df: pd.DataFrame, seed: int) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    groups = (
        df.groupby("group_id", sort=False)["anomaly_type"]
        .agg(lambda types: "duplicate" if ("duplicate" in types.values) and False else types.iloc[0])
        .reset_index(name="stratum")
    )
    parts = stratified_split(groups, "stratum", config.SPLIT_RATIOS, seed)
    return tuple(df[df["group_id"].isin(p["group_id"])].reset_index(drop=True) for p in parts)


def x_split__mutmut_15(df: pd.DataFrame, seed: int) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    groups = (
        df.groupby("group_id", sort=False)["anomaly_type"]
        .agg(lambda types: "duplicate" if ("duplicate" in types.values) or True else types.iloc[0])
        .reset_index(name="stratum")
    )
    parts = stratified_split(groups, "stratum", config.SPLIT_RATIOS, seed)
    return tuple(df[df["group_id"].isin(p["group_id"])].reset_index(drop=True) for p in parts)


def x_split__mutmut_16(df: pd.DataFrame, seed: int) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    groups = (
        df.groupby("group_id", sort=False)["anomaly_type"]
        .agg(lambda types: "XXduplicateXX" if "duplicate" in types.values else types.iloc[0])
        .reset_index(name="stratum")
    )
    parts = stratified_split(groups, "stratum", config.SPLIT_RATIOS, seed)
    return tuple(df[df["group_id"].isin(p["group_id"])].reset_index(drop=True) for p in parts)


def x_split__mutmut_17(df: pd.DataFrame, seed: int) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    groups = (
        df.groupby("group_id", sort=False)["anomaly_type"]
        .agg(lambda types: "DUPLICATE" if "duplicate" in types.values else types.iloc[0])
        .reset_index(name="stratum")
    )
    parts = stratified_split(groups, "stratum", config.SPLIT_RATIOS, seed)
    return tuple(df[df["group_id"].isin(p["group_id"])].reset_index(drop=True) for p in parts)


def x_split__mutmut_18(df: pd.DataFrame, seed: int) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    groups = (
        df.groupby("group_id", sort=False)["anomaly_type"]
        .agg(lambda types: "duplicate" if "XXduplicateXX" in types.values else types.iloc[0])
        .reset_index(name="stratum")
    )
    parts = stratified_split(groups, "stratum", config.SPLIT_RATIOS, seed)
    return tuple(df[df["group_id"].isin(p["group_id"])].reset_index(drop=True) for p in parts)


def x_split__mutmut_19(df: pd.DataFrame, seed: int) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    groups = (
        df.groupby("group_id", sort=False)["anomaly_type"]
        .agg(lambda types: "duplicate" if "DUPLICATE" in types.values else types.iloc[0])
        .reset_index(name="stratum")
    )
    parts = stratified_split(groups, "stratum", config.SPLIT_RATIOS, seed)
    return tuple(df[df["group_id"].isin(p["group_id"])].reset_index(drop=True) for p in parts)


def x_split__mutmut_20(df: pd.DataFrame, seed: int) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    groups = (
        df.groupby("group_id", sort=False)["anomaly_type"]
        .agg(lambda types: "duplicate" if "duplicate" not in types.values else types.iloc[0])
        .reset_index(name="stratum")
    )
    parts = stratified_split(groups, "stratum", config.SPLIT_RATIOS, seed)
    return tuple(df[df["group_id"].isin(p["group_id"])].reset_index(drop=True) for p in parts)


def x_split__mutmut_21(df: pd.DataFrame, seed: int) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    groups = (
        df.groupby("group_id", sort=False)["anomaly_type"]
        .agg(lambda types: "duplicate" if "duplicate" in types.values else types.iloc[1])
        .reset_index(name="stratum")
    )
    parts = stratified_split(groups, "stratum", config.SPLIT_RATIOS, seed)
    return tuple(df[df["group_id"].isin(p["group_id"])].reset_index(drop=True) for p in parts)


def x_split__mutmut_22(df: pd.DataFrame, seed: int) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    groups = (
        df.groupby("group_id", sort=False)["anomaly_type"]
        .agg(lambda types: "duplicate" if "duplicate" in types.values else types.iloc[0])
        .reset_index(name="XXstratumXX")
    )
    parts = stratified_split(groups, "stratum", config.SPLIT_RATIOS, seed)
    return tuple(df[df["group_id"].isin(p["group_id"])].reset_index(drop=True) for p in parts)


def x_split__mutmut_23(df: pd.DataFrame, seed: int) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    groups = (
        df.groupby("group_id", sort=False)["anomaly_type"]
        .agg(lambda types: "duplicate" if "duplicate" in types.values else types.iloc[0])
        .reset_index(name="STRATUM")
    )
    parts = stratified_split(groups, "stratum", config.SPLIT_RATIOS, seed)
    return tuple(df[df["group_id"].isin(p["group_id"])].reset_index(drop=True) for p in parts)


def x_split__mutmut_24(df: pd.DataFrame, seed: int) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    groups = (
        df.groupby("group_id", sort=False)["anomaly_type"]
        .agg(lambda types: "duplicate" if "duplicate" in types.values else types.iloc[0])
        .reset_index(name="stratum")
    )
    parts = None
    return tuple(df[df["group_id"].isin(p["group_id"])].reset_index(drop=True) for p in parts)


def x_split__mutmut_25(df: pd.DataFrame, seed: int) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    groups = (
        df.groupby("group_id", sort=False)["anomaly_type"]
        .agg(lambda types: "duplicate" if "duplicate" in types.values else types.iloc[0])
        .reset_index(name="stratum")
    )
    parts = stratified_split(None, "stratum", config.SPLIT_RATIOS, seed)
    return tuple(df[df["group_id"].isin(p["group_id"])].reset_index(drop=True) for p in parts)


def x_split__mutmut_26(df: pd.DataFrame, seed: int) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    groups = (
        df.groupby("group_id", sort=False)["anomaly_type"]
        .agg(lambda types: "duplicate" if "duplicate" in types.values else types.iloc[0])
        .reset_index(name="stratum")
    )
    parts = stratified_split(groups, None, config.SPLIT_RATIOS, seed)
    return tuple(df[df["group_id"].isin(p["group_id"])].reset_index(drop=True) for p in parts)


def x_split__mutmut_27(df: pd.DataFrame, seed: int) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    groups = (
        df.groupby("group_id", sort=False)["anomaly_type"]
        .agg(lambda types: "duplicate" if "duplicate" in types.values else types.iloc[0])
        .reset_index(name="stratum")
    )
    parts = stratified_split(groups, "stratum", None, seed)
    return tuple(df[df["group_id"].isin(p["group_id"])].reset_index(drop=True) for p in parts)


def x_split__mutmut_28(df: pd.DataFrame, seed: int) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    groups = (
        df.groupby("group_id", sort=False)["anomaly_type"]
        .agg(lambda types: "duplicate" if "duplicate" in types.values else types.iloc[0])
        .reset_index(name="stratum")
    )
    parts = stratified_split(groups, "stratum", config.SPLIT_RATIOS, None)
    return tuple(df[df["group_id"].isin(p["group_id"])].reset_index(drop=True) for p in parts)


def x_split__mutmut_29(df: pd.DataFrame, seed: int) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    groups = (
        df.groupby("group_id", sort=False)["anomaly_type"]
        .agg(lambda types: "duplicate" if "duplicate" in types.values else types.iloc[0])
        .reset_index(name="stratum")
    )
    parts = stratified_split("stratum", config.SPLIT_RATIOS, seed)
    return tuple(df[df["group_id"].isin(p["group_id"])].reset_index(drop=True) for p in parts)


def x_split__mutmut_30(df: pd.DataFrame, seed: int) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    groups = (
        df.groupby("group_id", sort=False)["anomaly_type"]
        .agg(lambda types: "duplicate" if "duplicate" in types.values else types.iloc[0])
        .reset_index(name="stratum")
    )
    parts = stratified_split(groups, config.SPLIT_RATIOS, seed)
    return tuple(df[df["group_id"].isin(p["group_id"])].reset_index(drop=True) for p in parts)


def x_split__mutmut_31(df: pd.DataFrame, seed: int) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    groups = (
        df.groupby("group_id", sort=False)["anomaly_type"]
        .agg(lambda types: "duplicate" if "duplicate" in types.values else types.iloc[0])
        .reset_index(name="stratum")
    )
    parts = stratified_split(groups, "stratum", seed)
    return tuple(df[df["group_id"].isin(p["group_id"])].reset_index(drop=True) for p in parts)


def x_split__mutmut_32(df: pd.DataFrame, seed: int) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    groups = (
        df.groupby("group_id", sort=False)["anomaly_type"]
        .agg(lambda types: "duplicate" if "duplicate" in types.values else types.iloc[0])
        .reset_index(name="stratum")
    )
    parts = stratified_split(groups, "stratum", config.SPLIT_RATIOS, )
    return tuple(df[df["group_id"].isin(p["group_id"])].reset_index(drop=True) for p in parts)


def x_split__mutmut_33(df: pd.DataFrame, seed: int) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    groups = (
        df.groupby("group_id", sort=False)["anomaly_type"]
        .agg(lambda types: "duplicate" if "duplicate" in types.values else types.iloc[0])
        .reset_index(name="stratum")
    )
    parts = stratified_split(groups, "XXstratumXX", config.SPLIT_RATIOS, seed)
    return tuple(df[df["group_id"].isin(p["group_id"])].reset_index(drop=True) for p in parts)


def x_split__mutmut_34(df: pd.DataFrame, seed: int) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    groups = (
        df.groupby("group_id", sort=False)["anomaly_type"]
        .agg(lambda types: "duplicate" if "duplicate" in types.values else types.iloc[0])
        .reset_index(name="stratum")
    )
    parts = stratified_split(groups, "STRATUM", config.SPLIT_RATIOS, seed)
    return tuple(df[df["group_id"].isin(p["group_id"])].reset_index(drop=True) for p in parts)


def x_split__mutmut_35(df: pd.DataFrame, seed: int) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    groups = (
        df.groupby("group_id", sort=False)["anomaly_type"]
        .agg(lambda types: "duplicate" if "duplicate" in types.values else types.iloc[0])
        .reset_index(name="stratum")
    )
    parts = stratified_split(groups, "stratum", config.SPLIT_RATIOS, seed)
    return tuple(None)


def x_split__mutmut_36(df: pd.DataFrame, seed: int) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    groups = (
        df.groupby("group_id", sort=False)["anomaly_type"]
        .agg(lambda types: "duplicate" if "duplicate" in types.values else types.iloc[0])
        .reset_index(name="stratum")
    )
    parts = stratified_split(groups, "stratum", config.SPLIT_RATIOS, seed)
    return tuple(df[df["group_id"].isin(p["group_id"])].reset_index(drop=None) for p in parts)


def x_split__mutmut_37(df: pd.DataFrame, seed: int) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    groups = (
        df.groupby("group_id", sort=False)["anomaly_type"]
        .agg(lambda types: "duplicate" if "duplicate" in types.values else types.iloc[0])
        .reset_index(name="stratum")
    )
    parts = stratified_split(groups, "stratum", config.SPLIT_RATIOS, seed)
    return tuple(df[df["group_id"].isin(None)].reset_index(drop=True) for p in parts)


def x_split__mutmut_38(df: pd.DataFrame, seed: int) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    groups = (
        df.groupby("group_id", sort=False)["anomaly_type"]
        .agg(lambda types: "duplicate" if "duplicate" in types.values else types.iloc[0])
        .reset_index(name="stratum")
    )
    parts = stratified_split(groups, "stratum", config.SPLIT_RATIOS, seed)
    return tuple(df[df["XXgroup_idXX"].isin(p["group_id"])].reset_index(drop=True) for p in parts)


def x_split__mutmut_39(df: pd.DataFrame, seed: int) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    groups = (
        df.groupby("group_id", sort=False)["anomaly_type"]
        .agg(lambda types: "duplicate" if "duplicate" in types.values else types.iloc[0])
        .reset_index(name="stratum")
    )
    parts = stratified_split(groups, "stratum", config.SPLIT_RATIOS, seed)
    return tuple(df[df["GROUP_ID"].isin(p["group_id"])].reset_index(drop=True) for p in parts)


def x_split__mutmut_40(df: pd.DataFrame, seed: int) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    groups = (
        df.groupby("group_id", sort=False)["anomaly_type"]
        .agg(lambda types: "duplicate" if "duplicate" in types.values else types.iloc[0])
        .reset_index(name="stratum")
    )
    parts = stratified_split(groups, "stratum", config.SPLIT_RATIOS, seed)
    return tuple(df[df["group_id"].isin(p["XXgroup_idXX"])].reset_index(drop=True) for p in parts)


def x_split__mutmut_41(df: pd.DataFrame, seed: int) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    groups = (
        df.groupby("group_id", sort=False)["anomaly_type"]
        .agg(lambda types: "duplicate" if "duplicate" in types.values else types.iloc[0])
        .reset_index(name="stratum")
    )
    parts = stratified_split(groups, "stratum", config.SPLIT_RATIOS, seed)
    return tuple(df[df["group_id"].isin(p["GROUP_ID"])].reset_index(drop=True) for p in parts)


def x_split__mutmut_42(df: pd.DataFrame, seed: int) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    groups = (
        df.groupby("group_id", sort=False)["anomaly_type"]
        .agg(lambda types: "duplicate" if "duplicate" in types.values else types.iloc[0])
        .reset_index(name="stratum")
    )
    parts = stratified_split(groups, "stratum", config.SPLIT_RATIOS, seed)
    return tuple(df[df["group_id"].isin(p["group_id"])].reset_index(drop=False) for p in parts)

mutants_x_split__mutmut['_mutmut_orig'] = x_split__mutmut_orig # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_1'] = x_split__mutmut_1 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_2'] = x_split__mutmut_2 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_3'] = x_split__mutmut_3 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_4'] = x_split__mutmut_4 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_5'] = x_split__mutmut_5 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_6'] = x_split__mutmut_6 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_7'] = x_split__mutmut_7 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_8'] = x_split__mutmut_8 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_9'] = x_split__mutmut_9 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_10'] = x_split__mutmut_10 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_11'] = x_split__mutmut_11 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_12'] = x_split__mutmut_12 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_13'] = x_split__mutmut_13 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_14'] = x_split__mutmut_14 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_15'] = x_split__mutmut_15 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_16'] = x_split__mutmut_16 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_17'] = x_split__mutmut_17 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_18'] = x_split__mutmut_18 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_19'] = x_split__mutmut_19 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_20'] = x_split__mutmut_20 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_21'] = x_split__mutmut_21 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_22'] = x_split__mutmut_22 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_23'] = x_split__mutmut_23 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_24'] = x_split__mutmut_24 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_25'] = x_split__mutmut_25 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_26'] = x_split__mutmut_26 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_27'] = x_split__mutmut_27 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_28'] = x_split__mutmut_28 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_29'] = x_split__mutmut_29 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_30'] = x_split__mutmut_30 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_31'] = x_split__mutmut_31 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_32'] = x_split__mutmut_32 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_33'] = x_split__mutmut_33 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_34'] = x_split__mutmut_34 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_35'] = x_split__mutmut_35 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_36'] = x_split__mutmut_36 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_37'] = x_split__mutmut_37 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_38'] = x_split__mutmut_38 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_39'] = x_split__mutmut_39 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_40'] = x_split__mutmut_40 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_41'] = x_split__mutmut_41 # type: ignore # mutmut generated
mutants_x_split__mutmut['x_split__mutmut_42'] = x_split__mutmut_42 # type: ignore # mutmut generated
mutants_x__build__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x__build__mutmut)
def _build(name: str, contamination: float, cols: list[str], seed: int):
    if name == "drift":
        return TemporalDriftDetector(time_column="t", columns=cols)
    return build(name, contamination, seed)


def x__build__mutmut_orig(name: str, contamination: float, cols: list[str], seed: int):
    if name == "drift":
        return TemporalDriftDetector(time_column="t", columns=cols)
    return build(name, contamination, seed)


def x__build__mutmut_1(name: str, contamination: float, cols: list[str], seed: int):
    if name != "drift":
        return TemporalDriftDetector(time_column="t", columns=cols)
    return build(name, contamination, seed)


def x__build__mutmut_2(name: str, contamination: float, cols: list[str], seed: int):
    if name == "XXdriftXX":
        return TemporalDriftDetector(time_column="t", columns=cols)
    return build(name, contamination, seed)


def x__build__mutmut_3(name: str, contamination: float, cols: list[str], seed: int):
    if name == "DRIFT":
        return TemporalDriftDetector(time_column="t", columns=cols)
    return build(name, contamination, seed)


def x__build__mutmut_4(name: str, contamination: float, cols: list[str], seed: int):
    if name == "drift":
        return TemporalDriftDetector(time_column=None, columns=cols)
    return build(name, contamination, seed)


def x__build__mutmut_5(name: str, contamination: float, cols: list[str], seed: int):
    if name == "drift":
        return TemporalDriftDetector(time_column="t", columns=None)
    return build(name, contamination, seed)


def x__build__mutmut_6(name: str, contamination: float, cols: list[str], seed: int):
    if name == "drift":
        return TemporalDriftDetector(columns=cols)
    return build(name, contamination, seed)


def x__build__mutmut_7(name: str, contamination: float, cols: list[str], seed: int):
    if name == "drift":
        return TemporalDriftDetector(time_column="t", )
    return build(name, contamination, seed)


def x__build__mutmut_8(name: str, contamination: float, cols: list[str], seed: int):
    if name == "drift":
        return TemporalDriftDetector(time_column="XXtXX", columns=cols)
    return build(name, contamination, seed)


def x__build__mutmut_9(name: str, contamination: float, cols: list[str], seed: int):
    if name == "drift":
        return TemporalDriftDetector(time_column="T", columns=cols)
    return build(name, contamination, seed)


def x__build__mutmut_10(name: str, contamination: float, cols: list[str], seed: int):
    if name == "drift":
        return TemporalDriftDetector(time_column="t", columns=cols)
    return build(None, contamination, seed)


def x__build__mutmut_11(name: str, contamination: float, cols: list[str], seed: int):
    if name == "drift":
        return TemporalDriftDetector(time_column="t", columns=cols)
    return build(name, None, seed)


def x__build__mutmut_12(name: str, contamination: float, cols: list[str], seed: int):
    if name == "drift":
        return TemporalDriftDetector(time_column="t", columns=cols)
    return build(name, contamination, None)


def x__build__mutmut_13(name: str, contamination: float, cols: list[str], seed: int):
    if name == "drift":
        return TemporalDriftDetector(time_column="t", columns=cols)
    return build(contamination, seed)


def x__build__mutmut_14(name: str, contamination: float, cols: list[str], seed: int):
    if name == "drift":
        return TemporalDriftDetector(time_column="t", columns=cols)
    return build(name, seed)


def x__build__mutmut_15(name: str, contamination: float, cols: list[str], seed: int):
    if name == "drift":
        return TemporalDriftDetector(time_column="t", columns=cols)
    return build(name, contamination, )

mutants_x__build__mutmut['_mutmut_orig'] = x__build__mutmut_orig # type: ignore # mutmut generated
mutants_x__build__mutmut['x__build__mutmut_1'] = x__build__mutmut_1 # type: ignore # mutmut generated
mutants_x__build__mutmut['x__build__mutmut_2'] = x__build__mutmut_2 # type: ignore # mutmut generated
mutants_x__build__mutmut['x__build__mutmut_3'] = x__build__mutmut_3 # type: ignore # mutmut generated
mutants_x__build__mutmut['x__build__mutmut_4'] = x__build__mutmut_4 # type: ignore # mutmut generated
mutants_x__build__mutmut['x__build__mutmut_5'] = x__build__mutmut_5 # type: ignore # mutmut generated
mutants_x__build__mutmut['x__build__mutmut_6'] = x__build__mutmut_6 # type: ignore # mutmut generated
mutants_x__build__mutmut['x__build__mutmut_7'] = x__build__mutmut_7 # type: ignore # mutmut generated
mutants_x__build__mutmut['x__build__mutmut_8'] = x__build__mutmut_8 # type: ignore # mutmut generated
mutants_x__build__mutmut['x__build__mutmut_9'] = x__build__mutmut_9 # type: ignore # mutmut generated
mutants_x__build__mutmut['x__build__mutmut_10'] = x__build__mutmut_10 # type: ignore # mutmut generated
mutants_x__build__mutmut['x__build__mutmut_11'] = x__build__mutmut_11 # type: ignore # mutmut generated
mutants_x__build__mutmut['x__build__mutmut_12'] = x__build__mutmut_12 # type: ignore # mutmut generated
mutants_x__build__mutmut['x__build__mutmut_13'] = x__build__mutmut_13 # type: ignore # mutmut generated
mutants_x__build__mutmut['x__build__mutmut_14'] = x__build__mutmut_14 # type: ignore # mutmut generated
mutants_x__build__mutmut['x__build__mutmut_15'] = x__build__mutmut_15 # type: ignore # mutmut generated
mutants_x__per_type__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x__per_type__mutmut)
def _per_type(flags: pd.Series, types: pd.Series) -> tuple[dict, dict]:
    clean = types == "clean"
    recall, precision = {}, {}
    for name in inj.ANOMALY_TYPES:
        is_type = types == name
        if not is_type.any():
            recall[name] = precision[name] = np.nan
            continue
        keep = is_type | clean
        recall[name] = recall_score(is_type[keep].astype(int), flags[keep])
        precision[name] = precision_score(is_type[keep].astype(int), flags[keep], zero_division=0)
    return recall, precision


def x__per_type__mutmut_orig(flags: pd.Series, types: pd.Series) -> tuple[dict, dict]:
    clean = types == "clean"
    recall, precision = {}, {}
    for name in inj.ANOMALY_TYPES:
        is_type = types == name
        if not is_type.any():
            recall[name] = precision[name] = np.nan
            continue
        keep = is_type | clean
        recall[name] = recall_score(is_type[keep].astype(int), flags[keep])
        precision[name] = precision_score(is_type[keep].astype(int), flags[keep], zero_division=0)
    return recall, precision


def x__per_type__mutmut_1(flags: pd.Series, types: pd.Series) -> tuple[dict, dict]:
    clean = None
    recall, precision = {}, {}
    for name in inj.ANOMALY_TYPES:
        is_type = types == name
        if not is_type.any():
            recall[name] = precision[name] = np.nan
            continue
        keep = is_type | clean
        recall[name] = recall_score(is_type[keep].astype(int), flags[keep])
        precision[name] = precision_score(is_type[keep].astype(int), flags[keep], zero_division=0)
    return recall, precision


def x__per_type__mutmut_2(flags: pd.Series, types: pd.Series) -> tuple[dict, dict]:
    clean = types != "clean"
    recall, precision = {}, {}
    for name in inj.ANOMALY_TYPES:
        is_type = types == name
        if not is_type.any():
            recall[name] = precision[name] = np.nan
            continue
        keep = is_type | clean
        recall[name] = recall_score(is_type[keep].astype(int), flags[keep])
        precision[name] = precision_score(is_type[keep].astype(int), flags[keep], zero_division=0)
    return recall, precision


def x__per_type__mutmut_3(flags: pd.Series, types: pd.Series) -> tuple[dict, dict]:
    clean = types == "XXcleanXX"
    recall, precision = {}, {}
    for name in inj.ANOMALY_TYPES:
        is_type = types == name
        if not is_type.any():
            recall[name] = precision[name] = np.nan
            continue
        keep = is_type | clean
        recall[name] = recall_score(is_type[keep].astype(int), flags[keep])
        precision[name] = precision_score(is_type[keep].astype(int), flags[keep], zero_division=0)
    return recall, precision


def x__per_type__mutmut_4(flags: pd.Series, types: pd.Series) -> tuple[dict, dict]:
    clean = types == "CLEAN"
    recall, precision = {}, {}
    for name in inj.ANOMALY_TYPES:
        is_type = types == name
        if not is_type.any():
            recall[name] = precision[name] = np.nan
            continue
        keep = is_type | clean
        recall[name] = recall_score(is_type[keep].astype(int), flags[keep])
        precision[name] = precision_score(is_type[keep].astype(int), flags[keep], zero_division=0)
    return recall, precision


def x__per_type__mutmut_5(flags: pd.Series, types: pd.Series) -> tuple[dict, dict]:
    clean = types == "clean"
    recall, precision = None
    for name in inj.ANOMALY_TYPES:
        is_type = types == name
        if not is_type.any():
            recall[name] = precision[name] = np.nan
            continue
        keep = is_type | clean
        recall[name] = recall_score(is_type[keep].astype(int), flags[keep])
        precision[name] = precision_score(is_type[keep].astype(int), flags[keep], zero_division=0)
    return recall, precision


def x__per_type__mutmut_6(flags: pd.Series, types: pd.Series) -> tuple[dict, dict]:
    clean = types == "clean"
    recall, precision = {}, {}
    for name in inj.ANOMALY_TYPES:
        is_type = None
        if not is_type.any():
            recall[name] = precision[name] = np.nan
            continue
        keep = is_type | clean
        recall[name] = recall_score(is_type[keep].astype(int), flags[keep])
        precision[name] = precision_score(is_type[keep].astype(int), flags[keep], zero_division=0)
    return recall, precision


def x__per_type__mutmut_7(flags: pd.Series, types: pd.Series) -> tuple[dict, dict]:
    clean = types == "clean"
    recall, precision = {}, {}
    for name in inj.ANOMALY_TYPES:
        is_type = types != name
        if not is_type.any():
            recall[name] = precision[name] = np.nan
            continue
        keep = is_type | clean
        recall[name] = recall_score(is_type[keep].astype(int), flags[keep])
        precision[name] = precision_score(is_type[keep].astype(int), flags[keep], zero_division=0)
    return recall, precision


def x__per_type__mutmut_8(flags: pd.Series, types: pd.Series) -> tuple[dict, dict]:
    clean = types == "clean"
    recall, precision = {}, {}
    for name in inj.ANOMALY_TYPES:
        is_type = types == name
        if is_type.any():
            recall[name] = precision[name] = np.nan
            continue
        keep = is_type | clean
        recall[name] = recall_score(is_type[keep].astype(int), flags[keep])
        precision[name] = precision_score(is_type[keep].astype(int), flags[keep], zero_division=0)
    return recall, precision


def x__per_type__mutmut_9(flags: pd.Series, types: pd.Series) -> tuple[dict, dict]:
    clean = types == "clean"
    recall, precision = {}, {}
    for name in inj.ANOMALY_TYPES:
        is_type = types == name
        if not is_type.any():
            recall[name] = precision[name] = None
            continue
        keep = is_type | clean
        recall[name] = recall_score(is_type[keep].astype(int), flags[keep])
        precision[name] = precision_score(is_type[keep].astype(int), flags[keep], zero_division=0)
    return recall, precision


def x__per_type__mutmut_10(flags: pd.Series, types: pd.Series) -> tuple[dict, dict]:
    clean = types == "clean"
    recall, precision = {}, {}
    for name in inj.ANOMALY_TYPES:
        is_type = types == name
        if not is_type.any():
            recall[name] = precision[name] = np.nan
            break
        keep = is_type | clean
        recall[name] = recall_score(is_type[keep].astype(int), flags[keep])
        precision[name] = precision_score(is_type[keep].astype(int), flags[keep], zero_division=0)
    return recall, precision


def x__per_type__mutmut_11(flags: pd.Series, types: pd.Series) -> tuple[dict, dict]:
    clean = types == "clean"
    recall, precision = {}, {}
    for name in inj.ANOMALY_TYPES:
        is_type = types == name
        if not is_type.any():
            recall[name] = precision[name] = np.nan
            continue
        keep = None
        recall[name] = recall_score(is_type[keep].astype(int), flags[keep])
        precision[name] = precision_score(is_type[keep].astype(int), flags[keep], zero_division=0)
    return recall, precision


def x__per_type__mutmut_12(flags: pd.Series, types: pd.Series) -> tuple[dict, dict]:
    clean = types == "clean"
    recall, precision = {}, {}
    for name in inj.ANOMALY_TYPES:
        is_type = types == name
        if not is_type.any():
            recall[name] = precision[name] = np.nan
            continue
        keep = is_type & clean
        recall[name] = recall_score(is_type[keep].astype(int), flags[keep])
        precision[name] = precision_score(is_type[keep].astype(int), flags[keep], zero_division=0)
    return recall, precision


def x__per_type__mutmut_13(flags: pd.Series, types: pd.Series) -> tuple[dict, dict]:
    clean = types == "clean"
    recall, precision = {}, {}
    for name in inj.ANOMALY_TYPES:
        is_type = types == name
        if not is_type.any():
            recall[name] = precision[name] = np.nan
            continue
        keep = is_type | clean
        recall[name] = None
        precision[name] = precision_score(is_type[keep].astype(int), flags[keep], zero_division=0)
    return recall, precision


def x__per_type__mutmut_14(flags: pd.Series, types: pd.Series) -> tuple[dict, dict]:
    clean = types == "clean"
    recall, precision = {}, {}
    for name in inj.ANOMALY_TYPES:
        is_type = types == name
        if not is_type.any():
            recall[name] = precision[name] = np.nan
            continue
        keep = is_type | clean
        recall[name] = recall_score(None, flags[keep])
        precision[name] = precision_score(is_type[keep].astype(int), flags[keep], zero_division=0)
    return recall, precision


def x__per_type__mutmut_15(flags: pd.Series, types: pd.Series) -> tuple[dict, dict]:
    clean = types == "clean"
    recall, precision = {}, {}
    for name in inj.ANOMALY_TYPES:
        is_type = types == name
        if not is_type.any():
            recall[name] = precision[name] = np.nan
            continue
        keep = is_type | clean
        recall[name] = recall_score(is_type[keep].astype(int), None)
        precision[name] = precision_score(is_type[keep].astype(int), flags[keep], zero_division=0)
    return recall, precision


def x__per_type__mutmut_16(flags: pd.Series, types: pd.Series) -> tuple[dict, dict]:
    clean = types == "clean"
    recall, precision = {}, {}
    for name in inj.ANOMALY_TYPES:
        is_type = types == name
        if not is_type.any():
            recall[name] = precision[name] = np.nan
            continue
        keep = is_type | clean
        recall[name] = recall_score(flags[keep])
        precision[name] = precision_score(is_type[keep].astype(int), flags[keep], zero_division=0)
    return recall, precision


def x__per_type__mutmut_17(flags: pd.Series, types: pd.Series) -> tuple[dict, dict]:
    clean = types == "clean"
    recall, precision = {}, {}
    for name in inj.ANOMALY_TYPES:
        is_type = types == name
        if not is_type.any():
            recall[name] = precision[name] = np.nan
            continue
        keep = is_type | clean
        recall[name] = recall_score(is_type[keep].astype(int), )
        precision[name] = precision_score(is_type[keep].astype(int), flags[keep], zero_division=0)
    return recall, precision


def x__per_type__mutmut_18(flags: pd.Series, types: pd.Series) -> tuple[dict, dict]:
    clean = types == "clean"
    recall, precision = {}, {}
    for name in inj.ANOMALY_TYPES:
        is_type = types == name
        if not is_type.any():
            recall[name] = precision[name] = np.nan
            continue
        keep = is_type | clean
        recall[name] = recall_score(is_type[keep].astype(None), flags[keep])
        precision[name] = precision_score(is_type[keep].astype(int), flags[keep], zero_division=0)
    return recall, precision


def x__per_type__mutmut_19(flags: pd.Series, types: pd.Series) -> tuple[dict, dict]:
    clean = types == "clean"
    recall, precision = {}, {}
    for name in inj.ANOMALY_TYPES:
        is_type = types == name
        if not is_type.any():
            recall[name] = precision[name] = np.nan
            continue
        keep = is_type | clean
        recall[name] = recall_score(is_type[keep].astype(int), flags[keep])
        precision[name] = None
    return recall, precision


def x__per_type__mutmut_20(flags: pd.Series, types: pd.Series) -> tuple[dict, dict]:
    clean = types == "clean"
    recall, precision = {}, {}
    for name in inj.ANOMALY_TYPES:
        is_type = types == name
        if not is_type.any():
            recall[name] = precision[name] = np.nan
            continue
        keep = is_type | clean
        recall[name] = recall_score(is_type[keep].astype(int), flags[keep])
        precision[name] = precision_score(None, flags[keep], zero_division=0)
    return recall, precision


def x__per_type__mutmut_21(flags: pd.Series, types: pd.Series) -> tuple[dict, dict]:
    clean = types == "clean"
    recall, precision = {}, {}
    for name in inj.ANOMALY_TYPES:
        is_type = types == name
        if not is_type.any():
            recall[name] = precision[name] = np.nan
            continue
        keep = is_type | clean
        recall[name] = recall_score(is_type[keep].astype(int), flags[keep])
        precision[name] = precision_score(is_type[keep].astype(int), None, zero_division=0)
    return recall, precision


def x__per_type__mutmut_22(flags: pd.Series, types: pd.Series) -> tuple[dict, dict]:
    clean = types == "clean"
    recall, precision = {}, {}
    for name in inj.ANOMALY_TYPES:
        is_type = types == name
        if not is_type.any():
            recall[name] = precision[name] = np.nan
            continue
        keep = is_type | clean
        recall[name] = recall_score(is_type[keep].astype(int), flags[keep])
        precision[name] = precision_score(is_type[keep].astype(int), flags[keep], zero_division=None)
    return recall, precision


def x__per_type__mutmut_23(flags: pd.Series, types: pd.Series) -> tuple[dict, dict]:
    clean = types == "clean"
    recall, precision = {}, {}
    for name in inj.ANOMALY_TYPES:
        is_type = types == name
        if not is_type.any():
            recall[name] = precision[name] = np.nan
            continue
        keep = is_type | clean
        recall[name] = recall_score(is_type[keep].astype(int), flags[keep])
        precision[name] = precision_score(flags[keep], zero_division=0)
    return recall, precision


def x__per_type__mutmut_24(flags: pd.Series, types: pd.Series) -> tuple[dict, dict]:
    clean = types == "clean"
    recall, precision = {}, {}
    for name in inj.ANOMALY_TYPES:
        is_type = types == name
        if not is_type.any():
            recall[name] = precision[name] = np.nan
            continue
        keep = is_type | clean
        recall[name] = recall_score(is_type[keep].astype(int), flags[keep])
        precision[name] = precision_score(is_type[keep].astype(int), zero_division=0)
    return recall, precision


def x__per_type__mutmut_25(flags: pd.Series, types: pd.Series) -> tuple[dict, dict]:
    clean = types == "clean"
    recall, precision = {}, {}
    for name in inj.ANOMALY_TYPES:
        is_type = types == name
        if not is_type.any():
            recall[name] = precision[name] = np.nan
            continue
        keep = is_type | clean
        recall[name] = recall_score(is_type[keep].astype(int), flags[keep])
        precision[name] = precision_score(is_type[keep].astype(int), flags[keep], )
    return recall, precision


def x__per_type__mutmut_26(flags: pd.Series, types: pd.Series) -> tuple[dict, dict]:
    clean = types == "clean"
    recall, precision = {}, {}
    for name in inj.ANOMALY_TYPES:
        is_type = types == name
        if not is_type.any():
            recall[name] = precision[name] = np.nan
            continue
        keep = is_type | clean
        recall[name] = recall_score(is_type[keep].astype(int), flags[keep])
        precision[name] = precision_score(is_type[keep].astype(None), flags[keep], zero_division=0)
    return recall, precision


def x__per_type__mutmut_27(flags: pd.Series, types: pd.Series) -> tuple[dict, dict]:
    clean = types == "clean"
    recall, precision = {}, {}
    for name in inj.ANOMALY_TYPES:
        is_type = types == name
        if not is_type.any():
            recall[name] = precision[name] = np.nan
            continue
        keep = is_type | clean
        recall[name] = recall_score(is_type[keep].astype(int), flags[keep])
        precision[name] = precision_score(is_type[keep].astype(int), flags[keep], zero_division=1)
    return recall, precision

mutants_x__per_type__mutmut['_mutmut_orig'] = x__per_type__mutmut_orig # type: ignore # mutmut generated
mutants_x__per_type__mutmut['x__per_type__mutmut_1'] = x__per_type__mutmut_1 # type: ignore # mutmut generated
mutants_x__per_type__mutmut['x__per_type__mutmut_2'] = x__per_type__mutmut_2 # type: ignore # mutmut generated
mutants_x__per_type__mutmut['x__per_type__mutmut_3'] = x__per_type__mutmut_3 # type: ignore # mutmut generated
mutants_x__per_type__mutmut['x__per_type__mutmut_4'] = x__per_type__mutmut_4 # type: ignore # mutmut generated
mutants_x__per_type__mutmut['x__per_type__mutmut_5'] = x__per_type__mutmut_5 # type: ignore # mutmut generated
mutants_x__per_type__mutmut['x__per_type__mutmut_6'] = x__per_type__mutmut_6 # type: ignore # mutmut generated
mutants_x__per_type__mutmut['x__per_type__mutmut_7'] = x__per_type__mutmut_7 # type: ignore # mutmut generated
mutants_x__per_type__mutmut['x__per_type__mutmut_8'] = x__per_type__mutmut_8 # type: ignore # mutmut generated
mutants_x__per_type__mutmut['x__per_type__mutmut_9'] = x__per_type__mutmut_9 # type: ignore # mutmut generated
mutants_x__per_type__mutmut['x__per_type__mutmut_10'] = x__per_type__mutmut_10 # type: ignore # mutmut generated
mutants_x__per_type__mutmut['x__per_type__mutmut_11'] = x__per_type__mutmut_11 # type: ignore # mutmut generated
mutants_x__per_type__mutmut['x__per_type__mutmut_12'] = x__per_type__mutmut_12 # type: ignore # mutmut generated
mutants_x__per_type__mutmut['x__per_type__mutmut_13'] = x__per_type__mutmut_13 # type: ignore # mutmut generated
mutants_x__per_type__mutmut['x__per_type__mutmut_14'] = x__per_type__mutmut_14 # type: ignore # mutmut generated
mutants_x__per_type__mutmut['x__per_type__mutmut_15'] = x__per_type__mutmut_15 # type: ignore # mutmut generated
mutants_x__per_type__mutmut['x__per_type__mutmut_16'] = x__per_type__mutmut_16 # type: ignore # mutmut generated
mutants_x__per_type__mutmut['x__per_type__mutmut_17'] = x__per_type__mutmut_17 # type: ignore # mutmut generated
mutants_x__per_type__mutmut['x__per_type__mutmut_18'] = x__per_type__mutmut_18 # type: ignore # mutmut generated
mutants_x__per_type__mutmut['x__per_type__mutmut_19'] = x__per_type__mutmut_19 # type: ignore # mutmut generated
mutants_x__per_type__mutmut['x__per_type__mutmut_20'] = x__per_type__mutmut_20 # type: ignore # mutmut generated
mutants_x__per_type__mutmut['x__per_type__mutmut_21'] = x__per_type__mutmut_21 # type: ignore # mutmut generated
mutants_x__per_type__mutmut['x__per_type__mutmut_22'] = x__per_type__mutmut_22 # type: ignore # mutmut generated
mutants_x__per_type__mutmut['x__per_type__mutmut_23'] = x__per_type__mutmut_23 # type: ignore # mutmut generated
mutants_x__per_type__mutmut['x__per_type__mutmut_24'] = x__per_type__mutmut_24 # type: ignore # mutmut generated
mutants_x__per_type__mutmut['x__per_type__mutmut_25'] = x__per_type__mutmut_25 # type: ignore # mutmut generated
mutants_x__per_type__mutmut['x__per_type__mutmut_26'] = x__per_type__mutmut_26 # type: ignore # mutmut generated
mutants_x__per_type__mutmut['x__per_type__mutmut_27'] = x__per_type__mutmut_27 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_evaluate__mutmut)
def evaluate(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                _build(name, contamination, cols, seed),
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_orig(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                _build(name, contamination, cols, seed),
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_1(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = None
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                _build(name, contamination, cols, seed),
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_2(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names and DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                _build(name, contamination, cols, seed),
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_3(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = None
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                _build(name, contamination, cols, seed),
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_4(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                _build(name, contamination, cols, seed),
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_5(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(None)
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                _build(name, contamination, cols, seed),
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_6(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = None
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                _build(name, contamination, cols, seed),
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_7(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(None, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                _build(name, contamination, cols, seed),
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_8(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, None)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                _build(name, contamination, cols, seed),
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_9(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                _build(name, contamination, cols, seed),
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_10(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, )
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                _build(name, contamination, cols, seed),
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_11(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = None
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                _build(name, contamination, cols, seed),
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_12(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(None)
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                _build(name, contamination, cols, seed),
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_13(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["XXanomalyXX"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                _build(name, contamination, cols, seed),
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_14(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["ANOMALY"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                _build(name, contamination, cols, seed),
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_15(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = None
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                _build(name, contamination, cols, seed),
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_16(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "XXtXX"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                _build(name, contamination, cols, seed),
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_17(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "T"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                _build(name, contamination, cols, seed),
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_18(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = None
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                _build(name, contamination, cols, seed),
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_19(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "XXtransform_dedupXX"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                _build(name, contamination, cols, seed),
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_20(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "TRANSFORM_DEDUP"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                _build(name, contamination, cols, seed),
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_21(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name != "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                _build(name, contamination, cols, seed),
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_22(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "XXtransform_dedupXX":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                _build(name, contamination, cols, seed),
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_23(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "TRANSFORM_DEDUP":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                _build(name, contamination, cols, seed),
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_24(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = None
        else:
            flags = detect(
                test[features],
                _build(name, contamination, cols, seed),
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_25(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=None, keep=False)
        else:
            flags = detect(
                test[features],
                _build(name, contamination, cols, seed),
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_26(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=None)
        else:
            flags = detect(
                test[features],
                _build(name, contamination, cols, seed),
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_27(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(keep=False)
        else:
            flags = detect(
                test[features],
                _build(name, contamination, cols, seed),
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_28(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, )
        else:
            flags = detect(
                test[features],
                _build(name, contamination, cols, seed),
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_29(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=True)
        else:
            flags = detect(
                test[features],
                _build(name, contamination, cols, seed),
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_30(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = None
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_31(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                None,
                _build(name, contamination, cols, seed),
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_32(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                None,
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_33(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                _build(name, contamination, cols, seed),
                fit_df=None,
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_34(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                _build(name, contamination, cols, seed),
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_35(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_36(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                _build(name, contamination, cols, seed),
                ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_37(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                _build(None, contamination, cols, seed),
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_38(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                _build(name, None, cols, seed),
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_39(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                _build(name, contamination, None, seed),
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_40(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                _build(name, contamination, cols, None),
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_41(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                _build(contamination, cols, seed),
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_42(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                _build(name, cols, seed),
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_43(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                _build(name, contamination, seed),
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_44(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                _build(name, contamination, cols, ),
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_45(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                _build(name, contamination, cols, seed),
                fit_df=capped(None, name, seed),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_46(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                _build(name, contamination, cols, seed),
                fit_df=capped(train[features], None, seed),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_47(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                _build(name, contamination, cols, seed),
                fit_df=capped(train[features], name, None),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_48(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                _build(name, contamination, cols, seed),
                fit_df=capped(name, seed),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_49(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                _build(name, contamination, cols, seed),
                fit_df=capped(train[features], seed),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_50(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                _build(name, contamination, cols, seed),
                fit_df=capped(train[features], name, ),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_51(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                _build(name, contamination, cols, seed),
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = None
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_52(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                _build(name, contamination, cols, seed),
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = pd.Series(None, index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_53(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                _build(name, contamination, cols, seed),
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = pd.Series(np.asarray(flags), index=None)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_54(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                _build(name, contamination, cols, seed),
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = pd.Series(index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_55(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                _build(name, contamination, cols, seed),
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = pd.Series(np.asarray(flags), )
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_56(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                _build(name, contamination, cols, seed),
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = pd.Series(np.asarray(None), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_57(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                _build(name, contamination, cols, seed),
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = None
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_58(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                _build(name, contamination, cols, seed),
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(None)
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_59(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                _build(name, contamination, cols, seed),
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["XXanomaly_typeXX"] == "clean"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_60(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                _build(name, contamination, cols, seed),
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["ANOMALY_TYPE"] == "clean"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_61(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                _build(name, contamination, cols, seed),
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] != "clean"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_62(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                _build(name, contamination, cols, seed),
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "XXcleanXX"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_63(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                _build(name, contamination, cols, seed),
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "CLEAN"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_64(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                _build(name, contamination, cols, seed),
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = None
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_65(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                _build(name, contamination, cols, seed),
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(None, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_66(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                _build(name, contamination, cols, seed),
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(flags, None)
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_67(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                _build(name, contamination, cols, seed),
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_68(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                _build(name, contamination, cols, seed),
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(flags, )
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_69(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                _build(name, contamination, cols, seed),
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(flags, test["XXanomaly_typeXX"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_70(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                _build(name, contamination, cols, seed),
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(flags, test["ANOMALY_TYPE"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_71(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                _build(name, contamination, cols, seed),
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append(None)
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_72(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                _build(name, contamination, cols, seed),
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"XXmethodXX": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_73(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                _build(name, contamination, cols, seed),
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"METHOD": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_74(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                _build(name, contamination, cols, seed),
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append(None)
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_75(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                _build(name, contamination, cols, seed),
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"XXmethodXX": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_76(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                _build(name, contamination, cols, seed),
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"METHOD": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_77(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                _build(name, contamination, cols, seed),
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "XXrecallXX": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_78(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                _build(name, contamination, cols, seed),
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "RECALL": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_79(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                _build(name, contamination, cols, seed),
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index(None),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_80(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                _build(name, contamination, cols, seed),
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(None).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_81(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                _build(name, contamination, cols, seed),
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("XXmethodXX"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_82(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                _build(name, contamination, cols, seed),
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("METHOD"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_83(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                _build(name, contamination, cols, seed),
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "XXprecisionXX": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_84(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                _build(name, contamination, cols, seed),
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "PRECISION": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_85(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                _build(name, contamination, cols, seed),
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index(None),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_86(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                _build(name, contamination, cols, seed),
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(None).set_index("method"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_87(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                _build(name, contamination, cols, seed),
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("XXmethodXX"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_88(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                _build(name, contamination, cols, seed),
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("METHOD"),
        "fpr": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_89(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                _build(name, contamination, cols, seed),
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "XXfprXX": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_90(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                _build(name, contamination, cols, seed),
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "FPR": pd.Series(fpr, name="fpr"),
    }


def x_evaluate__mutmut_91(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                _build(name, contamination, cols, seed),
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(None, name="fpr"),
    }


def x_evaluate__mutmut_92(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                _build(name, contamination, cols, seed),
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name=None),
    }


def x_evaluate__mutmut_93(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                _build(name, contamination, cols, seed),
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(name="fpr"),
    }


def x_evaluate__mutmut_94(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                _build(name, contamination, cols, seed),
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, ),
    }


def x_evaluate__mutmut_95(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                _build(name, contamination, cols, seed),
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name="XXfprXX"),
    }


def x_evaluate__mutmut_96(df: pd.DataFrame, cols: list[str], seed: int, names: list[str] | None = None):
    names = names or DETECTORS
    unknown = [n for n in names if n not in KNOWN]
    if unknown:
        raise ValueError(f"unknown detector names: {unknown}")
    train, _val, test = split(df, seed)
    contamination = float(train["anomaly"].mean())
    features = [*cols, "t"]
    recall_rows, precision_rows, fpr = [], [], {}
    for name in [*names, "transform_dedup"]:
        if name == "transform_dedup":
            flags = test.duplicated(subset=features, keep=False)
        else:
            flags = detect(
                test[features],
                _build(name, contamination, cols, seed),
                fit_df=capped(train[features], name, seed),
            ).flags
        flags = pd.Series(np.asarray(flags), index=test.index)
        fpr[name] = float(flags[test["anomaly_type"] == "clean"].mean())
        r, p = _per_type(flags, test["anomaly_type"])
        recall_rows.append({"method": name, **r})
        precision_rows.append({"method": name, **p})
    return {
        "recall": pd.DataFrame(recall_rows).set_index("method"),
        "precision": pd.DataFrame(precision_rows).set_index("method"),
        "fpr": pd.Series(fpr, name="FPR"),
    }

mutants_x_evaluate__mutmut['_mutmut_orig'] = x_evaluate__mutmut_orig # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_1'] = x_evaluate__mutmut_1 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_2'] = x_evaluate__mutmut_2 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_3'] = x_evaluate__mutmut_3 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_4'] = x_evaluate__mutmut_4 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_5'] = x_evaluate__mutmut_5 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_6'] = x_evaluate__mutmut_6 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_7'] = x_evaluate__mutmut_7 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_8'] = x_evaluate__mutmut_8 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_9'] = x_evaluate__mutmut_9 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_10'] = x_evaluate__mutmut_10 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_11'] = x_evaluate__mutmut_11 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_12'] = x_evaluate__mutmut_12 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_13'] = x_evaluate__mutmut_13 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_14'] = x_evaluate__mutmut_14 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_15'] = x_evaluate__mutmut_15 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_16'] = x_evaluate__mutmut_16 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_17'] = x_evaluate__mutmut_17 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_18'] = x_evaluate__mutmut_18 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_19'] = x_evaluate__mutmut_19 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_20'] = x_evaluate__mutmut_20 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_21'] = x_evaluate__mutmut_21 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_22'] = x_evaluate__mutmut_22 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_23'] = x_evaluate__mutmut_23 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_24'] = x_evaluate__mutmut_24 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_25'] = x_evaluate__mutmut_25 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_26'] = x_evaluate__mutmut_26 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_27'] = x_evaluate__mutmut_27 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_28'] = x_evaluate__mutmut_28 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_29'] = x_evaluate__mutmut_29 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_30'] = x_evaluate__mutmut_30 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_31'] = x_evaluate__mutmut_31 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_32'] = x_evaluate__mutmut_32 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_33'] = x_evaluate__mutmut_33 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_34'] = x_evaluate__mutmut_34 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_35'] = x_evaluate__mutmut_35 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_36'] = x_evaluate__mutmut_36 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_37'] = x_evaluate__mutmut_37 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_38'] = x_evaluate__mutmut_38 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_39'] = x_evaluate__mutmut_39 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_40'] = x_evaluate__mutmut_40 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_41'] = x_evaluate__mutmut_41 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_42'] = x_evaluate__mutmut_42 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_43'] = x_evaluate__mutmut_43 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_44'] = x_evaluate__mutmut_44 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_45'] = x_evaluate__mutmut_45 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_46'] = x_evaluate__mutmut_46 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_47'] = x_evaluate__mutmut_47 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_48'] = x_evaluate__mutmut_48 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_49'] = x_evaluate__mutmut_49 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_50'] = x_evaluate__mutmut_50 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_51'] = x_evaluate__mutmut_51 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_52'] = x_evaluate__mutmut_52 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_53'] = x_evaluate__mutmut_53 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_54'] = x_evaluate__mutmut_54 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_55'] = x_evaluate__mutmut_55 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_56'] = x_evaluate__mutmut_56 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_57'] = x_evaluate__mutmut_57 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_58'] = x_evaluate__mutmut_58 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_59'] = x_evaluate__mutmut_59 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_60'] = x_evaluate__mutmut_60 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_61'] = x_evaluate__mutmut_61 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_62'] = x_evaluate__mutmut_62 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_63'] = x_evaluate__mutmut_63 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_64'] = x_evaluate__mutmut_64 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_65'] = x_evaluate__mutmut_65 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_66'] = x_evaluate__mutmut_66 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_67'] = x_evaluate__mutmut_67 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_68'] = x_evaluate__mutmut_68 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_69'] = x_evaluate__mutmut_69 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_70'] = x_evaluate__mutmut_70 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_71'] = x_evaluate__mutmut_71 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_72'] = x_evaluate__mutmut_72 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_73'] = x_evaluate__mutmut_73 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_74'] = x_evaluate__mutmut_74 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_75'] = x_evaluate__mutmut_75 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_76'] = x_evaluate__mutmut_76 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_77'] = x_evaluate__mutmut_77 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_78'] = x_evaluate__mutmut_78 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_79'] = x_evaluate__mutmut_79 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_80'] = x_evaluate__mutmut_80 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_81'] = x_evaluate__mutmut_81 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_82'] = x_evaluate__mutmut_82 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_83'] = x_evaluate__mutmut_83 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_84'] = x_evaluate__mutmut_84 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_85'] = x_evaluate__mutmut_85 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_86'] = x_evaluate__mutmut_86 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_87'] = x_evaluate__mutmut_87 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_88'] = x_evaluate__mutmut_88 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_89'] = x_evaluate__mutmut_89 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_90'] = x_evaluate__mutmut_90 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_91'] = x_evaluate__mutmut_91 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_92'] = x_evaluate__mutmut_92 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_93'] = x_evaluate__mutmut_93 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_94'] = x_evaluate__mutmut_94 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_95'] = x_evaluate__mutmut_95 # type: ignore # mutmut generated
mutants_x_evaluate__mutmut['x_evaluate__mutmut_96'] = x_evaluate__mutmut_96 # type: ignore # mutmut generated
