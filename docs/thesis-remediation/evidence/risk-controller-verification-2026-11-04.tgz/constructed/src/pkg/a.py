def compute(value):
    return value + 1
