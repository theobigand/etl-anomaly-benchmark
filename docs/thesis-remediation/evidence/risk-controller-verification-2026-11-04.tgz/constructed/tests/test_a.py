from pkg.a import compute
def test_compute():
    assert compute(2) == 3
    assert compute(-1) == 0
