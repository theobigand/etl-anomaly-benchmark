

from mutmut.mutation.trampoline import wrap_in_trampoline as _mutmut_mutated, MutantDict
mutants_x_compute__mutmut: MutantDict = {}  # type: ignore
@_mutmut_mutated(mutants_x_compute__mutmut)
def compute(value):
    return value + 1
def x_compute__mutmut_orig(value):
    return value + 1
def x_compute__mutmut_1(value):
    return value - 1
def x_compute__mutmut_2(value):
    return value + 2

mutants_x_compute__mutmut['_mutmut_orig'] = x_compute__mutmut_orig # type: ignore # mutmut generated
mutants_x_compute__mutmut['x_compute__mutmut_1'] = x_compute__mutmut_1 # type: ignore # mutmut generated
mutants_x_compute__mutmut['x_compute__mutmut_2'] = x_compute__mutmut_2 # type: ignore # mutmut generated
