"""Run native mutation in an owned POSIX process group before binding its cache.

A terminal parent alone is insufficient when workers remain alive. Unresolved
attempts retain their pending record and require process inspection before reuse.
This command records execution provenance, not mutation-policy compliance.
"""

from __future__ import annotations

import argparse
import fcntl
import hashlib
import json
import os
import platform
import subprocess
import sys
import tomllib
from importlib.metadata import distributions
from pathlib import Path
from uuid import uuid4

from verification import mutation_cache, mutation_scope
from verification.mutation_policy import _relative, validate_policy

FIXED_ENV = {
    "OMP_NUM_THREADS": "1",
    "OPENBLAS_NUM_THREADS": "1",
    "MKL_NUM_THREADS": "1",
    "PYTHONHASHSEED": "0",
    "PYTHONPATH": "",
}
ENVIRONMENT_KEYS = (
    *FIXED_ENV,
    "PYTEST_ADDOPTS",
    "PYTEST_PLUGINS",
    "PYTEST_DISABLE_PLUGIN_AUTOLOAD",
    "COVERAGE_PROCESS_START",
    "COVERAGE_RCFILE",
    "NUMEXPR_NUM_THREADS",
    "VECLIB_MAXIMUM_THREADS",
    "CUDA_VISIBLE_DEVICES",
)


from mutmut.mutation.trampoline import wrap_in_trampoline as _mutmut_mutated, MutantDict
mutants_x_collect_runtime__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_collect_runtime__mutmut)
def collect_runtime(env: dict[str, str]) -> dict:
    """Observe this interpreter and installed versions; do not accept supplied pins."""
    packages: dict[str, str] = {}
    for distribution in distributions():
        name = distribution.metadata["Name"].lower().replace("_", "-")
        if name in packages and packages[name] != distribution.version:
            raise ValueError("conflicting installed distribution versions")
        packages[name] = distribution.version
    return {
        "python": platform.python_version(),
        "platform": platform.platform(),
        "executable_sha256": hashlib.sha256(Path(sys.executable).read_bytes()).hexdigest(),
        "packages": dict(sorted(packages.items())),
        "environment_sha256": {
            key: hashlib.sha256(env[key].encode()).hexdigest() if key in env else None
            for key in ENVIRONMENT_KEYS
        },
    }


def x_collect_runtime__mutmut_orig(env: dict[str, str]) -> dict:
    """Observe this interpreter and installed versions; do not accept supplied pins."""
    packages: dict[str, str] = {}
    for distribution in distributions():
        name = distribution.metadata["Name"].lower().replace("_", "-")
        if name in packages and packages[name] != distribution.version:
            raise ValueError("conflicting installed distribution versions")
        packages[name] = distribution.version
    return {
        "python": platform.python_version(),
        "platform": platform.platform(),
        "executable_sha256": hashlib.sha256(Path(sys.executable).read_bytes()).hexdigest(),
        "packages": dict(sorted(packages.items())),
        "environment_sha256": {
            key: hashlib.sha256(env[key].encode()).hexdigest() if key in env else None
            for key in ENVIRONMENT_KEYS
        },
    }


def x_collect_runtime__mutmut_1(env: dict[str, str]) -> dict:
    """Observe this interpreter and installed versions; do not accept supplied pins."""
    packages: dict[str, str] = None
    for distribution in distributions():
        name = distribution.metadata["Name"].lower().replace("_", "-")
        if name in packages and packages[name] != distribution.version:
            raise ValueError("conflicting installed distribution versions")
        packages[name] = distribution.version
    return {
        "python": platform.python_version(),
        "platform": platform.platform(),
        "executable_sha256": hashlib.sha256(Path(sys.executable).read_bytes()).hexdigest(),
        "packages": dict(sorted(packages.items())),
        "environment_sha256": {
            key: hashlib.sha256(env[key].encode()).hexdigest() if key in env else None
            for key in ENVIRONMENT_KEYS
        },
    }


def x_collect_runtime__mutmut_2(env: dict[str, str]) -> dict:
    """Observe this interpreter and installed versions; do not accept supplied pins."""
    packages: dict[str, str] = {}
    for distribution in distributions():
        name = None
        if name in packages and packages[name] != distribution.version:
            raise ValueError("conflicting installed distribution versions")
        packages[name] = distribution.version
    return {
        "python": platform.python_version(),
        "platform": platform.platform(),
        "executable_sha256": hashlib.sha256(Path(sys.executable).read_bytes()).hexdigest(),
        "packages": dict(sorted(packages.items())),
        "environment_sha256": {
            key: hashlib.sha256(env[key].encode()).hexdigest() if key in env else None
            for key in ENVIRONMENT_KEYS
        },
    }


def x_collect_runtime__mutmut_3(env: dict[str, str]) -> dict:
    """Observe this interpreter and installed versions; do not accept supplied pins."""
    packages: dict[str, str] = {}
    for distribution in distributions():
        name = distribution.metadata["Name"].lower().replace(None, "-")
        if name in packages and packages[name] != distribution.version:
            raise ValueError("conflicting installed distribution versions")
        packages[name] = distribution.version
    return {
        "python": platform.python_version(),
        "platform": platform.platform(),
        "executable_sha256": hashlib.sha256(Path(sys.executable).read_bytes()).hexdigest(),
        "packages": dict(sorted(packages.items())),
        "environment_sha256": {
            key: hashlib.sha256(env[key].encode()).hexdigest() if key in env else None
            for key in ENVIRONMENT_KEYS
        },
    }


def x_collect_runtime__mutmut_4(env: dict[str, str]) -> dict:
    """Observe this interpreter and installed versions; do not accept supplied pins."""
    packages: dict[str, str] = {}
    for distribution in distributions():
        name = distribution.metadata["Name"].lower().replace("_", None)
        if name in packages and packages[name] != distribution.version:
            raise ValueError("conflicting installed distribution versions")
        packages[name] = distribution.version
    return {
        "python": platform.python_version(),
        "platform": platform.platform(),
        "executable_sha256": hashlib.sha256(Path(sys.executable).read_bytes()).hexdigest(),
        "packages": dict(sorted(packages.items())),
        "environment_sha256": {
            key: hashlib.sha256(env[key].encode()).hexdigest() if key in env else None
            for key in ENVIRONMENT_KEYS
        },
    }


def x_collect_runtime__mutmut_5(env: dict[str, str]) -> dict:
    """Observe this interpreter and installed versions; do not accept supplied pins."""
    packages: dict[str, str] = {}
    for distribution in distributions():
        name = distribution.metadata["Name"].lower().replace("-")
        if name in packages and packages[name] != distribution.version:
            raise ValueError("conflicting installed distribution versions")
        packages[name] = distribution.version
    return {
        "python": platform.python_version(),
        "platform": platform.platform(),
        "executable_sha256": hashlib.sha256(Path(sys.executable).read_bytes()).hexdigest(),
        "packages": dict(sorted(packages.items())),
        "environment_sha256": {
            key: hashlib.sha256(env[key].encode()).hexdigest() if key in env else None
            for key in ENVIRONMENT_KEYS
        },
    }


def x_collect_runtime__mutmut_6(env: dict[str, str]) -> dict:
    """Observe this interpreter and installed versions; do not accept supplied pins."""
    packages: dict[str, str] = {}
    for distribution in distributions():
        name = distribution.metadata["Name"].lower().replace("_", )
        if name in packages and packages[name] != distribution.version:
            raise ValueError("conflicting installed distribution versions")
        packages[name] = distribution.version
    return {
        "python": platform.python_version(),
        "platform": platform.platform(),
        "executable_sha256": hashlib.sha256(Path(sys.executable).read_bytes()).hexdigest(),
        "packages": dict(sorted(packages.items())),
        "environment_sha256": {
            key: hashlib.sha256(env[key].encode()).hexdigest() if key in env else None
            for key in ENVIRONMENT_KEYS
        },
    }


def x_collect_runtime__mutmut_7(env: dict[str, str]) -> dict:
    """Observe this interpreter and installed versions; do not accept supplied pins."""
    packages: dict[str, str] = {}
    for distribution in distributions():
        name = distribution.metadata["Name"].upper().replace("_", "-")
        if name in packages and packages[name] != distribution.version:
            raise ValueError("conflicting installed distribution versions")
        packages[name] = distribution.version
    return {
        "python": platform.python_version(),
        "platform": platform.platform(),
        "executable_sha256": hashlib.sha256(Path(sys.executable).read_bytes()).hexdigest(),
        "packages": dict(sorted(packages.items())),
        "environment_sha256": {
            key: hashlib.sha256(env[key].encode()).hexdigest() if key in env else None
            for key in ENVIRONMENT_KEYS
        },
    }


def x_collect_runtime__mutmut_8(env: dict[str, str]) -> dict:
    """Observe this interpreter and installed versions; do not accept supplied pins."""
    packages: dict[str, str] = {}
    for distribution in distributions():
        name = distribution.metadata["XXNameXX"].lower().replace("_", "-")
        if name in packages and packages[name] != distribution.version:
            raise ValueError("conflicting installed distribution versions")
        packages[name] = distribution.version
    return {
        "python": platform.python_version(),
        "platform": platform.platform(),
        "executable_sha256": hashlib.sha256(Path(sys.executable).read_bytes()).hexdigest(),
        "packages": dict(sorted(packages.items())),
        "environment_sha256": {
            key: hashlib.sha256(env[key].encode()).hexdigest() if key in env else None
            for key in ENVIRONMENT_KEYS
        },
    }


def x_collect_runtime__mutmut_9(env: dict[str, str]) -> dict:
    """Observe this interpreter and installed versions; do not accept supplied pins."""
    packages: dict[str, str] = {}
    for distribution in distributions():
        name = distribution.metadata["name"].lower().replace("_", "-")
        if name in packages and packages[name] != distribution.version:
            raise ValueError("conflicting installed distribution versions")
        packages[name] = distribution.version
    return {
        "python": platform.python_version(),
        "platform": platform.platform(),
        "executable_sha256": hashlib.sha256(Path(sys.executable).read_bytes()).hexdigest(),
        "packages": dict(sorted(packages.items())),
        "environment_sha256": {
            key: hashlib.sha256(env[key].encode()).hexdigest() if key in env else None
            for key in ENVIRONMENT_KEYS
        },
    }


def x_collect_runtime__mutmut_10(env: dict[str, str]) -> dict:
    """Observe this interpreter and installed versions; do not accept supplied pins."""
    packages: dict[str, str] = {}
    for distribution in distributions():
        name = distribution.metadata["NAME"].lower().replace("_", "-")
        if name in packages and packages[name] != distribution.version:
            raise ValueError("conflicting installed distribution versions")
        packages[name] = distribution.version
    return {
        "python": platform.python_version(),
        "platform": platform.platform(),
        "executable_sha256": hashlib.sha256(Path(sys.executable).read_bytes()).hexdigest(),
        "packages": dict(sorted(packages.items())),
        "environment_sha256": {
            key: hashlib.sha256(env[key].encode()).hexdigest() if key in env else None
            for key in ENVIRONMENT_KEYS
        },
    }


def x_collect_runtime__mutmut_11(env: dict[str, str]) -> dict:
    """Observe this interpreter and installed versions; do not accept supplied pins."""
    packages: dict[str, str] = {}
    for distribution in distributions():
        name = distribution.metadata["Name"].lower().replace("XX_XX", "-")
        if name in packages and packages[name] != distribution.version:
            raise ValueError("conflicting installed distribution versions")
        packages[name] = distribution.version
    return {
        "python": platform.python_version(),
        "platform": platform.platform(),
        "executable_sha256": hashlib.sha256(Path(sys.executable).read_bytes()).hexdigest(),
        "packages": dict(sorted(packages.items())),
        "environment_sha256": {
            key: hashlib.sha256(env[key].encode()).hexdigest() if key in env else None
            for key in ENVIRONMENT_KEYS
        },
    }


def x_collect_runtime__mutmut_12(env: dict[str, str]) -> dict:
    """Observe this interpreter and installed versions; do not accept supplied pins."""
    packages: dict[str, str] = {}
    for distribution in distributions():
        name = distribution.metadata["Name"].lower().replace("_", "XX-XX")
        if name in packages and packages[name] != distribution.version:
            raise ValueError("conflicting installed distribution versions")
        packages[name] = distribution.version
    return {
        "python": platform.python_version(),
        "platform": platform.platform(),
        "executable_sha256": hashlib.sha256(Path(sys.executable).read_bytes()).hexdigest(),
        "packages": dict(sorted(packages.items())),
        "environment_sha256": {
            key: hashlib.sha256(env[key].encode()).hexdigest() if key in env else None
            for key in ENVIRONMENT_KEYS
        },
    }


def x_collect_runtime__mutmut_13(env: dict[str, str]) -> dict:
    """Observe this interpreter and installed versions; do not accept supplied pins."""
    packages: dict[str, str] = {}
    for distribution in distributions():
        name = distribution.metadata["Name"].lower().replace("_", "-")
        if name in packages or packages[name] != distribution.version:
            raise ValueError("conflicting installed distribution versions")
        packages[name] = distribution.version
    return {
        "python": platform.python_version(),
        "platform": platform.platform(),
        "executable_sha256": hashlib.sha256(Path(sys.executable).read_bytes()).hexdigest(),
        "packages": dict(sorted(packages.items())),
        "environment_sha256": {
            key: hashlib.sha256(env[key].encode()).hexdigest() if key in env else None
            for key in ENVIRONMENT_KEYS
        },
    }


def x_collect_runtime__mutmut_14(env: dict[str, str]) -> dict:
    """Observe this interpreter and installed versions; do not accept supplied pins."""
    packages: dict[str, str] = {}
    for distribution in distributions():
        name = distribution.metadata["Name"].lower().replace("_", "-")
        if name not in packages and packages[name] != distribution.version:
            raise ValueError("conflicting installed distribution versions")
        packages[name] = distribution.version
    return {
        "python": platform.python_version(),
        "platform": platform.platform(),
        "executable_sha256": hashlib.sha256(Path(sys.executable).read_bytes()).hexdigest(),
        "packages": dict(sorted(packages.items())),
        "environment_sha256": {
            key: hashlib.sha256(env[key].encode()).hexdigest() if key in env else None
            for key in ENVIRONMENT_KEYS
        },
    }


def x_collect_runtime__mutmut_15(env: dict[str, str]) -> dict:
    """Observe this interpreter and installed versions; do not accept supplied pins."""
    packages: dict[str, str] = {}
    for distribution in distributions():
        name = distribution.metadata["Name"].lower().replace("_", "-")
        if name in packages and packages[name] == distribution.version:
            raise ValueError("conflicting installed distribution versions")
        packages[name] = distribution.version
    return {
        "python": platform.python_version(),
        "platform": platform.platform(),
        "executable_sha256": hashlib.sha256(Path(sys.executable).read_bytes()).hexdigest(),
        "packages": dict(sorted(packages.items())),
        "environment_sha256": {
            key: hashlib.sha256(env[key].encode()).hexdigest() if key in env else None
            for key in ENVIRONMENT_KEYS
        },
    }


def x_collect_runtime__mutmut_16(env: dict[str, str]) -> dict:
    """Observe this interpreter and installed versions; do not accept supplied pins."""
    packages: dict[str, str] = {}
    for distribution in distributions():
        name = distribution.metadata["Name"].lower().replace("_", "-")
        if name in packages and packages[name] != distribution.version:
            raise ValueError(None)
        packages[name] = distribution.version
    return {
        "python": platform.python_version(),
        "platform": platform.platform(),
        "executable_sha256": hashlib.sha256(Path(sys.executable).read_bytes()).hexdigest(),
        "packages": dict(sorted(packages.items())),
        "environment_sha256": {
            key: hashlib.sha256(env[key].encode()).hexdigest() if key in env else None
            for key in ENVIRONMENT_KEYS
        },
    }


def x_collect_runtime__mutmut_17(env: dict[str, str]) -> dict:
    """Observe this interpreter and installed versions; do not accept supplied pins."""
    packages: dict[str, str] = {}
    for distribution in distributions():
        name = distribution.metadata["Name"].lower().replace("_", "-")
        if name in packages and packages[name] != distribution.version:
            raise ValueError("XXconflicting installed distribution versionsXX")
        packages[name] = distribution.version
    return {
        "python": platform.python_version(),
        "platform": platform.platform(),
        "executable_sha256": hashlib.sha256(Path(sys.executable).read_bytes()).hexdigest(),
        "packages": dict(sorted(packages.items())),
        "environment_sha256": {
            key: hashlib.sha256(env[key].encode()).hexdigest() if key in env else None
            for key in ENVIRONMENT_KEYS
        },
    }


def x_collect_runtime__mutmut_18(env: dict[str, str]) -> dict:
    """Observe this interpreter and installed versions; do not accept supplied pins."""
    packages: dict[str, str] = {}
    for distribution in distributions():
        name = distribution.metadata["Name"].lower().replace("_", "-")
        if name in packages and packages[name] != distribution.version:
            raise ValueError("CONFLICTING INSTALLED DISTRIBUTION VERSIONS")
        packages[name] = distribution.version
    return {
        "python": platform.python_version(),
        "platform": platform.platform(),
        "executable_sha256": hashlib.sha256(Path(sys.executable).read_bytes()).hexdigest(),
        "packages": dict(sorted(packages.items())),
        "environment_sha256": {
            key: hashlib.sha256(env[key].encode()).hexdigest() if key in env else None
            for key in ENVIRONMENT_KEYS
        },
    }


def x_collect_runtime__mutmut_19(env: dict[str, str]) -> dict:
    """Observe this interpreter and installed versions; do not accept supplied pins."""
    packages: dict[str, str] = {}
    for distribution in distributions():
        name = distribution.metadata["Name"].lower().replace("_", "-")
        if name in packages and packages[name] != distribution.version:
            raise ValueError("conflicting installed distribution versions")
        packages[name] = None
    return {
        "python": platform.python_version(),
        "platform": platform.platform(),
        "executable_sha256": hashlib.sha256(Path(sys.executable).read_bytes()).hexdigest(),
        "packages": dict(sorted(packages.items())),
        "environment_sha256": {
            key: hashlib.sha256(env[key].encode()).hexdigest() if key in env else None
            for key in ENVIRONMENT_KEYS
        },
    }


def x_collect_runtime__mutmut_20(env: dict[str, str]) -> dict:
    """Observe this interpreter and installed versions; do not accept supplied pins."""
    packages: dict[str, str] = {}
    for distribution in distributions():
        name = distribution.metadata["Name"].lower().replace("_", "-")
        if name in packages and packages[name] != distribution.version:
            raise ValueError("conflicting installed distribution versions")
        packages[name] = distribution.version
    return {
        "XXpythonXX": platform.python_version(),
        "platform": platform.platform(),
        "executable_sha256": hashlib.sha256(Path(sys.executable).read_bytes()).hexdigest(),
        "packages": dict(sorted(packages.items())),
        "environment_sha256": {
            key: hashlib.sha256(env[key].encode()).hexdigest() if key in env else None
            for key in ENVIRONMENT_KEYS
        },
    }


def x_collect_runtime__mutmut_21(env: dict[str, str]) -> dict:
    """Observe this interpreter and installed versions; do not accept supplied pins."""
    packages: dict[str, str] = {}
    for distribution in distributions():
        name = distribution.metadata["Name"].lower().replace("_", "-")
        if name in packages and packages[name] != distribution.version:
            raise ValueError("conflicting installed distribution versions")
        packages[name] = distribution.version
    return {
        "PYTHON": platform.python_version(),
        "platform": platform.platform(),
        "executable_sha256": hashlib.sha256(Path(sys.executable).read_bytes()).hexdigest(),
        "packages": dict(sorted(packages.items())),
        "environment_sha256": {
            key: hashlib.sha256(env[key].encode()).hexdigest() if key in env else None
            for key in ENVIRONMENT_KEYS
        },
    }


def x_collect_runtime__mutmut_22(env: dict[str, str]) -> dict:
    """Observe this interpreter and installed versions; do not accept supplied pins."""
    packages: dict[str, str] = {}
    for distribution in distributions():
        name = distribution.metadata["Name"].lower().replace("_", "-")
        if name in packages and packages[name] != distribution.version:
            raise ValueError("conflicting installed distribution versions")
        packages[name] = distribution.version
    return {
        "python": platform.python_version(),
        "XXplatformXX": platform.platform(),
        "executable_sha256": hashlib.sha256(Path(sys.executable).read_bytes()).hexdigest(),
        "packages": dict(sorted(packages.items())),
        "environment_sha256": {
            key: hashlib.sha256(env[key].encode()).hexdigest() if key in env else None
            for key in ENVIRONMENT_KEYS
        },
    }


def x_collect_runtime__mutmut_23(env: dict[str, str]) -> dict:
    """Observe this interpreter and installed versions; do not accept supplied pins."""
    packages: dict[str, str] = {}
    for distribution in distributions():
        name = distribution.metadata["Name"].lower().replace("_", "-")
        if name in packages and packages[name] != distribution.version:
            raise ValueError("conflicting installed distribution versions")
        packages[name] = distribution.version
    return {
        "python": platform.python_version(),
        "PLATFORM": platform.platform(),
        "executable_sha256": hashlib.sha256(Path(sys.executable).read_bytes()).hexdigest(),
        "packages": dict(sorted(packages.items())),
        "environment_sha256": {
            key: hashlib.sha256(env[key].encode()).hexdigest() if key in env else None
            for key in ENVIRONMENT_KEYS
        },
    }


def x_collect_runtime__mutmut_24(env: dict[str, str]) -> dict:
    """Observe this interpreter and installed versions; do not accept supplied pins."""
    packages: dict[str, str] = {}
    for distribution in distributions():
        name = distribution.metadata["Name"].lower().replace("_", "-")
        if name in packages and packages[name] != distribution.version:
            raise ValueError("conflicting installed distribution versions")
        packages[name] = distribution.version
    return {
        "python": platform.python_version(),
        "platform": platform.platform(),
        "XXexecutable_sha256XX": hashlib.sha256(Path(sys.executable).read_bytes()).hexdigest(),
        "packages": dict(sorted(packages.items())),
        "environment_sha256": {
            key: hashlib.sha256(env[key].encode()).hexdigest() if key in env else None
            for key in ENVIRONMENT_KEYS
        },
    }


def x_collect_runtime__mutmut_25(env: dict[str, str]) -> dict:
    """Observe this interpreter and installed versions; do not accept supplied pins."""
    packages: dict[str, str] = {}
    for distribution in distributions():
        name = distribution.metadata["Name"].lower().replace("_", "-")
        if name in packages and packages[name] != distribution.version:
            raise ValueError("conflicting installed distribution versions")
        packages[name] = distribution.version
    return {
        "python": platform.python_version(),
        "platform": platform.platform(),
        "EXECUTABLE_SHA256": hashlib.sha256(Path(sys.executable).read_bytes()).hexdigest(),
        "packages": dict(sorted(packages.items())),
        "environment_sha256": {
            key: hashlib.sha256(env[key].encode()).hexdigest() if key in env else None
            for key in ENVIRONMENT_KEYS
        },
    }


def x_collect_runtime__mutmut_26(env: dict[str, str]) -> dict:
    """Observe this interpreter and installed versions; do not accept supplied pins."""
    packages: dict[str, str] = {}
    for distribution in distributions():
        name = distribution.metadata["Name"].lower().replace("_", "-")
        if name in packages and packages[name] != distribution.version:
            raise ValueError("conflicting installed distribution versions")
        packages[name] = distribution.version
    return {
        "python": platform.python_version(),
        "platform": platform.platform(),
        "executable_sha256": hashlib.sha256(None).hexdigest(),
        "packages": dict(sorted(packages.items())),
        "environment_sha256": {
            key: hashlib.sha256(env[key].encode()).hexdigest() if key in env else None
            for key in ENVIRONMENT_KEYS
        },
    }


def x_collect_runtime__mutmut_27(env: dict[str, str]) -> dict:
    """Observe this interpreter and installed versions; do not accept supplied pins."""
    packages: dict[str, str] = {}
    for distribution in distributions():
        name = distribution.metadata["Name"].lower().replace("_", "-")
        if name in packages and packages[name] != distribution.version:
            raise ValueError("conflicting installed distribution versions")
        packages[name] = distribution.version
    return {
        "python": platform.python_version(),
        "platform": platform.platform(),
        "executable_sha256": hashlib.sha256(Path(None).read_bytes()).hexdigest(),
        "packages": dict(sorted(packages.items())),
        "environment_sha256": {
            key: hashlib.sha256(env[key].encode()).hexdigest() if key in env else None
            for key in ENVIRONMENT_KEYS
        },
    }


def x_collect_runtime__mutmut_28(env: dict[str, str]) -> dict:
    """Observe this interpreter and installed versions; do not accept supplied pins."""
    packages: dict[str, str] = {}
    for distribution in distributions():
        name = distribution.metadata["Name"].lower().replace("_", "-")
        if name in packages and packages[name] != distribution.version:
            raise ValueError("conflicting installed distribution versions")
        packages[name] = distribution.version
    return {
        "python": platform.python_version(),
        "platform": platform.platform(),
        "executable_sha256": hashlib.sha256(Path(sys.executable).read_bytes()).hexdigest(),
        "XXpackagesXX": dict(sorted(packages.items())),
        "environment_sha256": {
            key: hashlib.sha256(env[key].encode()).hexdigest() if key in env else None
            for key in ENVIRONMENT_KEYS
        },
    }


def x_collect_runtime__mutmut_29(env: dict[str, str]) -> dict:
    """Observe this interpreter and installed versions; do not accept supplied pins."""
    packages: dict[str, str] = {}
    for distribution in distributions():
        name = distribution.metadata["Name"].lower().replace("_", "-")
        if name in packages and packages[name] != distribution.version:
            raise ValueError("conflicting installed distribution versions")
        packages[name] = distribution.version
    return {
        "python": platform.python_version(),
        "platform": platform.platform(),
        "executable_sha256": hashlib.sha256(Path(sys.executable).read_bytes()).hexdigest(),
        "PACKAGES": dict(sorted(packages.items())),
        "environment_sha256": {
            key: hashlib.sha256(env[key].encode()).hexdigest() if key in env else None
            for key in ENVIRONMENT_KEYS
        },
    }


def x_collect_runtime__mutmut_30(env: dict[str, str]) -> dict:
    """Observe this interpreter and installed versions; do not accept supplied pins."""
    packages: dict[str, str] = {}
    for distribution in distributions():
        name = distribution.metadata["Name"].lower().replace("_", "-")
        if name in packages and packages[name] != distribution.version:
            raise ValueError("conflicting installed distribution versions")
        packages[name] = distribution.version
    return {
        "python": platform.python_version(),
        "platform": platform.platform(),
        "executable_sha256": hashlib.sha256(Path(sys.executable).read_bytes()).hexdigest(),
        "packages": dict(None),
        "environment_sha256": {
            key: hashlib.sha256(env[key].encode()).hexdigest() if key in env else None
            for key in ENVIRONMENT_KEYS
        },
    }


def x_collect_runtime__mutmut_31(env: dict[str, str]) -> dict:
    """Observe this interpreter and installed versions; do not accept supplied pins."""
    packages: dict[str, str] = {}
    for distribution in distributions():
        name = distribution.metadata["Name"].lower().replace("_", "-")
        if name in packages and packages[name] != distribution.version:
            raise ValueError("conflicting installed distribution versions")
        packages[name] = distribution.version
    return {
        "python": platform.python_version(),
        "platform": platform.platform(),
        "executable_sha256": hashlib.sha256(Path(sys.executable).read_bytes()).hexdigest(),
        "packages": dict(sorted(None)),
        "environment_sha256": {
            key: hashlib.sha256(env[key].encode()).hexdigest() if key in env else None
            for key in ENVIRONMENT_KEYS
        },
    }


def x_collect_runtime__mutmut_32(env: dict[str, str]) -> dict:
    """Observe this interpreter and installed versions; do not accept supplied pins."""
    packages: dict[str, str] = {}
    for distribution in distributions():
        name = distribution.metadata["Name"].lower().replace("_", "-")
        if name in packages and packages[name] != distribution.version:
            raise ValueError("conflicting installed distribution versions")
        packages[name] = distribution.version
    return {
        "python": platform.python_version(),
        "platform": platform.platform(),
        "executable_sha256": hashlib.sha256(Path(sys.executable).read_bytes()).hexdigest(),
        "packages": dict(sorted(packages.items())),
        "XXenvironment_sha256XX": {
            key: hashlib.sha256(env[key].encode()).hexdigest() if key in env else None
            for key in ENVIRONMENT_KEYS
        },
    }


def x_collect_runtime__mutmut_33(env: dict[str, str]) -> dict:
    """Observe this interpreter and installed versions; do not accept supplied pins."""
    packages: dict[str, str] = {}
    for distribution in distributions():
        name = distribution.metadata["Name"].lower().replace("_", "-")
        if name in packages and packages[name] != distribution.version:
            raise ValueError("conflicting installed distribution versions")
        packages[name] = distribution.version
    return {
        "python": platform.python_version(),
        "platform": platform.platform(),
        "executable_sha256": hashlib.sha256(Path(sys.executable).read_bytes()).hexdigest(),
        "packages": dict(sorted(packages.items())),
        "ENVIRONMENT_SHA256": {
            key: hashlib.sha256(env[key].encode()).hexdigest() if key in env else None
            for key in ENVIRONMENT_KEYS
        },
    }


def x_collect_runtime__mutmut_34(env: dict[str, str]) -> dict:
    """Observe this interpreter and installed versions; do not accept supplied pins."""
    packages: dict[str, str] = {}
    for distribution in distributions():
        name = distribution.metadata["Name"].lower().replace("_", "-")
        if name in packages and packages[name] != distribution.version:
            raise ValueError("conflicting installed distribution versions")
        packages[name] = distribution.version
    return {
        "python": platform.python_version(),
        "platform": platform.platform(),
        "executable_sha256": hashlib.sha256(Path(sys.executable).read_bytes()).hexdigest(),
        "packages": dict(sorted(packages.items())),
        "environment_sha256": {
            key: hashlib.sha256(env[key].encode()).hexdigest() if (key in env) and False else None
            for key in ENVIRONMENT_KEYS
        },
    }


def x_collect_runtime__mutmut_35(env: dict[str, str]) -> dict:
    """Observe this interpreter and installed versions; do not accept supplied pins."""
    packages: dict[str, str] = {}
    for distribution in distributions():
        name = distribution.metadata["Name"].lower().replace("_", "-")
        if name in packages and packages[name] != distribution.version:
            raise ValueError("conflicting installed distribution versions")
        packages[name] = distribution.version
    return {
        "python": platform.python_version(),
        "platform": platform.platform(),
        "executable_sha256": hashlib.sha256(Path(sys.executable).read_bytes()).hexdigest(),
        "packages": dict(sorted(packages.items())),
        "environment_sha256": {
            key: hashlib.sha256(env[key].encode()).hexdigest() if (key in env) or True else None
            for key in ENVIRONMENT_KEYS
        },
    }


def x_collect_runtime__mutmut_36(env: dict[str, str]) -> dict:
    """Observe this interpreter and installed versions; do not accept supplied pins."""
    packages: dict[str, str] = {}
    for distribution in distributions():
        name = distribution.metadata["Name"].lower().replace("_", "-")
        if name in packages and packages[name] != distribution.version:
            raise ValueError("conflicting installed distribution versions")
        packages[name] = distribution.version
    return {
        "python": platform.python_version(),
        "platform": platform.platform(),
        "executable_sha256": hashlib.sha256(Path(sys.executable).read_bytes()).hexdigest(),
        "packages": dict(sorted(packages.items())),
        "environment_sha256": {
            key: hashlib.sha256(None).hexdigest() if key in env else None
            for key in ENVIRONMENT_KEYS
        },
    }


def x_collect_runtime__mutmut_37(env: dict[str, str]) -> dict:
    """Observe this interpreter and installed versions; do not accept supplied pins."""
    packages: dict[str, str] = {}
    for distribution in distributions():
        name = distribution.metadata["Name"].lower().replace("_", "-")
        if name in packages and packages[name] != distribution.version:
            raise ValueError("conflicting installed distribution versions")
        packages[name] = distribution.version
    return {
        "python": platform.python_version(),
        "platform": platform.platform(),
        "executable_sha256": hashlib.sha256(Path(sys.executable).read_bytes()).hexdigest(),
        "packages": dict(sorted(packages.items())),
        "environment_sha256": {
            key: hashlib.sha256(env[key].encode()).hexdigest() if key not in env else None
            for key in ENVIRONMENT_KEYS
        },
    }

mutants_x_collect_runtime__mutmut['_mutmut_orig'] = x_collect_runtime__mutmut_orig # type: ignore # mutmut generated
mutants_x_collect_runtime__mutmut['x_collect_runtime__mutmut_1'] = x_collect_runtime__mutmut_1 # type: ignore # mutmut generated
mutants_x_collect_runtime__mutmut['x_collect_runtime__mutmut_2'] = x_collect_runtime__mutmut_2 # type: ignore # mutmut generated
mutants_x_collect_runtime__mutmut['x_collect_runtime__mutmut_3'] = x_collect_runtime__mutmut_3 # type: ignore # mutmut generated
mutants_x_collect_runtime__mutmut['x_collect_runtime__mutmut_4'] = x_collect_runtime__mutmut_4 # type: ignore # mutmut generated
mutants_x_collect_runtime__mutmut['x_collect_runtime__mutmut_5'] = x_collect_runtime__mutmut_5 # type: ignore # mutmut generated
mutants_x_collect_runtime__mutmut['x_collect_runtime__mutmut_6'] = x_collect_runtime__mutmut_6 # type: ignore # mutmut generated
mutants_x_collect_runtime__mutmut['x_collect_runtime__mutmut_7'] = x_collect_runtime__mutmut_7 # type: ignore # mutmut generated
mutants_x_collect_runtime__mutmut['x_collect_runtime__mutmut_8'] = x_collect_runtime__mutmut_8 # type: ignore # mutmut generated
mutants_x_collect_runtime__mutmut['x_collect_runtime__mutmut_9'] = x_collect_runtime__mutmut_9 # type: ignore # mutmut generated
mutants_x_collect_runtime__mutmut['x_collect_runtime__mutmut_10'] = x_collect_runtime__mutmut_10 # type: ignore # mutmut generated
mutants_x_collect_runtime__mutmut['x_collect_runtime__mutmut_11'] = x_collect_runtime__mutmut_11 # type: ignore # mutmut generated
mutants_x_collect_runtime__mutmut['x_collect_runtime__mutmut_12'] = x_collect_runtime__mutmut_12 # type: ignore # mutmut generated
mutants_x_collect_runtime__mutmut['x_collect_runtime__mutmut_13'] = x_collect_runtime__mutmut_13 # type: ignore # mutmut generated
mutants_x_collect_runtime__mutmut['x_collect_runtime__mutmut_14'] = x_collect_runtime__mutmut_14 # type: ignore # mutmut generated
mutants_x_collect_runtime__mutmut['x_collect_runtime__mutmut_15'] = x_collect_runtime__mutmut_15 # type: ignore # mutmut generated
mutants_x_collect_runtime__mutmut['x_collect_runtime__mutmut_16'] = x_collect_runtime__mutmut_16 # type: ignore # mutmut generated
mutants_x_collect_runtime__mutmut['x_collect_runtime__mutmut_17'] = x_collect_runtime__mutmut_17 # type: ignore # mutmut generated
mutants_x_collect_runtime__mutmut['x_collect_runtime__mutmut_18'] = x_collect_runtime__mutmut_18 # type: ignore # mutmut generated
mutants_x_collect_runtime__mutmut['x_collect_runtime__mutmut_19'] = x_collect_runtime__mutmut_19 # type: ignore # mutmut generated
mutants_x_collect_runtime__mutmut['x_collect_runtime__mutmut_20'] = x_collect_runtime__mutmut_20 # type: ignore # mutmut generated
mutants_x_collect_runtime__mutmut['x_collect_runtime__mutmut_21'] = x_collect_runtime__mutmut_21 # type: ignore # mutmut generated
mutants_x_collect_runtime__mutmut['x_collect_runtime__mutmut_22'] = x_collect_runtime__mutmut_22 # type: ignore # mutmut generated
mutants_x_collect_runtime__mutmut['x_collect_runtime__mutmut_23'] = x_collect_runtime__mutmut_23 # type: ignore # mutmut generated
mutants_x_collect_runtime__mutmut['x_collect_runtime__mutmut_24'] = x_collect_runtime__mutmut_24 # type: ignore # mutmut generated
mutants_x_collect_runtime__mutmut['x_collect_runtime__mutmut_25'] = x_collect_runtime__mutmut_25 # type: ignore # mutmut generated
mutants_x_collect_runtime__mutmut['x_collect_runtime__mutmut_26'] = x_collect_runtime__mutmut_26 # type: ignore # mutmut generated
mutants_x_collect_runtime__mutmut['x_collect_runtime__mutmut_27'] = x_collect_runtime__mutmut_27 # type: ignore # mutmut generated
mutants_x_collect_runtime__mutmut['x_collect_runtime__mutmut_28'] = x_collect_runtime__mutmut_28 # type: ignore # mutmut generated
mutants_x_collect_runtime__mutmut['x_collect_runtime__mutmut_29'] = x_collect_runtime__mutmut_29 # type: ignore # mutmut generated
mutants_x_collect_runtime__mutmut['x_collect_runtime__mutmut_30'] = x_collect_runtime__mutmut_30 # type: ignore # mutmut generated
mutants_x_collect_runtime__mutmut['x_collect_runtime__mutmut_31'] = x_collect_runtime__mutmut_31 # type: ignore # mutmut generated
mutants_x_collect_runtime__mutmut['x_collect_runtime__mutmut_32'] = x_collect_runtime__mutmut_32 # type: ignore # mutmut generated
mutants_x_collect_runtime__mutmut['x_collect_runtime__mutmut_33'] = x_collect_runtime__mutmut_33 # type: ignore # mutmut generated
mutants_x_collect_runtime__mutmut['x_collect_runtime__mutmut_34'] = x_collect_runtime__mutmut_34 # type: ignore # mutmut generated
mutants_x_collect_runtime__mutmut['x_collect_runtime__mutmut_35'] = x_collect_runtime__mutmut_35 # type: ignore # mutmut generated
mutants_x_collect_runtime__mutmut['x_collect_runtime__mutmut_36'] = x_collect_runtime__mutmut_36 # type: ignore # mutmut generated
mutants_x_collect_runtime__mutmut['x_collect_runtime__mutmut_37'] = x_collect_runtime__mutmut_37 # type: ignore # mutmut generated
mutants_x__command__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x__command__mutmut)
def _command(max_children: int) -> list[str]:
    return [sys.executable, "-P", "-m", "mutmut", "run", "--max-children", str(max_children)]


def x__command__mutmut_orig(max_children: int) -> list[str]:
    return [sys.executable, "-P", "-m", "mutmut", "run", "--max-children", str(max_children)]


def x__command__mutmut_1(max_children: int) -> list[str]:
    return [sys.executable, "XX-PXX", "-m", "mutmut", "run", "--max-children", str(max_children)]


def x__command__mutmut_2(max_children: int) -> list[str]:
    return [sys.executable, "-p", "-m", "mutmut", "run", "--max-children", str(max_children)]


def x__command__mutmut_3(max_children: int) -> list[str]:
    return [sys.executable, "-P", "XX-mXX", "mutmut", "run", "--max-children", str(max_children)]


def x__command__mutmut_4(max_children: int) -> list[str]:
    return [sys.executable, "-P", "-M", "mutmut", "run", "--max-children", str(max_children)]


def x__command__mutmut_5(max_children: int) -> list[str]:
    return [sys.executable, "-P", "-m", "XXmutmutXX", "run", "--max-children", str(max_children)]


def x__command__mutmut_6(max_children: int) -> list[str]:
    return [sys.executable, "-P", "-m", "MUTMUT", "run", "--max-children", str(max_children)]


def x__command__mutmut_7(max_children: int) -> list[str]:
    return [sys.executable, "-P", "-m", "mutmut", "XXrunXX", "--max-children", str(max_children)]


def x__command__mutmut_8(max_children: int) -> list[str]:
    return [sys.executable, "-P", "-m", "mutmut", "RUN", "--max-children", str(max_children)]


def x__command__mutmut_9(max_children: int) -> list[str]:
    return [sys.executable, "-P", "-m", "mutmut", "run", "XX--max-childrenXX", str(max_children)]


def x__command__mutmut_10(max_children: int) -> list[str]:
    return [sys.executable, "-P", "-m", "mutmut", "run", "--MAX-CHILDREN", str(max_children)]


def x__command__mutmut_11(max_children: int) -> list[str]:
    return [sys.executable, "-P", "-m", "mutmut", "run", "--max-children", str(None)]

mutants_x__command__mutmut['_mutmut_orig'] = x__command__mutmut_orig # type: ignore # mutmut generated
mutants_x__command__mutmut['x__command__mutmut_1'] = x__command__mutmut_1 # type: ignore # mutmut generated
mutants_x__command__mutmut['x__command__mutmut_2'] = x__command__mutmut_2 # type: ignore # mutmut generated
mutants_x__command__mutmut['x__command__mutmut_3'] = x__command__mutmut_3 # type: ignore # mutmut generated
mutants_x__command__mutmut['x__command__mutmut_4'] = x__command__mutmut_4 # type: ignore # mutmut generated
mutants_x__command__mutmut['x__command__mutmut_5'] = x__command__mutmut_5 # type: ignore # mutmut generated
mutants_x__command__mutmut['x__command__mutmut_6'] = x__command__mutmut_6 # type: ignore # mutmut generated
mutants_x__command__mutmut['x__command__mutmut_7'] = x__command__mutmut_7 # type: ignore # mutmut generated
mutants_x__command__mutmut['x__command__mutmut_8'] = x__command__mutmut_8 # type: ignore # mutmut generated
mutants_x__command__mutmut['x__command__mutmut_9'] = x__command__mutmut_9 # type: ignore # mutmut generated
mutants_x__command__mutmut['x__command__mutmut_10'] = x__command__mutmut_10 # type: ignore # mutmut generated
mutants_x__command__mutmut['x__command__mutmut_11'] = x__command__mutmut_11 # type: ignore # mutmut generated
mutants_x__scope__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x__scope__mutmut)
def _scope(root: Path) -> tuple[list[str], list[str]]:
    policy = json.loads((root / "verification/mutation_risk_policy.json").read_text())
    validate_policy(policy, root)
    configuration = tomllib.loads((root / "pyproject.toml").read_text())["tool"]["mutmut"]
    configured = mutation_scope.resolve(configuration["only_mutate"], root)
    sources = sorted(policy["units"])
    required = {name for name, unit in policy["units"].items() if "no_mutants" not in unit}
    if required - set(configured) or set(configured) - set(sources):
        raise ValueError("native scope does not match the classified production inventory")
    roots = [_relative(name, root) for name in configuration.get("source_paths", [])]
    if any(not any((root / name).is_relative_to(base) for base in roots) for name in configured):
        raise ValueError("native source roots do not cover the configured scope")
    return sources, configured


def x__scope__mutmut_orig(root: Path) -> tuple[list[str], list[str]]:
    policy = json.loads((root / "verification/mutation_risk_policy.json").read_text())
    validate_policy(policy, root)
    configuration = tomllib.loads((root / "pyproject.toml").read_text())["tool"]["mutmut"]
    configured = mutation_scope.resolve(configuration["only_mutate"], root)
    sources = sorted(policy["units"])
    required = {name for name, unit in policy["units"].items() if "no_mutants" not in unit}
    if required - set(configured) or set(configured) - set(sources):
        raise ValueError("native scope does not match the classified production inventory")
    roots = [_relative(name, root) for name in configuration.get("source_paths", [])]
    if any(not any((root / name).is_relative_to(base) for base in roots) for name in configured):
        raise ValueError("native source roots do not cover the configured scope")
    return sources, configured


def x__scope__mutmut_1(root: Path) -> tuple[list[str], list[str]]:
    policy = None
    validate_policy(policy, root)
    configuration = tomllib.loads((root / "pyproject.toml").read_text())["tool"]["mutmut"]
    configured = mutation_scope.resolve(configuration["only_mutate"], root)
    sources = sorted(policy["units"])
    required = {name for name, unit in policy["units"].items() if "no_mutants" not in unit}
    if required - set(configured) or set(configured) - set(sources):
        raise ValueError("native scope does not match the classified production inventory")
    roots = [_relative(name, root) for name in configuration.get("source_paths", [])]
    if any(not any((root / name).is_relative_to(base) for base in roots) for name in configured):
        raise ValueError("native source roots do not cover the configured scope")
    return sources, configured


def x__scope__mutmut_2(root: Path) -> tuple[list[str], list[str]]:
    policy = json.loads(None)
    validate_policy(policy, root)
    configuration = tomllib.loads((root / "pyproject.toml").read_text())["tool"]["mutmut"]
    configured = mutation_scope.resolve(configuration["only_mutate"], root)
    sources = sorted(policy["units"])
    required = {name for name, unit in policy["units"].items() if "no_mutants" not in unit}
    if required - set(configured) or set(configured) - set(sources):
        raise ValueError("native scope does not match the classified production inventory")
    roots = [_relative(name, root) for name in configuration.get("source_paths", [])]
    if any(not any((root / name).is_relative_to(base) for base in roots) for name in configured):
        raise ValueError("native source roots do not cover the configured scope")
    return sources, configured


def x__scope__mutmut_3(root: Path) -> tuple[list[str], list[str]]:
    policy = json.loads((root * "verification/mutation_risk_policy.json").read_text())
    validate_policy(policy, root)
    configuration = tomllib.loads((root / "pyproject.toml").read_text())["tool"]["mutmut"]
    configured = mutation_scope.resolve(configuration["only_mutate"], root)
    sources = sorted(policy["units"])
    required = {name for name, unit in policy["units"].items() if "no_mutants" not in unit}
    if required - set(configured) or set(configured) - set(sources):
        raise ValueError("native scope does not match the classified production inventory")
    roots = [_relative(name, root) for name in configuration.get("source_paths", [])]
    if any(not any((root / name).is_relative_to(base) for base in roots) for name in configured):
        raise ValueError("native source roots do not cover the configured scope")
    return sources, configured


def x__scope__mutmut_4(root: Path) -> tuple[list[str], list[str]]:
    policy = json.loads((root / "XXverification/mutation_risk_policy.jsonXX").read_text())
    validate_policy(policy, root)
    configuration = tomllib.loads((root / "pyproject.toml").read_text())["tool"]["mutmut"]
    configured = mutation_scope.resolve(configuration["only_mutate"], root)
    sources = sorted(policy["units"])
    required = {name for name, unit in policy["units"].items() if "no_mutants" not in unit}
    if required - set(configured) or set(configured) - set(sources):
        raise ValueError("native scope does not match the classified production inventory")
    roots = [_relative(name, root) for name in configuration.get("source_paths", [])]
    if any(not any((root / name).is_relative_to(base) for base in roots) for name in configured):
        raise ValueError("native source roots do not cover the configured scope")
    return sources, configured


def x__scope__mutmut_5(root: Path) -> tuple[list[str], list[str]]:
    policy = json.loads((root / "VERIFICATION/MUTATION_RISK_POLICY.JSON").read_text())
    validate_policy(policy, root)
    configuration = tomllib.loads((root / "pyproject.toml").read_text())["tool"]["mutmut"]
    configured = mutation_scope.resolve(configuration["only_mutate"], root)
    sources = sorted(policy["units"])
    required = {name for name, unit in policy["units"].items() if "no_mutants" not in unit}
    if required - set(configured) or set(configured) - set(sources):
        raise ValueError("native scope does not match the classified production inventory")
    roots = [_relative(name, root) for name in configuration.get("source_paths", [])]
    if any(not any((root / name).is_relative_to(base) for base in roots) for name in configured):
        raise ValueError("native source roots do not cover the configured scope")
    return sources, configured


def x__scope__mutmut_6(root: Path) -> tuple[list[str], list[str]]:
    policy = json.loads((root / "verification/mutation_risk_policy.json").read_text())
    validate_policy(None, root)
    configuration = tomllib.loads((root / "pyproject.toml").read_text())["tool"]["mutmut"]
    configured = mutation_scope.resolve(configuration["only_mutate"], root)
    sources = sorted(policy["units"])
    required = {name for name, unit in policy["units"].items() if "no_mutants" not in unit}
    if required - set(configured) or set(configured) - set(sources):
        raise ValueError("native scope does not match the classified production inventory")
    roots = [_relative(name, root) for name in configuration.get("source_paths", [])]
    if any(not any((root / name).is_relative_to(base) for base in roots) for name in configured):
        raise ValueError("native source roots do not cover the configured scope")
    return sources, configured


def x__scope__mutmut_7(root: Path) -> tuple[list[str], list[str]]:
    policy = json.loads((root / "verification/mutation_risk_policy.json").read_text())
    validate_policy(policy, None)
    configuration = tomllib.loads((root / "pyproject.toml").read_text())["tool"]["mutmut"]
    configured = mutation_scope.resolve(configuration["only_mutate"], root)
    sources = sorted(policy["units"])
    required = {name for name, unit in policy["units"].items() if "no_mutants" not in unit}
    if required - set(configured) or set(configured) - set(sources):
        raise ValueError("native scope does not match the classified production inventory")
    roots = [_relative(name, root) for name in configuration.get("source_paths", [])]
    if any(not any((root / name).is_relative_to(base) for base in roots) for name in configured):
        raise ValueError("native source roots do not cover the configured scope")
    return sources, configured


def x__scope__mutmut_8(root: Path) -> tuple[list[str], list[str]]:
    policy = json.loads((root / "verification/mutation_risk_policy.json").read_text())
    validate_policy(root)
    configuration = tomllib.loads((root / "pyproject.toml").read_text())["tool"]["mutmut"]
    configured = mutation_scope.resolve(configuration["only_mutate"], root)
    sources = sorted(policy["units"])
    required = {name for name, unit in policy["units"].items() if "no_mutants" not in unit}
    if required - set(configured) or set(configured) - set(sources):
        raise ValueError("native scope does not match the classified production inventory")
    roots = [_relative(name, root) for name in configuration.get("source_paths", [])]
    if any(not any((root / name).is_relative_to(base) for base in roots) for name in configured):
        raise ValueError("native source roots do not cover the configured scope")
    return sources, configured


def x__scope__mutmut_9(root: Path) -> tuple[list[str], list[str]]:
    policy = json.loads((root / "verification/mutation_risk_policy.json").read_text())
    validate_policy(policy, )
    configuration = tomllib.loads((root / "pyproject.toml").read_text())["tool"]["mutmut"]
    configured = mutation_scope.resolve(configuration["only_mutate"], root)
    sources = sorted(policy["units"])
    required = {name for name, unit in policy["units"].items() if "no_mutants" not in unit}
    if required - set(configured) or set(configured) - set(sources):
        raise ValueError("native scope does not match the classified production inventory")
    roots = [_relative(name, root) for name in configuration.get("source_paths", [])]
    if any(not any((root / name).is_relative_to(base) for base in roots) for name in configured):
        raise ValueError("native source roots do not cover the configured scope")
    return sources, configured


def x__scope__mutmut_10(root: Path) -> tuple[list[str], list[str]]:
    policy = json.loads((root / "verification/mutation_risk_policy.json").read_text())
    validate_policy(policy, root)
    configuration = None
    configured = mutation_scope.resolve(configuration["only_mutate"], root)
    sources = sorted(policy["units"])
    required = {name for name, unit in policy["units"].items() if "no_mutants" not in unit}
    if required - set(configured) or set(configured) - set(sources):
        raise ValueError("native scope does not match the classified production inventory")
    roots = [_relative(name, root) for name in configuration.get("source_paths", [])]
    if any(not any((root / name).is_relative_to(base) for base in roots) for name in configured):
        raise ValueError("native source roots do not cover the configured scope")
    return sources, configured


def x__scope__mutmut_11(root: Path) -> tuple[list[str], list[str]]:
    policy = json.loads((root / "verification/mutation_risk_policy.json").read_text())
    validate_policy(policy, root)
    configuration = tomllib.loads(None)["tool"]["mutmut"]
    configured = mutation_scope.resolve(configuration["only_mutate"], root)
    sources = sorted(policy["units"])
    required = {name for name, unit in policy["units"].items() if "no_mutants" not in unit}
    if required - set(configured) or set(configured) - set(sources):
        raise ValueError("native scope does not match the classified production inventory")
    roots = [_relative(name, root) for name in configuration.get("source_paths", [])]
    if any(not any((root / name).is_relative_to(base) for base in roots) for name in configured):
        raise ValueError("native source roots do not cover the configured scope")
    return sources, configured


def x__scope__mutmut_12(root: Path) -> tuple[list[str], list[str]]:
    policy = json.loads((root / "verification/mutation_risk_policy.json").read_text())
    validate_policy(policy, root)
    configuration = tomllib.loads((root * "pyproject.toml").read_text())["tool"]["mutmut"]
    configured = mutation_scope.resolve(configuration["only_mutate"], root)
    sources = sorted(policy["units"])
    required = {name for name, unit in policy["units"].items() if "no_mutants" not in unit}
    if required - set(configured) or set(configured) - set(sources):
        raise ValueError("native scope does not match the classified production inventory")
    roots = [_relative(name, root) for name in configuration.get("source_paths", [])]
    if any(not any((root / name).is_relative_to(base) for base in roots) for name in configured):
        raise ValueError("native source roots do not cover the configured scope")
    return sources, configured


def x__scope__mutmut_13(root: Path) -> tuple[list[str], list[str]]:
    policy = json.loads((root / "verification/mutation_risk_policy.json").read_text())
    validate_policy(policy, root)
    configuration = tomllib.loads((root / "XXpyproject.tomlXX").read_text())["tool"]["mutmut"]
    configured = mutation_scope.resolve(configuration["only_mutate"], root)
    sources = sorted(policy["units"])
    required = {name for name, unit in policy["units"].items() if "no_mutants" not in unit}
    if required - set(configured) or set(configured) - set(sources):
        raise ValueError("native scope does not match the classified production inventory")
    roots = [_relative(name, root) for name in configuration.get("source_paths", [])]
    if any(not any((root / name).is_relative_to(base) for base in roots) for name in configured):
        raise ValueError("native source roots do not cover the configured scope")
    return sources, configured


def x__scope__mutmut_14(root: Path) -> tuple[list[str], list[str]]:
    policy = json.loads((root / "verification/mutation_risk_policy.json").read_text())
    validate_policy(policy, root)
    configuration = tomllib.loads((root / "PYPROJECT.TOML").read_text())["tool"]["mutmut"]
    configured = mutation_scope.resolve(configuration["only_mutate"], root)
    sources = sorted(policy["units"])
    required = {name for name, unit in policy["units"].items() if "no_mutants" not in unit}
    if required - set(configured) or set(configured) - set(sources):
        raise ValueError("native scope does not match the classified production inventory")
    roots = [_relative(name, root) for name in configuration.get("source_paths", [])]
    if any(not any((root / name).is_relative_to(base) for base in roots) for name in configured):
        raise ValueError("native source roots do not cover the configured scope")
    return sources, configured


def x__scope__mutmut_15(root: Path) -> tuple[list[str], list[str]]:
    policy = json.loads((root / "verification/mutation_risk_policy.json").read_text())
    validate_policy(policy, root)
    configuration = tomllib.loads((root / "pyproject.toml").read_text())["XXtoolXX"]["mutmut"]
    configured = mutation_scope.resolve(configuration["only_mutate"], root)
    sources = sorted(policy["units"])
    required = {name for name, unit in policy["units"].items() if "no_mutants" not in unit}
    if required - set(configured) or set(configured) - set(sources):
        raise ValueError("native scope does not match the classified production inventory")
    roots = [_relative(name, root) for name in configuration.get("source_paths", [])]
    if any(not any((root / name).is_relative_to(base) for base in roots) for name in configured):
        raise ValueError("native source roots do not cover the configured scope")
    return sources, configured


def x__scope__mutmut_16(root: Path) -> tuple[list[str], list[str]]:
    policy = json.loads((root / "verification/mutation_risk_policy.json").read_text())
    validate_policy(policy, root)
    configuration = tomllib.loads((root / "pyproject.toml").read_text())["TOOL"]["mutmut"]
    configured = mutation_scope.resolve(configuration["only_mutate"], root)
    sources = sorted(policy["units"])
    required = {name for name, unit in policy["units"].items() if "no_mutants" not in unit}
    if required - set(configured) or set(configured) - set(sources):
        raise ValueError("native scope does not match the classified production inventory")
    roots = [_relative(name, root) for name in configuration.get("source_paths", [])]
    if any(not any((root / name).is_relative_to(base) for base in roots) for name in configured):
        raise ValueError("native source roots do not cover the configured scope")
    return sources, configured


def x__scope__mutmut_17(root: Path) -> tuple[list[str], list[str]]:
    policy = json.loads((root / "verification/mutation_risk_policy.json").read_text())
    validate_policy(policy, root)
    configuration = tomllib.loads((root / "pyproject.toml").read_text())["tool"]["XXmutmutXX"]
    configured = mutation_scope.resolve(configuration["only_mutate"], root)
    sources = sorted(policy["units"])
    required = {name for name, unit in policy["units"].items() if "no_mutants" not in unit}
    if required - set(configured) or set(configured) - set(sources):
        raise ValueError("native scope does not match the classified production inventory")
    roots = [_relative(name, root) for name in configuration.get("source_paths", [])]
    if any(not any((root / name).is_relative_to(base) for base in roots) for name in configured):
        raise ValueError("native source roots do not cover the configured scope")
    return sources, configured


def x__scope__mutmut_18(root: Path) -> tuple[list[str], list[str]]:
    policy = json.loads((root / "verification/mutation_risk_policy.json").read_text())
    validate_policy(policy, root)
    configuration = tomllib.loads((root / "pyproject.toml").read_text())["tool"]["MUTMUT"]
    configured = mutation_scope.resolve(configuration["only_mutate"], root)
    sources = sorted(policy["units"])
    required = {name for name, unit in policy["units"].items() if "no_mutants" not in unit}
    if required - set(configured) or set(configured) - set(sources):
        raise ValueError("native scope does not match the classified production inventory")
    roots = [_relative(name, root) for name in configuration.get("source_paths", [])]
    if any(not any((root / name).is_relative_to(base) for base in roots) for name in configured):
        raise ValueError("native source roots do not cover the configured scope")
    return sources, configured


def x__scope__mutmut_19(root: Path) -> tuple[list[str], list[str]]:
    policy = json.loads((root / "verification/mutation_risk_policy.json").read_text())
    validate_policy(policy, root)
    configuration = tomllib.loads((root / "pyproject.toml").read_text())["tool"]["mutmut"]
    configured = None
    sources = sorted(policy["units"])
    required = {name for name, unit in policy["units"].items() if "no_mutants" not in unit}
    if required - set(configured) or set(configured) - set(sources):
        raise ValueError("native scope does not match the classified production inventory")
    roots = [_relative(name, root) for name in configuration.get("source_paths", [])]
    if any(not any((root / name).is_relative_to(base) for base in roots) for name in configured):
        raise ValueError("native source roots do not cover the configured scope")
    return sources, configured


def x__scope__mutmut_20(root: Path) -> tuple[list[str], list[str]]:
    policy = json.loads((root / "verification/mutation_risk_policy.json").read_text())
    validate_policy(policy, root)
    configuration = tomllib.loads((root / "pyproject.toml").read_text())["tool"]["mutmut"]
    configured = mutation_scope.resolve(None, root)
    sources = sorted(policy["units"])
    required = {name for name, unit in policy["units"].items() if "no_mutants" not in unit}
    if required - set(configured) or set(configured) - set(sources):
        raise ValueError("native scope does not match the classified production inventory")
    roots = [_relative(name, root) for name in configuration.get("source_paths", [])]
    if any(not any((root / name).is_relative_to(base) for base in roots) for name in configured):
        raise ValueError("native source roots do not cover the configured scope")
    return sources, configured


def x__scope__mutmut_21(root: Path) -> tuple[list[str], list[str]]:
    policy = json.loads((root / "verification/mutation_risk_policy.json").read_text())
    validate_policy(policy, root)
    configuration = tomllib.loads((root / "pyproject.toml").read_text())["tool"]["mutmut"]
    configured = mutation_scope.resolve(configuration["only_mutate"], None)
    sources = sorted(policy["units"])
    required = {name for name, unit in policy["units"].items() if "no_mutants" not in unit}
    if required - set(configured) or set(configured) - set(sources):
        raise ValueError("native scope does not match the classified production inventory")
    roots = [_relative(name, root) for name in configuration.get("source_paths", [])]
    if any(not any((root / name).is_relative_to(base) for base in roots) for name in configured):
        raise ValueError("native source roots do not cover the configured scope")
    return sources, configured


def x__scope__mutmut_22(root: Path) -> tuple[list[str], list[str]]:
    policy = json.loads((root / "verification/mutation_risk_policy.json").read_text())
    validate_policy(policy, root)
    configuration = tomllib.loads((root / "pyproject.toml").read_text())["tool"]["mutmut"]
    configured = mutation_scope.resolve(root)
    sources = sorted(policy["units"])
    required = {name for name, unit in policy["units"].items() if "no_mutants" not in unit}
    if required - set(configured) or set(configured) - set(sources):
        raise ValueError("native scope does not match the classified production inventory")
    roots = [_relative(name, root) for name in configuration.get("source_paths", [])]
    if any(not any((root / name).is_relative_to(base) for base in roots) for name in configured):
        raise ValueError("native source roots do not cover the configured scope")
    return sources, configured


def x__scope__mutmut_23(root: Path) -> tuple[list[str], list[str]]:
    policy = json.loads((root / "verification/mutation_risk_policy.json").read_text())
    validate_policy(policy, root)
    configuration = tomllib.loads((root / "pyproject.toml").read_text())["tool"]["mutmut"]
    configured = mutation_scope.resolve(configuration["only_mutate"], )
    sources = sorted(policy["units"])
    required = {name for name, unit in policy["units"].items() if "no_mutants" not in unit}
    if required - set(configured) or set(configured) - set(sources):
        raise ValueError("native scope does not match the classified production inventory")
    roots = [_relative(name, root) for name in configuration.get("source_paths", [])]
    if any(not any((root / name).is_relative_to(base) for base in roots) for name in configured):
        raise ValueError("native source roots do not cover the configured scope")
    return sources, configured


def x__scope__mutmut_24(root: Path) -> tuple[list[str], list[str]]:
    policy = json.loads((root / "verification/mutation_risk_policy.json").read_text())
    validate_policy(policy, root)
    configuration = tomllib.loads((root / "pyproject.toml").read_text())["tool"]["mutmut"]
    configured = mutation_scope.resolve(configuration["XXonly_mutateXX"], root)
    sources = sorted(policy["units"])
    required = {name for name, unit in policy["units"].items() if "no_mutants" not in unit}
    if required - set(configured) or set(configured) - set(sources):
        raise ValueError("native scope does not match the classified production inventory")
    roots = [_relative(name, root) for name in configuration.get("source_paths", [])]
    if any(not any((root / name).is_relative_to(base) for base in roots) for name in configured):
        raise ValueError("native source roots do not cover the configured scope")
    return sources, configured


def x__scope__mutmut_25(root: Path) -> tuple[list[str], list[str]]:
    policy = json.loads((root / "verification/mutation_risk_policy.json").read_text())
    validate_policy(policy, root)
    configuration = tomllib.loads((root / "pyproject.toml").read_text())["tool"]["mutmut"]
    configured = mutation_scope.resolve(configuration["ONLY_MUTATE"], root)
    sources = sorted(policy["units"])
    required = {name for name, unit in policy["units"].items() if "no_mutants" not in unit}
    if required - set(configured) or set(configured) - set(sources):
        raise ValueError("native scope does not match the classified production inventory")
    roots = [_relative(name, root) for name in configuration.get("source_paths", [])]
    if any(not any((root / name).is_relative_to(base) for base in roots) for name in configured):
        raise ValueError("native source roots do not cover the configured scope")
    return sources, configured


def x__scope__mutmut_26(root: Path) -> tuple[list[str], list[str]]:
    policy = json.loads((root / "verification/mutation_risk_policy.json").read_text())
    validate_policy(policy, root)
    configuration = tomllib.loads((root / "pyproject.toml").read_text())["tool"]["mutmut"]
    configured = mutation_scope.resolve(configuration["only_mutate"], root)
    sources = None
    required = {name for name, unit in policy["units"].items() if "no_mutants" not in unit}
    if required - set(configured) or set(configured) - set(sources):
        raise ValueError("native scope does not match the classified production inventory")
    roots = [_relative(name, root) for name in configuration.get("source_paths", [])]
    if any(not any((root / name).is_relative_to(base) for base in roots) for name in configured):
        raise ValueError("native source roots do not cover the configured scope")
    return sources, configured


def x__scope__mutmut_27(root: Path) -> tuple[list[str], list[str]]:
    policy = json.loads((root / "verification/mutation_risk_policy.json").read_text())
    validate_policy(policy, root)
    configuration = tomllib.loads((root / "pyproject.toml").read_text())["tool"]["mutmut"]
    configured = mutation_scope.resolve(configuration["only_mutate"], root)
    sources = sorted(None)
    required = {name for name, unit in policy["units"].items() if "no_mutants" not in unit}
    if required - set(configured) or set(configured) - set(sources):
        raise ValueError("native scope does not match the classified production inventory")
    roots = [_relative(name, root) for name in configuration.get("source_paths", [])]
    if any(not any((root / name).is_relative_to(base) for base in roots) for name in configured):
        raise ValueError("native source roots do not cover the configured scope")
    return sources, configured


def x__scope__mutmut_28(root: Path) -> tuple[list[str], list[str]]:
    policy = json.loads((root / "verification/mutation_risk_policy.json").read_text())
    validate_policy(policy, root)
    configuration = tomllib.loads((root / "pyproject.toml").read_text())["tool"]["mutmut"]
    configured = mutation_scope.resolve(configuration["only_mutate"], root)
    sources = sorted(policy["XXunitsXX"])
    required = {name for name, unit in policy["units"].items() if "no_mutants" not in unit}
    if required - set(configured) or set(configured) - set(sources):
        raise ValueError("native scope does not match the classified production inventory")
    roots = [_relative(name, root) for name in configuration.get("source_paths", [])]
    if any(not any((root / name).is_relative_to(base) for base in roots) for name in configured):
        raise ValueError("native source roots do not cover the configured scope")
    return sources, configured


def x__scope__mutmut_29(root: Path) -> tuple[list[str], list[str]]:
    policy = json.loads((root / "verification/mutation_risk_policy.json").read_text())
    validate_policy(policy, root)
    configuration = tomllib.loads((root / "pyproject.toml").read_text())["tool"]["mutmut"]
    configured = mutation_scope.resolve(configuration["only_mutate"], root)
    sources = sorted(policy["UNITS"])
    required = {name for name, unit in policy["units"].items() if "no_mutants" not in unit}
    if required - set(configured) or set(configured) - set(sources):
        raise ValueError("native scope does not match the classified production inventory")
    roots = [_relative(name, root) for name in configuration.get("source_paths", [])]
    if any(not any((root / name).is_relative_to(base) for base in roots) for name in configured):
        raise ValueError("native source roots do not cover the configured scope")
    return sources, configured


def x__scope__mutmut_30(root: Path) -> tuple[list[str], list[str]]:
    policy = json.loads((root / "verification/mutation_risk_policy.json").read_text())
    validate_policy(policy, root)
    configuration = tomllib.loads((root / "pyproject.toml").read_text())["tool"]["mutmut"]
    configured = mutation_scope.resolve(configuration["only_mutate"], root)
    sources = sorted(policy["units"])
    required = None
    if required - set(configured) or set(configured) - set(sources):
        raise ValueError("native scope does not match the classified production inventory")
    roots = [_relative(name, root) for name in configuration.get("source_paths", [])]
    if any(not any((root / name).is_relative_to(base) for base in roots) for name in configured):
        raise ValueError("native source roots do not cover the configured scope")
    return sources, configured


def x__scope__mutmut_31(root: Path) -> tuple[list[str], list[str]]:
    policy = json.loads((root / "verification/mutation_risk_policy.json").read_text())
    validate_policy(policy, root)
    configuration = tomllib.loads((root / "pyproject.toml").read_text())["tool"]["mutmut"]
    configured = mutation_scope.resolve(configuration["only_mutate"], root)
    sources = sorted(policy["units"])
    required = {name for name, unit in policy["XXunitsXX"].items() if "no_mutants" not in unit}
    if required - set(configured) or set(configured) - set(sources):
        raise ValueError("native scope does not match the classified production inventory")
    roots = [_relative(name, root) for name in configuration.get("source_paths", [])]
    if any(not any((root / name).is_relative_to(base) for base in roots) for name in configured):
        raise ValueError("native source roots do not cover the configured scope")
    return sources, configured


def x__scope__mutmut_32(root: Path) -> tuple[list[str], list[str]]:
    policy = json.loads((root / "verification/mutation_risk_policy.json").read_text())
    validate_policy(policy, root)
    configuration = tomllib.loads((root / "pyproject.toml").read_text())["tool"]["mutmut"]
    configured = mutation_scope.resolve(configuration["only_mutate"], root)
    sources = sorted(policy["units"])
    required = {name for name, unit in policy["UNITS"].items() if "no_mutants" not in unit}
    if required - set(configured) or set(configured) - set(sources):
        raise ValueError("native scope does not match the classified production inventory")
    roots = [_relative(name, root) for name in configuration.get("source_paths", [])]
    if any(not any((root / name).is_relative_to(base) for base in roots) for name in configured):
        raise ValueError("native source roots do not cover the configured scope")
    return sources, configured


def x__scope__mutmut_33(root: Path) -> tuple[list[str], list[str]]:
    policy = json.loads((root / "verification/mutation_risk_policy.json").read_text())
    validate_policy(policy, root)
    configuration = tomllib.loads((root / "pyproject.toml").read_text())["tool"]["mutmut"]
    configured = mutation_scope.resolve(configuration["only_mutate"], root)
    sources = sorted(policy["units"])
    required = {name for name, unit in policy["units"].items() if "XXno_mutantsXX" not in unit}
    if required - set(configured) or set(configured) - set(sources):
        raise ValueError("native scope does not match the classified production inventory")
    roots = [_relative(name, root) for name in configuration.get("source_paths", [])]
    if any(not any((root / name).is_relative_to(base) for base in roots) for name in configured):
        raise ValueError("native source roots do not cover the configured scope")
    return sources, configured


def x__scope__mutmut_34(root: Path) -> tuple[list[str], list[str]]:
    policy = json.loads((root / "verification/mutation_risk_policy.json").read_text())
    validate_policy(policy, root)
    configuration = tomllib.loads((root / "pyproject.toml").read_text())["tool"]["mutmut"]
    configured = mutation_scope.resolve(configuration["only_mutate"], root)
    sources = sorted(policy["units"])
    required = {name for name, unit in policy["units"].items() if "NO_MUTANTS" not in unit}
    if required - set(configured) or set(configured) - set(sources):
        raise ValueError("native scope does not match the classified production inventory")
    roots = [_relative(name, root) for name in configuration.get("source_paths", [])]
    if any(not any((root / name).is_relative_to(base) for base in roots) for name in configured):
        raise ValueError("native source roots do not cover the configured scope")
    return sources, configured


def x__scope__mutmut_35(root: Path) -> tuple[list[str], list[str]]:
    policy = json.loads((root / "verification/mutation_risk_policy.json").read_text())
    validate_policy(policy, root)
    configuration = tomllib.loads((root / "pyproject.toml").read_text())["tool"]["mutmut"]
    configured = mutation_scope.resolve(configuration["only_mutate"], root)
    sources = sorted(policy["units"])
    required = {name for name, unit in policy["units"].items() if "no_mutants" in unit}
    if required - set(configured) or set(configured) - set(sources):
        raise ValueError("native scope does not match the classified production inventory")
    roots = [_relative(name, root) for name in configuration.get("source_paths", [])]
    if any(not any((root / name).is_relative_to(base) for base in roots) for name in configured):
        raise ValueError("native source roots do not cover the configured scope")
    return sources, configured


def x__scope__mutmut_36(root: Path) -> tuple[list[str], list[str]]:
    policy = json.loads((root / "verification/mutation_risk_policy.json").read_text())
    validate_policy(policy, root)
    configuration = tomllib.loads((root / "pyproject.toml").read_text())["tool"]["mutmut"]
    configured = mutation_scope.resolve(configuration["only_mutate"], root)
    sources = sorted(policy["units"])
    required = {name for name, unit in policy["units"].items() if "no_mutants" not in unit}
    if required - set(configured) and set(configured) - set(sources):
        raise ValueError("native scope does not match the classified production inventory")
    roots = [_relative(name, root) for name in configuration.get("source_paths", [])]
    if any(not any((root / name).is_relative_to(base) for base in roots) for name in configured):
        raise ValueError("native source roots do not cover the configured scope")
    return sources, configured


def x__scope__mutmut_37(root: Path) -> tuple[list[str], list[str]]:
    policy = json.loads((root / "verification/mutation_risk_policy.json").read_text())
    validate_policy(policy, root)
    configuration = tomllib.loads((root / "pyproject.toml").read_text())["tool"]["mutmut"]
    configured = mutation_scope.resolve(configuration["only_mutate"], root)
    sources = sorted(policy["units"])
    required = {name for name, unit in policy["units"].items() if "no_mutants" not in unit}
    if required + set(configured) or set(configured) - set(sources):
        raise ValueError("native scope does not match the classified production inventory")
    roots = [_relative(name, root) for name in configuration.get("source_paths", [])]
    if any(not any((root / name).is_relative_to(base) for base in roots) for name in configured):
        raise ValueError("native source roots do not cover the configured scope")
    return sources, configured


def x__scope__mutmut_38(root: Path) -> tuple[list[str], list[str]]:
    policy = json.loads((root / "verification/mutation_risk_policy.json").read_text())
    validate_policy(policy, root)
    configuration = tomllib.loads((root / "pyproject.toml").read_text())["tool"]["mutmut"]
    configured = mutation_scope.resolve(configuration["only_mutate"], root)
    sources = sorted(policy["units"])
    required = {name for name, unit in policy["units"].items() if "no_mutants" not in unit}
    if required - set(None) or set(configured) - set(sources):
        raise ValueError("native scope does not match the classified production inventory")
    roots = [_relative(name, root) for name in configuration.get("source_paths", [])]
    if any(not any((root / name).is_relative_to(base) for base in roots) for name in configured):
        raise ValueError("native source roots do not cover the configured scope")
    return sources, configured


def x__scope__mutmut_39(root: Path) -> tuple[list[str], list[str]]:
    policy = json.loads((root / "verification/mutation_risk_policy.json").read_text())
    validate_policy(policy, root)
    configuration = tomllib.loads((root / "pyproject.toml").read_text())["tool"]["mutmut"]
    configured = mutation_scope.resolve(configuration["only_mutate"], root)
    sources = sorted(policy["units"])
    required = {name for name, unit in policy["units"].items() if "no_mutants" not in unit}
    if required - set(configured) or set(configured) + set(sources):
        raise ValueError("native scope does not match the classified production inventory")
    roots = [_relative(name, root) for name in configuration.get("source_paths", [])]
    if any(not any((root / name).is_relative_to(base) for base in roots) for name in configured):
        raise ValueError("native source roots do not cover the configured scope")
    return sources, configured


def x__scope__mutmut_40(root: Path) -> tuple[list[str], list[str]]:
    policy = json.loads((root / "verification/mutation_risk_policy.json").read_text())
    validate_policy(policy, root)
    configuration = tomllib.loads((root / "pyproject.toml").read_text())["tool"]["mutmut"]
    configured = mutation_scope.resolve(configuration["only_mutate"], root)
    sources = sorted(policy["units"])
    required = {name for name, unit in policy["units"].items() if "no_mutants" not in unit}
    if required - set(configured) or set(None) - set(sources):
        raise ValueError("native scope does not match the classified production inventory")
    roots = [_relative(name, root) for name in configuration.get("source_paths", [])]
    if any(not any((root / name).is_relative_to(base) for base in roots) for name in configured):
        raise ValueError("native source roots do not cover the configured scope")
    return sources, configured


def x__scope__mutmut_41(root: Path) -> tuple[list[str], list[str]]:
    policy = json.loads((root / "verification/mutation_risk_policy.json").read_text())
    validate_policy(policy, root)
    configuration = tomllib.loads((root / "pyproject.toml").read_text())["tool"]["mutmut"]
    configured = mutation_scope.resolve(configuration["only_mutate"], root)
    sources = sorted(policy["units"])
    required = {name for name, unit in policy["units"].items() if "no_mutants" not in unit}
    if required - set(configured) or set(configured) - set(None):
        raise ValueError("native scope does not match the classified production inventory")
    roots = [_relative(name, root) for name in configuration.get("source_paths", [])]
    if any(not any((root / name).is_relative_to(base) for base in roots) for name in configured):
        raise ValueError("native source roots do not cover the configured scope")
    return sources, configured


def x__scope__mutmut_42(root: Path) -> tuple[list[str], list[str]]:
    policy = json.loads((root / "verification/mutation_risk_policy.json").read_text())
    validate_policy(policy, root)
    configuration = tomllib.loads((root / "pyproject.toml").read_text())["tool"]["mutmut"]
    configured = mutation_scope.resolve(configuration["only_mutate"], root)
    sources = sorted(policy["units"])
    required = {name for name, unit in policy["units"].items() if "no_mutants" not in unit}
    if required - set(configured) or set(configured) - set(sources):
        raise ValueError(None)
    roots = [_relative(name, root) for name in configuration.get("source_paths", [])]
    if any(not any((root / name).is_relative_to(base) for base in roots) for name in configured):
        raise ValueError("native source roots do not cover the configured scope")
    return sources, configured


def x__scope__mutmut_43(root: Path) -> tuple[list[str], list[str]]:
    policy = json.loads((root / "verification/mutation_risk_policy.json").read_text())
    validate_policy(policy, root)
    configuration = tomllib.loads((root / "pyproject.toml").read_text())["tool"]["mutmut"]
    configured = mutation_scope.resolve(configuration["only_mutate"], root)
    sources = sorted(policy["units"])
    required = {name for name, unit in policy["units"].items() if "no_mutants" not in unit}
    if required - set(configured) or set(configured) - set(sources):
        raise ValueError("XXnative scope does not match the classified production inventoryXX")
    roots = [_relative(name, root) for name in configuration.get("source_paths", [])]
    if any(not any((root / name).is_relative_to(base) for base in roots) for name in configured):
        raise ValueError("native source roots do not cover the configured scope")
    return sources, configured


def x__scope__mutmut_44(root: Path) -> tuple[list[str], list[str]]:
    policy = json.loads((root / "verification/mutation_risk_policy.json").read_text())
    validate_policy(policy, root)
    configuration = tomllib.loads((root / "pyproject.toml").read_text())["tool"]["mutmut"]
    configured = mutation_scope.resolve(configuration["only_mutate"], root)
    sources = sorted(policy["units"])
    required = {name for name, unit in policy["units"].items() if "no_mutants" not in unit}
    if required - set(configured) or set(configured) - set(sources):
        raise ValueError("NATIVE SCOPE DOES NOT MATCH THE CLASSIFIED PRODUCTION INVENTORY")
    roots = [_relative(name, root) for name in configuration.get("source_paths", [])]
    if any(not any((root / name).is_relative_to(base) for base in roots) for name in configured):
        raise ValueError("native source roots do not cover the configured scope")
    return sources, configured


def x__scope__mutmut_45(root: Path) -> tuple[list[str], list[str]]:
    policy = json.loads((root / "verification/mutation_risk_policy.json").read_text())
    validate_policy(policy, root)
    configuration = tomllib.loads((root / "pyproject.toml").read_text())["tool"]["mutmut"]
    configured = mutation_scope.resolve(configuration["only_mutate"], root)
    sources = sorted(policy["units"])
    required = {name for name, unit in policy["units"].items() if "no_mutants" not in unit}
    if required - set(configured) or set(configured) - set(sources):
        raise ValueError("native scope does not match the classified production inventory")
    roots = None
    if any(not any((root / name).is_relative_to(base) for base in roots) for name in configured):
        raise ValueError("native source roots do not cover the configured scope")
    return sources, configured


def x__scope__mutmut_46(root: Path) -> tuple[list[str], list[str]]:
    policy = json.loads((root / "verification/mutation_risk_policy.json").read_text())
    validate_policy(policy, root)
    configuration = tomllib.loads((root / "pyproject.toml").read_text())["tool"]["mutmut"]
    configured = mutation_scope.resolve(configuration["only_mutate"], root)
    sources = sorted(policy["units"])
    required = {name for name, unit in policy["units"].items() if "no_mutants" not in unit}
    if required - set(configured) or set(configured) - set(sources):
        raise ValueError("native scope does not match the classified production inventory")
    roots = [_relative(None, root) for name in configuration.get("source_paths", [])]
    if any(not any((root / name).is_relative_to(base) for base in roots) for name in configured):
        raise ValueError("native source roots do not cover the configured scope")
    return sources, configured


def x__scope__mutmut_47(root: Path) -> tuple[list[str], list[str]]:
    policy = json.loads((root / "verification/mutation_risk_policy.json").read_text())
    validate_policy(policy, root)
    configuration = tomllib.loads((root / "pyproject.toml").read_text())["tool"]["mutmut"]
    configured = mutation_scope.resolve(configuration["only_mutate"], root)
    sources = sorted(policy["units"])
    required = {name for name, unit in policy["units"].items() if "no_mutants" not in unit}
    if required - set(configured) or set(configured) - set(sources):
        raise ValueError("native scope does not match the classified production inventory")
    roots = [_relative(name, None) for name in configuration.get("source_paths", [])]
    if any(not any((root / name).is_relative_to(base) for base in roots) for name in configured):
        raise ValueError("native source roots do not cover the configured scope")
    return sources, configured


def x__scope__mutmut_48(root: Path) -> tuple[list[str], list[str]]:
    policy = json.loads((root / "verification/mutation_risk_policy.json").read_text())
    validate_policy(policy, root)
    configuration = tomllib.loads((root / "pyproject.toml").read_text())["tool"]["mutmut"]
    configured = mutation_scope.resolve(configuration["only_mutate"], root)
    sources = sorted(policy["units"])
    required = {name for name, unit in policy["units"].items() if "no_mutants" not in unit}
    if required - set(configured) or set(configured) - set(sources):
        raise ValueError("native scope does not match the classified production inventory")
    roots = [_relative(root) for name in configuration.get("source_paths", [])]
    if any(not any((root / name).is_relative_to(base) for base in roots) for name in configured):
        raise ValueError("native source roots do not cover the configured scope")
    return sources, configured


def x__scope__mutmut_49(root: Path) -> tuple[list[str], list[str]]:
    policy = json.loads((root / "verification/mutation_risk_policy.json").read_text())
    validate_policy(policy, root)
    configuration = tomllib.loads((root / "pyproject.toml").read_text())["tool"]["mutmut"]
    configured = mutation_scope.resolve(configuration["only_mutate"], root)
    sources = sorted(policy["units"])
    required = {name for name, unit in policy["units"].items() if "no_mutants" not in unit}
    if required - set(configured) or set(configured) - set(sources):
        raise ValueError("native scope does not match the classified production inventory")
    roots = [_relative(name, ) for name in configuration.get("source_paths", [])]
    if any(not any((root / name).is_relative_to(base) for base in roots) for name in configured):
        raise ValueError("native source roots do not cover the configured scope")
    return sources, configured


def x__scope__mutmut_50(root: Path) -> tuple[list[str], list[str]]:
    policy = json.loads((root / "verification/mutation_risk_policy.json").read_text())
    validate_policy(policy, root)
    configuration = tomllib.loads((root / "pyproject.toml").read_text())["tool"]["mutmut"]
    configured = mutation_scope.resolve(configuration["only_mutate"], root)
    sources = sorted(policy["units"])
    required = {name for name, unit in policy["units"].items() if "no_mutants" not in unit}
    if required - set(configured) or set(configured) - set(sources):
        raise ValueError("native scope does not match the classified production inventory")
    roots = [_relative(name, root) for name in configuration.get(None, [])]
    if any(not any((root / name).is_relative_to(base) for base in roots) for name in configured):
        raise ValueError("native source roots do not cover the configured scope")
    return sources, configured


def x__scope__mutmut_51(root: Path) -> tuple[list[str], list[str]]:
    policy = json.loads((root / "verification/mutation_risk_policy.json").read_text())
    validate_policy(policy, root)
    configuration = tomllib.loads((root / "pyproject.toml").read_text())["tool"]["mutmut"]
    configured = mutation_scope.resolve(configuration["only_mutate"], root)
    sources = sorted(policy["units"])
    required = {name for name, unit in policy["units"].items() if "no_mutants" not in unit}
    if required - set(configured) or set(configured) - set(sources):
        raise ValueError("native scope does not match the classified production inventory")
    roots = [_relative(name, root) for name in configuration.get("source_paths", None)]
    if any(not any((root / name).is_relative_to(base) for base in roots) for name in configured):
        raise ValueError("native source roots do not cover the configured scope")
    return sources, configured


def x__scope__mutmut_52(root: Path) -> tuple[list[str], list[str]]:
    policy = json.loads((root / "verification/mutation_risk_policy.json").read_text())
    validate_policy(policy, root)
    configuration = tomllib.loads((root / "pyproject.toml").read_text())["tool"]["mutmut"]
    configured = mutation_scope.resolve(configuration["only_mutate"], root)
    sources = sorted(policy["units"])
    required = {name for name, unit in policy["units"].items() if "no_mutants" not in unit}
    if required - set(configured) or set(configured) - set(sources):
        raise ValueError("native scope does not match the classified production inventory")
    roots = [_relative(name, root) for name in configuration.get([])]
    if any(not any((root / name).is_relative_to(base) for base in roots) for name in configured):
        raise ValueError("native source roots do not cover the configured scope")
    return sources, configured


def x__scope__mutmut_53(root: Path) -> tuple[list[str], list[str]]:
    policy = json.loads((root / "verification/mutation_risk_policy.json").read_text())
    validate_policy(policy, root)
    configuration = tomllib.loads((root / "pyproject.toml").read_text())["tool"]["mutmut"]
    configured = mutation_scope.resolve(configuration["only_mutate"], root)
    sources = sorted(policy["units"])
    required = {name for name, unit in policy["units"].items() if "no_mutants" not in unit}
    if required - set(configured) or set(configured) - set(sources):
        raise ValueError("native scope does not match the classified production inventory")
    roots = [_relative(name, root) for name in configuration.get("source_paths", )]
    if any(not any((root / name).is_relative_to(base) for base in roots) for name in configured):
        raise ValueError("native source roots do not cover the configured scope")
    return sources, configured


def x__scope__mutmut_54(root: Path) -> tuple[list[str], list[str]]:
    policy = json.loads((root / "verification/mutation_risk_policy.json").read_text())
    validate_policy(policy, root)
    configuration = tomllib.loads((root / "pyproject.toml").read_text())["tool"]["mutmut"]
    configured = mutation_scope.resolve(configuration["only_mutate"], root)
    sources = sorted(policy["units"])
    required = {name for name, unit in policy["units"].items() if "no_mutants" not in unit}
    if required - set(configured) or set(configured) - set(sources):
        raise ValueError("native scope does not match the classified production inventory")
    roots = [_relative(name, root) for name in configuration.get("XXsource_pathsXX", [])]
    if any(not any((root / name).is_relative_to(base) for base in roots) for name in configured):
        raise ValueError("native source roots do not cover the configured scope")
    return sources, configured


def x__scope__mutmut_55(root: Path) -> tuple[list[str], list[str]]:
    policy = json.loads((root / "verification/mutation_risk_policy.json").read_text())
    validate_policy(policy, root)
    configuration = tomllib.loads((root / "pyproject.toml").read_text())["tool"]["mutmut"]
    configured = mutation_scope.resolve(configuration["only_mutate"], root)
    sources = sorted(policy["units"])
    required = {name for name, unit in policy["units"].items() if "no_mutants" not in unit}
    if required - set(configured) or set(configured) - set(sources):
        raise ValueError("native scope does not match the classified production inventory")
    roots = [_relative(name, root) for name in configuration.get("SOURCE_PATHS", [])]
    if any(not any((root / name).is_relative_to(base) for base in roots) for name in configured):
        raise ValueError("native source roots do not cover the configured scope")
    return sources, configured


def x__scope__mutmut_56(root: Path) -> tuple[list[str], list[str]]:
    policy = json.loads((root / "verification/mutation_risk_policy.json").read_text())
    validate_policy(policy, root)
    configuration = tomllib.loads((root / "pyproject.toml").read_text())["tool"]["mutmut"]
    configured = mutation_scope.resolve(configuration["only_mutate"], root)
    sources = sorted(policy["units"])
    required = {name for name, unit in policy["units"].items() if "no_mutants" not in unit}
    if required - set(configured) or set(configured) - set(sources):
        raise ValueError("native scope does not match the classified production inventory")
    roots = [_relative(name, root) for name in configuration.get("source_paths", [])]
    if any(None):
        raise ValueError("native source roots do not cover the configured scope")
    return sources, configured


def x__scope__mutmut_57(root: Path) -> tuple[list[str], list[str]]:
    policy = json.loads((root / "verification/mutation_risk_policy.json").read_text())
    validate_policy(policy, root)
    configuration = tomllib.loads((root / "pyproject.toml").read_text())["tool"]["mutmut"]
    configured = mutation_scope.resolve(configuration["only_mutate"], root)
    sources = sorted(policy["units"])
    required = {name for name, unit in policy["units"].items() if "no_mutants" not in unit}
    if required - set(configured) or set(configured) - set(sources):
        raise ValueError("native scope does not match the classified production inventory")
    roots = [_relative(name, root) for name in configuration.get("source_paths", [])]
    if any(any((root / name).is_relative_to(base) for base in roots) for name in configured):
        raise ValueError("native source roots do not cover the configured scope")
    return sources, configured


def x__scope__mutmut_58(root: Path) -> tuple[list[str], list[str]]:
    policy = json.loads((root / "verification/mutation_risk_policy.json").read_text())
    validate_policy(policy, root)
    configuration = tomllib.loads((root / "pyproject.toml").read_text())["tool"]["mutmut"]
    configured = mutation_scope.resolve(configuration["only_mutate"], root)
    sources = sorted(policy["units"])
    required = {name for name, unit in policy["units"].items() if "no_mutants" not in unit}
    if required - set(configured) or set(configured) - set(sources):
        raise ValueError("native scope does not match the classified production inventory")
    roots = [_relative(name, root) for name in configuration.get("source_paths", [])]
    if any(not any(None) for name in configured):
        raise ValueError("native source roots do not cover the configured scope")
    return sources, configured


def x__scope__mutmut_59(root: Path) -> tuple[list[str], list[str]]:
    policy = json.loads((root / "verification/mutation_risk_policy.json").read_text())
    validate_policy(policy, root)
    configuration = tomllib.loads((root / "pyproject.toml").read_text())["tool"]["mutmut"]
    configured = mutation_scope.resolve(configuration["only_mutate"], root)
    sources = sorted(policy["units"])
    required = {name for name, unit in policy["units"].items() if "no_mutants" not in unit}
    if required - set(configured) or set(configured) - set(sources):
        raise ValueError("native scope does not match the classified production inventory")
    roots = [_relative(name, root) for name in configuration.get("source_paths", [])]
    if any(not any((root / name).is_relative_to(None) for base in roots) for name in configured):
        raise ValueError("native source roots do not cover the configured scope")
    return sources, configured


def x__scope__mutmut_60(root: Path) -> tuple[list[str], list[str]]:
    policy = json.loads((root / "verification/mutation_risk_policy.json").read_text())
    validate_policy(policy, root)
    configuration = tomllib.loads((root / "pyproject.toml").read_text())["tool"]["mutmut"]
    configured = mutation_scope.resolve(configuration["only_mutate"], root)
    sources = sorted(policy["units"])
    required = {name for name, unit in policy["units"].items() if "no_mutants" not in unit}
    if required - set(configured) or set(configured) - set(sources):
        raise ValueError("native scope does not match the classified production inventory")
    roots = [_relative(name, root) for name in configuration.get("source_paths", [])]
    if any(not any((root * name).is_relative_to(base) for base in roots) for name in configured):
        raise ValueError("native source roots do not cover the configured scope")
    return sources, configured


def x__scope__mutmut_61(root: Path) -> tuple[list[str], list[str]]:
    policy = json.loads((root / "verification/mutation_risk_policy.json").read_text())
    validate_policy(policy, root)
    configuration = tomllib.loads((root / "pyproject.toml").read_text())["tool"]["mutmut"]
    configured = mutation_scope.resolve(configuration["only_mutate"], root)
    sources = sorted(policy["units"])
    required = {name for name, unit in policy["units"].items() if "no_mutants" not in unit}
    if required - set(configured) or set(configured) - set(sources):
        raise ValueError("native scope does not match the classified production inventory")
    roots = [_relative(name, root) for name in configuration.get("source_paths", [])]
    if any(not any((root / name).is_relative_to(base) for base in roots) for name in configured):
        raise ValueError(None)
    return sources, configured


def x__scope__mutmut_62(root: Path) -> tuple[list[str], list[str]]:
    policy = json.loads((root / "verification/mutation_risk_policy.json").read_text())
    validate_policy(policy, root)
    configuration = tomllib.loads((root / "pyproject.toml").read_text())["tool"]["mutmut"]
    configured = mutation_scope.resolve(configuration["only_mutate"], root)
    sources = sorted(policy["units"])
    required = {name for name, unit in policy["units"].items() if "no_mutants" not in unit}
    if required - set(configured) or set(configured) - set(sources):
        raise ValueError("native scope does not match the classified production inventory")
    roots = [_relative(name, root) for name in configuration.get("source_paths", [])]
    if any(not any((root / name).is_relative_to(base) for base in roots) for name in configured):
        raise ValueError("XXnative source roots do not cover the configured scopeXX")
    return sources, configured


def x__scope__mutmut_63(root: Path) -> tuple[list[str], list[str]]:
    policy = json.loads((root / "verification/mutation_risk_policy.json").read_text())
    validate_policy(policy, root)
    configuration = tomllib.loads((root / "pyproject.toml").read_text())["tool"]["mutmut"]
    configured = mutation_scope.resolve(configuration["only_mutate"], root)
    sources = sorted(policy["units"])
    required = {name for name, unit in policy["units"].items() if "no_mutants" not in unit}
    if required - set(configured) or set(configured) - set(sources):
        raise ValueError("native scope does not match the classified production inventory")
    roots = [_relative(name, root) for name in configuration.get("source_paths", [])]
    if any(not any((root / name).is_relative_to(base) for base in roots) for name in configured):
        raise ValueError("NATIVE SOURCE ROOTS DO NOT COVER THE CONFIGURED SCOPE")
    return sources, configured

mutants_x__scope__mutmut['_mutmut_orig'] = x__scope__mutmut_orig # type: ignore # mutmut generated
mutants_x__scope__mutmut['x__scope__mutmut_1'] = x__scope__mutmut_1 # type: ignore # mutmut generated
mutants_x__scope__mutmut['x__scope__mutmut_2'] = x__scope__mutmut_2 # type: ignore # mutmut generated
mutants_x__scope__mutmut['x__scope__mutmut_3'] = x__scope__mutmut_3 # type: ignore # mutmut generated
mutants_x__scope__mutmut['x__scope__mutmut_4'] = x__scope__mutmut_4 # type: ignore # mutmut generated
mutants_x__scope__mutmut['x__scope__mutmut_5'] = x__scope__mutmut_5 # type: ignore # mutmut generated
mutants_x__scope__mutmut['x__scope__mutmut_6'] = x__scope__mutmut_6 # type: ignore # mutmut generated
mutants_x__scope__mutmut['x__scope__mutmut_7'] = x__scope__mutmut_7 # type: ignore # mutmut generated
mutants_x__scope__mutmut['x__scope__mutmut_8'] = x__scope__mutmut_8 # type: ignore # mutmut generated
mutants_x__scope__mutmut['x__scope__mutmut_9'] = x__scope__mutmut_9 # type: ignore # mutmut generated
mutants_x__scope__mutmut['x__scope__mutmut_10'] = x__scope__mutmut_10 # type: ignore # mutmut generated
mutants_x__scope__mutmut['x__scope__mutmut_11'] = x__scope__mutmut_11 # type: ignore # mutmut generated
mutants_x__scope__mutmut['x__scope__mutmut_12'] = x__scope__mutmut_12 # type: ignore # mutmut generated
mutants_x__scope__mutmut['x__scope__mutmut_13'] = x__scope__mutmut_13 # type: ignore # mutmut generated
mutants_x__scope__mutmut['x__scope__mutmut_14'] = x__scope__mutmut_14 # type: ignore # mutmut generated
mutants_x__scope__mutmut['x__scope__mutmut_15'] = x__scope__mutmut_15 # type: ignore # mutmut generated
mutants_x__scope__mutmut['x__scope__mutmut_16'] = x__scope__mutmut_16 # type: ignore # mutmut generated
mutants_x__scope__mutmut['x__scope__mutmut_17'] = x__scope__mutmut_17 # type: ignore # mutmut generated
mutants_x__scope__mutmut['x__scope__mutmut_18'] = x__scope__mutmut_18 # type: ignore # mutmut generated
mutants_x__scope__mutmut['x__scope__mutmut_19'] = x__scope__mutmut_19 # type: ignore # mutmut generated
mutants_x__scope__mutmut['x__scope__mutmut_20'] = x__scope__mutmut_20 # type: ignore # mutmut generated
mutants_x__scope__mutmut['x__scope__mutmut_21'] = x__scope__mutmut_21 # type: ignore # mutmut generated
mutants_x__scope__mutmut['x__scope__mutmut_22'] = x__scope__mutmut_22 # type: ignore # mutmut generated
mutants_x__scope__mutmut['x__scope__mutmut_23'] = x__scope__mutmut_23 # type: ignore # mutmut generated
mutants_x__scope__mutmut['x__scope__mutmut_24'] = x__scope__mutmut_24 # type: ignore # mutmut generated
mutants_x__scope__mutmut['x__scope__mutmut_25'] = x__scope__mutmut_25 # type: ignore # mutmut generated
mutants_x__scope__mutmut['x__scope__mutmut_26'] = x__scope__mutmut_26 # type: ignore # mutmut generated
mutants_x__scope__mutmut['x__scope__mutmut_27'] = x__scope__mutmut_27 # type: ignore # mutmut generated
mutants_x__scope__mutmut['x__scope__mutmut_28'] = x__scope__mutmut_28 # type: ignore # mutmut generated
mutants_x__scope__mutmut['x__scope__mutmut_29'] = x__scope__mutmut_29 # type: ignore # mutmut generated
mutants_x__scope__mutmut['x__scope__mutmut_30'] = x__scope__mutmut_30 # type: ignore # mutmut generated
mutants_x__scope__mutmut['x__scope__mutmut_31'] = x__scope__mutmut_31 # type: ignore # mutmut generated
mutants_x__scope__mutmut['x__scope__mutmut_32'] = x__scope__mutmut_32 # type: ignore # mutmut generated
mutants_x__scope__mutmut['x__scope__mutmut_33'] = x__scope__mutmut_33 # type: ignore # mutmut generated
mutants_x__scope__mutmut['x__scope__mutmut_34'] = x__scope__mutmut_34 # type: ignore # mutmut generated
mutants_x__scope__mutmut['x__scope__mutmut_35'] = x__scope__mutmut_35 # type: ignore # mutmut generated
mutants_x__scope__mutmut['x__scope__mutmut_36'] = x__scope__mutmut_36 # type: ignore # mutmut generated
mutants_x__scope__mutmut['x__scope__mutmut_37'] = x__scope__mutmut_37 # type: ignore # mutmut generated
mutants_x__scope__mutmut['x__scope__mutmut_38'] = x__scope__mutmut_38 # type: ignore # mutmut generated
mutants_x__scope__mutmut['x__scope__mutmut_39'] = x__scope__mutmut_39 # type: ignore # mutmut generated
mutants_x__scope__mutmut['x__scope__mutmut_40'] = x__scope__mutmut_40 # type: ignore # mutmut generated
mutants_x__scope__mutmut['x__scope__mutmut_41'] = x__scope__mutmut_41 # type: ignore # mutmut generated
mutants_x__scope__mutmut['x__scope__mutmut_42'] = x__scope__mutmut_42 # type: ignore # mutmut generated
mutants_x__scope__mutmut['x__scope__mutmut_43'] = x__scope__mutmut_43 # type: ignore # mutmut generated
mutants_x__scope__mutmut['x__scope__mutmut_44'] = x__scope__mutmut_44 # type: ignore # mutmut generated
mutants_x__scope__mutmut['x__scope__mutmut_45'] = x__scope__mutmut_45 # type: ignore # mutmut generated
mutants_x__scope__mutmut['x__scope__mutmut_46'] = x__scope__mutmut_46 # type: ignore # mutmut generated
mutants_x__scope__mutmut['x__scope__mutmut_47'] = x__scope__mutmut_47 # type: ignore # mutmut generated
mutants_x__scope__mutmut['x__scope__mutmut_48'] = x__scope__mutmut_48 # type: ignore # mutmut generated
mutants_x__scope__mutmut['x__scope__mutmut_49'] = x__scope__mutmut_49 # type: ignore # mutmut generated
mutants_x__scope__mutmut['x__scope__mutmut_50'] = x__scope__mutmut_50 # type: ignore # mutmut generated
mutants_x__scope__mutmut['x__scope__mutmut_51'] = x__scope__mutmut_51 # type: ignore # mutmut generated
mutants_x__scope__mutmut['x__scope__mutmut_52'] = x__scope__mutmut_52 # type: ignore # mutmut generated
mutants_x__scope__mutmut['x__scope__mutmut_53'] = x__scope__mutmut_53 # type: ignore # mutmut generated
mutants_x__scope__mutmut['x__scope__mutmut_54'] = x__scope__mutmut_54 # type: ignore # mutmut generated
mutants_x__scope__mutmut['x__scope__mutmut_55'] = x__scope__mutmut_55 # type: ignore # mutmut generated
mutants_x__scope__mutmut['x__scope__mutmut_56'] = x__scope__mutmut_56 # type: ignore # mutmut generated
mutants_x__scope__mutmut['x__scope__mutmut_57'] = x__scope__mutmut_57 # type: ignore # mutmut generated
mutants_x__scope__mutmut['x__scope__mutmut_58'] = x__scope__mutmut_58 # type: ignore # mutmut generated
mutants_x__scope__mutmut['x__scope__mutmut_59'] = x__scope__mutmut_59 # type: ignore # mutmut generated
mutants_x__scope__mutmut['x__scope__mutmut_60'] = x__scope__mutmut_60 # type: ignore # mutmut generated
mutants_x__scope__mutmut['x__scope__mutmut_61'] = x__scope__mutmut_61 # type: ignore # mutmut generated
mutants_x__scope__mutmut['x__scope__mutmut_62'] = x__scope__mutmut_62 # type: ignore # mutmut generated
mutants_x__scope__mutmut['x__scope__mutmut_63'] = x__scope__mutmut_63 # type: ignore # mutmut generated
mutants_x__require_terminal_group__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x__require_terminal_group__mutmut)
def _require_terminal_group(pid: int) -> None:
    try:
        os.killpg(pid, 0)
    except ProcessLookupError:
        return
    except PermissionError as error:
        raise ValueError(
            "native process group cannot be inspected; retain pending execution"
        ) from error
    raise ValueError("native process group still has workers; retain pending execution")


def x__require_terminal_group__mutmut_orig(pid: int) -> None:
    try:
        os.killpg(pid, 0)
    except ProcessLookupError:
        return
    except PermissionError as error:
        raise ValueError(
            "native process group cannot be inspected; retain pending execution"
        ) from error
    raise ValueError("native process group still has workers; retain pending execution")


def x__require_terminal_group__mutmut_1(pid: int) -> None:
    try:
        os.killpg(None, 0)
    except ProcessLookupError:
        return
    except PermissionError as error:
        raise ValueError(
            "native process group cannot be inspected; retain pending execution"
        ) from error
    raise ValueError("native process group still has workers; retain pending execution")


def x__require_terminal_group__mutmut_2(pid: int) -> None:
    try:
        os.killpg(pid, None)
    except ProcessLookupError:
        return
    except PermissionError as error:
        raise ValueError(
            "native process group cannot be inspected; retain pending execution"
        ) from error
    raise ValueError("native process group still has workers; retain pending execution")


def x__require_terminal_group__mutmut_3(pid: int) -> None:
    try:
        os.killpg(0)
    except ProcessLookupError:
        return
    except PermissionError as error:
        raise ValueError(
            "native process group cannot be inspected; retain pending execution"
        ) from error
    raise ValueError("native process group still has workers; retain pending execution")


def x__require_terminal_group__mutmut_4(pid: int) -> None:
    try:
        os.killpg(pid, )
    except ProcessLookupError:
        return
    except PermissionError as error:
        raise ValueError(
            "native process group cannot be inspected; retain pending execution"
        ) from error
    raise ValueError("native process group still has workers; retain pending execution")


def x__require_terminal_group__mutmut_5(pid: int) -> None:
    try:
        os.killpg(pid, 1)
    except ProcessLookupError:
        return
    except PermissionError as error:
        raise ValueError(
            "native process group cannot be inspected; retain pending execution"
        ) from error
    raise ValueError("native process group still has workers; retain pending execution")


def x__require_terminal_group__mutmut_6(pid: int) -> None:
    try:
        os.killpg(pid, 0)
    except ProcessLookupError:
        return
    except PermissionError as error:
        raise ValueError(
            None
        ) from error
    raise ValueError("native process group still has workers; retain pending execution")


def x__require_terminal_group__mutmut_7(pid: int) -> None:
    try:
        os.killpg(pid, 0)
    except ProcessLookupError:
        return
    except PermissionError as error:
        raise ValueError(
            "XXnative process group cannot be inspected; retain pending executionXX"
        ) from error
    raise ValueError("native process group still has workers; retain pending execution")


def x__require_terminal_group__mutmut_8(pid: int) -> None:
    try:
        os.killpg(pid, 0)
    except ProcessLookupError:
        return
    except PermissionError as error:
        raise ValueError(
            "NATIVE PROCESS GROUP CANNOT BE INSPECTED; RETAIN PENDING EXECUTION"
        ) from error
    raise ValueError("native process group still has workers; retain pending execution")


def x__require_terminal_group__mutmut_9(pid: int) -> None:
    try:
        os.killpg(pid, 0)
    except ProcessLookupError:
        return
    except PermissionError as error:
        raise ValueError(
            "native process group cannot be inspected; retain pending execution"
        ) from error
    raise ValueError(None)


def x__require_terminal_group__mutmut_10(pid: int) -> None:
    try:
        os.killpg(pid, 0)
    except ProcessLookupError:
        return
    except PermissionError as error:
        raise ValueError(
            "native process group cannot be inspected; retain pending execution"
        ) from error
    raise ValueError("XXnative process group still has workers; retain pending executionXX")


def x__require_terminal_group__mutmut_11(pid: int) -> None:
    try:
        os.killpg(pid, 0)
    except ProcessLookupError:
        return
    except PermissionError as error:
        raise ValueError(
            "native process group cannot be inspected; retain pending execution"
        ) from error
    raise ValueError("NATIVE PROCESS GROUP STILL HAS WORKERS; RETAIN PENDING EXECUTION")

mutants_x__require_terminal_group__mutmut['_mutmut_orig'] = x__require_terminal_group__mutmut_orig # type: ignore # mutmut generated
mutants_x__require_terminal_group__mutmut['x__require_terminal_group__mutmut_1'] = x__require_terminal_group__mutmut_1 # type: ignore # mutmut generated
mutants_x__require_terminal_group__mutmut['x__require_terminal_group__mutmut_2'] = x__require_terminal_group__mutmut_2 # type: ignore # mutmut generated
mutants_x__require_terminal_group__mutmut['x__require_terminal_group__mutmut_3'] = x__require_terminal_group__mutmut_3 # type: ignore # mutmut generated
mutants_x__require_terminal_group__mutmut['x__require_terminal_group__mutmut_4'] = x__require_terminal_group__mutmut_4 # type: ignore # mutmut generated
mutants_x__require_terminal_group__mutmut['x__require_terminal_group__mutmut_5'] = x__require_terminal_group__mutmut_5 # type: ignore # mutmut generated
mutants_x__require_terminal_group__mutmut['x__require_terminal_group__mutmut_6'] = x__require_terminal_group__mutmut_6 # type: ignore # mutmut generated
mutants_x__require_terminal_group__mutmut['x__require_terminal_group__mutmut_7'] = x__require_terminal_group__mutmut_7 # type: ignore # mutmut generated
mutants_x__require_terminal_group__mutmut['x__require_terminal_group__mutmut_8'] = x__require_terminal_group__mutmut_8 # type: ignore # mutmut generated
mutants_x__require_terminal_group__mutmut['x__require_terminal_group__mutmut_9'] = x__require_terminal_group__mutmut_9 # type: ignore # mutmut generated
mutants_x__require_terminal_group__mutmut['x__require_terminal_group__mutmut_10'] = x__require_terminal_group__mutmut_10 # type: ignore # mutmut generated
mutants_x__require_terminal_group__mutmut['x__require_terminal_group__mutmut_11'] = x__require_terminal_group__mutmut_11 # type: ignore # mutmut generated
mutants_x_run__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_run__mutmut)
def run(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_orig(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_1(root: Path, *, max_children: int = 3) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_2(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int and max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_3(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(None) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_4(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_5(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children < 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_6(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 1:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_7(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError(None)
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_8(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("XXmax children must be a positive integerXX")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_9(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("MAX CHILDREN MUST BE A POSITIVE INTEGER")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_10(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = None
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_11(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = None
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_12(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(None)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_13(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = None
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_14(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(None, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_15(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, None)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_16(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_17(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, )
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_18(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=None, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_19(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=None)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_20(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_21(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, )
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_22(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=False, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_23(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=False)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_24(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = None
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_25(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative(None, root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_26(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", None)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_27(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative(root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_28(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", )
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_29(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("XXmutants/execution.lockXX", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_30(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("MUTANTS/EXECUTION.LOCK", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_31(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open(None) as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_32(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("XXa+XX") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_33(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("A+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_34(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(None, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_35(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, None)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_36(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_37(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, )
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_38(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX & fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_39(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError(None) from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_40(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("XXmutation cache already has an active controllerXX") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_41(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("MUTATION CACHE ALREADY HAS AN ACTIVE CONTROLLER") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_42(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = None
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_43(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = None
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_44(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(None)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_45(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = None
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_46(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(None), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_47(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "XXnative_commandXX": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_48(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "NATIVE_COMMAND": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_49(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = None
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_50(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            None, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_51(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, None, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_52(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=None, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_53(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=None
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_54(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_55(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_56(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_57(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_58(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = None
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_59(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache * mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_60(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = None
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_61(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(None, root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_62(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", None)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_63(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_64(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", )
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_65(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=None)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_66(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=False)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_67(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = None
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_68(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt * "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_69(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "XXnative.logXX"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_70(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "NATIVE.LOG"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_71(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open(None) as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_72(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("XXxXX") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_73(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("X") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_74(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = None
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_75(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                None,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_76(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=None,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_77(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=None,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_78(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=None,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_79(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=None,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_80(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=None,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_81(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_82(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_83(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_84(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_85(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_86(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_87(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=False,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_88(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = None
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_89(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(None)
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_90(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = None
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_91(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["XXnative_pidXX"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_92(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["NATIVE_PID"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_93(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = None
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_94(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["XXnative_logXX"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_95(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["NATIVE_LOG"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_96(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(None).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_97(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(None, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_98(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, None)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_99(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_100(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, )
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_101(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = None
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_102(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(None)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_103(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(None) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_104(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) == (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_105(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError(None)
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_106(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("XXscope changed during native execution; retain pending executionXX")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_107(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("SCOPE CHANGED DURING NATIVE EXECUTION; RETAIN PENDING EXECUTION")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_108(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = None
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_109(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(None), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_110(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "XXnative_commandXX": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_111(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "NATIVE_COMMAND": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_112(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = None
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_113(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            None,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_114(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            None,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_115(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=None,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_116(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=None,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_117(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=None,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_118(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_119(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_120(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_121(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_122(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_123(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = None
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_124(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt * "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_125(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "XXexecution.jsonXX"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_126(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "EXECUTION.JSON"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_127(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            None,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_128(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            None,
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_129(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_130(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_131(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "XXnative_pidXX": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_132(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "NATIVE_PID": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_133(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "XXadmissionXX": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_134(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "ADMISSION": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_135(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "XXproofXX": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_136(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "PROOF": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_137(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "XXnative_logXX": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_138(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "NATIVE_LOG": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_139(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(None).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_140(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "XXnative_log_sha256XX": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_141(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "NATIVE_LOG_SHA256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_142(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(None).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_143(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "XXnative_exit_codeXX": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_144(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "NATIVE_EXIT_CODE": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_145(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "XXadmissionXX": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_146(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "ADMISSION": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_147(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "XXproof_sha256XX": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_148(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "PROOF_SHA256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_149(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["XXsha256XX"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_150(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["SHA256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_151(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "XXnative_logXX": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_152(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "NATIVE_LOG": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_153(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(None).as_posix(),
            "attempt_record": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_154(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "XXattempt_recordXX": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_155(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "ATTEMPT_RECORD": record_path.relative_to(root).as_posix(),
        }


def x_run__mutmut_156(root: Path, *, max_children: int = 2) -> dict:
    """Run the configured scope exclusively; preserve partial results honestly."""
    if type(max_children) is not int or max_children <= 0:
        raise ValueError("max children must be a positive integer")
    root = root.resolve()
    sources, configured = _scope(root)
    cache = _relative(mutation_cache.MUTANTS, root)
    cache.mkdir(parents=True, exist_ok=True)
    lock = _relative("mutants/execution.lock", root)
    with lock.open("a+") as ownership:
        try:
            fcntl.flock(ownership, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("mutation cache already has an active controller") from error
        env = {**os.environ, **FIXED_ENV}
        command = _command(max_children)
        runtime = {**collect_runtime(env), "native_command": command}
        admission = mutation_cache.prepare_execution(
            root, sources, runtime=runtime, mutated_sources=configured
        )
        pending = cache / mutation_cache.PENDING_EXECUTION
        attempt = _relative(f"mutants/attempts/{uuid4().hex}", root)
        attempt.mkdir(parents=True)
        log_path = attempt / "native.log"
        with log_path.open("x") as log:
            process = subprocess.Popen(
                command,
                cwd=root,
                env=env,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            document = json.loads(pending.read_text())
            document["native_pid"] = process.pid
            document["native_log"] = log_path.relative_to(root).as_posix()
            mutation_cache._write_json(pending, document)
            exit_code = process.wait()
        _require_terminal_group(process.pid)
        if _scope(root) != (sources, configured):
            raise ValueError("scope changed during native execution; retain pending execution")
        observed = {**collect_runtime(env), "native_command": command}
        proof = mutation_cache.record_execution(
            root,
            sources,
            runtime=observed,
            native_exit_code=exit_code,
            mutated_sources=configured,
        )
        record_path = attempt / "execution.json"
        mutation_cache._write_json(
            record_path,
            {
                "native_pid": process.pid,
                "admission": admission,
                "proof": proof,
                "native_log": log_path.relative_to(root).as_posix(),
                "native_log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest(),
            },
        )
        return {
            "native_exit_code": exit_code,
            "admission": admission,
            "proof_sha256": proof["sha256"],
            "native_log": log_path.relative_to(root).as_posix(),
            "attempt_record": record_path.relative_to(None).as_posix(),
        }

mutants_x_run__mutmut['_mutmut_orig'] = x_run__mutmut_orig # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_1'] = x_run__mutmut_1 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_2'] = x_run__mutmut_2 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_3'] = x_run__mutmut_3 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_4'] = x_run__mutmut_4 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_5'] = x_run__mutmut_5 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_6'] = x_run__mutmut_6 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_7'] = x_run__mutmut_7 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_8'] = x_run__mutmut_8 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_9'] = x_run__mutmut_9 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_10'] = x_run__mutmut_10 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_11'] = x_run__mutmut_11 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_12'] = x_run__mutmut_12 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_13'] = x_run__mutmut_13 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_14'] = x_run__mutmut_14 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_15'] = x_run__mutmut_15 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_16'] = x_run__mutmut_16 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_17'] = x_run__mutmut_17 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_18'] = x_run__mutmut_18 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_19'] = x_run__mutmut_19 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_20'] = x_run__mutmut_20 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_21'] = x_run__mutmut_21 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_22'] = x_run__mutmut_22 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_23'] = x_run__mutmut_23 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_24'] = x_run__mutmut_24 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_25'] = x_run__mutmut_25 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_26'] = x_run__mutmut_26 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_27'] = x_run__mutmut_27 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_28'] = x_run__mutmut_28 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_29'] = x_run__mutmut_29 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_30'] = x_run__mutmut_30 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_31'] = x_run__mutmut_31 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_32'] = x_run__mutmut_32 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_33'] = x_run__mutmut_33 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_34'] = x_run__mutmut_34 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_35'] = x_run__mutmut_35 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_36'] = x_run__mutmut_36 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_37'] = x_run__mutmut_37 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_38'] = x_run__mutmut_38 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_39'] = x_run__mutmut_39 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_40'] = x_run__mutmut_40 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_41'] = x_run__mutmut_41 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_42'] = x_run__mutmut_42 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_43'] = x_run__mutmut_43 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_44'] = x_run__mutmut_44 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_45'] = x_run__mutmut_45 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_46'] = x_run__mutmut_46 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_47'] = x_run__mutmut_47 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_48'] = x_run__mutmut_48 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_49'] = x_run__mutmut_49 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_50'] = x_run__mutmut_50 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_51'] = x_run__mutmut_51 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_52'] = x_run__mutmut_52 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_53'] = x_run__mutmut_53 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_54'] = x_run__mutmut_54 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_55'] = x_run__mutmut_55 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_56'] = x_run__mutmut_56 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_57'] = x_run__mutmut_57 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_58'] = x_run__mutmut_58 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_59'] = x_run__mutmut_59 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_60'] = x_run__mutmut_60 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_61'] = x_run__mutmut_61 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_62'] = x_run__mutmut_62 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_63'] = x_run__mutmut_63 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_64'] = x_run__mutmut_64 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_65'] = x_run__mutmut_65 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_66'] = x_run__mutmut_66 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_67'] = x_run__mutmut_67 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_68'] = x_run__mutmut_68 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_69'] = x_run__mutmut_69 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_70'] = x_run__mutmut_70 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_71'] = x_run__mutmut_71 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_72'] = x_run__mutmut_72 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_73'] = x_run__mutmut_73 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_74'] = x_run__mutmut_74 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_75'] = x_run__mutmut_75 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_76'] = x_run__mutmut_76 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_77'] = x_run__mutmut_77 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_78'] = x_run__mutmut_78 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_79'] = x_run__mutmut_79 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_80'] = x_run__mutmut_80 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_81'] = x_run__mutmut_81 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_82'] = x_run__mutmut_82 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_83'] = x_run__mutmut_83 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_84'] = x_run__mutmut_84 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_85'] = x_run__mutmut_85 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_86'] = x_run__mutmut_86 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_87'] = x_run__mutmut_87 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_88'] = x_run__mutmut_88 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_89'] = x_run__mutmut_89 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_90'] = x_run__mutmut_90 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_91'] = x_run__mutmut_91 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_92'] = x_run__mutmut_92 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_93'] = x_run__mutmut_93 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_94'] = x_run__mutmut_94 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_95'] = x_run__mutmut_95 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_96'] = x_run__mutmut_96 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_97'] = x_run__mutmut_97 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_98'] = x_run__mutmut_98 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_99'] = x_run__mutmut_99 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_100'] = x_run__mutmut_100 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_101'] = x_run__mutmut_101 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_102'] = x_run__mutmut_102 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_103'] = x_run__mutmut_103 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_104'] = x_run__mutmut_104 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_105'] = x_run__mutmut_105 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_106'] = x_run__mutmut_106 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_107'] = x_run__mutmut_107 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_108'] = x_run__mutmut_108 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_109'] = x_run__mutmut_109 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_110'] = x_run__mutmut_110 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_111'] = x_run__mutmut_111 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_112'] = x_run__mutmut_112 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_113'] = x_run__mutmut_113 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_114'] = x_run__mutmut_114 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_115'] = x_run__mutmut_115 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_116'] = x_run__mutmut_116 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_117'] = x_run__mutmut_117 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_118'] = x_run__mutmut_118 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_119'] = x_run__mutmut_119 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_120'] = x_run__mutmut_120 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_121'] = x_run__mutmut_121 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_122'] = x_run__mutmut_122 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_123'] = x_run__mutmut_123 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_124'] = x_run__mutmut_124 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_125'] = x_run__mutmut_125 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_126'] = x_run__mutmut_126 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_127'] = x_run__mutmut_127 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_128'] = x_run__mutmut_128 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_129'] = x_run__mutmut_129 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_130'] = x_run__mutmut_130 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_131'] = x_run__mutmut_131 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_132'] = x_run__mutmut_132 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_133'] = x_run__mutmut_133 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_134'] = x_run__mutmut_134 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_135'] = x_run__mutmut_135 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_136'] = x_run__mutmut_136 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_137'] = x_run__mutmut_137 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_138'] = x_run__mutmut_138 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_139'] = x_run__mutmut_139 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_140'] = x_run__mutmut_140 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_141'] = x_run__mutmut_141 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_142'] = x_run__mutmut_142 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_143'] = x_run__mutmut_143 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_144'] = x_run__mutmut_144 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_145'] = x_run__mutmut_145 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_146'] = x_run__mutmut_146 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_147'] = x_run__mutmut_147 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_148'] = x_run__mutmut_148 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_149'] = x_run__mutmut_149 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_150'] = x_run__mutmut_150 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_151'] = x_run__mutmut_151 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_152'] = x_run__mutmut_152 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_153'] = x_run__mutmut_153 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_154'] = x_run__mutmut_154 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_155'] = x_run__mutmut_155 # type: ignore # mutmut generated
mutants_x_run__mutmut['x_run__mutmut_156'] = x_run__mutmut_156 # type: ignore # mutmut generated
mutants_x_main__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_main__mutmut)
def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument("--max-children", type=int, default=2)
    args = parser.parse_args(argv)
    report = run(args.root, max_children=args.max_children)
    print(json.dumps(report, sort_keys=True))
    return 0 if report["native_exit_code"] == 0 else 1


def x_main__mutmut_orig(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument("--max-children", type=int, default=2)
    args = parser.parse_args(argv)
    report = run(args.root, max_children=args.max_children)
    print(json.dumps(report, sort_keys=True))
    return 0 if report["native_exit_code"] == 0 else 1


def x_main__mutmut_1(argv: list[str] | None = None) -> int:
    parser = None
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument("--max-children", type=int, default=2)
    args = parser.parse_args(argv)
    report = run(args.root, max_children=args.max_children)
    print(json.dumps(report, sort_keys=True))
    return 0 if report["native_exit_code"] == 0 else 1


def x_main__mutmut_2(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=None)
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument("--max-children", type=int, default=2)
    args = parser.parse_args(argv)
    report = run(args.root, max_children=args.max_children)
    print(json.dumps(report, sort_keys=True))
    return 0 if report["native_exit_code"] == 0 else 1


def x_main__mutmut_3(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(None, type=Path, default=Path.cwd())
    parser.add_argument("--max-children", type=int, default=2)
    args = parser.parse_args(argv)
    report = run(args.root, max_children=args.max_children)
    print(json.dumps(report, sort_keys=True))
    return 0 if report["native_exit_code"] == 0 else 1


def x_main__mutmut_4(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=None, default=Path.cwd())
    parser.add_argument("--max-children", type=int, default=2)
    args = parser.parse_args(argv)
    report = run(args.root, max_children=args.max_children)
    print(json.dumps(report, sort_keys=True))
    return 0 if report["native_exit_code"] == 0 else 1


def x_main__mutmut_5(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=None)
    parser.add_argument("--max-children", type=int, default=2)
    args = parser.parse_args(argv)
    report = run(args.root, max_children=args.max_children)
    print(json.dumps(report, sort_keys=True))
    return 0 if report["native_exit_code"] == 0 else 1


def x_main__mutmut_6(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(type=Path, default=Path.cwd())
    parser.add_argument("--max-children", type=int, default=2)
    args = parser.parse_args(argv)
    report = run(args.root, max_children=args.max_children)
    print(json.dumps(report, sort_keys=True))
    return 0 if report["native_exit_code"] == 0 else 1


def x_main__mutmut_7(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", default=Path.cwd())
    parser.add_argument("--max-children", type=int, default=2)
    args = parser.parse_args(argv)
    report = run(args.root, max_children=args.max_children)
    print(json.dumps(report, sort_keys=True))
    return 0 if report["native_exit_code"] == 0 else 1


def x_main__mutmut_8(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, )
    parser.add_argument("--max-children", type=int, default=2)
    args = parser.parse_args(argv)
    report = run(args.root, max_children=args.max_children)
    print(json.dumps(report, sort_keys=True))
    return 0 if report["native_exit_code"] == 0 else 1


def x_main__mutmut_9(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("XX--rootXX", type=Path, default=Path.cwd())
    parser.add_argument("--max-children", type=int, default=2)
    args = parser.parse_args(argv)
    report = run(args.root, max_children=args.max_children)
    print(json.dumps(report, sort_keys=True))
    return 0 if report["native_exit_code"] == 0 else 1


def x_main__mutmut_10(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--ROOT", type=Path, default=Path.cwd())
    parser.add_argument("--max-children", type=int, default=2)
    args = parser.parse_args(argv)
    report = run(args.root, max_children=args.max_children)
    print(json.dumps(report, sort_keys=True))
    return 0 if report["native_exit_code"] == 0 else 1


def x_main__mutmut_11(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument(None, type=int, default=2)
    args = parser.parse_args(argv)
    report = run(args.root, max_children=args.max_children)
    print(json.dumps(report, sort_keys=True))
    return 0 if report["native_exit_code"] == 0 else 1


def x_main__mutmut_12(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument("--max-children", type=None, default=2)
    args = parser.parse_args(argv)
    report = run(args.root, max_children=args.max_children)
    print(json.dumps(report, sort_keys=True))
    return 0 if report["native_exit_code"] == 0 else 1


def x_main__mutmut_13(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument("--max-children", type=int, default=None)
    args = parser.parse_args(argv)
    report = run(args.root, max_children=args.max_children)
    print(json.dumps(report, sort_keys=True))
    return 0 if report["native_exit_code"] == 0 else 1


def x_main__mutmut_14(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument(type=int, default=2)
    args = parser.parse_args(argv)
    report = run(args.root, max_children=args.max_children)
    print(json.dumps(report, sort_keys=True))
    return 0 if report["native_exit_code"] == 0 else 1


def x_main__mutmut_15(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument("--max-children", default=2)
    args = parser.parse_args(argv)
    report = run(args.root, max_children=args.max_children)
    print(json.dumps(report, sort_keys=True))
    return 0 if report["native_exit_code"] == 0 else 1


def x_main__mutmut_16(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument("--max-children", type=int, )
    args = parser.parse_args(argv)
    report = run(args.root, max_children=args.max_children)
    print(json.dumps(report, sort_keys=True))
    return 0 if report["native_exit_code"] == 0 else 1


def x_main__mutmut_17(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument("XX--max-childrenXX", type=int, default=2)
    args = parser.parse_args(argv)
    report = run(args.root, max_children=args.max_children)
    print(json.dumps(report, sort_keys=True))
    return 0 if report["native_exit_code"] == 0 else 1


def x_main__mutmut_18(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument("--MAX-CHILDREN", type=int, default=2)
    args = parser.parse_args(argv)
    report = run(args.root, max_children=args.max_children)
    print(json.dumps(report, sort_keys=True))
    return 0 if report["native_exit_code"] == 0 else 1


def x_main__mutmut_19(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument("--max-children", type=int, default=3)
    args = parser.parse_args(argv)
    report = run(args.root, max_children=args.max_children)
    print(json.dumps(report, sort_keys=True))
    return 0 if report["native_exit_code"] == 0 else 1


def x_main__mutmut_20(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument("--max-children", type=int, default=2)
    args = None
    report = run(args.root, max_children=args.max_children)
    print(json.dumps(report, sort_keys=True))
    return 0 if report["native_exit_code"] == 0 else 1


def x_main__mutmut_21(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument("--max-children", type=int, default=2)
    args = parser.parse_args(None)
    report = run(args.root, max_children=args.max_children)
    print(json.dumps(report, sort_keys=True))
    return 0 if report["native_exit_code"] == 0 else 1


def x_main__mutmut_22(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument("--max-children", type=int, default=2)
    args = parser.parse_args(argv)
    report = None
    print(json.dumps(report, sort_keys=True))
    return 0 if report["native_exit_code"] == 0 else 1


def x_main__mutmut_23(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument("--max-children", type=int, default=2)
    args = parser.parse_args(argv)
    report = run(None, max_children=args.max_children)
    print(json.dumps(report, sort_keys=True))
    return 0 if report["native_exit_code"] == 0 else 1


def x_main__mutmut_24(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument("--max-children", type=int, default=2)
    args = parser.parse_args(argv)
    report = run(args.root, max_children=None)
    print(json.dumps(report, sort_keys=True))
    return 0 if report["native_exit_code"] == 0 else 1


def x_main__mutmut_25(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument("--max-children", type=int, default=2)
    args = parser.parse_args(argv)
    report = run(max_children=args.max_children)
    print(json.dumps(report, sort_keys=True))
    return 0 if report["native_exit_code"] == 0 else 1


def x_main__mutmut_26(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument("--max-children", type=int, default=2)
    args = parser.parse_args(argv)
    report = run(args.root, )
    print(json.dumps(report, sort_keys=True))
    return 0 if report["native_exit_code"] == 0 else 1


def x_main__mutmut_27(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument("--max-children", type=int, default=2)
    args = parser.parse_args(argv)
    report = run(args.root, max_children=args.max_children)
    print(None)
    return 0 if report["native_exit_code"] == 0 else 1


def x_main__mutmut_28(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument("--max-children", type=int, default=2)
    args = parser.parse_args(argv)
    report = run(args.root, max_children=args.max_children)
    print(json.dumps(None, sort_keys=True))
    return 0 if report["native_exit_code"] == 0 else 1


def x_main__mutmut_29(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument("--max-children", type=int, default=2)
    args = parser.parse_args(argv)
    report = run(args.root, max_children=args.max_children)
    print(json.dumps(report, sort_keys=None))
    return 0 if report["native_exit_code"] == 0 else 1


def x_main__mutmut_30(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument("--max-children", type=int, default=2)
    args = parser.parse_args(argv)
    report = run(args.root, max_children=args.max_children)
    print(json.dumps(sort_keys=True))
    return 0 if report["native_exit_code"] == 0 else 1


def x_main__mutmut_31(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument("--max-children", type=int, default=2)
    args = parser.parse_args(argv)
    report = run(args.root, max_children=args.max_children)
    print(json.dumps(report, ))
    return 0 if report["native_exit_code"] == 0 else 1


def x_main__mutmut_32(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument("--max-children", type=int, default=2)
    args = parser.parse_args(argv)
    report = run(args.root, max_children=args.max_children)
    print(json.dumps(report, sort_keys=False))
    return 0 if report["native_exit_code"] == 0 else 1


def x_main__mutmut_33(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument("--max-children", type=int, default=2)
    args = parser.parse_args(argv)
    report = run(args.root, max_children=args.max_children)
    print(json.dumps(report, sort_keys=True))
    return 0 if (report["native_exit_code"] == 0) and False else 1


def x_main__mutmut_34(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument("--max-children", type=int, default=2)
    args = parser.parse_args(argv)
    report = run(args.root, max_children=args.max_children)
    print(json.dumps(report, sort_keys=True))
    return 0 if (report["native_exit_code"] == 0) or True else 1


def x_main__mutmut_35(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument("--max-children", type=int, default=2)
    args = parser.parse_args(argv)
    report = run(args.root, max_children=args.max_children)
    print(json.dumps(report, sort_keys=True))
    return 1 if report["native_exit_code"] == 0 else 1


def x_main__mutmut_36(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument("--max-children", type=int, default=2)
    args = parser.parse_args(argv)
    report = run(args.root, max_children=args.max_children)
    print(json.dumps(report, sort_keys=True))
    return 0 if report["XXnative_exit_codeXX"] == 0 else 1


def x_main__mutmut_37(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument("--max-children", type=int, default=2)
    args = parser.parse_args(argv)
    report = run(args.root, max_children=args.max_children)
    print(json.dumps(report, sort_keys=True))
    return 0 if report["NATIVE_EXIT_CODE"] == 0 else 1


def x_main__mutmut_38(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument("--max-children", type=int, default=2)
    args = parser.parse_args(argv)
    report = run(args.root, max_children=args.max_children)
    print(json.dumps(report, sort_keys=True))
    return 0 if report["native_exit_code"] != 0 else 1


def x_main__mutmut_39(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument("--max-children", type=int, default=2)
    args = parser.parse_args(argv)
    report = run(args.root, max_children=args.max_children)
    print(json.dumps(report, sort_keys=True))
    return 0 if report["native_exit_code"] == 1 else 1


def x_main__mutmut_40(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument("--max-children", type=int, default=2)
    args = parser.parse_args(argv)
    report = run(args.root, max_children=args.max_children)
    print(json.dumps(report, sort_keys=True))
    return 0 if report["native_exit_code"] == 0 else 2

mutants_x_main__mutmut['_mutmut_orig'] = x_main__mutmut_orig # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_1'] = x_main__mutmut_1 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_2'] = x_main__mutmut_2 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_3'] = x_main__mutmut_3 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_4'] = x_main__mutmut_4 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_5'] = x_main__mutmut_5 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_6'] = x_main__mutmut_6 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_7'] = x_main__mutmut_7 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_8'] = x_main__mutmut_8 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_9'] = x_main__mutmut_9 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_10'] = x_main__mutmut_10 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_11'] = x_main__mutmut_11 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_12'] = x_main__mutmut_12 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_13'] = x_main__mutmut_13 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_14'] = x_main__mutmut_14 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_15'] = x_main__mutmut_15 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_16'] = x_main__mutmut_16 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_17'] = x_main__mutmut_17 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_18'] = x_main__mutmut_18 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_19'] = x_main__mutmut_19 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_20'] = x_main__mutmut_20 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_21'] = x_main__mutmut_21 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_22'] = x_main__mutmut_22 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_23'] = x_main__mutmut_23 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_24'] = x_main__mutmut_24 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_25'] = x_main__mutmut_25 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_26'] = x_main__mutmut_26 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_27'] = x_main__mutmut_27 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_28'] = x_main__mutmut_28 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_29'] = x_main__mutmut_29 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_30'] = x_main__mutmut_30 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_31'] = x_main__mutmut_31 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_32'] = x_main__mutmut_32 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_33'] = x_main__mutmut_33 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_34'] = x_main__mutmut_34 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_35'] = x_main__mutmut_35 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_36'] = x_main__mutmut_36 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_37'] = x_main__mutmut_37 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_38'] = x_main__mutmut_38 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_39'] = x_main__mutmut_39 # type: ignore # mutmut generated
mutants_x_main__mutmut['x_main__mutmut_40'] = x_main__mutmut_40 # type: ignore # mutmut generated


if __name__ == "__main__":
    raise SystemExit(main())
